import json
import sys
import urllib.error
import urllib.request


def fetch_json(url: str) -> dict:
    with urllib.request.urlopen(url, timeout=30) as response:
        return json.load(response)


rows = []
for paper_id in sys.argv[1:]:
    row = {"requested_id": paper_id}
    try:
        data = fetch_json(f"https://huggingface.co/api/papers/{paper_id}")
        row.update(
            {
                "id": data.get("id"),
                "title": data.get("title"),
                "publishedAt": data.get("publishedAt"),
                "summary": data.get("summary"),
                "projectPage": data.get("projectPage"),
                "githubRepo": data.get("githubRepo"),
                "authors": [author.get("name") for author in data.get("authors", [])],
            }
        )
    except urllib.error.HTTPError as error:
        row["metadata_error"] = error.code
    try:
        with urllib.request.urlopen(
            f"https://huggingface.co/papers/{paper_id}.md", timeout=30
        ) as response:
            row["markdown_status"] = response.status
            row["markdown_bytes"] = len(response.read())
    except urllib.error.HTTPError as error:
        row["markdown_error"] = error.code
    rows.append(row)

print(json.dumps(rows, ensure_ascii=True, indent=2))
