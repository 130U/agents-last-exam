# UniPat / UniFuncs interview research — primary-source findings

**Prepared:** 2026-08-04 (America/New_York)  
**Purpose:** Interview preparation under time constraint  
**Scope:** UniPat's official pages, company-controlled profiles, founder/cofounder profiles, official HongShan collaboration page, public GitHub organization, recruitment copy, and the supplied UniFuncs SID page.

## Bottom line

UniPat's deepest through-line is **producing learning experience for agents and models**: construct realistic environments and professional tasks, encode success in verifiable checks or expert rubrics, use that signal for evaluation and post-training, and release models/agents that demonstrate the loop. The public surface looks like many benchmarks and models; the underlying asset appears to be a repeatable **data + environment + evaluation + training engine**.

That interpretation is grounded most directly in cofounder Liang Chen's phrase “Agent Data and RL Environments,” the official mission around realistic scenarios, and the methods disclosed in ExpertEval, UniScientist, UniMath, SaaS-Bench, and the benchmark portfolio. It is still an **interpretation**, not a published corporate strategy slide.

## Evidence labels used here

- **Confirmed — official:** stated on UniPat, founder/cofounder, GitHub, or HongShan official pages.
- **Company claim:** a performance, scale, or funding statement made by UniPat or its recruitment copy but not independently validated here.
- **Inference:** a synthesis of several primary signals; useful for interview hypotheses, not a fact to assert.
- **Unknown:** not disclosed or not verified in the reviewed primary evidence.

## 1. What UniPat does

### The official thesis

**Confirmed — official:** UniPat says its mission is to accelerate AI toward real-world automation and argues that progress will come from training in realistic scenarios that yield generalizable, economically meaningful intelligence. [Homepage evidence](sources/01_unipat_homepage.md)

**Confirmed — founder:** Liang Chen says the long-run question is where AI will obtain the learning experiences for its next evolution, and identifies the startup's focus as “Agent Data and RL Environments.” [Founder evidence](sources/11_liang_chen_profile.md)

### The operating loop visible in its work

1. **Build realistic environments/tasks.** SaaS-Bench runs agents in 23 deployable SaaS systems; Terminal-X/RoadmapBench/EvoCode-Bench create executable coding environments; ClawBench uses live websites. [Benchmark evidence](sources/04_unipat_benchmarks.md) [SaaS-Bench evidence](sources/08_unipat_saas_bench.md)
2. **Define reliable success signals.** Monthly-SWEBench uses fresh verified software tasks; ExpertEval turns professional judgment into weighted, source-grounded rubrics; BabyVision isolates core visual primitives. [ExpertEval evidence](sources/06_unipat_experteval.md)
3. **Turn evaluation into training data.** ExpertEval explicitly calls expert rubrics training signal. UniScientist creates research-grade tasks and rubric supervision; UniMath supervises how proofs are critiqued and repaired. [UniScientist evidence](sources/07_unipat_uniscientist.md) [UniMath evidence](sources/18_unipat_unimath.md)
4. **Train or orchestrate systems.** Public outputs include UniScientist, UniMath, SWE-Vision, and EchoZ/Train-on-Future.
5. **Measure, publish, and iterate.** The company maintains leaderboards, open repositories, and a rapid release cadence. [Blog cadence](sources/03_unipat_blog_index.md) [GitHub evidence](sources/13_unipat_github_org.md)

### Public product/research map

| Layer | Public artifacts | What it suggests |
|---|---|---|
| Real environments | SaaS-Bench, ClawBench, Terminal-X, RoadmapBench, EvoCode-Bench | Long-horizon, stateful, executable experience generation |
| Evaluation | Monthly-SWEBench, BabyVision, ExpertEval, Echo leaderboard, Vibe-Coding Arena | Fresh tasks, fine-grained behavioral checks, expert judgment |
| Data/rubrics | ExpertEval, UniScientist corpus, UniMath proof-evolution trajectories | High-information supervision rather than generic volume |
| Models/agents | UniScientist, UniMath, SWE-Vision, EchoZ-1.0 | Demonstrations of post-training and agent workflows |
| Commercial-facing product | Echo prediction API/access funnel | Clearest public path from research system to external users |

## 2. Business model: what is known versus inferred

### What is actually confirmed

- **Echo controlled access:** UniPat invites users to request access by email. No public price or self-serve API is shown. [Echo access](sources/17_echo_access.md)
- **Collaboration/access motion:** ExpertEval and UniScientist invite collaboration and access requests through company email. [ExpertEval](sources/06_unipat_experteval.md)
- **Open-source distribution:** Ten public, non-archived repositories were returned by the GitHub organization on 2026-08-04. [GitHub organization](sources/13_unipat_github_org.md)
- **Model-vendor/ecosystem connection:** HongShan xbench and UniPat jointly released BabyVision with model-company and university researchers. [HongShan evidence](sources/10_hongshan_babyvision.md)
- **Recruitment claim:** HongShan/BOSS copy says UniPat works with leading model vendors and aims to close data/environment feedback loops. It also claims top-tier USD VC backing, without naming the investor or round. [Recruitment evidence](sources/16_hongshan_boss_job_copy.md)

### Most plausible commercial wedges — **inference**

1. **Enterprise/model-vendor evaluation and benchmark construction:** paid design of realistic, fresh, verifiable environments and tasks.
2. **Training-data and expert-rubric production:** acquiring scarce expert judgment and converting it into model-ready supervision.
3. **Post-training/RL environment partnerships:** supplying the feedback loop between deployed agents and model builders.
4. **Vertical APIs/products:** Echo prediction API is the clearest example; finance, politics, crypto, sports, and esports are named domains.
5. **Agent-native workflow redesign:** SaaS-Bench's conclusion points toward software and workflow infrastructure designed for agents rather than humans.

### What remains **unknown**

- Revenue, revenue mix, burn, runway, cash-flow status
- Paying customers and customer concentration
- Contracted model-vendor partners
- Pricing, gross margin, API usage, retention, or SLA
- Whether benchmarks are products, loss-leader research, recruiting/brand assets, or internal data infrastructure
- Ownership and licensing of expert-authored data
- Which product is the near-term commercial priority

**Interview-safe formulation:** “Publicly, the clearest commercial surface is Echo access; the broader monetization of benchmark, expert-data, and environment capabilities is not disclosed.”

## 3. Stage, team, funding, and corporate identity

### Stage

- **Confirmed — company-controlled LinkedIn:** founded in 2025; 11–50 employees; Research Services; eight associated employees displayed when checked. This is self-entered profile data, not a filing. [LinkedIn evidence](sources/09_unipat_linkedin.md)
- **Confirmed — founder/cofounder profiles:** Liang Chen lists cofounder/CTO from December 2025 and a startup start in August 2025; Wendong Xu lists cofounder/research scientist from October 2025. [Liang Chen](sources/11_liang_chen_profile.md) [Wendong Xu](sources/12_wendong_xu_profile.md)
- **Confirmed — execution cadence:** nine major public launches from January through July 2026 and ten public GitHub repositories by August. [Blog index](sources/03_unipat_blog_index.md) [GitHub](sources/13_unipat_github_org.md)
- **Inference:** this is an early, rapidly expanding research/product company still building both technical systems and corporate/commercial functions.

### Team

- **Liang Chen:** self-identified cofounder and CTO; final-year PKU computational linguistics PhD; prior Moonshot multimodal, Qwen, Tencent NLP, and MSRA experience.
- **Wendong Xu:** self-identified cofounder and research scientist; HKU PhD candidate focused on code agents; former Baidu senior software engineer.
- **Kuan Li:** repeatedly appears as final contributor/corresponding contact across official UniPat projects, but no verified public title was found in this pass.
- **Broader contributors:** official launch pages repeatedly name Baixuan Li, Jialong Wu, Xuanzhong Chen, Wendong Xu, Liang Chen, Kuan Li and project-specific collaborators across PKU, HKU, model companies, and xbench.
- **LinkedIn-visible names:** Le Kang, Stanley Wu, Yixin Ren, and Suning Chen were among visible associated employees. Exact current titles were not reliably exposed on the company page.

### Funding

- **Confirmed:** a HongShan official article proves an xbench/BabyVision collaboration.
- **Company recruiting claim:** BOSS/HongShan copy says “获顶级美元 VC 投资” and labels UniPat a member company.
- **Not verified:** investor name, whether HongShan itself invested, round, amount, date, valuation, lead/co-investors, and ownership.

**Do not say:** “HongShan/Sequoia definitely invested in UniPat.”  
**Safe version:** “HongShan publicly collaborates with UniPat through xbench, and recruitment copy claims top-tier USD VC backing; financing details are not public in the reviewed sources.”

### Legal/corporate identity

- UniPat's official site does not disclose a registered company name, registration number, registered address, headquarters, ICP record, or jurisdiction.
- The LinkedIn “Partnership” category is not a legal form.
- `优函数智能科技（深圳）有限责任公司` is the legal entity disclosed by **UniFuncs**, the unrelated host of the supplied search page—not UniPat. [UniFuncs evidence](sources/14_unifuncs_homepage.md)

## 4. Likely hiring needs

### Confirmed current role families

The official Join Us page lists research scientists/interns, agent systems engineering, infrastructure, expert community, design technology, marketing/PR, legal, and tax. [Join Us](sources/02_unipat_join_us.md)

### What those roles imply — **inference**

1. **Research and agent systems:** convert new task domains into datasets, environments, evaluation, and post-training experiments.
2. **Infrastructure:** operate expensive, stateful, reproducible benchmark and RL-environment pipelines.
3. **Expert supply/data operations:** recruit and manage credentialed experts, design workflows, enforce source/rubric quality, and increase throughput.
4. **Productization/design:** turn research systems and APIs into usable products, demos, and customer workflows.
5. **Go-to-market/ecosystem:** model-vendor partnerships, domain partners, launch narrative, community, and overseas activity.
6. **Corporate buildout:** legal and tax openings indicate company-formation, contracting, IP/data, and cross-border work are material enough to staff.

### Why an “open conversation, no fixed role” is plausible

The public hiring map has a large gap between deep research teams and corporate/commercial execution. A high-agency generalist could plausibly be assessed for founder's-office/special-projects, research-to-product strategy, partnerships, expert operations, or a hybrid role. This is an inference; the interview must test whether the role has real ownership or is undefined support work.

## 5. Interview-oriented hypotheses to test

### Hypothesis A — the durable moat is the experience-production engine

Ask: “Across ExpertEval, SaaS-Bench, UniScientist and UniMath, is the reusable core asset the model, or the machinery for generating tasks, environments, rubrics and feedback?”

### Hypothesis B — the company has two clocks

- Research clock: publish benchmarks/models fast, build credibility and recruiting leverage.
- Commercial clock: convert environment/data/evaluation capability into model-vendor or enterprise contracts.

Ask which clock is the priority over the next 6–12 months and which leader owns it.

### Hypothesis C — the unspecified role could be either high leverage or low-definition

Distinguish them with concrete questions:

1. “What outcome would I own in the first 90 days?”
2. “Which decisions would I make versus prepare for the CEO?”
3. “What recurring process or metric would become mine?”
4. “Who are my internal customers, and what work would I stop the CEO from doing?”
5. “What would make you say after six months that this hire materially changed the company—not only saved time?”

### Hypothesis D — monetization is less public than technical progress

Ask directly but neutrally:

- “Which offering has paying external users today: prediction API, evaluation, data, environments, or custom research?”
- “Who is the economic buyer—model labs, enterprises, investors, or developers?”
- “What is the repeatable unit of delivery, rather than a one-off project?”
- “Where does proprietary data accumulate when a customer uses the system?”

## 6. The supplied SID page: exact interpretation

The supplied URL is a saved **UniFuncs U深搜** session, not a UniPat page. Its embedded prompt asks the model to search `unipat.ai` and explain the company. Metadata dates it to June 8–12, 2026. [SID audit](sources/15_unifuncs_supplied_sid.md)

It is useful as a June-era project inventory but unsafe as evidence because it:

- mixes official, secondary, and inferred claims;
- asserts HongShan investment in some passages, then later calls financing unverified;
- is stale relative to July launches and the current ten-repository GitHub organization;
- turns plausible commercial paths into statements without primary proof.

Use it to generate questions, not to state facts.

## 7. Adversarial read: what could be less attractive than the public story

- A broad portfolio can indicate a powerful platform—or a still-unfocused company publishing across too many fronts.
- Strong benchmark/model launches can create attention without proving a repeatable revenue engine.
- “No fixed role” can mean unusual autonomy—or that the organization has not defined decision rights, mentorship, output, and career path.
- Expert-data work can be strategically valuable but operationally heavy; much of the real job may be sourcing, QA, coordination, and delivery rather than glamorous research.
- A founder's-office role only becomes high-learning if it owns a decision loop, product/workstream, or measurable operating system. Proximity to the CEO alone is not sufficient.

## 8. Concise interview-ready company description

> UniPat is an early-stage AI company building the learning experiences that let agents become useful in real work. It creates realistic task environments and expert-grounded evaluation signals, turns them into training data, and uses that loop to build and assess models across coding, SaaS work, scientific research, mathematics, vision, and prediction. Publicly, Echo is the clearest commercial-facing product; the wider business model and financing details are not disclosed.

## Source index

1. [Official homepage](sources/01_unipat_homepage.md)
2. [Official recruiting page](sources/02_unipat_join_us.md)
3. [Official blog cadence](sources/03_unipat_blog_index.md)
4. [Official benchmark portfolio](sources/04_unipat_benchmarks.md)
5. [Echo](sources/05_unipat_echo.md)
6. [ExpertEval](sources/06_unipat_experteval.md)
7. [UniScientist](sources/07_unipat_uniscientist.md)
8. [SaaS-Bench](sources/08_unipat_saas_bench.md)
9. [LinkedIn profile](sources/09_unipat_linkedin.md)
10. [HongShan/xbench collaboration](sources/10_hongshan_babyvision.md)
11. [Liang Chen profile](sources/11_liang_chen_profile.md)
12. [Wendong Xu profile](sources/12_wendong_xu_profile.md)
13. [GitHub organization](sources/13_unipat_github_org.md)
14. [UniFuncs identity](sources/14_unifuncs_homepage.md)
15. [Supplied SID audit](sources/15_unifuncs_supplied_sid.md)
16. [HongShan/BOSS recruitment copy](sources/16_hongshan_boss_job_copy.md)
17. [Echo access page](sources/17_echo_access.md)
18. [UniMath](sources/18_unipat_unimath.md)

