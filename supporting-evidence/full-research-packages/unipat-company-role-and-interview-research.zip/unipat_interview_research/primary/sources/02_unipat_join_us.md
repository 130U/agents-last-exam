# Source 02 — UniPat “Join Us” page

- URL: https://unipat.ai/joinus
- Source type: Official company recruiting page
- Page date: No publication date shown; live on 2026-08-04
- Accessed: 2026-08-04
- Evidence score: Credibility 5/5; Recency 5/5; Hiring-signal bias 2/5

## Exact excerpt

> “Shape what comes next with UniPat AI.”

## Current role families

- Research Scientist
- Research Intern
- Agent Systems Engineer
- Infra Engineer
- Expert Community Lead
- Design Technologist
- Marketing / PR Manager
- Legal Counsel
- Senior Tax Specialist

Application address: `hr-recruit@unipat.ai`.

## Interview meaning

- Hiring spans research, agent engineering, infrastructure, expert operations, design, communications, legal, and tax—not only model research.
- “Expert Community Lead” aligns closely with ExpertEval and UniScientist's dependence on credentialed experts and rubric/data production.
- Legal and tax hiring suggests corporate/commercial setup work is active, but it does not prove a particular jurisdiction or transaction.

## Limits

- No job descriptions, seniority, location, compensation, reporting lines, or fixed “CEO office” role are disclosed.

