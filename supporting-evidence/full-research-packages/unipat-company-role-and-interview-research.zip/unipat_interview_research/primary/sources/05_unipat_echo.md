# Source 05 — Echo: general AI prediction

- URL: https://unipat.ai/blog/Echo
- Source type: Official company product/research launch
- Published: 2026-03-27
- Accessed: 2026-08-04
- Evidence score: Credibility 5/5 for product description; Recency 5/5; Performance-claim bias 3/5

## Exact excerpt

> “We are building an AI-native prediction API around EchoZ-1.0.”

## Claims supported

- Echo is presented as a full-stack prediction intelligence system.
- Its three layers are a dynamic evaluation engine, a Train-on-Future post-training pipeline, and an AI-native prediction API.
- The API is designed to return probabilities, attributed evidence, counterfactual fragility, monitoring recommendations, and a structured prediction record.
- Named public domains include finance, politics, crypto, sports, and esports.
- UniPat names Zhengwei Tao, Rui Min, Hongfeng He, Jialong Wu, Baixuan Li, Liang Chen, Wentao Zhang, and Kuan Li as contributors.

## Commercial signal

- Echo is the clearest public product wedge: an API with an access funnel, framed for customer/enterprise use.
- The public site does not show price, SLA, customer logos, contracts, usage volume, or recurring revenue.

## Limits

- Leaderboard and “outperforms market” claims are UniPat's own evaluation claims and should be framed as such in the interview.

