# Source 10 — HongShan/xbench collaboration announcement

- URL: https://www.hongshan.com/article/多模态大模型输给三岁宝宝？xbench-x-unipat联合发布新评测/
- Source type: Official HongShan (formerly Sequoia China) publication
- Published: 2026-01-12
- Accessed: 2026-08-04
- Evidence score: Credibility 5/5; Recency 5/5; Partner-publicity bias 3/5

## Exact excerpt

> “红杉中国xbench携手UniPat AI团队”

## Claims supported

- HongShan's xbench and UniPat jointly launched BabyVision with researchers from model companies and universities.
- The collaboration is substantive and public, not merely a referral relationship.
- HongShan frames BabyVision as part of xbench's AGI Tracking track.

## Critical boundary

- This page confirms product/research collaboration.
- It does **not** state that HongShan invested in UniPat, name an investment vehicle, or disclose a financing round, amount, ownership, or valuation.
