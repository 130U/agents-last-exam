# Source 12 — Wendong Xu personal profile

- URL: https://vincentxwd.github.io/
- Source type: First-person cofounder/researcher profile
- Page date: Current profile; role from 2025-10
- Accessed: 2026-08-04
- Evidence score: Credibility 5/5 for self-identity; Recency 5/5; Self-report bias 3/5

## Exact excerpt

> “Co-Founder and Research Scientist at UniPat AI”

## Claims supported

- Wendong Xu identifies himself as a UniPat cofounder and research scientist since October 2025.
- He is an HKU EEE PhD candidate whose stated interests include code agents and the full lifetime of agents.
- He previously worked as a senior software engineer at Baidu on search-engine evolution.

## Interview meaning

- Public evidence confirms at least two cofounders: Liang Chen and Wendong Xu.
- The founding team combines multimodal/model work, coding agents, search, engineering, and academic research.

## Limits

- Public sources reviewed do not establish the full founder list, CEO identity, ownership, or reporting lines.

