# Source 14 — UniFuncs official homepage

- URL: https://www.unifuncs.com/
- Source type: Official UniFuncs company/product page
- Page date: Copyright 2025; live on 2026-08-04
- Accessed: 2026-08-04
- Evidence score: Credibility 5/5 for UniFuncs identity; Recency 5/5; Marketing bias 3/5

## Exact excerpt

> “基于 UniFuncs 最先进 S3 高速深搜模型的深度搜索产品”

## Claims supported

- `s.unifuncs.com` is UniFuncs' U深搜 product, not a UniPat property.
- UniFuncs identifies its legal company as `优函数智能科技（深圳）有限责任公司`.
- Disclosed address: 深圳市深汕特别合作区鲘门镇通港路南小区五街18号.
- Disclosed records: 粤公网安备44030002007262号 and 粤ICP备2025383270号-1.

## Interview meaning

- The user-supplied `sid` URL is a shared deep-search result hosted by a separate Shenzhen company.
- It should be treated as a secondary research artifact, not as an official UniPat statement.
