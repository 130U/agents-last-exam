# Source 16 — HongShan/BOSS recruitment copy for UniPat

- URL: https://www.zhipin.com/zhaopin/704db0bedea9b7ff0XNz0920/
- Additional indexed listing: https://www.zhipin.com/zhaopin/26025687d331fb5903Nz09W7EQ~~/
- Source type: Recruitment-platform listing under HongShan; company-provided copy, not a corporate filing
- Indexed: 2026-05 to 2026-07; accessed 2026-08-04
- Evidence score: Credibility 3/5; Recency 5/5; Recruiting bias 4/5

## Exact excerpt

> “获顶级美元 VC 投资”

## Claims/signals in indexed copy

- A Researcher Intern listing says UniPat was formed by researchers from leading model companies and works on flexible, adaptive, continuously evolving AI via reinforcement learning.
- The copy frames the operating thesis as closing the data/environment feedback loop between model vendors and downstream agent applications.
- Indexed roles included Researcher Intern and AI full-stack engineer/intern; Beijing locations appeared in the results.
- The listing calls UniPat a HongShan member company and claims top-tier USD VC backing.

## Critical boundary

- The copy does not name the investor, round, amount, date, ownership, or valuation.
- BOSS blocked the detailed pages behind a security screen, so only indexed recruitment text was verifiable.
- Treat the funding language as an employer claim, not independently verified financing data.

