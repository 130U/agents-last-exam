# Source 13 — UniPat-AI GitHub organization

- URL: https://github.com/UniPat-AI
- Source type: Official public code organization; checked through the connected GitHub API
- Observed: 2026-08-04
- Evidence score: Credibility 5/5; Recency 5/5; Repository-description bias 2/5

## Exact API observation

> Owner type: “Organization”; visibility: “public.”

## Public repositories returned

1. BabyVision
2. SWE-Vision
3. UniScientist
4. SaaS-Bench
5. EvoCodeBench
6. RoadmapBench
7. harbor_multiturn
8. harbor
9. unimath
10. Terminal-X

All were public and non-archived when checked. Most defaulted to `main`; `harbor_multiturn` defaulted to `multi_turn_support`.

## Interview meaning

- The code footprint corroborates an open-source-heavy research and infrastructure strategy.
- The portfolio covers data/benchmarks, agent environments, model releases, and evaluation harnesses.

## Limits

- Repository existence does not show production usage, customer adoption, revenue, or maintenance quality.
- The supplied UniFuncs report's “9 repositories” was already stale by 2026-08-04.

