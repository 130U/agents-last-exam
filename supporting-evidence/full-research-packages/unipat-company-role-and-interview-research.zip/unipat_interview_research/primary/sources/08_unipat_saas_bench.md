# Source 08 — SaaS-Bench

- URL: https://unipat.ai/blog/SaaS-Bench
- Source type: Official company benchmark launch
- Published: 2026-05-25
- Accessed: 2026-08-04
- Evidence score: Credibility 5/5 for benchmark design; Recency 5/5; Benchmark-owner bias 3/5

## Exact excerpt

> “Can agents move from browsing pages to finishing professional work?”

## Claims supported

- SaaS-Bench uses 23 real, containerized SaaS systems across six professional domains and 106 workflows.
- Tasks require persistent state, cross-application coordination, domain constraints, and verifiable artifacts.
- The company reports that only 45% of candidate tasks survive its construction and QA process.
- UniPat's conclusion is broader than agent evaluation: human-centric SaaS may need to be redesigned for agent-native use.

## Interview meaning

- This is close to the firm's stated mission: defining realistic work environments, generating measurable agent experience, and finding capability bottlenecks with economic relevance.
- It creates potential services around benchmark construction, agent evaluation, environment engineering, and workflow redesign.

## Limits

- No public evidence shows which of these possibilities is currently monetized.

