# Source 06 — ExpertEval

- URL: https://unipat.ai/blog/ExpertEval
- Source type: Official company data/evaluation launch
- Published: 2026-05-06
- Accessed: 2026-08-04
- Evidence score: Credibility 5/5 for disclosed method; Recency 5/5; Performance-claim bias 3/5

## Exact excerpt

> “Expert Signal as Training Data”

## Claims supported

- ExpertEval contains 3,213 expert-authored cases across medicine, finance, and law, with 207 scenarios and an average 21.83 rubrics per case.
- UniPat says every case is authored by credentialed practitioners and knowledge-dependent rubric criteria are linked to authoritative primary sources.
- The company explicitly treats expert rubrics as both evaluation infrastructure and model-training signal.
- The official page says collaboration/access requests should go to `contact@unipat.ai`.

## Interview meaning

- A core capability is not simply “benchmark publishing”; it is sourcing scarce expert judgment, converting it into verifiable rubrics, and turning those rubrics into training data.
- This explains the “Expert Community Lead” opening and creates non-technical needs in expert acquisition, workflow design, QA, partnerships, and domain-market selection.

## Limits

- No expert compensation model, data-licensing terms, customer list, access terms, or pricing is public.

