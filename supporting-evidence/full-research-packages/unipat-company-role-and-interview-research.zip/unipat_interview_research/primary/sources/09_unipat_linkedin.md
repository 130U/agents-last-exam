# Source 09 — UniPat LinkedIn company profile

- URL: https://www.linkedin.com/company/unipat
- Source type: Company-controlled social profile
- Page date: Live on 2026-08-04
- Accessed: 2026-08-04
- Evidence score: Credibility 4/5; Recency 5/5; Self-profile bias 3/5

## Exact excerpt

> “Company size 11-50 employees”

## Claims supported

- The profile labels UniPat as Research Services, founded in 2025, type “Partnership,” with 11–50 employees.
- LinkedIn displayed eight associated employees when checked; visible names included Le Kang, Stanley Wu, Yixin Ren, and Suning Chen.
- Company posts market Echo as a prediction API and said it was onboarding an initial cohort.

## Limits

- LinkedIn fields are self-entered and are not legal registration records.
- “Partnership” is a LinkedIn category, not proof of legal form.
- The employee count is a platform estimate and may not include contractors, interns, or stealth staff.

