# Source 18 — UniMath

- URL: https://unipat.ai/blog/UniMath
- Source type: Official company model/data launch
- Published: 2026-07-13
- Accessed: 2026-08-04
- Evidence score: Credibility 5/5 for disclosed approach; Recency 5/5; Performance-claim bias 3/5

## Exact excerpt

> “teach models to understand and improve their own reasoning process.”

## Claims supported

- UniMath-35B-A3B is an open-source math model post-trained on proof-evolution data.
- Its training trajectories expose draft, critique, obstruction diagnosis, repair, alternative exploration, and final synthesis.
- At inference time it uses a learned proof-editing loop rather than blind repeated sampling.

## Interview meaning

- UniMath reinforces the same company-level architecture visible in ExpertEval and UniScientist: design high-information data about *how work improves*, train on it, and evaluate the resulting behavior.
- The reusable asset may be the data/evaluation production engine as much as any one named model.

## Limits

- Performance results are company-reported; commercial availability is not stated.

