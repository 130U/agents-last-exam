# Source 15 — Supplied UniFuncs/U深搜 SID report

- URL: https://s.unifuncs.com/?sid=f7377937-fcb2-4665-9c46-7c9c6d4bb60a
- Source type: Shareable AI-generated search session; **not a UniPat primary source**
- Published metadata: 2026-06-08 13:03:39 +08:00
- Modified metadata: 2026-06-12 15:43:21 +08:00
- Directly retrieved: 2026-08-04
- Evidence score: Credibility 2/5; Recency 3/5; Synthesis/hallucination risk 4/5

## What the page is

- HTML title: `UniPat AI 是做什么的？ - U深搜`.
- Embedded user prompt: `unipat.ai 搜索一下这个公司 告诉我他们是做什么的`.
- The UUID `sid` selects a saved/shareable U深搜 conversation.
- The page contains the model's planning trace, searches, provisional notes, and multiple generated summaries—not a UniPat-authored company profile.

## Exact excerpt

> “具体融资轮次与金额（Crunchbase访问超时，未获取到）”

## Reliability audit

- It usefully inventories projects known by June 2026, but it is stale relative to UniPat's July launches and the current ten-repository GitHub footprint.
- It internally oscillates between asserting “红杉中国” as an investor and later marking financing as unverified/undisclosed.
- The official HongShan page reviewed only proves a BabyVision/xbench collaboration; it does not prove investment.
- It assigns roles and commercial models from mixed secondary sources without consistently preserving source boundaries.

## How to use in the interview

- Use it as a lead list and vocabulary primer.
- Do not cite its funding, cap-table, customer, or commercial-model assertions as fact.
- Prefer UniPat, founder, GitHub, and HongShan primary sources for every material claim.
