# Source 11 — Liang Chen personal profile

- URL: https://chenllliang.github.io/
- Source type: First-person founder profile
- Page date: Current profile; entries through 2026
- Accessed: 2026-08-04
- Evidence score: Credibility 5/5 for self-identity; Recency 5/5; Self-report bias 3/5

## Exact excerpt

> “where will AI obtain the learning experiences required for its next stage of evolution?”

## Claims supported

- Liang Chen identifies himself as UniPat cofounder and CTO, from 2025-12 to present.
- He is a final-year PhD candidate at Peking University's Institute of Computational Linguistics.
- His dated note for 2025-08-28 says he started an AI company focused on “Agent Data and RL Environments.”
- Prior disclosed experience includes Moonshot AI multimodal, Alibaba Qwen, Tencent NLP, and Microsoft Research Asia.

## Interview meaning

- “Agent Data and RL Environments” is the most concise founder-level description of the underlying company thesis.
- Public benchmarks, expert rubrics, realistic SaaS/terminal environments, and post-trained models can be read as parts of one experience-generation and learning loop.

## Limits

- This profile does not name the legal entity, cap table, funding, revenue, customers, or Kuan Li's role.

