# Source 04 — UniPat benchmark portfolio

- URL: https://unipat.ai/benchmarks
- Source type: Official company product/benchmark page
- Page date: Live portfolio on 2026-08-04
- Accessed: 2026-08-04
- Evidence score: Credibility 5/5; Recency 5/5; Benchmark-owner bias 3/5

## Exact excerpt

> “Define the Frontier and Track the Acceleration.”

## Portfolio shown

- Monthly-SWEBench — continuously refreshed real-world software-engineering tasks
- SaaS-Bench — 23 deployable SaaS systems, 106 tasks, 3,971 checkpoints, six professional domains
- RoadmapBench — 115 version-upgrade tasks from 17 repositories and five languages
- EvoCode-Bench — 26 multi-turn coding tasks, 227 evaluated rounds
- ClawBench — live-web browser-agent tasks
- Echo Leaderboard — prediction intelligence
- BabyVision — visual reasoning

## Interview meaning

- Evaluation infrastructure is not one isolated project; it is a repeatable product/research capability across coding, browser use, SaaS workflows, prediction, and vision.
- The emphasis is on fresh, executable, stateful, verifiable tasks rather than static question-answer benchmarks.

## Limits

- Public pages do not disclose which benchmarks are paid products, model-vendor contracts, research collaborations, or internal infrastructure.

