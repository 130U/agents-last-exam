# Source 07 — UniScientist

- URL: https://unipat.ai/blog/UniScientist
- Source type: Official company model/research launch
- Published: 2026-03-04
- Accessed: 2026-08-04
- Evidence score: Credibility 5/5 for architecture/data disclosure; Recency 5/5; Performance-claim bias 3/5

## Exact excerpt

> “human experts act primarily as high-precision reviewers”

## Claims supported

- UniScientist is a 30B-A3B scientific-research model built with research-grade tasks and structured rubric supervision.
- The disclosed dataset has 4,700+ research-grade instances across 50+ disciplines, with 20+ checks per task and 1–2 hours average expert handling time.
- UniPat's production loop combines broad LLM synthesis with expert review for solvability, non-triviality, and research value.
- Named contributors include Baixuan Li, Jialong Wu, Yida Zhao, Wendong Xu, Xuanzhong Chen, Huifeng Yin, Liang Chen, Wentao Zhang, and Kuan Li.

## Interview meaning

- The operating problem is a complex data supply chain: task discovery, expert recruitment, rubric construction, QA, agent/tool orchestration, model training, evaluation, and publication.
- A generalist can add value by improving throughput and quality across that chain rather than only writing research summaries.

## Limits

- The page does not disclose who paid for the data, whether it is licensed, or whether the model is offered commercially.
