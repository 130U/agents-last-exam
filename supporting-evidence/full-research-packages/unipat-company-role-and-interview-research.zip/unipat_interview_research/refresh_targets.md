# Refresh targets

- Unipat/UniFuncs legal entity, founders, and current leadership.
- Current product positioning, pricing, and public availability.
- Funding round, investor, and team-size changes.
- Active roles and any change in role scope after the interview.
- Evidence of paid use, retention, or customer outcomes.
- The proposed reporting line, 30/60/90-day charter, decision rights, and success metrics.
