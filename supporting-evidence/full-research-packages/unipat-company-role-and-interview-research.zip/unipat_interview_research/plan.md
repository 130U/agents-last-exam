# Unipat interview research plan

## Decision and report genre

This is a time-boxed decision brief for an interview on 2026-08-04. It must help the candidate (1) present a coherent, evidence-backed identity, (2) discover what opportunity actually exists, and (3) decide whether that opportunity is superior to or meaningfully different from the accepted Manifold offer.

## Falsifiable hypotheses

1. The role-agnostic interview reflects deliberate scouting for a high-agency generalist; it is not proof that the company has a defined, funded role.
2. Unipat's visible needs favor an AI-native product/operator who can turn ambiguous business problems into shipped systems, rather than a conventional strategy-only profile.
3. The candidate's strongest credible positioning is an unusually fast cross-domain problem solver with AI leverage and public research artifacts; describing himself simply as a "CEO assistant" would undersell him and create scope risk.
4. The Manifold offer is useful evidence of market validation and a real BATNA, but leading with it as leverage would weaken commitment signaling.

## Sourcing strategy

- Primary: Unipat and UniFuncs pages, official team/company profiles, official job posts and corporate announcements.
- Candidate: submitted resume first, master resume second, then public GitHub artifacts for corroboration.
- Independent: reputable databases, news, job boards, public profiles, user/community traces, and corporate records.
- Opposition: searches for product complaints, inactive pages, inconsistent entity descriptions, missing traction, vague roles, and role-scope failure modes.

## Evidence rules

- Every consequential statement is labeled as verified fact, official self-report, third-party claim, inference, or unknown.
- Major theses target three independent source types. When the short time box prevents triangulation, the report says "insufficient public evidence."
- Every web source is saved separately with URL, access date, source type, relevant excerpt, and credibility/recency/bias notes.

## Risk register

- Brand/entity ambiguity between Unipat and UniFuncs.
- Product pages may be personalized, dynamic, gated, or generated from the supplied SID.
- Job-board postings can be stale, duplicated, or written aspirationally.
- Private-company traction and financing claims may be unverifiable.
- Candidate's world-model explanation may be technically overcompressed or use incorrect company/product names.
- A role without a charter can become unbounded execution work with low decision exposure.

## Stop criteria

- The two supplied URLs are inspected.
- Both resumes are fully extracted and visually reviewed.
- Official company/product claims and at least two independent source types are collected, or the absence is documented.
- Candidate claims are mapped to evidence and tightened into a 60-90 second opening.
- The brief includes a role-design proposal, high-value questions, red flags, and a decision rule.

## Changelog

- 2026-08-04: Initial time-boxed plan created before the interview.

