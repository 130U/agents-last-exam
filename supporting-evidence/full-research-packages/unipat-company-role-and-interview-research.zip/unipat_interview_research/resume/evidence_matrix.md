# 个人定位证据矩阵

## 总体判断

| 定位 | 证据强度 | 面试官可见度 | 建议 |
|---|---:|---:|---|
| Fast learner | 4.5 / 5 | 3.5 / 5 | 成立，但必须用具体陌生领域、时间、产出和个人判断来证明 |
| AI-native | 5 / 5 | 5 / 5 | 最强标签；不要落成工具清单，要讲工作流设计、人机边界和质量控制 |
| 复合 / 跨职能 | 4.5 / 5 | 3.5 / 5 | 成立；用“复杂决策系统”串联 AI、数据、产品、投资和研究，避免像经历堆叠 |
| 沟通能力 | 4 / 5 | 3 / 5 | 有案例，提交版证据偏隐含；用专家校准、跨职能对齐或双语 briefing 讲行为 |
| Team player / 好相处 | 3 / 5 | 2.5 / 5 | 不能靠形容词自证；换成协作动作、冲突处理和团队结果 |
| 编码能力 | 3.5 / 5 | 4 / 5 | 足以说能写数据 pipeline 和可运行原型；不宜包装成资深软件工程师 |

## 逐项证据与建议话术

| 定位 | 提交版直接证据 | Master Resume / 作品补强 | 最稳健的一句话 | 风险点 |
|---|---|---|---|---|
| Fast learner | Jiritsu 从 token 市场质量进入 issuer / counterparty risk；Micro1 把陌生业务争议快速结构化；Duke 数学与风险工程底座 | 世界模型研究约 22.04 小时收口，141 个来源、111 条原子主张；早期投资、资本市场、市场研究跨度大 | “我不是只会快速吸收信息，而是能在陌生领域迅速建立分类、证据门和决策标准。” | 简历没有写研究速度；“一天读完几十篇论文”无法由现有公开证据直接证明 |
| AI-native | Micro1 的 Agent 可执行 spec、RLHF / Rubric；Context Agent 独立完成需求、原型和 39/0 测试；比较多种 agentic coding workflow | 研究仓库保存 Agent 编排、Source Card、Atomic Claim、Red Team、Content Lock 与 provenance | “我把 AI 编进可检查、可暂停、可纠错的工作流，而不是把问题交给模型等答案。” | 只报 Agent 数量或工具名会像堆 buzzword；必须说明人负责什么、AI 负责什么 |
| 复合背景 | 数学 / 风险工程 + AI 评测 + 广告策略 + 数据工程 + tokenization + 个人产品 | SAIF 投资、JLL 资本市场、Euromonitor 市场进入、Hubble 董事会汇报 | “我的共同主线是把高不确定问题变成业务可执行的决策系统。” | “咨询背景”在提交版不可见，且并非传统咨询公司主线；要说“咨询式项目交付” |
| 沟通 | Micro1 组织 / 校准外部专家、结构化辩论和专家访谈；AI at Duke workshop | SAIF partner memo；JLL 双语 leadership / client briefing；Euromonitor 全球 stakeholder calls；Hubble board presentation | “我擅长把技术、风险和业务语言翻译到同一套决策标准里。” | “public speaking 很强”太抽象；应准备一次对象、冲突、表达和结果完整的案例 |
| Teamwork | 外部专家校准；Jiritsu 支持 BD、风控和治理评审；AI at Duke 社群 workshop | 与 SAIF VP / team 共建 longlist；跨国 stakeholder 协同；客户经理 briefings | “我通常先把分歧变成显性标准，再让不同角色围绕同一份证据做决定。” | “非常好相处”不可验证；若被问冲突，需要真实例子，不要只说 low ego |
| Coding / building | Python / SQL / Prefect / DuckDB / Parquet / LightGBM；mock-first 原型；39 个测试 | 50,000 SKU ETL、dashboard、研究仓库审计脚本和结构化生成流程 | “我可以独立搭数据管线和可运行原型，并能判断何时需要专业工程团队接手。” | 不要把 AI-assisted prototyping 说成完整生产工程；39 tests 不是性能、可靠性或用户验证 |
| Judgment under ambiguity | 广告库存策略、synthetic data 边界、issuer risk taxonomy、go-for-good 选择 | 投资筛选、ESG gate、五席研究选择与 Red Team 降调 | “我擅长在信息不完整时先定义证据上限、决策门和下一步验证，而不是补全未知事实。” | 面试官会追问一次你改变原判断或承认未知的案例 |

## 当前自我描述中最需要修正的地方

### 1. 公司和产品名

- 错误 / 高风险：`Fiducial Intelligence`。
- 正确：**Physical Intelligence**。
- π0、π0.7 是模型名称；`PI` 是公司常用简称，不是“产品就叫 PI，因为两个单词首字母”。

### 2. 不要把 VLA 与 WM / WAM 简化成“文字传输 vs 视频 / latent 传输”

- 这不是可靠的根本分界。VLA 可以使用语言、视觉表示和连续 / 离散化动作表示，语言并不一定是动作决策的唯一中介。
- 更稳健的区分：
  - **policy-first / VLA**：核心目标是从观察和指令直接生成动作；
  - **world-model-assisted / WM-WAM**：显式学习或利用未来状态 / 结果预测，帮助规划、训练或动作选择。
- 两条路线不是互斥；但“可融合”不等于某个系统已经实现完整的因果 WAM。

### 3. π0.7 的说法必须降调

- 高风险说法：“π0.7 有两个中心，先由 VLA 快速判断，再由 WAM 优化，并用 WAM 结果训练整体模型。”
- 更稳健说法：“我注意到 π0.7 在动作模型之外引入 BAGEL 生成近未来目标图像，说明 policy 与视觉未来预测正在靠近；我把它理解为 world-model-assisted VLA，但不会把它直接等同于完整的 action-conditioned WAM。”
- 若面试官不是具身智能专家，自我介绍不需要展开 π0.7；留作追问案例即可。

### 4. “所有研究都是 2024 年后”太绝对

- 世界模型、模仿学习和视觉-语言-动作的基础工作明显早于 2024。
- 建议说：“我重点覆盖的这一批前沿产品、模型版本和商业线索大多集中在 2024-2026，因此公开材料更新快、证据容易漂移。”

### 5. “读了几十篇论文”与“AI-native”的贡献边界

- 当前可公开核验的是 141 个公开来源、111 条原子主张、102 次 Web 搜索完成和约 22.04 小时 wall-clock；来源不等于论文，搜索也不等于本人逐篇精读。
- 推荐说法：“我设计并收口了覆盖 141 个公开来源的研究系统，自己对关键原始材料和最终判断负责；AI / Agent 做并行检索、来源恢复和机械 QA。”
- 若要说“精读论文”，只列自己能现场讲清方法、实验和局限的具体论文，例如 π0、π0.7、WorldScape；不要用无法展开的总数。

### 6. “编码能力”需要准确定位

- 可以说：能写 Python / SQL、数据 ETL、排序 / 聚类 pipeline、Agent 原型与测试。
- 不要说：自己是资深 SWE、生产级全栈工程师，除非能解释架构、部署、监控、性能、安全和多人维护。

### 7. “复合”要有主轴

- 弱说法：“我做过咨询、投资、AI、数据，所以很复合。”
- 强说法：“我一直在做同一类事：把高不确定、高风险的问题，转成可验证的结构和可执行的决策；只是场景从投资和风险，延伸到 AI 评测、数据产品和 Agent。”

### 8. “好相处”换成行为证据

- 弱说法：“我是非常好相处的 team player。”
- 强说法：“我的协作方式是先把隐性的判断标准写出来，邀请不同角色指出缺口，再用 case calibration 收敛分歧；Micro1 的外部专家校准和 SAIF / JLL 的跨职能交付都用过这种方式。”

## 面试时建议的证据优先级

1. **AI-native：** Micro1 + Context Agent + 可审计世界模型研究工作流。
2. **Fast learner：** 世界模型研究的 22 小时 / 141 来源 / 111 claims，但清楚区分本人决策与 Agent 执行。
3. **跨职能判断：** Jiritsu 的 18,000 token → 800 issuers → 30 候选，以及从 market quality 到 counterparty risk 的 error analysis。
4. **沟通：** 外部专家校准；若允许补充未提交经历，再讲 JLL 双语 briefing 或 SAIF partner memo。
5. **Teamwork：** 用一次真实分歧如何收敛来证明，不主动用人格形容词。
