# 简历证据摘录与核验笔记

## 使用边界

- 面试官收到的是 `20260628_resume.pdf`，因此下文将其称为“提交版”，所有主动自我介绍应优先从提交版出发。
- `Theodore Ouyang - Master Resume.pdf` 共 16 页，仅用来理解背景、准备追问和补充案例；不能假设面试官已经知道其中经历。
- 两份 PDF 均已逐页完成文本提取与 PNG 渲染检查。提交版 1 页；Master Resume 16 页。
- 原 PDF 未修改。

## 提交版：面试官实际看到的内容

### 教育

- Duke University 风险工程硕士，金融风险方向，2023.08-2025.05；Pratt School of Engineering Merit Scholarship，覆盖 50% 学费。
- Duke University 数学本科，2019.08-2023.05；本科奖学金，覆盖 25% 学费。
- 课程组合覆盖机器学习、深度学习、统计建模、随机过程、金融数学、算法博弈论、风险决策，以及高等数学训练。

### Micro1，AI 模型评估与策略工程师，2025.11-2026.06

提交版提供了两条互补证据链：

1. **LLM Evaluation / RLHF 偏好数据**
   - 组织并校准外部领域专家，把金融、消费等前沿实践中的极端场景、专家易错点和真实噪声转成评测样本。
   - 按 MECE 搭建风险维度和 scenario 矩阵，定义关键变量、假设、Rubric、A/B 排序规则和重复检验。
   - 定义人工合成数据质量边界，并把约束转成 Agent 可执行的数据生成 spec。
   - 沉淀 task card、Prompt 模板、难度分层、边界 case 校准、evidence re-check 和 badcase 回溯流程。

2. **LLM 聊天广告商业化策略**
   - 把展示数量、稀缺性、相关性和落地页质量等模糊争议转成可执行 Rubric。
   - 使用“市场研究 - 结构化辩论 - 专家访谈 - A/B 验证 - 策略手册”的流程。
   - 代表性案例是比较约 20 家酒店短名单与 100+ 全量库存，推荐全量库存以扩大点击捕捉并减少竞品流失。

### Jiritsu Network，数据 / 产品分析师，2024.08-2025.10

- 将 18,000+ CoinGecko token 经市场质量、数据完整性、主体映射与负面风险筛查，收敛为约 800 家 acceptable issuers，再形成 30 家优先合作对象。
- 使用 Python、Prefect、DuckDB、Parquet 搭建可复用 ETL。
- 通过 issuer-level error analysis 发现：市场质量指标只能衡量可交易性，不能充分识别博彩、匿名 / mixer-adjacent、披露不足和主体不清等 counterparty risk。
- 构建 negative risk taxonomy、reason code 和 token-to-issuer mapping；结合 LightGBM pairwise ranker、uncertainty sampling 与 Leiden clustering 支持边界识别、相似主体覆盖和候选多样性。
- 支持 6 个 tokenization pilot 的筛选与验证准备。

### AI-native 个人决策 Context Agent，Solo Product Project，2026.01-2026.06

- 从市场观察、需求发现、产品定义做到可运行 demo，问题聚焦于高不确定性个人决策。
- 设计 guided input、context profile、question framing、forecast preview、policy disclosure 等模块。
- 比较 Codex、multi-agent coding workflow 与 Claude Code dynamic workflow 在任务拆解、上下文压缩、token 消耗和交付质量上的差异。
- 采用 mock-first 架构跑通端到端体验；核心 prediction layer 与 mock provider 测试为 39 pass / 0 fail。
- 这是提交版中“AI-native”最直接的证据，但 39 个测试证明的是原型正确性，不是用户采用、产品市场匹配或预测质量。

### Duke University - AI at Duke，2024.08-2025.05

- 在公益 workshop 中设计研究生级数学物理与 Putnam 级问题、参考解法和评分 Rubric。
- 将问题拆成设定、假设、推理路径、评分标准和常见错误，用于识别长链推理、约束建模、边界条件和非标准解法中的 failure mode。
- 这段更适合支撑“严谨评测思维”和“能解释复杂问题”，不宜包装成正式发表的 AI 研究成果。

### 提交版视觉与链接检查

- 单页 A4，版式完整，没有裁切、重叠、黑块或不可读字符。
- 信息密度很高但仍可读；面试官更可能挑选具体数字深挖，而不是逐条阅读。
- PDF 中唯一链接注释是邮箱 `mailto:`；没有 GitHub、LinkedIn、项目仓库或作品集链接。

## Master Resume：只作为背景和案例库

### 对“复合背景”最有用的证据

- **SAIF Partners / 投资分析（第 7-8 页）**：整合 2,000 个融资案例与 200 个监管条目，覆盖 600+ 大中华牙科交易；与 VP 和团队形成 100+ 标的 longlist，并用治理 / 合规闸门收敛候选；情景式 memo 触发 2 次管理层会议和额外审计任期核查。
- **JLL / 资本市场（第 8-9 页）**：22 城筛至 5 个核心市场、20 个资产；使用 DCF、重置成本和可比交易；构建约 40 项 ESG / 经营指标和 10 个 Excel / Python / Tableau dashboard。
- **Euromonitor（第 10-11 页）**：负责全球绿色家电市场进入项目的中国 workstream；标准化 5 个平台、7 个品类、50,000 个 SKU；代表中国参与全球 stakeholder calls。
- **Hubble Network（第 13 页）**：交付 100 页市场格局报告并向董事会汇报；两类优先 segment 和情景预测属于策略沟通案例。
- **数学 / 物理竞赛与教学（第 14-15 页）**：竞赛训练、原创高难题与长期教学能够解释抽象能力和表达能力，但年代较早，只应作为底层能力来源，而不是当前核心卖点。

### 对“沟通与团队协作”最有用的证据

- SAIF：与 VP / 团队共同把研究转为候选名单、风险 memo、管理层问答和尽调动作。
- JLL：面向资本市场领导和客户经理做双语 briefings，输出直接影响实地考察顺序和尽调清单。
- Euromonitor：代表中国参与全球 stakeholder calls，协调绿色产品定义、政策节奏和渠道风险预期。
- Hubble：把 100 页研究压缩成面向董事会的建议。
- 长期竞赛教学：能把复杂数学物理结构化为解题框架、参考答案和评分 Rubric。

### 需要主动解释的版本差异

- Master Resume 第 4-5 页将同一时期的部分 AI 工作写为 **Alignerr / Domain Expert / Present**，提交版写为 **Micro1 / AI 模型评估与策略工程师 / 至 2026.06**。面试前必须准备一句一致、真实的关系说明，例如平台、项目、合同主体或品牌之间的关系，并解释结束时间。
- 提交版没有列 SAIF、JLL、Euromonitor、Hubble 等经历。若在自我介绍中说“投资、咨询背景”，面试官可能立刻追问“为什么简历没有”。更稳妥的说法是：“我在更早经历里做过投资、资本市场和策略研究；这份简历为了突出 AI / 数据 / 产品主线做了取舍。”
- Master Resume 的 “consulting” 证据主要是项目式咨询 / 研究交付，并非传统管理咨询公司任职。建议说“投资、市场研究和咨询式项目交付”，不要泛化成“多年咨询背景”。

## 公开世界模型研究：可核验的作品证据

### 本地只读仓库

- 本地研究仓库：`C:\Users\theod\OneDrive\文档\2026年7月28日工作\source-manifold-world-model-research`
- README 明确写明研究设计与决策归属：用户负责问题定义、三份 Deep Research 拆分、范围与准入门、阶段审批、证据结构、红队裁决、五席选择与最终表达；AI / Agent 负责并行研究、来源恢复、结构化整理和机械 QA。
- 研究体系包括 Source Card、Atomic Claim、Evidence Map、检查点、Red Team 和 Content Lock。
- README 记录的结果包括 141 个来源、141 张来源卡、111 条原子主张、63 条页面证据映射、10 页 PPT、4 个 PPTX 版本和 252 个文本框 QA。
- `provenance/session_summary.json` 记录从 2026-07-14 15:32:47 UTC 到最终状态约 **22.04 个 wall-clock hours**，33 次 Agent 创建请求、30 个实际启动、102 次 Web 搜索完成。
- 因此最稳健的快学证据不是“我亲自一天读完几十篇论文”，而是：“在约 22 小时内，我设计并收口了一套覆盖 141 个公开来源的可审计研究流程，最终形成 111 条原子主张；AI 承担并行检索和机械 QA，我承担边界、判断和最终取舍。”

### GitHub 地址状态

- PDF 中没有 GitHub 地址。
- 本地 `origin` 当前写为 `https://github.com/130U/manifold-world-model-research.git`，但本轮 GitHub connector 对 `130U/...` 和 `Madarame87/...` 均返回 404，CLI 凭证也已失效，无法用认证 API 确认当前所有权。
- 公共 Web 索引最近可见的页面仍为 `https://github.com/Madarame87/manifold-world-model-research`，显示 Public、7 commits，并展示同一 README。内置浏览器实时核验超时。
- 面试前应手动打开一次旧地址。旧地址是目前最稳妥的分享入口；如转移已完成，GitHub 通常会重定向到新 owner。不要在未打开确认前口头报 `130U` 新地址。

## 结论：最可信的个人主线

不是“三个互不相干的标签”，而是一条统一能力链：

> 我擅长进入陌生且高不确定的问题，把它快速拆成可验证的结构；再用 AI、数据和定量方法扩大覆盖，同时保留人的判断、证据边界和交付责任；最后把结果翻译成业务能够做决定的语言。

这条主线同时覆盖提交版的 LLM 评测、广告策略、token 筛选、Context Agent 和科学推理评测，也能自然接上 Master Resume 中的投资、资本市场、市场研究和董事会沟通。
