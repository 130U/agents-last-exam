# Source index and evidence labels

| File | Evidence role |
|---|---|
| [01](sources/01_unipat_official_site.md) | Company mission; self-report |
| [02](sources/02_unipat_linkedin.md) | Company-maintained LinkedIn metadata |
| [03](sources/03_unipat_join_us.md) | Hiring breadth; self-report |
| [04](sources/04_liang_chen_homepage.md) | Liang Chen first-person role claim |
| [05](sources/05_wendong_xu_homepage.md) | Wendong Xu first-person role claim |
| [06](sources/06_zhengwei_tao_homepage.md) | Tao Zhengwei first-person advisor claim |
| [07](sources/07_gradient_hongshan_event.md) | Event's conflicting cofounder claim |
| [08](sources/08_hongshan_babyvision.md) | Direct HongShan/xbench collaboration evidence |
| [09](sources/09_boss_hongshan_recruiting.md) | HongShan member-company recruiting evidence |
| [10](sources/10_shushu_researcher_job.md) | Recruiting narrative; unverified financial claims |
| [11](sources/11_bebee_pr_job.md) | Weak explicit investment claim |
| [12](sources/12_dealroom_profile.md) | Startup aggregator footprint |
| [13](sources/13_unipat_domain_rdap.md) | Verified UniPat domain metadata |
| [14](sources/14_unifuncs_domain_rdap.md) | Verified UniFuncs domain metadata |
| [15](sources/15_unifuncs_about.md) | UniFuncs legal-entity self-disclosure |
| [16](sources/16_unifuncs_shared_report.md) | User-provided generated report and method caveat |
| [17](sources/17_github_organization.md) | Verified public technical footprint |
| [18](sources/18_github_reproducibility_signals.md) | External issue/reproduction signals |
| [19](sources/19_babyvision_method.md) | Benchmark-method caveat |
| [20](sources/20_theblock_echo_press_release.md) | Company-provided Echo claim |
| [21](sources/21_independent_echo_repo.md) | Independent inspiration, not customer proof |
| [22](sources/22_kuan_li_homepage.md) | Core-author role ambiguity |

