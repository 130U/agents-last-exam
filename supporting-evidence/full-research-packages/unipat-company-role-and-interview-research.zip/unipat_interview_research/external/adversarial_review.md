# Adversarial review: strongest claims that may fail under scrutiny

**Cut-off:** 2026-08-04

## 1. “红杉投资了 UniPat”

### Supporting evidence

- BOSS and other job pages repeatedly say “红杉成员企业.”
- A low-quality BeBee mirror explicitly says “红杉中国美元 VC 投资.”
- HongShan published the xbench × UniPat BabyVision collaboration and co-hosted ecosystem activity.

### Disconfirming / limiting evidence

- No direct financing announcement from UniPat or HongShan was located.
- No round, amount, valuation, date, investing entity, or cap-table evidence was located.
- Collaboration and recruiting support are not transaction disclosures.

### Safe conclusion

**High confidence in a HongShan ecosystem/recruiting relationship; medium confidence that some HongShan-linked investment occurred; low confidence in any specific financing terms.** Phrase it as a question, not a fact.

## 2. “UniPat 是 11-50 人、由十多位顶尖研究员创办”

### Supporting evidence

- LinkedIn self-reports 11-50 employees.
- Recruiter copy says more than ten top researchers.
- Many authors and repositories exist.

### Disconfirming / limiting evidence

- LinkedIn showed only a small visible employee/follower footprint.
- Academic coauthorship does not equal full-time employment.
- At least one important author's personal page does not clearly state a UniPat job.
- Leadership titles conflict for Tao Zhengwei.

### Safe conclusion

**A credible extended research network exists; the number of full-time employees and founders is not publicly verified.**

## 3. “研究产出证明公司有强 PMF”

### Supporting evidence

- Ten-plus public repositories, active releases, papers, and moderate GitHub stars.
- External issue reporters are attempting to use/reproduce work.
- Media and HongShan ecosystem coverage exists.

### Disconfirming / limiting evidence

- Most media hits are company-provided releases or syndication of the same announcement, not independent reporting.
- No named paying customers, revenue, retention, or production case studies were found.
- Independent Echo-inspired code is a reimplementation, not an API adoption case.

### Safe conclusion

**Research execution is demonstrated; commercial PMF is not publicly demonstrated.**

## 4. “Echo 已被真实收益验证”

### Supporting evidence

- Company-provided release says four of five agents were profitable in a public debut.
- Public prediction markets can make trades observable in principle.

### Disconfirming / limiting evidence

- Five agents is a tiny sample.
- No audited record, evaluation window, drawdown, fees, compute cost, or risk adjustment is supplied.
- The media host explicitly disclaims endorsement.

### Safe conclusion

**Treat as a product demonstration, not investment-performance evidence.**

## 5. “BabyVision 证明最强模型不如三岁儿童”

### Supporting evidence

- The benchmark and methodology are public.
- The child baseline is a genuine human comparison.

### Disconfirming / limiting evidence

- Child comparison is on a 20-question Mini subset from one school; adult baseline is on the 388-item full benchmark.
- Open GitHub discussion asks for raw human-evaluation data.
- Tool-using model scores later became much higher, so the headline depends on model date and protocol.

### Safe conclusion

**It is a useful diagnostic benchmark and launch finding, but the viral headline is protocol-bound and time-sensitive.**

## 6. “UniFuncs 与 UniPat 是同一家公司”

### Supporting evidence

- The recruiter/user shared a UniPat report through a UniFuncs domain.

### Disconfirming / limiting evidence

- The page is visibly a generic generated research report from a user query.
- UniFuncs names its own Shenzhen legal entity; UniPat does not publicly name that entity.
- Domains differ in age, registrar, nameservers, and mail systems.
- No ownership or operating link was found.

### Safe conclusion

**No relationship should be inferred. Verify the hiring entity directly.**

## 7. “没有负面新闻，所以风险低”

No substantive public allegation of fraud, litigation, or misconduct was found in this focused search. However, the company is less than a year old, small, privately held, and lightly covered by independent media. Low visibility creates an evidence gap; it is not affirmative proof of low risk.

## 8. Interview decision rule

Do not decide from prestige proxies alone. The opportunity becomes compelling if the interviewer can connect:

1. a specific company priority,
2. a concrete 90-day owned outcome,
3. direct access to the decision-maker and customer/problem context,
4. a credible learning loop that expands responsibility,
5. and a clean employment/equity structure.

If the answer remains only “help the CEO with whatever is needed,” the candidate should ask for a scoped trial project or written 90-day charter before giving up a role with clearer learning and ownership.

