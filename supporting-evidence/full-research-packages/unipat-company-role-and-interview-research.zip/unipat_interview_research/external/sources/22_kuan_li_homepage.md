# Kuan Li personal homepage

- URL: https://likuanppd.github.io/
- Accessed: 2026-08-04
- Source type: individual-controlled professional profile
- Evidence label: first-person profile plus publication metadata
- Credibility / recency / bias: 4 / 4 / medium self-presentation bias

## Captured facts

Kuan Li appears as corresponding/senior author on multiple UniPat technical releases using a unipat.ai email. His personal homepage identifies him as an HKUST PhD student and describes work in Tongyi DeepResearch, but does not clearly state a current UniPat title.

## Interpretation

The publication link is real, but public materials do not resolve whether his UniPat relationship is founder, employee, contractor, collaborator, or part-time contributor. This is normal in academic/startup collaborations but matters for assessing team capacity and IP ownership.

