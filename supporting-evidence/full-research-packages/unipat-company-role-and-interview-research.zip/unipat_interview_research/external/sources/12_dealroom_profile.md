# Dealroom UniPat profile

- URL: https://app.dealroom.co/companies/unipat_1
- Accessed: 2026-08-04
- Source type: startup database aggregator
- Evidence label: third-party profile
- Credibility / recency / bias: 2 / 3 / medium aggregation bias

## Captured claim

The accessible profile lists launch date 2025 and describes UniPat around AI benchmarks and agentic frameworks. No financing fields or independently sourced transaction terms were visible in the accessible result.

## What it supports

There is a startup-database footprint consistent with the company's public technical positioning.

## Caveat

Aggregator presence is not legal-registration, financing, or traction verification.

