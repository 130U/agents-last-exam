# HongShan article on BabyVision

- URL: https://www.hongshan.com/article/%E5%A4%9A%E6%A8%A1%E6%80%81%E5%A4%A7%E6%A8%A1%E5%9E%8B%E8%BE%93%E7%BB%99%E4%B8%89%E5%B2%81%E5%AE%9D%E5%AE%9D%EF%BC%9Fxbench-x-unipat%E8%81%94%E5%90%88%E5%8F%91%E5%B8%83%E6%96%B0%E8%AF%84%E6%B5%8B/
- Accessed: 2026-08-04
- Source type: investor/ecosystem publication
- Evidence label: primary evidence of collaboration; not financing proof
- Credibility / recency / bias: 4 / 5 / medium promotional bias

## Captured claim

The article says xbench and UniPat jointly released the BabyVision multimodal benchmark.

## What it supports

There is a direct, public collaboration between UniPat and xbench in the HongShan ecosystem.

## What it does not support

A joint benchmark and publication do not by themselves establish that HongShan invested, the round size, ownership, or any financing terms.

