# RDAP record — unipat.ai

- URL: https://rdap.identitydigital.services/rdap/domain/unipat.ai
- Accessed: 2026-08-04
- Source type: registry protocol record
- Evidence label: verified infrastructure metadata
- Credibility / recency / bias: 5 / 5 / low bias

## Captured facts

- Registered: 2025-11-18
- Registrar: GoDaddy.com, LLC / Identity Digital RDAP
- Registrant contact: privacy-protected through Domains By Proxy
- Nameservers: ns09.domaincontrol.com and ns10.domaincontrol.com
- Current listed expiry: 2027-11-18

Live DNS inspection also showed Feishu mail exchangers and verification records.

## What it supports

The domain is recent and privacy protected. This is normal for startups and is neither a legitimacy certificate nor a red flag by itself.

