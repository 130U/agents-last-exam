# GitHub issues — external interest and reproducibility signals

- URLs:
  - https://github.com/UniPat-AI/BabyVision/issues
  - https://github.com/UniPat-AI/SaaS-Bench/issues
  - https://github.com/UniPat-AI/SWE-Vision/issues
- Accessed: 2026-08-04
- Source type: public issue trackers
- Evidence label: verified external/user questions, not adjudicated findings
- Credibility / recency / bias: 4 / 5 / low-medium issue-reporter bias

## Captured signals

Open issues included requests for BabyVision raw human-evaluation data and additional model results; SaaS-Bench questions about exact reasoning-effort settings, leaderboard submission, and result reproduction; and a SWE-Vision report of a Python error under the default setup.

## Interpretation

These questions show real outside interest and attempted use. They also identify practical due-diligence topics: human-baseline transparency, exact evaluation settings, leaderboard governance, and default onboarding reliability. An open issue is not proof that a result is invalid.

