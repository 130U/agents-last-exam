# BOSS Zhipin HongShan-member recruiting page

- URL: https://www.zhipin.com/zhaopin/704db0bedea9b7ff0XNz0920/
- Accessed: 2026-08-04
- Source type: job platform listing
- Evidence label: third-party platform carrying employer/recruiter claims
- Credibility / recency / bias: 3 / 5 / high recruiting bias

## Captured excerpt

> [红杉成员企业] Researcher Intern

The accessible listing showed a compensation range of RMB 800-1,000 per day, Beijing Haidian/Suzhou Bridge, and the employer/recruiting channel as 红杉中国 while the description referred to UniPat.

## What it supports

HongShan's recruiting channel publicly handles at least one UniPat role and labels it a HongShan member company.

## What it does not support

“Member company” is not a financing disclosure. The page does not identify the investment entity, round, date, amount, valuation, or contracting employer.

