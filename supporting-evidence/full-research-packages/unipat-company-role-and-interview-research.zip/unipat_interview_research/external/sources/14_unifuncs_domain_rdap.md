# RDAP record — unifuncs.com

- URL: https://rdap.verisign.com/com/v1/domain/unifuncs.com
- Accessed: 2026-08-04
- Source type: registry protocol record
- Evidence label: verified infrastructure metadata
- Credibility / recency / bias: 5 / 5 / low bias

## Captured facts

- Registered: 2024-12-09
- Registrar: Alibaba Cloud Computing (Beijing) Co., Ltd. / HiChina
- Nameservers: VIP1.ALIDNS.COM and VIP2.ALIDNS.COM
- Current listed expiry: 2026-12-09

Live DNS inspection showed Tencent enterprise mail exchangers.

## Relevance

The domain predates unipat.ai and uses different registrar, DNS, and mail infrastructure. This does not prove corporate independence, but it supplies no affirmative evidence that the two brands share ownership.

