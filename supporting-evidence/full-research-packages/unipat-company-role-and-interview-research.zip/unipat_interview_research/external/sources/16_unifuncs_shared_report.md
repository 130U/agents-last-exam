# User-provided UniFuncs shared report

- URL: https://s.unifuncs.com/?sid=f7377937-fcb2-4665-9c46-7c9c6d4bb60a
- Accessed: 2026-08-04
- Source type: AI-generated research report hosted by UniFuncs
- Evidence label: mixed-source secondary synthesis; not independent verification
- Credibility / recency / bias: 2 / 5 / unknown model and retrieval bias

## Captured context

The visible user query dated 06-08 01:03 asked: “unipat.ai 搜索一下这个公司 告诉我他们是做什么的”. The generated title was “UniPat AI 是做什么的？ - U深搜”.

The report describes UniPat as founded in 2025, LinkedIn size 11-50, and active across Echo, UniScientist, SWE-Vision, BabyVision, SaaS-Bench, and other projects. It repeats recruiting-source language about being a HongShan member company while acknowledging that financing amount, round, valuation, and ownership are not publicly verified.

## Method warning

This report is itself a generated synthesis. Its references to “collaboration,” “investment,” and ecosystem relationships should not be merged into one claim. Use underlying sources, not the report, for interview assertions.

