# GitHub organization — UniPat-AI

- URL: https://github.com/UniPat-AI
- Accessed: 2026-08-04
- Source type: public code organization
- Evidence label: verified public technical footprint
- Credibility / recency / bias: 5 / 5 / medium project-presentation bias

## Captured repositories

The organization exposed at least ten public repositories: BabyVision, SWE-Vision, UniScientist, SaaS-Bench, EvoCodeBench, RoadmapBench, harbor_multiturn, harbor, unimath, and Terminal-X.

Approximate public counters observed:

- BabyVision: 236 stars, 10 forks, 3 open issues, 12 commits
- UniScientist: 169 stars, 12 forks, 1 open issue, 14 commits
- SaaS-Bench: 93 stars, 12 forks
- SWE-Vision: 173 stars, 8 forks, 1 open issue

## What it supports

UniPat has real, active, externally visible research artifacts and modest developer interest. Stars and repositories do not demonstrate customers, revenue, model quality, or production usage.

