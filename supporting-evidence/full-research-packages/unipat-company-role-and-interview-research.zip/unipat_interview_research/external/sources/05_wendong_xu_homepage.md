# Wendong Xu personal homepage

- URL: https://vincentxwd.github.io/
- Accessed: 2026-08-04
- Source type: individual-controlled professional profile
- Evidence label: first-person claim
- Credibility / recency / bias: 4 / 4 / medium self-presentation bias

## Captured excerpt

The experience section identifies Wendong Xu as Co-Founder and Research Scientist at UniPat AI from October 2025 to present. It also describes him as an HKU PhD candidate and a former Baidu senior software engineer.

## What it supports

Xu publicly claims cofounder status and a research/engineering background. It does not establish the legal company or operational role split.

