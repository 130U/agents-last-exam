# Gradient / HongShan event listing

- URL: https://luma.com/8b8yg0fg?locale=zh
- Alternate mirror: https://lianpu.com/event/shu-ma-bao-bei-ai-jin-hua-lun
- Accessed: 2026-08-04
- Source type: third-party event listing
- Evidence label: third-party claim
- Credibility / recency / bias: 3 / 4 / medium event-promotion bias

## Captured excerpt

The event listing presents “陶政为 & 陈亮” as “UniPat AI 联合创始人” and identifies the event with Gradient / 红杉中国 participation.

## What it supports

UniPat people have appeared in a HongShan-linked ecosystem event. It does not prove financing. Its description of Tao conflicts with Tao's own homepage, which says advisor.

