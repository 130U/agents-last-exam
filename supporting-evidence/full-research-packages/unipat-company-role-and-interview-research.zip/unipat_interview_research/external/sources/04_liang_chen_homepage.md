# Liang Chen personal academic homepage

- URL: https://chenllliang.github.io/
- Accessed: 2026-08-04
- Source type: individual-controlled professional profile
- Evidence label: first-person claim
- Credibility / recency / bias: 4 / 4 / medium self-presentation bias

## Captured excerpts

> I cofounded UniPat AI.

The experience section identifies him as UniPat AI Co-Founder & CTO, beginning 2025.12, and as a final-year PhD student at Peking University. It also lists prior research experience involving MSRA, Tencent NLP, Alibaba Qwen, Moonshot AI, and other teams.

## What it supports

Liang Chen publicly claims cofounder/CTO status and has a credible technical-research background. It does not establish the legal entity, equity, full-time status, or CEO identity.

