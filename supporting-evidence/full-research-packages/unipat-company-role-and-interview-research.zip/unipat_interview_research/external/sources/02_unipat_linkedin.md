# UniPat LinkedIn company page

- URL: https://www.linkedin.com/company/unipat
- Accessed: 2026-08-04
- Source type: company-maintained third-party profile
- Evidence label: company self-report hosted by LinkedIn
- Credibility / recency / bias: 3 / 4 / medium-high promotional bias

## Captured excerpts

> Industry: Research Services

> Company size: 11-50 employees

> Founded: 2025

> Type: Partnership

The accessible page showed roughly 63 followers and visible associated people including Le KANG, Stanley Wu, Yixin Ren, and Suning Chen.

## What it supports

UniPat has a small but non-empty professional-network footprint and publicly describes itself as founded in 2025 with 11-50 people. LinkedIn does not verify headcount, incorporation, or employment status.

