# UniPat Join Us page

- URL: https://unipat.ai/joinus
- Accessed: 2026-08-04
- Source type: company-controlled primary source
- Evidence label: company self-report
- Credibility / recency / bias: 4 / 5 / high recruiting bias

## Captured roles

The page listed Research Scientist, Research Intern, Agent Systems Engineer, Infra Engineer, Expert Community Lead, Design Technologist, Marketing/PR Manager, Legal Counsel, and Senior Tax Specialist.

## What it supports

The company is publicly recruiting across research, engineering, community, design, communications, legal, and tax. The breadth is unusual for a publicly described 11-50-person company founded in 2025.

## Inference, not fact

This may indicate rapid institution-building, exploratory requisitions, or a deliberately broad talent funnel. It is consistent with an interview that starts without a fixed role, but it does not prove hiring urgency or organizational maturity.

