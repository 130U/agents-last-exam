# Zhengwei Tao personal homepage

- URL: https://tzwwww.github.io/
- Accessed: 2026-08-04
- Source type: individual-controlled professional profile
- Evidence label: first-person claim
- Credibility / recency / bias: 4 / 4 / medium self-presentation bias

## Captured excerpt

> advisor at UniPat.ai

## What it supports

Tao's own current-facing profile describes an advisor relationship, not a cofounder role.

## Conflict to resolve

Third-party event listings describe “陶政为 & 陈亮” as UniPat AI cofounders. The discrepancy may be stale event copy, a changed role, translation shorthand, or a genuine governance ambiguity. Ask neutrally rather than treating either label as definitive.

