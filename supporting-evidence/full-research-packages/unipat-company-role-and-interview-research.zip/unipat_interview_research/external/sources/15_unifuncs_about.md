# UniFuncs official About page

- URL: https://unifuncs.com/about
- Accessed: 2026-08-04
- Source type: company-controlled primary source
- Evidence label: company self-report
- Credibility / recency / bias: 4 / 4 / medium promotional bias

## Captured facts

The page identifies the operator as “优函数智能科技（深圳）有限责任公司,” gives a Shenzhen-Shenshan Special Cooperation Zone address, and lists service@unifuncs.com.

## What it supports

UniFuncs discloses a Chinese legal entity on its own site. UniPat's accessible public site did not disclose the same entity or any relationship to it.

## Interview relevance

Because the interview link was a UniFuncs-generated share page, ask whether UniFuncs is merely the research tool used by the recruiter or is legally/operationally related to UniPat.

