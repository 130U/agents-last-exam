# The Block press release — Echo prediction agents

- URL: https://www.theblock.co/press-releases/396934/unipat-ai-launches-echo-agents-on-polymarket-four-of-five-turn-profitable-in-public-trading-debut
- Accessed: 2026-08-04
- Source type: company-provided press release hosted by media outlet
- Evidence label: company self-report, explicitly non-endorsed
- Credibility / recency / bias: 2 / 5 / high promotional bias

## Captured claim

The release says UniPat launched five Echo agents on Polymarket and four of five were profitable in a public trading debut. The page labels the content as provided by UniPat and says The Block does not endorse it.

## What it supports

UniPat publicly operated or presented multiple named prediction agents and disclosed a small-sample result.

## What it does not support

No audited P&L, time horizon, risk-adjusted return, fee treatment, drawdown, statistical significance, or independent reproduction is established by this release.

