# Shushu job mirror — Researcher Intern

- URL: https://www.shushuqiuzhi.com/position/305283
- Accessed: 2026-08-04
- Source type: recruiting mirror
- Evidence label: copied employer self-description
- Credibility / recency / bias: 2 / 5 / high recruiting bias

## Captured excerpts

> 红杉成员企业 Researcher Intern

> 顶级美元 VC 投资

The page identifies the job source as 北京红杉顾问咨询有限公司, location Beijing, and an update date of 2026-05-08. The copied description says UniPat was founded by more than ten top researchers, has healthy cash flow, and is growing rapidly.

## What it supports

The recruiting narrative and HongShan-channel connection are persistent across more than one job site.

## Caveat

Claims about investors, cash flow, team quality, and growth are unattributed job-ad copy, not audited evidence or a financing announcement.

