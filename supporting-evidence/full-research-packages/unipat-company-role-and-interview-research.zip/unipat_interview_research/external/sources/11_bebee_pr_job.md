# BeBee job mirror — PR and Content

- URL: https://bebee.com/cn/jobs/pr--techmap_cn_84004087
- Accessed: 2026-08-04
- Source type: low-quality job aggregator
- Evidence label: third-party republication of recruiting claim
- Credibility / recency / bias: 1 / 3 / high recruiting and aggregation bias

## Captured excerpt

> [红杉成员企业] PR 与内容传播经理

The listing says the company received “红杉中国美元 VC 投资.”

## Use with caution

This is the most explicit public investment wording found, but it is on an aggregator and may simply copy recruiter text. Without a HongShan or UniPat financing announcement, treat it as an unverified third-party claim.

