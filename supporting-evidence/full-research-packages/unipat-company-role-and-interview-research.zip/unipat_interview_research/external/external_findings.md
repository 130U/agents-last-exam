# UniPat external due diligence for interview

**Cut-off:** 2026-08-04  
**Scope:** Independent/public-source investigation of UniPat AI, with explicit separation between verified fact, company self-report, third-party claim, and inference.  
**Bottom line:** UniPat appears to be a real, very young, research-heavy AI startup with a credible technical founder group, a substantial cadence of public benchmarks/code, and a visible HongShan ecosystem/recruiting connection. What is still missing from the public record is equally important: the contracting legal entity, CEO, precise founder/governance map, financing terms, paid customers, revenue, and the one commercial wedge that currently matters most.

## 1. Direct answer: what can be said with confidence

### Verified or strongly corroborated

1. **There is a real public technical footprint.** The `UniPat-AI` GitHub organization exposes at least ten repositories, including BabyVision, UniScientist, SaaS-Bench, and SWE-Vision. The larger repositories have roughly 90-236 stars, active issues, and externally visible code/data/model artifacts. This is meaningful evidence of execution, although not of revenue or production adoption. See [GitHub organization](sources/17_github_organization.md) and [issue signals](sources/18_github_reproducibility_signals.md).

2. **Liang Chen and Wendong Xu publicly claim cofounder roles.** Liang says he cofounded UniPat and lists Co-Founder & CTO; Xu lists Co-Founder and Research Scientist. Both have credible academic/engineering backgrounds. See [Liang Chen](sources/04_liang_chen_homepage.md) and [Wendong Xu](sources/05_wendong_xu_homepage.md).

3. **HongShan-linked channels publicly recruit for UniPat.** BOSS and job mirrors repeatedly label roles “红杉成员企业”; a BOSS listing is presented through the HongShan recruiting channel. HongShan also published the xbench × UniPat BabyVision collaboration. See [BOSS](sources/09_boss_hongshan_recruiting.md), [Shushu](sources/10_shushu_researcher_job.md), and [HongShan BabyVision](sources/08_hongshan_babyvision.md).

4. **The company is recruiting very broadly.** Its own page lists research, agent systems, infra, expert community, design, PR, legal, and tax roles. BOSS mirrors add product/platform, IT operations, and other functions. See [Join Us](sources/03_unipat_join_us.md).

5. **The `unipat.ai` domain is very new.** Registry data gives 2025-11-18 as the registration date. A new domain is expected for a 2025 startup but reinforces that this is an early-stage organization. See [RDAP](sources/13_unipat_domain_rdap.md).

### Company self-report or recruiter narrative

1. UniPat describes its mission as creating expert-level agentic models through reasoning and reinforcement learning. [Official site](sources/01_unipat_official_site.md)
2. LinkedIn describes it as founded in 2025, 11-50 employees, Research Services, and “Partnership.” These fields are company maintained and not legal-registry verification. [LinkedIn](sources/02_unipat_linkedin.md)
3. Recruiting copy says it was founded by more than ten top researchers, has top-dollar-VC investment, healthy cash flow, and rapid growth. None of those financial claims were independently documented. [Shushu](sources/10_shushu_researcher_job.md)
4. A company-provided press release says four of five Echo Polymarket agents were profitable. The host explicitly disclaims endorsement, and the release does not provide an audited or statistically meaningful performance record. [The Block release](sources/20_theblock_echo_press_release.md)

### Third-party claims not yet primary-source confirmed

1. A BeBee mirror explicitly says “红杉中国美元 VC 投资.” This is stronger wording than “member company,” but it is a low-quality aggregator and may copy recruiter text. No direct UniPat/HongShan financing announcement, round, amount, valuation, or transaction date was found. [BeBee](sources/11_bebee_pr_job.md)
2. Event listings call Tao Zhengwei and Liang Chen UniPat cofounders. Tao's own homepage calls him an advisor. [Event listing](sources/07_gradient_hongshan_event.md) versus [Tao homepage](sources/06_zhengwei_tao_homepage.md)
3. Dealroom carries a UniPat profile, but the accessible record did not provide independent financing data. [Dealroom](sources/12_dealroom_profile.md)

## 2. What the public record does not establish

No accessible, credible public source located in this review established:

- the exact legal entity that will sign the employment or consulting agreement;
- incorporation jurisdiction, shareholder registry, or office entity for UniPat;
- CEO identity and formal reporting lines;
- complete founder list, equity split, or full-time/part-time status of core researchers;
- financing round, amount, valuation, lead investor, close date, or runway;
- paid customer names, recurring revenue, gross margin, retention, or production-scale usage;
- independent, audited validation of Echo profitability;
- a single prioritized commercial wedge across its many research/product lines.

This means the right interview stance is **interested but precise**, not suspicious. Ask for operating facts that a serious candidate needs in order to compare roles.

## 3. UniPat versus UniFuncs: do not infer a corporate relationship

The interview/research link is a UniFuncs-hosted report, but the available evidence does not show that UniFuncs owns or operates UniPat.

- UniFuncs' own About page identifies its operator as **优函数智能科技（深圳）有限责任公司**. [UniFuncs About](sources/15_unifuncs_about.md)
- `unifuncs.com` was registered 2024-12-09 through Alibaba/HiChina and uses AliDNS/Tencent enterprise email. [UniFuncs RDAP](sources/14_unifuncs_domain_rdap.md)
- `unipat.ai` was registered 2025-11-18 through GoDaddy/Identity Digital and uses DomainControl/Feishu mail. [UniPat RDAP](sources/13_unipat_domain_rdap.md)
- The shared page is visibly an AI-generated report created from the query “unipat.ai 搜索一下这个公司 告诉我他们是做什么的.” [Shared report](sources/16_unifuncs_shared_report.md)

**Conclusion:** Different dates, registrars, DNS, and email systems do not prove independence, but they give no affirmative support for common ownership. The most economical explanation is that UniFuncs is the research tool used to prepare/share a report. Ask HR which entity is hiring and whether any relationship exists.

## 4. Leadership and team map

| Person | Publicly supportable relationship | Confidence | Unresolved point |
|---|---|---:|---|
| Liang Chen | Co-Founder & CTO, self-reported | High | Full-time status, equity, executive remit |
| Wendong Xu | Co-Founder & Research Scientist, self-reported | High | Full-time status, executive remit |
| Tao Zhengwei | Own page says advisor; event page says cofounder | Medium/conflicted | Current title and governance role |
| Kuan Li | Corresponding/senior author on UniPat work, unipat.ai email | Medium | Employee/founder/collaborator/part-time status |
| Le Kang | Visible professional-network association and public promotion | Low-medium | Exact current title; a generated report calls him global BD, but accessible primary evidence did not confirm it |
| CEO | Not identified in reliable accessible public material | Unknown | Identity, background, decision rights, time allocation |

The team has credible research credentials. The main diligence issue is not “are these researchers real?” but “who is actually full-time, who owns which decisions, and who will manage this role?”

## 5. Product and traction assessment

### Technical/research traction: real, early, and visible

Public projects span multimodal evaluation, scientific-agent training, coding-agent benchmarks, SaaS workflows, mathematical reasoning, terminal tasks, roadmap planning, prediction agents, and evaluation infrastructure. The release cadence and artifacts are stronger than a pure slide-deck startup.

External GitHub issues show people trying to inspect or reproduce results. Questions about BabyVision human data, SaaS-Bench exact settings/submission, and SWE-Vision setup are useful signals: there is genuine outside interest, but also normal early-project reproducibility/onboarding friction.

### Commercial traction: opaque

No named paying customer, customer case with measurable ROI, public API adoption metric, ARR, or retention figure was located. The independent `echo-polymarket` repository is inspiration/reimplementation rather than evidence of using a UniPat commercial product. [Independent Echo repo](sources/21_independent_echo_repo.md)

### The strategic question

Public materials reveal many plausible businesses but not which one is the current revenue engine:

- benchmark/evaluation and leaderboards;
- RL environments, trajectories, and training data;
- expert-community/data operations;
- model/API products such as Echo or UniScientist;
- enterprise evaluation/research services;
- platform or marketplace infrastructure.

In an early company, multiple experiments are normal. For a candidate, however, the key question is which wedge has customers or a board-level milestone in the next 6-12 months.

## 6. Benchmark-claim hygiene

BabyVision is a good example of why to separate headline, protocol, and current state:

- The public methodology uses a 388-item full benchmark.
- The child comparison uses a 20-question BabyVision-Mini subset with more than 20 children per age group from one school.
- The adult comparison uses 16 adults on the full benchmark.
- Later tool-using models materially change the leaderboard.

Therefore, “模型输给三岁宝宝” is a useful launch headline but not a timeless or protocol-neutral scientific conclusion. This is not evidence of wrongdoing; it is a prompt to ask how UniPat protects benchmark credibility as models, tools, and prompts evolve. [BabyVision method](sources/19_babyvision_method.md)

## 7. Competitive map

UniPat does not face one clean competitor because it spans several layers:

| Wedge | Relevant alternatives / reference points | Interview implication |
|---|---|---|
| Model/agent evaluation | xbench, Scale/SEAL, Artificial Analysis, Epoch AI, LiveBench, Chatbot Arena | What proprietary data, distribution, or customer workflow makes UniPat more than another benchmark publisher? |
| Coding/computer-use evaluation | SWE-bench, Terminal-Bench, BrowserGym/WebArena, OSWorld, AgentBench | Does UniPat own a differentiated environment or merely a leaderboard? |
| Scientific/deep-research agents | OpenAI Deep Research, Gemini Deep Research, Perplexity, FutureHouse, AI Scientist-style systems, Tongyi DeepResearch | Is UniScientist a product, training system, benchmark, or research demo? |
| Prediction intelligence | Metaculus, Polymarket/Kalshi ecosystems, Good Judgment, trading/research agents | Is Echo monetized via API, internal strategies, enterprise forecasting, or publicity? |
| Expert data / RL environments | Scale AI, Surge AI and specialist data/evaluation vendors | Can the expert network compound into proprietary trajectories and durable model advantage? |

These are category reference points, not claims that each company is a direct head-to-head competitor.

## 8. Likely interview agenda

Given “先聊、没有固定岗位,” the broad hiring slate, and the user's alternative Manifold offer, the likely meeting is a **talent-mapping/founder-fit conversation**, not a conventional requisition interview.

1. **0-5 min — framing and motivation.** Why take the call now; why UniPat despite another offer; what kind of impact is sought.
2. **5-15 min — non-resume personal narrative.** The interviewer will look for a coherent identity rather than another chronology.
3. **15-30 min — evidence for fast learning and AI-native work.** Expect probing on how the embodied-AI/world-model research was actually produced, what was independently reasoned, and how quality was controlled.
4. **30-45 min — ambiguous operating scenario.** Likely tests: take an unclear CEO problem, structure research, identify options, reach experts/customers, communicate externally, or stand up a workflow from zero.
5. **45-55 min — role shaping.** Research/product/partnership/strategy/content/CEO-office possibilities; willingness to execute details; what degree of ownership and decision access is necessary.
6. **55-60 min — logistics and next step.** Offer timing, location, start date, compensation, and a follow-up with the actual hiring manager/founder.

### What they are probably testing

- Can this person turn ambiguity into a decision, not just produce a long report?
- Is the “AI-native” claim backed by reproducible workflows and judgment?
- Will the person execute unglamorous work while progressively earning scope?
- Can consulting/investing communication translate into customer, partnership, recruiting, product, or fundraising leverage?
- Is the candidate genuinely interested, or only creating optionality against Manifold?

## 9. Top due-diligence questions, in priority order

Ask 4-6 in the first conversation; save the rest for later.

1. **“我最终签约、发薪和授予期权的法律主体是什么？它与 UniPat.ai、UniFuncs 或其他境内外实体分别是什么关系？”**
2. **“如果我们合作，您希望我在前 90 天解决的三个具体问题是什么？每个问题怎样算成功？”**
3. **“这个角色实际向谁汇报？我每周大约多少时间是战略/决策支持，多少是执行协调或行政类工作？哪些事项我可以直接 owner？”**
4. **“公开资料里有‘红杉成员企业’和‘美元 VC 投资’的表述。方便说明已完成融资的轮次、投资方、到账状态和目前最关键的 runway 里程碑吗？不方便给数字的话，给区间也可以。”**
5. **“目前真正有收入或最接近 PMF 的 wedge 是哪一个：评测、训练数据/RL environment、专家网络、模型/API，还是企业服务？过去三个月哪个指标增长最快？”**
6. **“目前 CEO、联合创始人和核心业务负责人分别是谁？陶政为公开资料里同时出现 advisor 和 cofounder 两种说法，当前准确角色是什么？”**
7. **“为什么现在需要我？在我的研究、咨询/投资、AI workflow、沟通和编码能力里，哪一项是团队最稀缺的？”**
8. **“公司发布线很多。哪些是探索，哪些是公司级优先级？过去半年你们主动砍掉过什么？”**
9. **“Echo ‘5 个 agent、4 个盈利’对应多长时间窗？是否扣除交易费和算力成本？看最大回撤还是只看期末 P&L？有没有独立复现或客户使用？”**
10. **“BabyVision/SaaS-Bench 这类结果如何做版本管理、human baseline 原始数据、prompt/tool-use 规范和第三方复现？”**
11. **“核心研究成员有高校和大厂背景。全职投入比例、IP 归属、开源策略和论文署名怎么治理？”**
12. **“下一轮前，能否让我与潜在直属经理或同类岗位成员聊 15 分钟，了解真实的一周工作？”**

## 10. How to calibrate the opportunity

Three green signals would materially improve confidence:

- a clear legal/employment structure and unambiguous manager;
- a 90-day mission with one or two owned outcomes, not an indefinite CEO errand queue;
- one monetization wedge with real customer evidence or a credible milestone/risk explanation.

Three yellow-to-red signals would lower confidence:

- repeated refusal to identify the employing entity or financing/runway even at a high level;
- inability to say who decides priorities across the many projects;
- describing success only as “save CEO time” without defining decision access, ownership progression, or measurable outputs.

The best framing is: **“I am happy to do high-leverage dirty work; I need to know what learning loop and ownership it compounds into.”**

