"""Minimal compatibility shim for the bundled research validator.

The fields.yaml artifact is JSON-formatted YAML, so the standard library JSON
parser is sufficient and avoids adding a package dependency to the workspace.
"""

import json


def safe_load(stream):
    return json.load(stream)
