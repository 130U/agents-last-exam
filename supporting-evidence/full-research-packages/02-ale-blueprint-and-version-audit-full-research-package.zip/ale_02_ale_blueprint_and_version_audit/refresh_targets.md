# Refresh targets — ALE blueprint and version audit

Baseline date: **2026-08-08**. Refresh produces `diffs/YYYY-MM-DD_delta.md`; never overwrite the baseline or normalize differing units.

## 1. Canonical version targets

| Entity | Baseline pin | Refresh action | Material-change trigger |
|---|---|---|---|
| arXiv | `2606.05405v2`, 2026-06-11 | check abs/version history; diff HTML/PDF sections and appendices | v3+; count/protocol/metric wording changes |
| GitHub | `1e615e456de7cef57706680613cb80ee13c7fc76` | record new head; diff README, manifests, runner, loaders, agent configs, four tasks, evaluator commits | manifest/evaluator/lifecycle/config change |
| HF dataset | `a8c1fd174a1f6cfa76526572a2e3ebece1276be2`; LFS Parquet hash in S05 | pin new full SHA/LFS hash; recompute row/schema/taxonomy/split stats | rows/schema/repo-path/taxonomy change |
| Homepage | live 2026-08-08 | archive visible count/claims and links | 1.5K+/300+/55/5,000 target changes |
| Submit page | live 2026-08-08 | diff criteria, five-part schema, verification tree, terms | admission/evaluation/contributor rights change |
| Framework docs | live 2026-08-08 | diff lifecycle/providers/config/task lists/add-task contract | full/unlicensed/CLI counts; staging/retry/schema change |
| RDI blog | June 2026 page | diff updates/result framing | result/task/expert/job-ready statement change |
| Leaderboard | `ALE-V1` visible 2026-08-08 | record exact manifest/split/config/aggregation/result date, not only rows | benchmark version, best-of policy, metric/runtime/cost methodology change |

## 2. Count/unit ledger to refresh separately

- paper `workflow` / `instance` / `submission` / `commissioned task` / release-state counts;
- public release vs experiment distinct tasks vs tier memberships;
- GitHub README approximation vs published manifest vs experiment list vs task tree;
- HF task-card rows vs runnable instance data;
- expert/practitioner/author counts;
- domains/subdomains and residual `Other→Sports` display;
- agent runs, attempts, independent trials, best-of aggregation;
- licensed/unlicensed/CPU/GPU/CLI splits.

Never infer identity from equal numbers. Re-test whether a row-level crosswalk for the two `960`s has been published.

## 3. Technical drift targets

- task package/task-card schema, `load/start/evaluate` signatures and central score validation;
- reference staging modes, archive/mount/bucket/network isolation;
- provider/image/software/license/resolution/resource mappings;
- agent harness presets, model IDs, CLI versions, effort, tool/context/subagent policies;
- `max_attempts`, wall-time, retry/infra-invalid/repeated-trial semantics;
- task/evaluator blobs for AAPL, KiCad, MicroDicom, storyboard;
- judge model/prompt/renderer/API overrides and reproducibility;
- grader hardening/repaired tasks and replay/backfill policy;
- public traces: whether pinned trace IDs now exist for the four audited examples.

## 4. Validity/adversarial targets

- ALE-specific evaluator FPR/FNR, alternative-correct/known-bad/red-team studies;
- independent replication of harness/model sweeps;
- contamination/exposure/provider data-use/near-duplicate audits;
- complete repeated-run CIs, `pass@k`/`pass^k`, perturbation/reliability evidence;
- matched-human runs under identical ALE conditions;
- real deployment/productivity/economic outcomes and task-frequency weighting;
- newly reported benchmark gaming/leakage incidents.

## 5. Hypothesis re-open conditions

- **H1:** reopen if one canonical standardized-harness protocol makes model the sole varying component.
- **H2:** reopen if official released manifests count non-runnable submissions/cards as benchmark instances.
- **H3:** reopen if a revision-pinned crosswalk unifies paper/repo/HF/live counts or maps the two `960`s.
- **H4:** narrow only when evaluator/exposure/repeat/human/deployment evidence is available for the same new manifest and independently reproduced.

## 6. Delta template

```markdown
# YYYY-MM-DD ALE delta

- Previous pins:
- New pins:
- Source-by-source changes (do not merge units):
- Added/removed/renamed workflows and instances:
- Manifest/taxonomy/evaluator/config changes:
- Result changes under matched configuration:
- Validity/adversarial evidence changes:
- H1–H4 status changes:
- Impact on 1,000-asset product scope/SOW:
- Required migrations/replays/retirements:
```
