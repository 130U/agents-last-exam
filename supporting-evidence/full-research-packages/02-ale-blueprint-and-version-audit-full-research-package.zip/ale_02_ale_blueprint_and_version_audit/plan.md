# ALE version-pinned technical blueprint — research plan

- **Research date / access cutoff:** 2026-08-08 (America/New_York)
- **Object:** UC Berkeley RDI, *Agents' Last Exam* (ALE), arXiv `2606.05405v2`; exclude unrelated ALE / ALE-Bench.
- **Decision:** define a defensible scope and acceptance contract for producing about 1,000 ALE-style benchmark assets.
- **Genre:** technical blueprint + version audit + production decision memo.

## Falsifiable hypotheses

1. **H1 — system construct.** ALE results primarily measure a pinned end-to-end agent configuration (foundation model + harness + prompts/tools/context/computer control + environment + budget), not a bare foundation model. Refutation: official protocol exposes the same standardized harness and treats only the model as the varying evaluated object.
2. **H2 — task identity.** A countable ALE `task instance` is a runnable, versioned case bound to task specification, inputs, environment, hidden reference and executable lifecycle/evaluator; an expert submission or natural-language prompt alone is not yet a runnable instance. Refutation: official manifests count non-executable submissions/prompts as released tasks without implementation/QC.
3. **H3 — snapshot non-equivalence.** Paper, live site, GitHub, Hugging Face and leaderboard are different versioned surfaces; their counts/taxonomy/manifests/configurations cannot be collapsed. In particular, Figure 5's `960` external-submission variants and Appendix C.3.7's `960 workflows` are not established as the same statistical set. Refutation: a canonical mapping or revision-pinned manifest proves one-to-one identity.
4. **H4 — interpretation boundary.** ALE scores support evaluator-bounded claims about end-to-end task completion under the tested configuration, but do not alone establish human-level professional ability, labor productivity, job replacement or deployment reliability; evaluator weakness, data exposure and harness differences remain alternative explanations. Refutation: matched human baselines, external validity studies and robustness audits close those gaps.

## Required unit ledger

Every number will be tagged as one of: `benchmark`, `domain`, `subdomain`, `workflow`, `runnable task instance`, `expert submission`, `commissioned task`, `public/private/pending-QC instance`, `agent run`, `repeated trial`. Ambiguous numbers remain ambiguous rather than being normalized.

## Canonical starting sources

1. arXiv HTML `2606.05405v2`
2. official site
3. official submission page
4. official GitHub repository (commit-pinned)
5. official Hugging Face dataset (revision-pinned)
6. Berkeley RDI blog

ALE implementation facts use these primary sources. Cross-project validity claims require source-type diversity: primary paper/site, code/data, independent academic work, and—where useful—credible industry material. Multiple mirrors or restatements do not count as independent corroboration.

## Search blocks

- Paper definitions, counts, methods, appendices, metrics and both uses of `960`.
- Live site/submit/leaderboard snapshot and displayed agent configurations.
- Git commit, task tree, SDK/lifecycle (`load/start/evaluate`), runner, images, evaluator paths and public manifest.
- HF revision, row count, features, task identifiers, taxonomy and file-level metadata.
- Three to five official task traces from description/input/software/output/reference/evaluator through agent execution.
- Independent construct-validity evidence: agent benchmark sensitivity to scaffolding/harness, evaluator reliability/gaming, benchmark contamination, repeated-trial uncertainty and external-validity limits.
- Opposition queries: bare-model interpretation; workflow=instance; two-960 identity; public subset representativeness; evaluator false positives/false negatives; leaked references/tasks; configuration/retry/budget sensitivity; matched-human evidence.

## Risk register

- Living pages drift after 2026-08-08; record access date and visible revision/commit where available.
- `task`, `variant`, `instance`, `workflow`, `submission` may be used inconsistently even within one paper; preserve local wording and unit.
- Public data cannot reveal private references/evaluators; do not infer private-corpus proportions from public tasks.
- Leaderboard rows may bundle different harnesses/budgets/retries; do not rank foundation models without configuration controls.
- A repo checkout or HF `main` branch is mutable; pin SHA/revision before counting.
- Generated cost/timeline/allocation values would be unsupported; provide formulas and pilot variables, not invented point estimates.

## Stop criteria

- All six canonical sources are saved separately with metadata, quotations/evidence, scores and claim mapping.
- Each major ALE-specific claim is tied to a pinned primary source; each cross-project thesis has three source types or is marked `公开资料不足`.
- At least one adversarial pass tests H1–H4 and enumerates failure conditions.
- Version matrix, 3–5 task traces, system diagram, glossary, minimum schema, proof boundary table, 1,000-task interpretation, reusable checklist/formulas and refresh targets are complete.

## Change log

- 2026-08-08: initialized; prior ALE notes treated only as leads and scheduled for live re-verification.
