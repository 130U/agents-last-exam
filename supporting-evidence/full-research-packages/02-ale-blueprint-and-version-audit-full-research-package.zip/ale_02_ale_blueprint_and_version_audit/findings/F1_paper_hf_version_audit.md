# F1 — arXiv v2 + Hugging Face revision audit

## Bottom line

ALE v2 evaluates a **configured end-to-end agent system**, not a bare foundation model. A countable runnable ALE task is a concrete **task instance** bound to a workflow-level executable task specification, instance-specific input/reference data, a provisioned environment and `evaluate()`; one expert submission or one HF task card is upstream metadata, not equivalent to that runnable unit.

The two `960`s in v2 are different statistical labels. Figure 5 counts **960 external submissions** by provenance/review yield; Appendix C.3.7 counts **960 task workflows**. No published one-to-one crosswalk makes them identical. `1,490 / 960 ≈ 1.55` is descriptive of one inventory snapshot, not a production quota.

## Evidence labels used below

- **[F] Frozen-source fact:** directly stated/observable in arXiv v2 or pinned HF revision.
- **[C] Author claim:** ALE authors’ interpretation or quality assertion without independent validation here.
- **[I] Researcher inference:** follows from the evidence but is not explicit source wording.
- **[R] Project recommendation:** proposed acceptance/scope decision for a 1,000-asset program.

## 1. What ALE actually measures

**[F] Evaluation subject:** `agent = harness + foundation model`. The harness builds prompts/context, routes tools, controls GUI/CLI/file/API actions, can dispatch subagents, compacts context and terminates the loop. The task executes inside a configured VM; `evaluate()` scores resulting artifacts/state. Runs have a five-hour wall-clock cap in the reported experiment.

**[I] Operational construct:**

`task instance + task spec + VM/software + visible context + hidden reference/evaluator + agent harness + model + tool surface + context policy + budget/timeout + termination/retry policy → one run score`

Therefore a leaderboard row supports a claim about that complete configuration under that snapshot. It does not isolate the bare model unless harness, prompt, tools, environment, budget and evaluator are held fixed.

**[C] Paper interpretation:** ALE targets long-horizon, economically valuable, real-world professional work and argues that eventual saturation may signal industrial adoption/economic transformation. Those are benchmark-author claims, not consequences proven by the reported scores.

## 2. Glossary and unit contract

| Term | Version-pinned meaning | Countability / boundary |
|---|---|---|
| **benchmark** | ALE corpus, taxonomy, task/evaluator protocol, environment and reporting rules | One benchmark can contain many snapshots/manifests. |
| **domain / subdomain** | Taxonomy groupings; v2 says 13 domains and 55 workflow-level subdomains | Not tasks. HF row coverage is not taxonomy completeness. |
| **workflow** | End-to-end professional procedure; implementation-level unit is one `main.py` exposing shared evaluator/variants | v2 Appendix: 960 workflows. |
| **task instance** | One runnable case of a workflow: concrete input/output pair, instance config and hidden reference sharing workflow `evaluate()` | v2: 1,490 inventory instances; “task” usually means instance. |
| **expert submission** | Practitioner proposal/past project entering portal/review | Not executable until implementation and QC. Figure 5 labels 960 external submissions; do not equate with workflows. |
| **commissioned task** | Figure 5 provenance label for 530 items | Public mapping to workflow/instance schema is insufficient; preserve original label. |
| **task specification** | Executable `main.py` encapsulating description, input assets, required software, reference assets and evaluation criteria | Workflow-level executable contract. |
| **input** | Agent-readable assets in `input/` | Instance-specific bytes/paths, not merely HF descriptors. |
| **output** | Agent-created deliverable/artifacts in the sole writable `output/` target, or evaluated system/application state | Produced by a run. |
| **reference** | Ground-truth artifact/rubric in hidden `reference/` | Evaluator-only; leakage changes the construct. |
| **load()** | Purely declarative: returns visible description, metadata/config and compute/OS requirements | Defines task; no remote state mutation. |
| **start()** | Uses session API to create deterministic starting state: stage assets, configure/launch software | Begins environment preparation, not model inference. |
| **evaluate()** | After termination/timeout, retrieves artifacts/state and returns normalized `[0,1]` score | Shared at workflow level; must be versioned. |
| **environment** | Remote VM + OS/hardware/software + standardized directories and session interface | Part of test condition. |
| **agent** | Harness + foundation model | Not synonymous with model. |
| **run** | **[I] normalized definition:** one execution of one agent configuration on one task instance from prepared start state through termination/timeout and one evaluator result | A repeated trial is another run, not another task. |
| **Mean Score** | Mean fine-grained normalized task score (reported as percent) | Partial evaluator credit; not calibrated worker productivity. |
| **Full Pass Rate** | Fraction of evaluated tasks with full credit | Exact evaluator-bounded completion, not probabilistic reliability unless repeat policy/sample are specified. |
| **repeated trial** | Independent rerun of same instance/configuration | v2 shows 3-run SDs only for some configurations; total run count unpublished. |

## 3. Minimal complete ALE-style task schema

```yaml
benchmark_snapshot:
  benchmark_id: string
  release_id: string
  source_commit: string
  manifest_hash: string

taxonomy:
  domain_id: string
  subdomain_id: string
  workflow_id: string

workflow:
  description: string
  representativeness_evidence: [source_or_expert_record]
  shared_evaluator_version: string
  expected_software:
    - name: string
      version: string
      license_or_image_digest: string

instance:
  instance_id: string
  variant_config: object
  visible_inputs:
    - path: string
      sha256: string
      read_only: true
  expected_output_contract:
    - path_or_state: string
      format: string
      required: true
  hidden_references:
    - evaluator_only_path: string
      sha256: string

task_specification:
  main_py_hash: string
  load_contract:
    visible_prompt: string
    metadata: object
    os_hardware_requirements: object
  start_contract:
    initial_state_hash_or_recipe: string
    software_launch_steps: [string]
  evaluate_contract:
    evaluator_hash: string
    artifact_modes: [exact, structured, geometric, visual, behavioral, semantic, executable]
    gates: [string]
    tolerances_or_rubric: object
    score_range: [0, 1]

run_protocol:
  agent_harness: string
  harness_version: string
  foundation_model: string
  model_snapshot: string
  system_prompt_hash: string
  tools_and_permissions: object
  context_compaction_policy: object
  vm_image_digest: string
  wall_clock_cap: duration
  token_or_cost_budget: object
  retries: integer
  random_seed_policy: string

acceptance:
  expert_reference_reviewed: boolean
  engineer_dry_run_passed: boolean
  evaluator_false_positive_tests_passed: boolean
  evaluator_false_negative_tests_passed: boolean
  leakage_scan_passed: boolean
  reproducibility_run_ids: [string]
```

**[R] Minimum countable delivery:** do not count an asset as a runnable instance until hashes/versions for visible inputs, start environment, hidden reference and evaluator exist and a dry-run plus adversarial evaluator QA passes.

## 4. Paper ↔ HF version matrix

| Dimension | arXiv `2606.05405v2` | HF `a8c1fd174…` | Audit conclusion |
|---|---|---|---|
| Revision/date | v2, 2026-06-11 | verified commit head checked 2026-08-08; dataset `v1.0` | Separate snapshots; labels `v2` and `v1.0` are not shared release numbering. |
| Workflow/instance size | 960 workflows / 1,490 instances | no workflow count; 153 task-card rows | HF rows are metadata assets, not inventory instances. |
| Provenance | 960 external submissions + 530 commissioned tasks | submission/commission fields absent | Cannot crosswalk or infer conversion yield. |
| Release state | 150 public, 1,017 private, 323 pending QC | 153 open metadata rows | Later public-card surface differs; no published row-level crosswalk. |
| Experiment set | 152 distinct public tasks; 67/55/38 tier memberships | 67/47/38 single labels + 1 blank | Full-Spectrum membership overlaps/changes; HF single label cannot recreate v2 manifest. |
| Expert count | 250+ experts in abstract/introduction; 300+ practitioners in §5 | no expert-count field | Even v2 has two author-reported thresholds; author count/submission count are different units. |
| Taxonomy | 13 domains/55 subdomains; Figure 2 residual `Other→Sports` | 14 observed structured domain codes, 51 represented mappings | HF public coverage/schema ≠ complete paper taxonomy. |
| Task manifest | executable `main.py`, variants, assets, refs, evaluator | card fields and repo path | Card is discovery/documentation layer only. |
| Evaluator | `[0,1]`, artifact-specific, host/VM, deterministic or narrow judge | evaluator omitted | HF cannot independently reproduce scores. |
| Environment | Windows/Linux VM, hardware/software, four-directory contract | software names + input descriptors only | Missing image/version/provisioning. |
| Agent/config | harness + model + GUI-as-Tool, tools/context/budget | absent | Scores cannot be attributed to model from HF metadata. |
| Metrics | Mean Score, Full Pass Rate, cost/time/tokens; some 3-run SDs | absent | No metric equivalence on HF card surface. |

## 5. The `960` trap

```text
Figure 5 provenance surface:
  1,490 instance records shown = 960 external submissions + 530 commissioned tasks

Appendix C.3.7 implementation surface:
  960 workflows ──VARIANTS/shared evaluate()──> 1,490 runnable instances
```

**[F]** The labels and denominators differ. **[I]** Equality may be accidental or reflect an unpublished pipeline relation, but the paper does not prove which. **[R]** A 1,000-asset SOW must name the counted unit and conversion funnel; never set `960 workflows` because ALE has a visually matching `960 submissions`.

## 6. What ALE can and cannot support

| Supported, if version/config is pinned | Not supported by ALE scores alone |
|---|---|
| Evaluator-bounded completion of the sampled ALE instances | Bare-model ability independent of harness/prompts/tools/context/budget |
| End-to-end artifact production under specified VM/tool conditions | Human-level professional competence or expert-time equivalence |
| Relative comparison of configurations when task/evaluator/budget are controlled | General job replacement, GDP impact or organization-level productivity |
| Partial vs full rubric satisfaction via Mean Score/FPR | Deployment reliability without repeated trials and operational monitoring |
| Capability on public or hidden instances of a documented snapshot | Unseen-work generalization if tasks/references/evaluators leaked or were optimized against |
| Coverage across v2 taxonomy labels | Economic representativeness of a 1,000-task client corpus without its own sampling frame |

## 7. Counterevidence and failure conditions

- **Evaluator weakness:** code/rubric may be spuriously permissive, overly narrow, or miss semantic correctness. ALE reports QC and deterministic preference, but public evidence does not independently estimate false-positive/false-negative rates across 1,490 instances.
- **LLM judge drift:** v2 says 6.8% of open workflows use LLM judges and records model/prompt; reproducibility still depends on judge snapshot and nondeterminism.
- **Leakage/task-specific optimization:** public prompts/cards and some reference access surfaces increase exposure risk. A high public score may reflect optimization, not generalization; private holdout policy must be verified per release.
- **Harness difference:** model and harness effects can both change scores. The paper’s own ablation is limited to evaluated systems and cannot make model-only claims universal.
- **Budget/retry difference:** five-hour cap, tool permissions, VM resources, context policy and retries affect outcome. A leaderboard comparison fails if these are not controlled.
- **Single-run noise:** most configurations are not reported with repeated trials; Full Pass Rate from one attempt is not pass probability.
- **Public representativeness claim:** `r=0.89` is one agent/configuration and domain-cluster aggregation. It does not prove proportional domain/source/difficulty sampling or generalize to a future snapshot.
- **Snapshot counts:** 150, 152 and 153 are all real on different surfaces/roles; none is a production quota. Likewise 250+, 300+, 960 submissions, 960 workflows and 310 paper authors are different units.

## 8. Rigorous interpretation of “一千道题”

**[R] Most defensible interpretation:** “约 1,000 个 ALE-style benchmark assets” is a delivery portfolio, not automatically 1,000 workflows or 1,000 runnable instances. Contract it as:

```text
W = accepted workflow specifications
I = runnable instances after engineering + QC
S = expert submissions entering review
C = commissioned source projects
R = agent runs executed for validation/evaluation

I = Σ instances_per_accepted_workflow
submission_to_instance_yield = I_accepted_from_submissions / S
commission_to_instance_yield = I_accepted_from_commissions / C
QA_runs = I × configurations × repeats + adversarial_evaluator_runs
```

Do not assign numeric values to `W:S:C:R`, acceptance rate, experts, time or cost from public ALE counts. Public material is insufficient. A pilot must estimate: expert proposal yield, engineering hours per environment/evaluator mode, instance multiplicity distribution, reference/evaluator defect rates, rerun variance, licensed-software/VM costs and QC rework loops.

Suggested SOW wording:

> “Target ≈1,000 accepted runnable task instances across an explicitly approved workflow portfolio. Each accepted instance includes a versioned specification, visible inputs, deterministic start state, hidden reference, executable evaluator, environment manifest, expert/engineering QA evidence, and release/holdout designation. Workflow count and submission volume are pilot-derived, separately reported units.”

## 9. Hypothesis status for this audit slice

- **H1 system construct — supported.** v2 explicitly defines agent as harness + model and makes tools, VM, prompt/context loop and budget part of the tested configuration.
- **H2 task identity — supported.** v2 lifecycle and HF omissions show that a card/submission is not sufficient for a runnable instance.
- **H3 snapshot non-equivalence — supported.** 150/152/153, 55 vs 51 represented mappings and the two 960 labels demonstrate non-equivalence; no canonical crosswalk was found.
- **H4 interpretation boundary — supported for the negative boundary; positive economic validity underdetermined.** v2 provides evaluator-bounded task evidence, not matched human/productivity/job/GDP validation.

## 10. Questions requiring client/interviewer confirmation

1. Does “1,000” count submitted concepts, accepted workflow specs, runnable instances, public cards, or fully QA’d hidden-holdout instances?
2. Is each workflow required to support multiple instances? If yes, what variation must remain capability-equivalent and what is the minimum/maximum multiplicity?
3. Which outputs are public: prompt/card, input data, environment recipe, evaluator, reference? What is the rotation/retirement policy?
4. Is evaluation system-level or must a foundation model be isolated under one fixed harness? What are tool, context, budget, retry and timeout policies?
5. What evaluator error tolerance and adversarial QA evidence is required before acceptance?
6. Who owns licensed software, VM images, private reference data and evaluator keys/models?
7. Must taxonomy weights follow client workforce/economic priorities, risk coverage, or balanced capability coverage? Public ALE snapshots do not supply a defensible allocation quota.

## Source files

- `sources/01_arxiv_2606_05405v2.md`
- `sources/05_huggingface_task_cards_a8c1fd1.md`

