# F2 — 固定 GitHub commit 的 ALE runtime、task contract 与四条官方 task trace 审计

## 结论先行

研究对象固定为 `rdi-berkeley/agents-last-exam` 的 `main@1e615e456de7cef57706680613cb80ee13c7fc76`，commit 时间为 2026-08-05T19:19:49Z，访问日为 2026-08-08。[S07]

本文件使用四种标签，避免把实现事实、作者主张和项目建议混在一起：

- **[事实]**：固定 commit 的代码、配置、manifest 或 task package 直接证明。
- **[ALE 主张]**：README/注释/任务卡的维护者描述，但没有由本次代码审计独立验证。
- **[推断]**：研究员由多段代码共同推出，明确指出推理边界。
- **[建议]**：面向 1,000-asset 项目的产品/生产决策。

最重要的五个结论：

1. **[事实] ALE 的被测对象不是裸 foundation model。** 一个 run unit 绑定 `agent preset/model/harness/executor`、task workflow/variant、sandbox snapshot/software、prompt、tools/GUI/CLI transport、wall-time/turn/budget 等运行条件，再由 task-specific evaluator 打分。[S07][S08][S10]
2. **[事实] `workflow`、`runnable task instance`、`agent run` 是三个不同单位。** 官方 task docs 把一个 `main.py` 定义为一个 workflow 加共享 grading logic；`load()` 返回的一个 variant 是具体配置入口；runner 再做 agent × task × variant 的笛卡尔积形成 run unit。[S09][S10]
3. **[事实] 同一个 Git commit 内也不存在单一“public task 数”。** README 写 “around 150”；`tasks/published_tasks.json` 有 153 个 key/153 个公开 variant；`selected_tasks/full.txt` 有 152 条；tree 中有 157 个 non-demo `main.py`，其中四个未列入 published manifest。[S07][S15]
4. **[事实] task card 的自然语言 evaluation 不能替代读取真实 evaluator。** MicroDicom 的 task card 说 adjudication log 与隐藏 reference 精确匹配，但代码忽略 `resolution_basis`；storyboard task 定义了 `reference_storyboard`，实际 grader 从未读取它，而是让 LLM 从候选文档回答十道选择题。[S13][S14]
5. **[推断] Artifact score 只能证明“通过了这个版本的 evaluator”，不能自动证明 agent 实际使用了指定软件、执行了完整专业 workflow、没有看过公开 grader/答案，或具备等同人类专家的能力。** 公开 package 没有四个示例的实际 run trajectory；其 evaluator 通常只看最终文件。[S11]–[S14]

**四例的“agent 实际执行路径”结论：underdetermined。** 公开 repo/site 没有与这四个 task instance 绑定、同时固定 `trace_id/run_id + agent config + environment + evaluator revision` 的官方 trajectory。本文件因此只给出 framework code 能证明的 lifecycle 与 task prompt/evaluator 所规定的 intended/code-mandated path；任何逐步点击、命令、软件使用顺序都不能写成已发生的事实。

---

## 1. Version pin 与 repo 内部 inventory matrix

| GitHub surface（同一 commit） | 单位 | 固定快照结果 | 可否当作 ALE 总量 |
|---|---:|---:|---|
| `README.md` | 近似 public tasks | “around 150” | 否；近似宣传/说明文本 |
| `tasks/published_tasks.json` | manifest workflow keys | 153 | 仅能表示该文件在该 commit 的 keys |
| `tasks/published_tasks.json` | listed public variants | 153 | 仅能表示该 manifest 的 runnable variant entries |
| `selected_tasks/full.txt` | 默认 full list task paths | 152 | 仅能表示这份 experiment list |
| `tasks/**/main.py`，排除 demo | repo 内 workflow packages | 157 | 否；其中四个未发布到 published manifest |
| public repo 的 private/pending-QC manifest | instance | 未发现 | **公开资料不足**，不能从 repo 反推 |

**[事实]** `published_tasks.json` 与 `full.txt` 的唯一差项是 `engineering/2d_drawings_to_3d_bridge_model`：前者包含，后者不包含。[S15]

**[事实]** `published_tasks.json` 在该 commit 中每个 workflow key 恰有一个公开 variant，但 variant 名并不都叫 `base`，也有 `images`、`variant_1`、`table2` 等。[S15]

**[推断]** 这个快照恰好接近“一 workflow 对一公开 variant”，不能据此把 workflow 与 instance 视为同义，也不能推导“每个 workflow 只能/应该生产一个 instance”。

**[建议]** 任何数量表都必须带五列：`surface`、`commit/revision`、`accessed_at`、`counted_unit`、`selection rule`。不要把 README、published manifest、experiment list、全部 repo code、paper corpus 或 private pool 合并成一个数。

---

## 2. 关键定义：代码层面到底什么才算一条 ALE task

### 2.1 Workflow

**[事实]** 官方 docs 的原始定义是：一个 `main.py` 对应一个 workflow 与一套通用 grading logic；variants 在不同具体 inputs 上复用该逻辑。[S09]

**[推断]** workflow 是“可复用的专业过程/能力模板”，不是某一次输入，也不是某一次 agent execution。

### 2.2 Task specification

**[事实]** public repo 中一条可发现的 task 至少有：

- `tasks/<domain>/<task>/main.py`：`load()`、`start()`、`evaluate()`；
- `task_card.json`：title/summary/prompt、input/output prose、software、VM snapshot/timeout、taxonomy；
- task-data identity：`domain_name/task_name/variant_name`；
- agent-visible `input/` 和可选 `software/`；
- agent-hidden `reference/` 或不依赖 reference 的 structural/judge evaluator；
- output path 与 score contract。[S09][S10]

**[推断]** `task_card.json` 不是完整 spec 的唯一真相。它必须与 `main.py`、scorer、实际 data manifest 和 environment snapshot 联合审计；AAPL 与 MicroDicom 已显示 card/code 语义不完全一致。[S11][S13]

### 2.3 Runnable task instance

**[事实]** `load()` 返回 `cb.Task` 列表，`variant_index` 选中其中一个；loader 再合并 prompt/metadata/computer、task-data paths 与 task-card VM 配置。[S09]

**[推断]** runnable instance 是：

`workflow code + selected variant + concrete input payload + hidden reference/evaluator inputs + environment snapshot + output/evaluation contract`。

它不是“题目文本”，也不是“专家提交”。缺任意一项都可能只有 task idea 或 task specification draft，而不是可执行 instance。

### 2.4 Input / output / reference

- **[事实] Input**：在 agent run 前进入 sandbox，对 agent 可见。
- **[事实] Output**：agent 在规定路径留下的最终 artifact/application state；是否拉回 host 由 `output_path` 控制，但 evaluator 可以直接在 sandbox 读取。
- **[事实] Reference**：grader 的隐藏 truth/artifact。baked image 用加密 `reference.7z`，只在 evaluation phase 解密；local/Docker 和 GCS backend 主要靠“agent 完成后才 stage”隐藏。[S10]
- **[事实]** 并非每条 task 都必须读取 hidden reference；KiCad 使用 DRC + structural checks，storyboard 使用 visible questions + public answer key + LLM judge。[S12][S14]

### 2.5 `load()` / `start()` / `evaluate()`

| Hook | 代码事实 | 不应误解为 |
|---|---|---|
| `load()` | discovery 时返回一个或多个 `cb.Task`；每个携带 prompt、metadata、computer/OS | 不执行 agent，不是一次 run |
| `start(cfg, session)` | input 已 stage 后，在 fresh sandbox 中完成 task-specific setup、开 app/建目录/注入凭据等 | 不等于生成 reference；通常不应让 reference 可见 |
| `evaluate(cfg, session)` | agent 完成、reference stage 后读取 outputs/reference 并返回 `list[float]`/dict/scalar | 不保证 evaluator 覆盖 prompt 的每条要求 |

**[事实]** `TaskDriver` 对 `list[float]` 只取第一项作为主 score；core lifecycle 把值转换为 float，但不统一 clamp 到 `[0,1]`。[S09][S10]

### 2.6 Environment

**[事实]** environment 是 provider + snapshot/image + OS/software/data substrate。task card 提供 logical snapshot，environment config 把它映射到 GCloud/Docker/QEMU/static 等 provider，并可固定 Windows resolution、GPU、licensed image 等。[S07][S10]

**[推断]** 同一个 model/harness 在不同 image、软件版本、分辨率、权限、网络或 license 条件下不是同一 evaluation condition。

### 2.7 Run 与 repeated trial

- **[事实] Run unit**：一个 `agent_id × task_path × variant_index` 组合。[S10]
- **[事实] Attempt**：`max_attempts` 只对 `failed` unit 重新排队；已经 completed 的 unit 不会为了统计稳定性重复运行。[S10]
- **[推断] Repeated trial**：若要测 stochastic reliability，应显式新增 `trial_id/seed` 并对同一完整配置独立运行多次；不能把 failure retry 当 trial。

---

## 3. ALE system diagram（GitHub runtime 视角）

```mermaid
flowchart LR
  subgraph X["Experiment spec"]
    A["Agent preset\nmodel, harness, executor, tools, context, budgets, versions"]
    E["Environment profile\nprovider, snapshot, OS, software, resolution, resources"]
    T["Task selection\nworkflow path + variant index"]
  end

  A --> U["Run unit\nagent × workflow × variant"]
  E --> U
  T --> U
  U --> P["Provision fresh sandbox"]
  P --> I["Stage agent-visible input/software"]
  I --> S["start(cfg, session)"]
  S --> G["Give task description to agent harness"]
  G --> R["Agent loop\nCLI + GUI/CUA + memory/context + tools"]
  R --> O["Output artifacts / final app state + raw logs"]
  H["Hidden reference\nencrypted or withheld by timing"] -. "not available during agent run" .-> R
  H --> J["Stage/decrypt reference after agent finishes"]
  O --> J
  J --> V["task evaluate()\ndeterministic, structural or LLM/VLM judge"]
  V --> Q["Per-run score + eval result + unified trajectory"]
  Q --> C["Cleanup sandbox"]
```

**[事实]** prompt suffix、wall time、harness tool restrictions、turn limits、judge model 等都能改变这条 pipeline 的 observable result。[S08][S10][S14]

---

## 4. End-to-end lifecycle（可复现 phase trace）

| Phase | 固定 commit 的实现 | 关键 QA 点 |
|---|---|---|
| 0 Provision | 读 task metadata，选 snapshot/provider，创建 sandbox | image/OS/resources/resolution/version 必须记录 |
| 1 Stage + start | stage `input/`/`software/`，构建 `TaskDriver`，调用 `start()` | reference absence、input hashes、setup idempotency |
| 2 Agent | 将同一 `task_meta["description"]`交给 deployer；harness 在 wall-time 内运行 | harness/model/CLI/tool/context/budget/prompt suffix 必须 pin |
| 2b Gather logs | 拉取/合并 deployer hot artifacts/raw logs | 轨迹丢失不能默认为 task 成功 |
| 3a Output handling | 可不拉回、拉到 local、或推到 object storage | gather 失败不必然等于 evaluator 失败；需分别记状态 |
| 3b Reference | agent 结束后 stage/decrypt reference | 记录 reference hash 与 isolation proof |
| 3c Evaluate | `TaskDriver.evaluate()`，提取主 score；随后 parse artifacts/trajectory | evaluator code/data/judge revision、infra error 与 task failure分离 |
| 4 Cleanup | 关闭 task driver 与 environment；delete/stop/keep 由 config 控制 | 失败时保留诊断资产的策略 |

**[事实]** 多个样例 evaluator 在 reference 缺失、grader CLI 不可用、judge exception 等情况下直接返回 `[0.0]`。[S11]–[S14]

**[推断]** 如果没有独立 `eval_status/infra_error`，0 分会混合“agent 输出错误”和“评测基础设施失败”；生产 acceptance 不能只看 score。

---

## 5. 四条官方 public task：task spec、evaluator 与可证明执行路径

### 5.1 Business/Finance — Apple FY2024 Balance Sheet

| 字段 | 固定 commit 证据 |
|---|---|
| Task description | 从 Apple FY2024 10-K 重建 Consolidated Balance Sheet，单位为 USD millions |
| Input | PDF、SEC HTML、output schema、source notes、task metadata |
| Software/environment | Linux `cpu-free-ubuntu`；Python/pdftotext/grep wrappers；task-card timeout 7,200s |
| Expected output | `base/output/balance_sheet.json` |
| Hidden reference | `reference/aapl_fy2024_balance_sheet_reference.json`（由 `main.py` 定义，不是 card 的 output-style `referenceFiles`） |
| Evaluator | metadata gates + `consolidated_balance_sheet` numeric leaves exact Decimal comparison；score = correct numeric fields / expected numeric fields |
| Agent path | **只有 code-implied path**：框架交付 prompt/inputs；agent 可选择 PDF/HTML 与 wrappers；留下 JSON；之后 reference 才 stage，scorer 运行 |

**[事实]** scorer 还计算 `accuracy >= 0.95` 的 `pass_fail`，但 task `evaluate()` 返回的是连续 `score`，不是该 boolean。[S11]

**[边界]** repo 没有这条 task 的实际 trajectory，不能声称某个 agent 确实使用了 `pdftotext`、阅读了完整 10-K 或遵循某一人工 workflow。

### 5.2 Engineering — KiCad Mini Encabulator PCB

| 字段 | 固定 commit 证据 |
|---|---|
| Task description | 从 schematic 创建完整 routed PCB，四个安装孔、Edge.Cuts、双面 GND zone、stitching vias、零 DRC/unconnected |
| Input | `mini_encabulator.kicad_sch` 与 `OpenKiCad.bat` |
| Software/environment | Windows `cpu-free`；KiCad 10 package；task-card timeout 7,200s |
| Expected output | `mini_encabulator.kicad_pcb` |
| Hidden reference | 当前 evaluator 不读取 hidden golden PCB；card 的 `referenceFiles` 描述的是期望 output |
| Evaluator | KiCad CLI DRC + 文本结构检查。DRC fail=0；DRC pass 且所有结构项 pass=1；DRC pass 但结构项 fail=0.5 |
| Agent path | **只有 code-implied path**：agent 可用 KiCad GUI/CLI生成文件；框架不强制或证明 GUI 操作序列；grader复制文件后跑 DRC/parse |

**[反例]** `Edge.Cuts` 只检查字符串存在；代码没有明确检查 enclosure fit、完整 component placement 或 closed outline geometry。DRC 能覆盖部分电气问题，但不能补齐全部 prompt 语义。[S12]

### 5.3 Health/Medicine — MicroDicom NIH CXR Reader Adjudication

| 字段 | 固定 commit 证据 |
|---|---|
| Task description | 对 9 个 CXR case 的 reader A/B boxes 做影像 adjudication |
| Input | rules、case manifest、两份 reader TSV、clinical notes、DICOM cases |
| Software/environment | Windows `cpu-free`；MicroDicom launcher；task-card timeout 7,200s |
| Expected output | `adjudicated_boxes.tsv`、`adjudication_log.tsv`、`final_impressions.tsv` |
| Hidden reference | 同名三份 reference TSV |
| Evaluator | boxes：case set/reader exact + IoU ≥ 0.50；log：部分字段 exact；impressions：full table exact；score = 三个文件 pass 比例 |
| Agent path | **只有 code-implied path**：prompt 要求打开 MicroDicom逐例看图，但 evaluator 只读 TSV；成功 artifact 不能证明软件实际被使用 |

**[关键 mismatch]** task card 声称 adjudication log exact match，但实现比较 keys 只有 `case_id/selected_reader/disagreement_type`，完全忽略 `resolution_basis`。prompt 已公开固定 impression labels，因此该组件的部分答案结构是公开的。[S13]

### 5.4 Visual Media — Vintage Animation Shot Log

| 字段 | 固定 commit 证据 |
|---|---|
| Task description | 完整观看 1931 OGV，结合 fact-check brief，生成带 shot/segment ID、in/out time、事实描述的 DOCX；不得直接回答 brief |
| Input | source OGV、question DOCX |
| Software/environment | Windows `cpu-free`；VLC、LibreOffice/DOCX editor；task-card timeout 7,200s |
| Expected output | `storyboard.docx` |
| Hidden reference | config 定义 `reference_storyboard.docx`，但实际 evaluator 不读取 |
| Evaluator | 提取 candidate/question DOCX 文本；LLM 从 candidate 回答 Q1–Q10；与公开 `ANSWER_KEY` 比较；score = correct/10 |
| Agent path | **只有 code-implied path**：agent 被要求看视频/写 DOCX；grader 不检查视频、reference storyboard 或轨迹，只检查 candidate 文本能否让 judge 答对十题 |

**[强反例]** 当前实现不直接验证 temporal order、timestamps、完整观看、video-groundedness 或“不要回答问题”；公开 grader/answer key 允许直接针对十个答案优化。[S14]

**[复现风险]** judge 默认为 `gpt-5.4`，但环境变量可覆盖。未 pin judge model/API/version 的两个 run 不是同一 evaluator condition。

---

## 6. Evaluator weakness、数据泄漏与 harness difference 风险

| 风险 | 代码证据 | 可能造成的假阳性/假阴性 | 必须记录/修复 |
|---|---|---|---|
| Public grader gaming | Storyboard answer key 与 scoring prompt 全公开 | 不执行视频 workflow 也可能高分 | private holdout grader；adversarial submissions；grader exposure 标记 |
| Prompt/evaluator coverage gap | KiCad 未覆盖 enclosure fit；MicroDicom 忽略 rationale | artifact 通过但专业要求未完成 | requirement→check traceability matrix；未覆盖项不得宣称已测 |
| Infrastructure zero conflation | 多个 evaluator catch exception 后 `[0.0]` | reference/judge/CLI 故障被算成 agent failure | 独立 `eval_status`, `infra_error`, `score_valid`；infra failure 不入模型均值 |
| Judge drift/bias | Storyboard judge 可通过 env 覆盖 | 同一 output 不同时间/模型得分不同 | pin judge model/revision/prompt/API；calibration set + human audit |
| Reference isolation dependency | baked 用加密，local/GCS 用时序隔离 | 密码、host mount、bucket ACL 或 image 污染可泄漏答案 | pre-run reference scan；least privilege；reference hash；隔离审计 |
| Task-card/code mismatch | AAPL hidden reference path、MicroDicom exact-match描述不等于代码 | QA 审错合同或错误解释 score | card/scorer contract lint；生成式 docs 从 evaluator schema 导出 |
| No central score range enforcement | lifecycle 仅 float conversion | buggy task 可返回越界 score | framework clamp 前先 fail closed；schema validation `[0,1]` |
| Harness differences | 15 presets的 turn/tool/context/executor/version差异巨大 | “model差异”其实是 harness/tool/budget差异 | 结果主键包含完整 agent config hash |
| Retry selection | 只重试 failed，不重复 completed | failure-recovery 与统计 trial 混淆 | 分开 `attempt_id`、`trial_id`，公开 aggregation rule |
| Output-only construct | MicroDicom/storyboard不看轨迹 | 不能证明指定软件或过程被使用 | 若过程本身是 construct，加入 trajectory/process evidence；否则只声明 outcome 能力 |

**[事实]** 2026-08-05 merge 前后有 “prevent schema-only grader false zeros”“sync repaired Blender evaluators”“validate semantic A/B test recommendation”等 evaluator 修复 commit。[S16]

**[推断]** grader revision 足以改变结果，即使 model/harness/output 不变；因此 evaluator code hash 是 benchmark version 的组成部分，而不是实现细节。

---

## 7. 这份 repo 能证明什么 / 不能证明什么

| 可以由固定 commit 直接证明 | 不能由固定 commit 单独证明 |
|---|---|
| 公开 framework 的 task discovery、run-unit 与 lifecycle 实现 | 私有 instance 数、pending-QC 数、完整生产库存 |
| public manifest/list/tree 在该 commit 的各自成员与数量 | 哪个 manifest 是商业项目应该采用的配额 |
| 四个 task 的 prompt、环境要求、output、实际 evaluator code | 某个 agent 在一次真实 run 中执行了哪些动作（缺 trajectory） |
| reference 的 intended staging/isolation机制 | 不存在任何泄漏、训练污染、ACL/镜像配置错误 |
| harness presets 的模型、executor、turn/tool/context/version差异 | model 本体脱离 harness 的“纯能力” |
| 某 output 是否通过该 evaluator 的逻辑 | 完成真实岗位、达到人类专家、提高生产率或替代劳动 |
| per-run score 的生成方式 | Mean Score / Full Pass Rate 的跨任务统计定义与历史结果；核心 repo 未提供统一聚合实现 |

**[ALE 主张]** README 把环境称作 faithfully reproduces real production context，并把不同 agents 的 artifact completion 视作可比轴。[S07]

**[推断]** 这些主张只有在 environment fidelity、evaluator validity、reference isolation、task representativeness 和 configuration parity 同时成立时才成立；四个 task 反例说明 evaluator coverage 必须逐 task 验证，不能从框架设计自动外推。

---

## 8. ALE-style task 的最小完整 schema（repo-derived，供主报告复用）

```yaml
benchmark_revision:
  benchmark_id: agents-last-exam
  repo_commit: <40-char SHA>
  task_manifest_id: <path + blob SHA>
  accessed_at: <ISO date>

identity:
  workflow_id: <domain/task>
  workflow_version: <main.py blob SHA>
  variant_name: <semantic variant id>
  variant_index: <load() list index>
  runnable_instance_id: <immutable id>
  source_type: commissioned | expert_submission | other
  visibility: public | private | validation | pending_qc

task_spec:
  title: <string>
  domain: <versioned taxonomy id>
  subdomain: <versioned taxonomy id>
  task_description: <exact prompt>
  prompt_suffix: <exact experiment suffix or empty>
  required_actions: [<auditable requirement>]
  input_manifest:
    - {path: <sandbox path>, sha256: <hash>, visible_to_agent: true}
  software_manifest:
    - {name: <software>, version: <version>, launcher: <path>, license: <class>}
  output_contract:
    - {path: <required path>, format: <type>, schema: <schema id>}

environment:
  provider: <gcloud|aws|aliyun|docker|qemu|static>
  snapshot: <logical snapshot>
  image_digest: <immutable digest/id>
  os: <name/version>
  cpu_gpu_memory_disk: <resolved resources>
  display_resolution: <WxH or null>
  network_policy: <policy id>
  locale_timezone: <values>

hooks:
  load_entry: <file/function/blob>
  start_entry: <file/function/blob>
  evaluate_entry: <file/function/blob>

reference_and_evaluator:
  reference_manifest:
    - {path: <hidden path>, sha256: <hash>, owner: <role>}
  isolation_mode: encrypted_baked | staged_after_run | none
  evaluator_type: deterministic | structural | llm_judge | vlm_judge | hybrid
  evaluator_code_hash: <hash>
  judge_model_prompt_revision: <fully pinned or null>
  score_range: [0.0, 1.0]
  score_components: [{name: <component>, weight: <number>, gate: <rule>}]
  full_pass_rule: <exact boolean rule>
  missing_output_semantics: <rule>
  infrastructure_failure_semantics: <separate non-score status>

run_config:
  agent_id: <id>
  foundation_model: <provider/model/revision>
  harness: <name/version>
  executor: <sandbox|local|docker>
  tools_and_transports: <CLI/GUI/CUA/MCP/web/subagents>
  context_memory_compaction: <config hash>
  reasoning_effort: <value>
  wall_time_s: <value>
  turn_token_cost_budgets: <values>
  attempt_id: <retry identity>
  trial_id: <independent repeat identity>
  random_seed: <value or null>

qa_and_acceptance:
  spec_to_evaluator_traceability: <artifact>
  positive_negative_adversarial_fixtures: <ids>
  reference_isolation_check: <status/evidence>
  environment_smoke_test: <status>
  evaluator_calibration: <status>
  trajectory_and_artifacts: <locations/hashes>
  acceptance_status: accepted | rejected | infra_invalid | pending_qc
```

**[建议]** `runnable_instance_id`、`agent run id`、`attempt_id`、`trial_id` 必须是不同字段；否则 1,000-task scope、重试成本和统计样本量会被系统性混淆。

---

## 9. 对 1,000-task 项目的直接决策影响

### 9.1 最严谨的“一千道题”解释

**[建议]** 默认把合同中的“一千道题”解释为 **约 1,000 个通过 acceptance 的 runnable task instances/assets**，而不是：

- 1,000 个 workflow；
- 1,000 个自然语言 prompts；
- 1,000 个 expert submissions；
- 1,000 次 agent runs；
- public/private/pending 三个状态的混合总数。

同时必须单列：

`workflow_count`、`instance_count`、`instances_per_workflow distribution`、`public/private/validation/pending-QC split`、`agent_runs_per_instance`。

### 9.2 Asset acceptance definition

**[建议]** 只有同时满足以下条件，才计为一个交付 asset：

1. immutable identity 与 version pin 完整；
2. exact prompt/input/software/output/reference/evaluator schema 完整；
3. 指定 environment 能 provision，`start()` 可重复执行；
4. reference 在 agent phase 不可见；
5. positive fixture、negative fixture、schema-only、empty output、adversarial gaming tests 均通过预期；
6. task card 与 evaluator 的 requirement coverage traceability 已审签；
7. evaluator infra failure 不被记为 agent 0 分；
8. 至少一次完整 harness smoke run 产生 score、trajectory、logs、artifact hashes；
9. 专家与 QA reviewer 完成独立验收；
10. visibility/holdout/rotation policy 已分配。

### 9.3 生产流程中必须新增的 QA gate

- **Contract lint**：task card 的每条 must-do 映射到 evaluator check 或明确标为“未评分要求”。
- **Evaluator mutation test**：改变一个 requirement 的正确/错误字段，score 应按设计单调变化。
- **Gaming test**：只填 public schema、复制 prompt 固定值、嵌入公开答案、伪造字符串 token、避开指定软件，分别测试是否获得不当 credit。
- **Infra split**：reference missing、CLI missing、judge auth/model retired、timeout、parser crash 必须产生 `infra_invalid`，不能落成普通 0 分。
- **Harness parity**：至少在目标 harness/config 上 smoke；GUI 分辨率、tool transport、CLI version 与 turn/budget 固定。
- **Reference security**：构建后自动扫描 agent-visible filesystem；验证 archive/mount/bucket ACL；记录 stage timing。
- **Run audit**：artifact-only construct 可以只评 outcome；若客户要求“必须使用某软件/过程”，必须把 trajectory/process evidence 加入 evaluator，而非从 output 猜。

### 9.4 成本、工期、通过率与配额

**[事实]** public repo 能提供 7,200 秒 task-card timeout、运行配置与 evaluator complexity，但没有公开的 per-task 专家工时、QA 工时、基础设施单价、返工率或 production throughput。[S11]–[S14]

**[建议]** 不编造精确人天/成本/排期。先用 pilot 估计这些变量：

- `hours_spec`, `hours_data`, `hours_environment`, `hours_evaluator`, `hours_expert_review`, `hours_qa`, `hours_rework`；
- `fixture_failure_rate`, `evaluator_false_positive_rate`, `evaluator_false_negative_rate`；
- `vm_minutes_per_valid_run`, `judge_calls_per_eval`, `storage_gb`, `run_retry_rate`；
- `workflow_reuse_factor`, `instances_per_workflow`, `licensed_software_share`, `GPU_share`；
- `first_pass_acceptance_rate`, `median_revision_cycles`, `infra_invalid_rate`。

可复用成本公式：

`Total cost = Σ(instance production labor) + Σ(expert/QA review labor) + Σ(valid + infra-invalid run compute/judge/storage) + tooling/platform fixed cost + contingency`。

不要从 ALE 当前 `153/152/157` 的 repo inventory 反推 workflow 配额或 staffing ratio。

---

## 10. 反方证据与失效条件

当前“score 代表 task outcome completion”的解释在以下条件下会失效或显著变弱：

1. evaluator 没覆盖关键要求（已在 KiCad/MicroDicom/storyboard 看到实例）；
2. grader/answer key public 且被模型训练或 agent 针对优化；
3. hidden reference 通过 image、archive password、mount、bucket 或日志泄漏；
4. evaluator model/API/CLI/software revision 漂移；
5. 不同 harness 的 tools、turns、context、reasoning、executor、GUI transport 或 budget 不一致；
6. infra failure 被编码成 0 分；
7. task input 与真实生产分布不一致，或只代表少数易验证 artifact；
8. 客户真正关心的是“过程合规/软件使用”，但 evaluator 只看 outcome；
9. run 没有独立 repeated trials，却把一次 score 当稳定性能；
10. 将 public manifest、private pool、pending-QC、workflow 与 variants 合并成一个生产数字。

**[建议]** 主报告所有 leaderboard/Mean Score/Full Pass Rate 结论必须把 GitHub commit、task list blob、agent preset hash、environment image、prompt suffix、budget、attempt/trial policy、evaluator/judge revision一并作为结果主键。

---

## 11. 可直接复用的 repo audit checklist

- [ ] Repository URL、branch、40-char commit、commit date、access date 已记录
- [ ] README count、published manifest count、experiment list count、tree package count 分开
- [ ] workflow path 与 variant name/index 分开
- [ ] task card、main.py、scorer、data manifest 全部审阅
- [ ] `load()` 返回 variants 数量与 selected index 已验证
- [ ] input/software/output/reference paths 与 hashes 完整
- [ ] task-card VM snapshot/timeout 与 resolved environment 一致
- [ ] reference isolation mode 与 stage timing 已验证
- [ ] task must-do → evaluator check mapping 100% 显式
- [ ] 未评分要求已标注，不在能力结论中偷换
- [ ] deterministic/structural/judge evaluator 类型与 revision 已 pin
- [ ] judge model/prompt/API revision 与 credentials error path 已 pin
- [ ] missing output、malformed output、infra error、timeout 的语义分开
- [ ] score range/weights/gates/full-pass rule 机器可读
- [ ] public grader gaming、schema-only、prompt-copy、answer leakage 反例已测试
- [ ] agent model/harness/executor/tools/context/budget/versions 已 pin
- [ ] attempt 与 independent trial 分开
- [ ] 实际 trajectory/logs/artifacts 已保存；没有 trajectory 时不声称软件/过程被使用

## Evidence index

- [S07] `sources/07_official_github_fixed_snapshot.md`
- [S08] `sources/08_official_agent_harness_configs.md`
- [S09] `sources/09_official_task_contract_loader.md`
- [S10] `sources/10_official_runtime_lifecycle_and_staging.md`
- [S11] `sources/11_official_task_aapl_balance_sheet.md`
- [S12] `sources/12_official_task_kicad_pcb.md`
- [S13] `sources/13_official_task_microdicom.md`
- [S14] `sources/14_official_task_video_storyboard.md`
- [S15] `sources/15_official_public_manifests_at_commit.md`
- [S16] `sources/16_official_grader_revision_history.md`
