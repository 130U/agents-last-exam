# F3 — 反方证据：ALE 的 construct validity、可解释边界与失效条件

**研究截止：2026-08-08。对象固定为 UC Berkeley RDI Agents' Last Exam，论文固定为 `arXiv:2606.05405v2`。**

## 结论先行

1. **[事实] ALE v2 测量的是一次被版本固定的端到端 agent system run。** 论文明确把 agent 定义为 `harness + foundation model`，任务执行还依赖 system prompt、工具、上下文压缩、GUI/CLI 控制、VM/software、五小时上限和 evaluator。因此，表格中的一行是某个配置的成绩，不是裸 foundation model 的固有属性。[S20](../sources/20_ale_arxiv_v2_construct.md)
2. **[作者分析] 在 ALE v2 已测试的“竞争性 harness”范围内，backbone 的成绩跨度大于 harness 的跨度。** 这反驳“harness 一定是主导因素”的过强说法；但它不反驳系统级 construct，因为换 harness 仍带来 4.9–7.2 pp 的 pass-rate 区间，且提示、工具路由、视觉子代理、重试和上下文管理仍是配置组成。[S20](../sources/20_ale_arxiv_v2_construct.md)
3. **[研究员判断] deterministic evaluator 只保证同一输入可重复算出同一分数，不保证评分条件忠实、完整、公平。** SWE-bench 的两轮人工审计是强反例：可执行单测仍会因题意不充分、测试过窄/过宽或环境差异而误拒正确解；AgentRewardBench 还显示 rule-based evaluator 可能低报成功。[S26](../sources/26_openai_swebench_verified_2024.md) [S27](../sources/27_openai_swebench_retirement_2026.md) [S31](../sources/31_agentrewardbench.md)
4. **[事实 + 证据缺口] ALE 的 private pool、reference isolation 和 rolling release 是合理的污染缓解设计，但公开材料不能证明“零污染”。** 公开题可被训练、prompt tuning 或 task-specific optimization；私有题如果经第三方 API 执行，也需要数据使用条款、日志隔离和 exposure audit 才能降低 provider-side exposure 风险。ALE v2 未公开这种模型供应商训练数据审计。[S20](../sources/20_ale_arxiv_v2_construct.md) [S27](../sources/27_openai_swebench_retirement_2026.md) [S28](../sources/28_benchmark_leakage.md) [S29](../sources/29_livebench_contamination_limited.md)
5. **[事实 + 推断] ALE v2 只对部分配置/题目做三次独立 run；大部分榜单数字不是完整 repeated-trial 可靠性估计。** 独立研究显示 agentic eval 的单次 pass@1 可有数个百分点波动；`pass@k` 与 `pass^k` 会随重试数向相反方向变化。因此，几百分点的榜单差距在没有 ALE-specific repeats、置信区间和 matched budget 时不可稳健解释。[S20](../sources/20_ale_arxiv_v2_construct.md) [S23](../sources/23_tau_bench_reliability.md) [S24](../sources/24_randomness_agentic_evals.md) [S25](../sources/25_anthropic_demystifying_evals.md)
6. **[边界] ALE 可以支持“某端到端配置在某 task manifest、environment、budget、evaluator 下完成这些可验证 deliverables 的程度”这一窄而强的结论。** ALE v2 本身不能证明 human-level professional ability、劳动生产率、岗位替代、ROI、GDP 影响或部署可靠性；论文未报告 humans 在相同 ALE VM、信息、预算和 grader 下的 matched runs，也没有把 55 subdomains 按真实劳动市场权重外推。[S20](../sources/20_ale_arxiv_v2_construct.md) [S32](../sources/32_rebench_matched_humans.md) [S34](../sources/34_remote_labor_index.md) [S35](../sources/35_construct_validity_raji.md)

## 1. 四类陈述必须分开

| 标签 | 本文含义 | 示例 |
|---|---|---|
| **论文/代码事实** | pinned source 明确写出或可由代码直接审计 | agent=`harness+model`；五小时 cap；`evaluate()` 输出 `[0,1]`；部分配置做三次 run |
| **ALE 作者/机构主张** | 论文作者对代表性、经济意义或设计效果的解释，尚未有独立复现 | `r=0.89` 被作者解释为 public subset “representative”；ALE 被描述为连接 benchmark 与 GDP impact 的工具 |
| **研究员推断** | 多源证据支持但 ALE 未直接测量 | provider-side exposure 仍是 residual risk；接近的单次榜单差异可能被随机性覆盖 |
| **项目建议** | 为约 1,000 assets 设计的 acceptance/QA 控制 | evaluator blind audit、repeated-run pilot、human baseline、manifest/config card |

这一区分很重要：作者提出 “GDP-relevant” 方向，不等于论文已经测了 GDP；从真实项目提取 task，不等于 task 分布按就业、工资或工作时长加权；reference 由人类专家制作，也不等于完成了 matched-human comparison。

## 2. H1：ALE 测什么？系统 construct，不是裸 model

### 2.1 直接证据

ALE v2 的运行链可以表示为：

`task instance + task spec + VM/software + visible input`

`→ pinned agent = model + harness + prompts + tools + context policy + GUI/CLI interface`

`→ one run under wall-clock/token/API constraints`

`→ output/application state`

`→ pinned evaluate() + hidden reference/rubric/judge`

`→ score in [0,1] → Mean Score / Full Pass Rate`

论文还报告 model sweep 与 harness sweep，并将 GUI-as-Tool、视觉 sub-agent、上下文压缩、token、API cost、wall-clock 和 timeout 一并作为实验条件。[S20](../sources/20_ale_arxiv_v2_construct.md) 这和跨 benchmark 的独立结论一致：agent evaluation 需要把 model、scaffold、benchmark、cost 和实现分开，标准化 harness 是为了减少实现误差，不是为了把 scaffold 从 construct 中抹掉。[S21](../sources/21_ai_agents_that_matter.md) [S22](../sources/22_holistic_agent_leaderboard.md)

### 2.2 最强反方：论文自己的 model-vs-harness 分析

ALE 作者固定 OpenClaw 后换 12 个 backbone，pass-rate spread 为 16.8 pp；固定 backbone 后换竞争性 harness，spread 为 4.9–7.2 pp。**合理的窄结论**是：在这组测试配置里，backbone 与得分关系更强。**不合理的扩张**是：“因此 ALE 是裸 model benchmark”或“harness 不重要”。原因：

- harness sweep 本身仍改变结果；
- 结果只覆盖论文选择的 harness、backbone、prompt/tool integration 和当前任务；
- 五小时 cap、timeout policy、视觉能力接入方式、token/cost 与重试策略均可能与 harness 交互；
- agent 轨迹是由系统组件共同产生，单个总分不能识别因果贡献。

要回答 model 的独立贡献，应做 preregistered factorial/ablation：同 task manifest、同环境、同 budget、同重试规则，跨多 model × harness 组合，并报告交互项和不确定性。

### 2.3 H1 的判定与反驳条件

- **判定：SUPPORTED。** 官方定义和实验单位都指向端到端配置。
- **什么会反驳 H1：** 后续 canonical protocol 若强制所有提交使用完全相同、不可变的 harness/prompt/tools/context/GUI bridge/budget，且唯一可变因素是 model，同时 leaderboard 明确只声称该标准化条件下的 model effect；即便如此，它也只成为“standard-harness-conditioned model evaluation”，不是脱离条件的模型本性测量。

## 3. Evaluator validity：可重复不等于正确

### 3.1 ALE 的强项

**[事实]** ALE v2 将大多数开源 task workflow 归为 code-based evaluator，并把 LLM judge 限于创意/视觉/语义类输出；reference 与 agent workspace 隔离；missing output、wrong shape、gate failure 均返回有定义的分数；judge model/prompt 随结果记录。[S20](../sources/20_ale_arxiv_v2_construct.md)

这些控制减少了开放式主观评分、reference 泄漏和 crash-as-missing-data。但 93.2% code / 6.8% LLM 是**开源 task-workflow 层面的静态分析快照**，不是 private/pending 实例的已验证比例，也不是生产 quota。

### 3.2 三类 evaluator weakness

| 风险 | 可能造成的表象 | 反例/证据 | ALE-style QA |
|---|---|---|---|
| **Specification undercoverage** | 错误产物碰巧通过；Full Pass 假阳性 | 测试只覆盖 reference path 或少量字段；HAL 发现 agent 通过查 benchmark 等捷径取得表面成功 [S22](../sources/22_holistic_agent_leaderboard.md) | mutation tests、metamorphic tests、隐藏 adversarial cases、轨迹审计 |
| **Over-specific / misaligned criteria** | 功能正确但得 0；假阴性 | SWE-bench 审计发现窄测试、宽测试、underspecification 和环境导致误拒 [S26](../sources/26_openai_swebench_verified_2024.md) [S27](../sources/27_openai_swebench_retirement_2026.md) | 至少两位盲审专家判断 candidate correctness；比较 evaluator vs human adjudication |
| **Judge bias / drift** | 同一 artifact 因 judge/model/prompt/位置/风格变化而变分 | LLM-as-judge 有 position、verbosity、self-enhancement 和 reasoning limits；web-agent evaluator 无单一 judge 跨 benchmark 最优 [S30](../sources/30_llm_as_judge_biases.md) [S31](../sources/31_agentrewardbench.md) | 固定 judge version/prompt；swap/order tests；human agreement；回放旧 artifacts 检查 drift |

ALE 的 targeted yes/no visual probes 比通用“看起来对吗”更窄，是合理设计；但问题中仍存在 “well enough to pass / acceptable enough” 等边界词。**[研究员推断]** 这些条目必须用 domain-expert labeled artifact set 校准，不能从 prompt 的狭窄形式直接推断可靠性。

### 3.3 evaluator acceptance 应报告的统计

对人工 adjudication 结果 `H` 与 evaluator 判定 `E`：

- `FPR = count(E=pass, H=fail) / count(H=fail)`
- `FNR = count(E=fail, H=pass) / count(H=pass)`
- partial-score 任务：报告与专家分数的 MAE/秩相关、分层误差和边界样本 disagreement；不能只报总体 correlation。
- 对 LLM judge：报告 judge exact version、prompt hash、temperature、image renderer/version、重复 judge variance 和 human-human baseline agreement。

**公开资料不足：** ALE v2 未给出按 evaluator family 分层的 blinded human-vs-evaluator FPR/FNR、judge agreement 或 red-team escape rate。因此不能编造可接受阈值；应由 pilot 决定。

## 4. Contamination / exposure / task-specific optimization

### 4.1 现有证据能说什么

- **[事实]** ALE v2 采用 public/private pool、reference isolation 和 rolling rotation，明确把 pretraining overlap 与 task-specific optimization 视为威胁。[S20](../sources/20_ale_arxiv_v2_construct.md)
- **[独立证据]** 开放 benchmark 的 task/gold patch 曝光会使得分 increasingly reflect exposure；静态 benchmark 可因训练数据重叠失去能力信号。[S27](../sources/27_openai_swebench_retirement_2026.md) [S28](../sources/28_benchmark_leakage.md)
- **[设计先例]** LiveBench 使用新近来源和滚动更新，但当前标题谨慎改为 contamination-**limited**，没有声称 contamination-free。[S29](../sources/29_livebench_contamination_limited.md)

### 4.2 private 不等于未曝光

私有题仍可能经以下路径暴露：

1. 专家/供应商复用已公开项目、模板或 reference；
2. internal pilot logs、screenshots、artifact 或 prompts 进入训练/支持系统；
3. 第三方模型 API 保留输入，随后进入改进流程；
4. agent 可联网搜索任务描述、文件指纹或公开 reference；
5. public examples 允许针对 workflow/evaluator family 优化，进而转移到 private variants；
6. evaluator/reference 路径或错误信息通过 environment side channel 泄漏。

这些是**风险路径，不是 ALE 已发生事实**。判定需要 provenance、近重复检索、provider contractual evidence、canary、trace inspection 和隔离测试。

### 4.3 成功可能来自什么，而非目标能力

| 观测成功 | 替代解释 | 需要的排除证据 |
|---|---|---|
| public task Full Pass 上升 | prompt/task-specific tuning 或公开轨迹模仿 | private fresh workflow/instance、训练截止、exposure audit |
| private task 成功 | API/provider exposure、supplier reuse、近重复项目 | data-use agreement、canary、similarity search、独立新作 |
| evaluator 满分 | 只满足 rubric surface、提交 placeholder/shortcut、访问 grader artifact | anti-gaming gate、held-out evaluator tests、trace audit |
| best-of-k 成功 | 多次尝试的搜索预算，而非单次可靠能力 | 同等 k、总 token/API/wall-clock；同时报 pass^k |
| 更换 harness 后上升 | prompt/tools/context/GUI bridge 改进 | 不能归因给 foundation model；需要 factorial ablation |

## 5. Budget、retry 与 repeated-trial sensitivity

### 5.1 ALE v2 的证据边界

**[事实]** 每个 run 有五小时 cap；timeout 时 evaluator 对现有 artifact 正常打分；不同 harness 的 timeout、wall-clock、token 与 retry strategy 不同。论文只对部分配置报告同一实例三次运行的 score standard deviation。[S20](../sources/20_ale_arxiv_v2_construct.md)

所以：

- `agent run` 不是 `task instance`；一次实例可有多个 run；
- 单次 Full Pass Rate 是配置在一组随机轨迹上的 realization，不是固定真值；
- `best-of-k`、自动 retry、失败后重启、并行 sub-agent 都会改变有效 budget；
- 总 wall-clock 还受并行度影响，不能替代 per-run resource cap；
- 没有相同 task coverage 时，总 cost/time 不能直接比较效率。

### 5.2 建议公式（不预设任何精确重复次数）

令实例 `i` 的单次成功概率为 `p_i`，在独立同分布近似下：

- `pass@k_i = 1 - (1 - p_i)^k`：k 次至少一次成功，偏向“可搜索到解”；
- `pass^k_i = p_i^k`：k 次全部成功，偏向“稳定可部署”；
- benchmark macro average 应为 `N^-1 Σ_i metric_i`，并按 workflow cluster bootstrap；不要把多实例 workflow 当成独立同分布题目。

真实 run 往往不独立（相同缓存、服务故障、prompt、模型版本），因此最终报告应优先使用 repeated-run empirical estimate 与 cluster bootstrap CI，而不是只套公式。

总运行量与成本只给公式：

- `TotalRuns = Σ_stratum N_stratum × R_stratum`
- `Compute/API budget = Σ_run measured_cost(run)`
- `Calendar time` 还取决于并行度、VM availability、license、retry 和人工 adjudication，公开资料不足以给本项目精确数字。

### 5.3 反方证据

- τ-bench 显示 pass^8 可显著低于单次成功，说明偶尔成功与连续可靠不同。[S23](../sources/23_tau_bench_reliability.md)
- 60,000 trajectories 的研究显示即便 temperature 0，单次估计仍会波动；2–3 pp 改进可能是噪声。[S24](../sources/24_randomness_agentic_evals.md)
- Anthropic 的行业方法说明 pass@k 随 k 上升、pass^k 随 k 下降，产品问题决定应选哪一个。[S25](../sources/25_anthropic_demystifying_evals.md)
- HAL 还发现更高 reasoning effort 在多数测试运行中反而降低准确率，反驳“预算越高一定越强”的单调假设。[S22](../sources/22_holistic_agent_leaderboard.md)

以上都不是 ALE 数值估计；它们只证明必须运行 ALE-specific pilot。

## 6. Matched-human baseline 与 external validity

### 6.1 ALE 可以证明什么 / 不能证明什么

| 结论 | ALE v2 单独能否支持 | 严谨措辞 / 缺失证据 |
|---|---|---|
| 某配置能否在 pinned ALE task/evaluator 下完成 deliverable | **能**，但受 run 随机性与 grader validity 约束 | 报 system card、manifest、run policy、Mean Score、Full Pass Rate、CI |
| 某 backbone 在一个固定 harness 下相对更强 | **有限支持** | 只限该 harness、任务和 budget；需要 repeats 与 interaction analysis |
| general computer-use ability | **不能作无限外推** | ALE 是有限、筛选、软件可执行的任务样本；应描述覆盖面而非“通用能力” [S35](../sources/35_construct_validity_raji.md) |
| human-level professional ability | **不能** | 缺 matched human runs：相同 brief/input/VM/tools/time/grader |
| 提高劳动生产率 | **不能** | 缺人机协作实验、质量校正后的时间/成本与真实组织约束 |
| 替代岗位 / 自动化比例 | **不能** | 缺 occupation/task-frequency/economic weighting、采用成本、责任与非数字工作 |
| GDP impact / ROI | **不能** | GDP relevance 是作者目标 framing；缺因果部署与经济数据 |
| 部署可靠性 | **不能** | 缺 repeated-run `pass^k`、扰动、tool/API failure、model drift、安全/副作用测试 |

### 6.2 为什么 reference output 不是 human baseline

专家制作 input/reference 或过去完成过类似项目，只说明有目标 artifact 和专业来源。matched baseline 还要求人类在**同一可见信息、同一工具/软件、同一初始状态、同一时间/成本 budget、同一 grader**下执行，并报告分布而非单个 gold artifact。

RE-Bench 的结果是直接反例：AI 在两小时预算优于 humans，但长预算下 humans 的收益更高；结论随 budget 反转。[S32](../sources/32_rebench_matched_humans.md) OSWorld 提供任务协议下的 human completion rate，至少可校准 GUI benchmark 的天花板和歧义。[S33](../sources/33_osworld_human_baseline.md) RLI 更进一步绑定 professional deliverable、时间/成本和真实交易，但仍承认平台可执行性筛选限制。[S34](../sources/34_remote_labor_index.md)

### 6.3 public-subset “representativeness” 的窄读法

ALE v2 用一个 agent configuration 在 taxonomy cluster 上比较 public/full pool pass rate，报告 `r=0.89`，作者据此说 public subset representative；同段也承认两者 tier mix 不同且 full pool pass rate 更高。[S20](../sources/20_ale_arxiv_v2_construct.md)

可支持：该配置下，cluster 难度排序/关联在两个 pool 中较一致。

不能支持：

- public 与 full pool 难度分布相同；
- domain/subdomain/来源/软件/专家/项目价值按比例抽样；
- 对其他 agent configuration 也保持同样相关；
- public score 是 private score 的无偏估计；
- 这 150 或任何快照数应成为 1,000-assets 项目的 public quota。

## 7. H1–H4 adversarial verdict

| 假设 | 判定 | 主要证据 | 会使判定失效/反转的条件 |
|---|---|---|---|
| **H1 system construct** | **SUPPORTED** | 官方定义 agent=`harness+model`，并显式配置工具/GUI/context/budget [S20](../sources/20_ale_arxiv_v2_construct.md) | canonical protocol 将所有非 model 组件完全标准化且只允许 model 变化；结论仍需限定于该标准 harness |
| **H2 runnable identity** | **SUPPORTED（本证据线只核对最小 contract）** | task spec、input/environment/reference、`load/start/evaluate` 共同构成 runnable unit [S20](../sources/20_ale_arxiv_v2_construct.md) | revision-pinned official manifest 实际把未经 implementation/QC 的 raw submission/prompt 计为 released runnable instance |
| **H3 snapshot non-equivalence / two 960** | **UNDERDETERMINED in F3** | 本文件不做 960 集合映射审计 | canonical one-to-one mapping + revision-pinned manifest 可反驳；应由 version-matrix 证据线裁决，F3 不借有效性文献代替事实核验 |
| **H4 interpretation boundary** | **SUPPORTED** | grader failure、exposure、scaffold/budget、随机性和 matched-human 证据共同限制外推 [S21–S35] | ALE 后续公开跨模式 evaluator audit、训练曝光审计、充分 repeats、matched humans、真实部署与经济 outcome 验证，并且在新版本/manifest 上复现 |

## 8. 对约 1,000 ALE-style assets 的直接决策影响

### 8.1 产品范围必须分成四层，不要只交“题”

1. **Asset inventory:** workflow、runnable instance、task spec、input、hidden reference/evaluator、environment image、software/license、provenance。
2. **Evaluation protocol:** agent/config card、budget/retry/timeout、network policy、run ID/seed、artifact/trace retention、metrics。
3. **Validity evidence:** evaluator audit set、human adjudication、anti-gaming tests、contamination ledger、repeatability pilot、matched-human subset。
4. **Release governance:** public/private/rotation status、access control、provider data-use rule、retirement trigger、revision manifest。

如果客户只购买自然语言 task descriptions，就不能把交付称为“1,000 runnable ALE-style benchmark tasks”；更准确是 1,000 candidate specifications/submissions，仍需 implementation、reference、environment、evaluator 和 QC。

### 8.2 每个实例新增的 validity 字段

```yaml
validity_contract:
  intended_construct: "observable capability under named system/environment"
  excluded_claims: ["human parity", "job replacement", "GDP impact"]
  workflow_id: "..."
  instance_id: "..."
  task_spec_version: "..."
  manifest_sha: "..."
  input_hashes: ["..."]
  reference_hashes_private: ["..."]
  environment_image_digest: "..."
  software_versions: {app: "..."}
  evaluator_sha: "..."
  evaluator_family: "code|state|geometry|llm_visual|llm_text|hybrid"
  judge_config_hash: null
  known_shortcuts: ["..."]
  adversarial_tests: ["..."]
  expert_adjudication_protocol: "..."
  contamination_provenance: "..."
  exposure_status: "public|private|retired|suspected"

run_contract:
  agent_model: "..."
  harness_version: "..."
  prompt_tool_config_hash: "..."
  context_policy: "..."
  gui_cli_bridge_version: "..."
  network_policy: "..."
  wall_clock_cap: "..."
  token_api_budget: "..."
  retry_policy: "..."
  run_id: "..."
  trial_index: 1
  termination_reason: "..."
```

### 8.3 QA gates

- **G0 provenance:** expert authority、source/use rights、PII、reference origin、近重复检索完成。
- **G1 spec sufficiency:** 独立专家仅凭 visible task package 可执行；记录 clarification 次数与阻塞点。
- **G2 environment reproducibility:** clean rebuild、dependency/license、locale/timezone/network、start-state checks。
- **G3 evaluator validity:** gold pass、known-bad fail、alternative-correct pass、mutation/metamorphic/adversarial cases；盲测 FPR/FNR。
- **G4 anti-gaming:** reference/path/API isolation、error-message leakage、placeholder、hard-coded answer、benchmark search 和 grader tampering。
- **G5 stochastic pilot:** 对分层样本做 repeats；估计 per-task variance、cluster CI、pass@k/pass^k；据 expected effect size 决定正式重复数。
- **G6 human calibration:** 至少在声明 human/economic relevance 的 strata 做 matched-human runs；没有就明确禁用相关 marketing claim。
- **G7 release:** manifest/config/evaluator/judge 全部 pinned；public/private/rotation/retirement 与 provider logging policy 生效。

### 8.4 不能从公开材料直接给出的精确数字

以下变量均应写“公开资料不足，需 pilot”：

- 1,000 assets 中 workflow/instance、domain、public/private 的比例；
- 每实例要跑几次才足以区分目标 effect size；
- evaluator audit 抽样率、允许 FPR/FNR、judge-human agreement 门槛；
- matched-human 样本量、专家人数、小时与成本；
- 单实例生产工期、VM/license/API 成本、整体排期；
- contamination scan 的召回率或“无污染”概率。

ALE v2 的 task counts、公开/私有数、单 run 费用、五小时 cap、93.2%/6.8% judge mix 和三次重复都是**特定快照/实验选择**，可用于理解 ALE 历史实现，绝不能自动转成项目配额或 SLA。

## 9. 自我反驳与停止条件

1. **是否把所有分数问题都归咎于 harness？** 没有。ALE 自己的 controlled sweep 显示 backbone spread 更大；本文只坚持总分仍是系统条件化的。
2. **是否因存在 LLM judge 就否定 ALE？** 没有。ALE 优先 code-based、targeted probes 是明显优点；独立研究也显示经过校准的 LLM judge 可接近 human-human agreement。[S30](../sources/30_llm_as_judge_biases.md) 结论是“需验证”，不是“不可用”。
3. **是否把其他 benchmark 的缺陷率转移给 ALE？** 没有。SWE-bench、τ-bench、AgentRewardBench 和 randomness study 只建立 failure mode 与 QA necessity；所有 ALE-specific incidence 都标为公开资料不足。
4. **什么时候当前结论会失效？** 新 revision 若提供完整 evaluator-human audit、污染/供应商审计、全配置 repeated runs、matched humans、真实 deployment outcome，并在版本固定 manifest 上独立复现，H4 的部分边界可收窄；在此之前不能预支该证据。

