# F4 — 2026-08-08 live-surface audit

## Atomic finding

ALE's living official surfaces are already internally asynchronous. The homepage (`1.5K+`, `300+`), framework overview (`1,000+`, `250+`, around 150 public, hardest-tier 2.6%), RDI blog (`1,500+`, `300+`, 0% for named systems on the hardest tier), and ALE-V1 leaderboard (configuration-specific current rows plus best-of aggregation) are not one versioned statistical snapshot.

## Consequence

- Treat each page as a dated surface, not a row to average or reconcile into one inventory.
- Prefer arXiv v2 for the v2 study cohort, a commit/HF revision for the public manifest, and the live leaderboard only for the 2026-08-08 result surface.
- Do not turn `1.5K+`, `300+`, `250+`, `2.6%`, or a current leaderboard percentage into a production quota or universal model claim.
- A leaderboard row is `(task split, manifest, harness, model, effort, prompt/tools, environment, budget, retry/trial aggregation, evaluator revision, date)`, not just `model`.

## Evidence

Sources 17–19 and 36–40. Source 39 pins the live-docs `full.txt` public manifest to 152 task units and shows why agent/configuration/runtime settings belong in every result row. Source 40 shows an official fixed-model harness spread, while explicitly limiting its own generalizability.
