# Source 07 — ALE official GitHub fixed snapshot

- **Title:** `rdi-berkeley/agents-last-exam` — open evaluation framework
- **Author / institution:** UC Berkeley RDI × RDI Foundation; pinned commit authored by Yiyou Sun
- **URL:** https://github.com/rdi-berkeley/agents-last-exam/tree/1e615e456de7cef57706680613cb80ee13c7fc76
- **README URL:** https://github.com/rdi-berkeley/agents-last-exam/blob/1e615e456de7cef57706680613cb80ee13c7fc76/README.md
- **Published:** repository/file publication date not stated; pinned commit timestamp 2026-08-05T19:19:49Z
- **Accessed:** 2026-08-08
- **Version / revision:** branch `main`; commit `1e615e456de7cef57706680613cb80ee13c7fc76`; README blob `5b21e3feba8251d2935bc235913ad5176ad0d9e8`
- **Source type:** canonical primary source, immutable code snapshot

## Direct evidence and locations

- README lines 44–45: the repository contains the `ale_run` framework and “around **150 public tasks**”; this is approximate prose, not an exact manifest count.
- README lines 88–110: ALE describes the evaluated object as an agent harness driving a foundation model, plus a sandbox and a task whose hidden reference is scored by `evaluate()`.
- README lines 113–123: the published flow is provision → input → agent → hidden reference → grade → logs/trajectory.
- README lines 129–135: both in-sandbox CLI harnesses and out-of-sandbox harnesses are supported.

## Assessment

- **Credibility: 5/5.** Primary implementation repository.
- **Recency: 5/5.** Pinned three days before the research date.
- **Bias: 3/5** (5 = highest bias). Maintainer self-description is authoritative for intended architecture, but claims such as “faithfully reproduces” and broad comparability are not independently validated by code alone.

## Supports / challenges

- Supports: ALE evaluates a configured end-to-end agent system, not a bare foundation model; references are intended to be hidden until after the agent run.
- Challenges: treating README’s “around 150” as an exact quota or merging it with other snapshots.
- Classification: code/repository composition is **fact**; coverage/economic framing is an **ALE author claim**.

