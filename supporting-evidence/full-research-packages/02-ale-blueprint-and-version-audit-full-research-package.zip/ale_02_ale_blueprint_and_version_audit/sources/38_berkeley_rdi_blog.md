# Source 38 — Berkeley RDI launch/results blog

- **Title:** Agents’ Last Exam
- **Author / institution:** Yiyou Sun et al.; UC Berkeley RDI
- **URL:** https://rdi.berkeley.edu/blog/agents-last-exam/
- **Published:** June 2026
- **Accessed:** 2026-08-08
- **Version / revision:** unversioned institutional blog snapshot
- **Source type:** canonical institutional announcement / interpretation

## Direct evidence

- Scope excerpt: “more than 1,500 expert-sourced tasks spanning 55 occupations.”
- The page reports `300+` experts from `100+` institutions and calls the tasks derived from prior expert projects converted into verifiable evaluations.
- It makes a strong interpretation—agents are useful but not yet “job-ready”—and reports 0% success on the hardest tier for the named evaluated frontier systems.
- It claims “No human judges”, while official technical docs allow judge-based LLM/VLM grading; this should be read as no live human scoring, not necessarily deterministic-only grading.

## Assessment

- **Credibility: 4/5** for project chronology and institutional self-report; use paper/code for exact protocol.
- **Recency: 5/5** (June 2026, accessed 2026-08-08).
- **Bias: 4/5** (launch/positioning document with recruitment and benchmark-promotion incentives).

## Supports / challenges

- Supports: author framing, live June scale claims, official validity boundary against “job-ready”.
- Challenges: treating launch prose as a versioned task manifest or independent proof of human-level/job readiness.
- Classification: scale/results are **institution claims** until pinned to paper/manifest; job-readiness language is **author interpretation**.

