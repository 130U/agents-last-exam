# Source 36 — ALE framework overview

- **Title:** ALE · Open Evaluation Framework — Overview
- **Author / institution:** UC Berkeley RDI / ALE project team
- **URL:** https://agents-last-exam.org/docs/ale/index.html (embedded at https://agents-last-exam.org/docs)
- **Published:** living documentation; date not stated
- **Accessed:** 2026-08-08
- **Version / revision:** unversioned docs snapshot; current GitHub `main` links; DOM verified in the in-app browser
- **Source type:** canonical official framework documentation

## Direct evidence

- Construct excerpt: “Every run pairs three swappable pieces: Agent, Environment, Task.”
- The lifecycle shown is provision sandbox → stage input/start state → run agent → stage hidden reference and grade → normalize trajectory/artifacts → teardown.
- The `Agent` slot is described as any harness under a uniform interface; `Environment` supplies OS/software/data; `Task` supplies instruction, inputs and hidden grading reference.
- This docs snapshot says `250+` experts, `13` clusters, `55` subdomains, `1,000+` corpus, around `150` public, and `2.6%` average hardest-tier pass rate.

## Assessment

- **Credibility: 5/5** for current framework semantics.
- **Recency: 4/5** because it is live but exposes no dated revision and visibly lags other live count surfaces.
- **Bias: 2/5** (technical official docs, though benchmark-level claims are self-description).

## Supports / challenges

- Supports: H1 system construct; the run lifecycle; environment/reference isolation.
- Challenges: merging current docs counts with homepage/blog or v2 paper counts.
- Classification: lifecycle details are **official implementation facts**; “real economic impact” framing is an **author claim**.

