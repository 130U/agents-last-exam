# Source 13 — Official public task: MicroDicom reader adjudication

- **Title:** `health_medicine/microdicom_nih_cxr_reader_adjudication`
- **Author / institution:** UC Berkeley RDI / ALE task maintainers
- **URL:** https://github.com/rdi-berkeley/agents-last-exam/tree/1e615e456de7cef57706680613cb80ee13c7fc76/tasks/health_medicine/microdicom_nih_cxr_reader_adjudication
- **Published:** task-file publication date not stated; included in 2026-08-05 pinned snapshot
- **Accessed:** 2026-08-08
- **Version / revision:** commit `1e615e456de7cef57706680613cb80ee13c7fc76`; task card `a2c8304e...`, main `0b733ad1...`
- **Source type:** canonical public task package

## Direct evidence and locations

- `task_card.json` lines 2–81: Windows/MicroDicom task over nine CXR cases; visible rules, reader boxes, clinical notes and DICOM; three required TSV outputs; `cpu-free`; 7,200-second timeout.
- `main.py` lines 267–280: the boxes file must cover the hidden case set, match the hidden selected reader and reach IoU ≥ 0.50.
- `main.py` lines 291–373: three hidden reference TSVs are read; each output file passes or fails as a whole; total score is the fraction of the three file contracts.
- Critical code/card mismatch: the task card says the adjudication log matches the hidden reference exactly, but `main.py` lines 325–333 compares only `case_id`, `selected_reader` and `disagreement_type`. It ignores `resolution_basis` content.
- `final_impressions.tsv` uses labels already fixed in the public prompt; this component can pass without demonstrating case-by-case visual adjudication if the case IDs are recovered.

## Assessment

- **Credibility: 5/5.** Actual public evaluator is decisive over prose.
- **Recency: 5/5.** Pinned current snapshot.
- **Bias: 1/5.** Executable code.

## Supports / challenges

- Supports: hidden case-level references and artifact evaluation.
- Challenges/evaluator weakness: partial rubric coverage and coarse three-file scoring can award credit without validating the stated rationale quality.
- No trajectory is included; actual use of MicroDicom is not provable from successful TSVs alone.

