# Source 14 — Official public task: vintage-animation shot log

- **Title:** `visual_media/video_storyboard_001`
- **Author / institution:** UC Berkeley RDI / ALE task maintainers
- **URL:** https://github.com/rdi-berkeley/agents-last-exam/tree/1e615e456de7cef57706680613cb80ee13c7fc76/tasks/visual_media/video_storyboard_001
- **Published:** task-file publication date not stated; included in 2026-08-05 pinned snapshot
- **Accessed:** 2026-08-08
- **Version / revision:** commit `1e615e456de7cef57706680613cb80ee13c7fc76`; task card `56102410...`, main `67544536...`, evaluator `e467a7bb...`, shared evaluator utility `b2e38fb6...`
- **Source type:** canonical public task package

## Direct evidence and locations

- `task_card.json` lines 2–52: Windows task using source OGV, a DOCX fact-check brief, VLC and a DOCX editor; output is `storyboard.docx`; 7,200-second timeout.
- The prompt requires a temporal, grounded shot log and explicitly forbids answering the brief’s questions.
- `main.py` lines 59–60 defines `reference_storyboard.docx`, but lines 134–159 never read it. The actual evaluator reads only the candidate DOCX and the visible question DOCX.
- `evaluate_storyboard.py` lines 25–39 contains a public ten-item answer key. Lines 99–117 normalize an LLM judge’s answers and score `correct_count / 10`; lines 122–206 prompt the judge to answer the questions from candidate text.
- `tasks/utils/evaluation.py` lines 75–100 defaults the LLM judge to `gpt-5.4`, but permits task-specific/shared environment overrides.

## Assessment

- **Credibility: 5/5.** Actual public evaluator.
- **Recency: 5/5.** Pinned current snapshot.
- **Bias: 1/5.** Executable code.

## Supports / challenges

- Supports: ALE permits judge-based artifact scoring.
- Strong counterexample/evaluator weakness: the implementation does not directly verify timestamps, shot/segment structure, video-groundedness, full-film inspection or the “do not answer” constraint. Because the answer key and grader are public, a candidate can optimize to the ten answers instead of performing the intended workflow.
- Reproducibility also requires pinning judge model/config; actual trajectory is absent.

