# Source 23 — τ-bench reliability metric

- **Title:** τ-bench: A Benchmark for Tool-Agent-User Interaction in Real-World Domains
- **Authors:** Shunyu Yao, Noah Shinn, Pedram Razavi, Karthik Narasimhan
- **URL:** https://arxiv.org/abs/2406.12045v1
- **Published / revision:** 2024-06-17; arXiv **v1**; ICLR 2025 paper
- **Accessed:** 2026-08-08
- **Source type:** independent academic benchmark/paper with code and data
- **Scores:** Credibility **5/5**; Recency **3/5**; Bias risk **2/5**

## Direct evidence and locations

Short excerpt (abstract): “pass^8 <25% in retail.”

- The benchmark compares final database state with an annotated goal state and introduces `pass^k` for all-k repeated-run reliability (abstract lines 16–18).
- Reported single-run success below 50% coexists with substantially lower repeated-run consistency.

## Supports / challenges

- **Supports H4:** a one-run Full Pass Rate does not establish reliable repeated completion.
- **Production implication:** report `pass@1`, `pass@k` and `pass^k` only when their trial semantics and independence/empirical estimation are explicit.
- Not evidence of ALE's exact variance; it motivates an ALE-specific repeated-run pilot.

