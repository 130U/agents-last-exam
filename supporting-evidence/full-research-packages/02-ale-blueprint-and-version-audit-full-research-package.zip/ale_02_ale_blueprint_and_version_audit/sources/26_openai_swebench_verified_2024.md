# Source 26 — OpenAI: Introducing SWE-bench Verified

- **Title:** Introducing SWE-bench Verified
- **Authors / institution:** Neil Chowdhury et al.; OpenAI with SWE-bench authors
- **URL:** https://openai.com/index/introducing-swe-bench-verified/
- **Published / revision:** 2024-08-13; updated 2025-02-24
- **Accessed:** 2026-08-08
- **Source type:** credible industry audit plus released annotations/harness
- **Scores:** Credibility **5/5**; Recency **4/5**; Bias risk **2/5**

## Direct evidence and locations

Short excerpt (annotation results): “68.3% ... filtered out due to underspecification, unfair unit tests, or other issues.”

- 93 developers screened 1,699 samples; each sample had three independent annotations (lines 165–180).
- Criteria included underspecified issue text, tests rejecting valid solutions and easily gamed tests (lines 167–174).
- A new containerized evaluation harness accompanied the curated 500-sample subset (lines 155–160).

## Supports / challenges

- **Evaluator counterexample:** deterministic unit tests can be reproducible yet invalid, too narrow or gameable.
- **Production implication:** ALE-style evaluator acceptance requires expert criterion-validity review and adversarial tests, not only deterministic execution.
- Does not establish ALE's evaluator defect rate.

