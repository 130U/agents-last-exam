# Source 28 — Benchmarking Benchmark Leakage in Large Language Models

- **Title:** Benchmarking Benchmark Leakage in Large Language Models
- **Authors:** Ruijie Xu, Zengzhi Wang, Run-Ze Fan, Pengfei Liu
- **URL:** https://arxiv.org/abs/2404.18824v1
- **Published / revision:** 2024-04-29; arXiv **v1**
- **Accessed:** 2026-08-08
- **Source type:** independent academic contamination study with released pipeline/predictions
- **Scores:** Credibility **4/5**; Recency **3/5**; Bias risk **1/5**

## Direct evidence and locations

Short excerpt (abstract): “substantial instances of training even test set misuse.”

- Study covers 31 LLMs in mathematical reasoning and proposes perplexity/N-gram leakage detection (abstract lines 15–18).
- Authors recommend a Benchmark Transparency Card and release pipeline/model predictions.

## Supports / challenges

- **Supports H4:** opaque training makes public-task exposure hard to rule out from performance alone.
- Scope is static mathematical benchmarks; transfer to interactive ALE tasks is conceptual, not a measured ALE contamination rate.

