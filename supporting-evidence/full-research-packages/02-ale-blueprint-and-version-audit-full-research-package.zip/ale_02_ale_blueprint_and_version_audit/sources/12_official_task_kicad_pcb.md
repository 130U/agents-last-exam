# Source 12 — Official public task: KiCad PCB layout

- **Title:** `engineering/pcb_layout_kicad_1`
- **Author / institution:** UC Berkeley RDI / ALE task maintainers
- **URL:** https://github.com/rdi-berkeley/agents-last-exam/tree/1e615e456de7cef57706680613cb80ee13c7fc76/tasks/engineering/pcb_layout_kicad_1
- **Published:** task-file publication date not stated; included in 2026-08-05 pinned snapshot
- **Accessed:** 2026-08-08
- **Version / revision:** commit `1e615e456de7cef57706680613cb80ee13c7fc76`; task card `3db24bb6...`, main `e6f6e12f...`, scorer `a1c02ba5...`
- **Source type:** canonical public task package

## Direct evidence and locations

- `task_card.json` lines 2–36: Windows/KiCad task; input schematic and launcher; required routed PCB, outline, four holes, two GND zones, vias and clean DRC; output `.kicad_pcb`; 7,200-second timeout.
- `main.py` lines 150–275: one variant; finds the submitted PCB, invokes KiCad CLI DRC, runs structural scoring and returns the task score.
- `score_outputs.py` lines 81–99: structural checks are string/block-level conditions for Edge.Cuts, GND zones, hole count/spacing, at least 20 segments and at least two vias.
- `score_outputs.py` lines 138–169: DRC failure scores 0; DRC pass plus all structural checks scores 1; DRC pass with structural failure scores 0.5; normal runtime does not use the admin-only fallback.

## Assessment

- **Credibility: 5/5.** Direct runnable evaluator.
- **Recency: 5/5.** Pinned current snapshot.
- **Bias: 1/5.** Executable scoring logic.

## Supports / challenges

- Supports: a GUI-authoring workflow can be graded through an application-native file plus application CLI checks.
- Challenges/evaluator weakness: the code does not explicitly score compact fit for the named enclosure, complete component placement or a geometrically closed outline; the Edge.Cuts check is string presence. DRC mitigates some but not all omissions.
- Actual agent actions are not proven without a run trajectory; the package only proves the instructed/code-implied path.

