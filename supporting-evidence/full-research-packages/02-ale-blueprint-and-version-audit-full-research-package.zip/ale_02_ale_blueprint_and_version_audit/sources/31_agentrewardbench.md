# Source 31 — AgentRewardBench

- **Title:** AgentRewardBench: Evaluating Automatic Evaluations of Web Agent Trajectories
- **Authors:** Xing Han Lù et al.
- **URL:** https://arxiv.org/abs/2504.08942v2
- **Published / revision:** v1 2025-04-11; **v2 2025-10-06**
- **Accessed:** 2026-08-08
- **Source type:** independent academic evaluator benchmark with expert labels and code/data
- **Scores:** Credibility **5/5**; Recency **4/5**; Bias risk **1/5**

## Direct evidence and locations

Short excerpt (abstract): “no single LLM excels across all benchmarks.”

- 1,302 trajectories from five web benchmarks were expert-reviewed for success, side effects and repetition (abstract lines 16–19).
- Rule-based evaluators tended to underreport agent success; LLM evaluators varied by benchmark.

## Supports / challenges

- **Supports evaluator audit:** rule-based and model-based graders have different false-negative/robustness profiles.
- Web trajectories differ from ALE deliverables; use as a reason to measure evaluator-human agreement on ALE task families, not to assume one direction of bias.

