# Source 11 — Official public task: Apple FY2024 balance-sheet reconstruction

- **Title:** `business_finance/financial_stmt_reconstruction_aapl_fy2024`
- **Author / institution:** UC Berkeley RDI / ALE task maintainers
- **URL:** https://github.com/rdi-berkeley/agents-last-exam/tree/1e615e456de7cef57706680613cb80ee13c7fc76/tasks/business_finance/financial_stmt_reconstruction_aapl_fy2024
- **Published:** task-file publication date not stated; included in 2026-08-05 pinned snapshot
- **Accessed:** 2026-08-08
- **Version / revision:** commit `1e615e456de7cef57706680613cb80ee13c7fc76`; task card `d892bd8e...`, main `61f66041...`, scorer `e41995f2...`
- **Source type:** canonical public task package

## Direct evidence and locations

- `task_card.json` lines 2–49: Linux task; visible Apple 10-K PDF/HTML/schema; output `balance_sheet.json`; `cpu-free-ubuntu`; 7,200-second task-card timeout.
- `main.py` lines 160–198: one `base` variant; `start()` delegates setup; `evaluate()` requires hidden `reference/aapl_fy2024_balance_sheet_reference.json`, runs the scorer and returns its numeric score.
- `score_outputs.py` lines 102–154: validates metadata, recursively compares numeric leaves and returns field accuracy; its separate 95% `pass_fail` flag is not the score returned by `evaluate()`.
- The task card’s `referenceFiles` entry describes the agent-produced output path, while the actual hidden reference path is only established in `main.py`. The card alone is therefore insufficient to reconstruct the grading contract.

## Assessment

- **Credibility: 5/5.** Direct runnable package and evaluator.
- **Recency: 5/5.** Pinned current snapshot.
- **Bias: 1/5.** Executable scoring logic.

## Supports / challenges

- Supports: an instance includes concrete inputs, output schema, environment, hidden reference and deterministic evaluator.
- Challenges: describing the task as a question/prompt only; treating `referenceFiles` card prose as authoritative over code.
- Evaluator boundary: extra numeric paths are reported but do not reduce field accuracy; actual run trajectory is not present in this package.

