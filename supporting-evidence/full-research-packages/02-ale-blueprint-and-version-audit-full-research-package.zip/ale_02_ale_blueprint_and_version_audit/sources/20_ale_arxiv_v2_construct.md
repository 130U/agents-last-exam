# Source 20 — Agents' Last Exam (arXiv v2)

- **Title:** Agents' Last Exam
- **Authors / institution:** Yiyou Sun et al. (310 authors); UC Berkeley RDI-led collaboration
- **URL:** https://arxiv.org/html/2606.05405v2
- **Published / revision:** v1 2026-06-03; **v2 2026-06-11**
- **Accessed:** 2026-08-08
- **Pinned surface:** arXiv `2606.05405v2` HTML/abstract; not the mutable project site
- **Source type:** ALE canonical primary paper
- **Scores:** Credibility **5/5**; Recency **5/5**; Bias risk **2/5** (author-reported benchmark design/results)

## Direct evidence and locations

Short excerpt (Sec. C.1, lines 497–502): “The agent is the system under evaluation, composed of a harness ... and a model.”

Short excerpt (Sec. 4.1, lines 228–230): “Each run is capped at five hours.”

- Sec. 3.2 and C.4 define the GCUA harness: model inference, system prompt, tools, sub-agent dispatch, context compaction, GUI/CLI control and runtime substrate (HTML lines 151–161, 719–725).
- Sec. 4.1 reports paired harness–backbone configurations, GUI-as-Tool, Mean Score, Full Pass Rate, cost, wall time and tokens (lines 224–236). Table 1 notes only a subset received three repeated runs (lines 169–170).
- Sec. D.4 reports an author analysis: under fixed OpenClaw, backbone spread was 16.8 pp; under fixed backbones, competitive-harness spread was 4.9–7.2 pp (lines 862–867). This is a within-tested-set result, not proof that harness is irrelevant.
- Sec. C.3 reports code-based and LLM judge modes, including visual and free-text criteria, and says 93.2% / 6.8% of open-sourced task workflows respectively use them (lines 541–715).
- Sec. 2.3 describes a 150-instance public set, private pool and rotation as contamination controls (lines 138–139). The paper does not report a provider-side training-data audit proving zero exposure.
- Sec. D.1 reports one-configuration public/full-pool correlation (`r=0.89`) across taxonomy clusters, but also says their overall pass rates differ because tier mixes differ (lines 756–760).
- Abstract/conclusion frame ALE as a bridge toward GDP-relevant impact (lines 74–75, 271–274); methods/results do not report matched human runs under identical ALE environment, budget and grader.

## Supports / challenges

- **Supports H1:** the measured object is a pinned end-to-end agent configuration, not a bare model.
- **Supports H2:** an executable task specification plus input/environment/reference/evaluate contract defines a runnable instance.
- **Supports H4 boundary:** scores are evaluator- and configuration-bounded; repeated-trial and human-comparison evidence is incomplete.
- **Challenges overstatement:** deterministic execution does not by itself validate evaluator criteria; “GDP-relevant” is an author framing, not demonstrated labor-market external validity.

