# Source 30 — Judging LLM-as-a-Judge

- **Title:** Judging LLM-as-a-Judge with MT-Bench and Chatbot Arena
- **Authors:** Lianmin Zheng et al.
- **URL:** https://arxiv.org/abs/2306.05685v4
- **Published / revision:** v1 2023-06-09; **v4 2023-12-24**; NeurIPS 2023 Datasets & Benchmarks
- **Accessed:** 2026-08-08
- **Source type:** independent academic evaluator-validation study with human preference data
- **Scores:** Credibility **5/5**; Recency **3/5**; Bias risk **1/5**

## Direct evidence and locations

Short excerpt (abstract): “position, verbosity, and self-enhancement biases, as well as limited reasoning ability.”

- Controlled and crowdsourced comparisons found strong GPT-4 judges exceeded 80% agreement after mitigation (abstract lines 16–18; PDF lines 110–128).

## Supports / challenges

- **Balanced evaluator evidence:** LLM judging can scale and reach useful agreement, but must be validated for known biases.
- ALE's targeted visual yes/no probes differ from MT-Bench pairwise text preference, so neither the 80% agreement nor exact bias sizes can be imported.

