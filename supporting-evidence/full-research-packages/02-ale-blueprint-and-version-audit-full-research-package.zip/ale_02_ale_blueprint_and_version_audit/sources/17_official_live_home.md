# Source 17 — ALE official live homepage

- **Title:** Agents' Last Exam — AI Agent Benchmark for Real-World Professional Workflows
- **Author / institution:** UC Berkeley RDI / ALE project team
- **URL:** https://agents-last-exam.org/
- **Published:** living page; publication date not stated
- **Accessed:** 2026-08-08
- **Version / revision:** unversioned live homepage snapshot; page title and DOM verified in the in-app browser
- **Source type:** canonical official project page

## Direct evidence

- Hero claim excerpt: “55 targeted sub-industries” and “1,500+ tasks collected toward a 5,000-task target.”
- The same snapshot displays `55 Sub-Industries Covered`, `1.5K+ Tasks Collected`, and `300+ Experts`.
- It describes the benchmark as long-horizon, economically valuable tasks with verifiable outcomes and links the official arXiv, GitHub, leaderboard, traces and submission page.

## Assessment

- **Credibility: 5/5** for current official self-description; not an independent validation.
- **Recency: 5/5** as a 2026-08-08 live snapshot; no revision history exposed.
- **Bias: 3/5** (project marketing and recruitment incentives; counts are self-reported).

## Supports / challenges

- Supports: the current live marketing/count surface uses 55, 1.5K+, 300+, and a 5,000 target.
- Challenges: any attempt to treat the paper, docs and homepage counts as one revision-pinned inventory.
- Classification: **author/institution claim** unless corroborated by a pinned manifest or paper snapshot.

