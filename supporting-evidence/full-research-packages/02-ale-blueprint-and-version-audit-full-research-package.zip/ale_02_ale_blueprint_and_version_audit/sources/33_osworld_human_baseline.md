# Source 33 — OSWorld human baseline

- **Title:** OSWorld: Benchmarking Multimodal Agents for Open-Ended Tasks in Real Computer Environments
- **Authors:** Tianbao Xie et al.
- **URL:** https://arxiv.org/abs/2404.07972v2
- **Published / revision:** v1 2024-04-11; **v2 2024-05-30**
- **Accessed:** 2026-08-08
- **Source type:** independent academic benchmark with code/environment/data
- **Scores:** Credibility **5/5**; Recency **3/5**; Bias risk **2/5**

## Direct evidence and locations

Short excerpt (abstract): “humans can accomplish over 72.36% ... best model achieves only 12.24%.”

- 369 real desktop/web tasks include setup configuration and custom execution-based evaluators (abstract lines 15–19).
- Paper positions the human baseline as evidence of a GUI grounding/operational-knowledge gap, not labor automation.

## Supports / challenges

- **Supports matched-human requirement:** human completion under a task protocol provides a calibration ALE currently does not publish.
- OSWorld's task duration and scope are narrower; its numbers cannot calibrate ALE difficulty or human performance.

