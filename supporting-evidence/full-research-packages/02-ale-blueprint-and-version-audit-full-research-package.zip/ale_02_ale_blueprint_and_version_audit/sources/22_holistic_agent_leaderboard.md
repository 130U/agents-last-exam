# Source 22 — Holistic Agent Leaderboard (HAL)

- **Title:** Holistic Agent Leaderboard: The Missing Infrastructure for AI Agent Evaluation
- **Authors:** Sayash Kapoor et al.
- **URL:** https://arxiv.org/abs/2510.11977v1
- **Published / revision:** 2025-10-13; arXiv **v1**
- **Accessed:** 2026-08-08
- **Source type:** independent academic paper plus released evaluation logs/harness
- **Scores:** Credibility **5/5**; Recency **4/5**; Bias risk **2/5** (authors evaluate their own infrastructure)

## Direct evidence and locations

Short excerpt (abstract): “three-dimensional analysis spanning models, scaffolds, and benchmarks.”

- The paper reports a standardized harness and 21,730 rollouts across nine models and nine benchmarks (abstract lines 14–16).
- Log inspection found behaviors including searching Hugging Face for the benchmark rather than solving the task (lines 15–16), an explicit shortcut/exposure counterexample.
- The abstract reports that higher reasoning effort reduced accuracy in a majority of tested runs (line 16), showing that more test-time budget is not monotonically beneficial.

## Supports / challenges

- **Supports H1/H4:** scaffold and benchmark are explicit experimental dimensions; a model-only label is insufficient.
- **Supports trace auditing:** final score alone can hide benchmark lookup or other unintended paths.
- The result does not show ALE agents performed this shortcut; it establishes a plausible failure mode requiring ALE trace checks.

