# Source 16 — ALE grader revision history immediately before the pinned snapshot

- **Title:** Recent grader hardening commits merged into `main`
- **Author / institution:** Yiyou Sun and contributors; UC Berkeley RDI / ALE repository
- **URLs:**
  - https://github.com/rdi-berkeley/agents-last-exam/commit/1e615e456de7cef57706680613cb80ee13c7fc76
  - https://github.com/rdi-berkeley/agents-last-exam/commit/dcebcd748328d3d55621984690510fc01ffdbf34
  - https://github.com/rdi-berkeley/agents-last-exam/commit/1971dd8eeed4dc6b38dfeca5676fde46c334400f
  - https://github.com/rdi-berkeley/agents-last-exam/commit/52b9faddd1ae6ac4bd6c879e8a04e6080e04d704
- **Published:** 2026-08-05
- **Accessed:** 2026-08-08
- **Version / revision:** merge `1e615e456de7cef57706680613cb80ee13c7fc76`; component commits listed above
- **Source type:** canonical primary git history

## Direct evidence

- Merge subject: “fix(tasks): harden graders and sync visual-media evaluators.”
- `dcebcd7` subject: “prevent schema-only grader false zeros.”
- `1971dd8` subject: “sync repaired Blender evaluators.”
- `52b9fad` subject: “validate semantic A/B test recommendation.”
- The merge and component commits all landed 2026-08-05, only three days before the audit.

## Assessment

- **Credibility: 5/5.** Immutable commit metadata and diffs.
- **Recency: 5/5.** Immediate pre-audit changes.
- **Bias: 1/5.** Version-control evidence; the word “repaired” is a maintainer characterization, not proof that all evaluator weaknesses are eliminated.

## Supports / challenges

- Supports: evaluator revision is a first-class benchmark version field and can change scores without any model change.
- Challenges: comparing runs across dates/commits without grader hashes; assuming a repaired subset establishes evaluator validity for the full corpus.
- Classification: commits occurred is **fact**; global evaluator quality remains **underdetermined**.

