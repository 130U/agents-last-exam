# Source 10 — ALE runtime lifecycle, run units and reference staging

- **Title:** Orchestrator lifecycle, run-unit enumeration and task-data staging
- **Author / institution:** UC Berkeley RDI / ALE maintainers
- **URLs:**
  - https://github.com/rdi-berkeley/agents-last-exam/blob/1e615e456de7cef57706680613cb80ee13c7fc76/ale_run/orchestration/lifecycle.py
  - https://github.com/rdi-berkeley/agents-last-exam/blob/1e615e456de7cef57706680613cb80ee13c7fc76/ale_run/orchestration/runner.py
  - https://github.com/rdi-berkeley/agents-last-exam/blob/1e615e456de7cef57706680613cb80ee13c7fc76/ale_run/environments/task_data/baked_in_sandbox.py
- **Published:** file publication dates not stated; pinned snapshot commit 2026-08-05T19:19:49Z
- **Accessed:** 2026-08-08
- **Version / revision:** commit `1e615e456de7cef57706680613cb80ee13c7fc76`; lifecycle blob `e6a10a79...`, runner `92450ebd...`, baked staging `ad14437f...`
- **Source type:** canonical primary implementation

## Direct evidence and locations

- `lifecycle.py` lines 8–17 and 217–447: provision; stage input and call `start`; run the deployer with the task description; gather output; stage reference; call `evaluate`; extract the score.
- `lifecycle.py` lines 242–250: the exact task description is recorded as the user instruction; lines 328–331 pass the same description to the deployer.
- `runner.py` lines 50–60: a run unit is the Cartesian product of agent × task × variant index.
- `runner.py` lines 70–125: `max_attempts` only requeues failed units. It is retry behavior, not independent repeated trials of completed runs.
- `baked_in_sandbox.py` lines 6–20 and 108–176: input is visible, while `reference.7z` remains encrypted until evaluation and its password is read at evaluation time.
- `local_host.py` lines 9–14 and 100–118: the Docker/local backend instead hides plain reference data by staging time.
- `lifecycle.py` lines 630–648: central score extraction converts to float but does not clamp or validate `[0,1]`; range validity depends on task evaluators.

## Assessment

- **Credibility: 5/5.** Executable orchestration path.
- **Recency: 5/5.** Immutable 2026-08-05 snapshot.
- **Bias: 1/5.** Operational code.

## Supports / challenges

- Supports: precise run definition, reference isolation and the end-to-end system construct.
- Challenges: equating retry attempts with repeated trials; assuming every backend hides references identically; assuming the framework centrally guarantees valid scores.
- Classification: all listed behavior is **implementation fact**; security effectiveness beyond this mechanism is not established.

