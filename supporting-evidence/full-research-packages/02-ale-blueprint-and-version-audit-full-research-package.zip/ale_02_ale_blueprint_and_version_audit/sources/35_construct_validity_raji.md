# Source 35 — Construct-validity critique of broad benchmarks

- **Title:** AI and the Everything in the Whole Wide World Benchmark
- **Authors:** Inioluwa Deborah Raji, Emily M. Bender, Amandalynne Paullada, Emily Denton, Alex Hanna
- **URL:** https://arxiv.org/abs/2111.15366v1
- **Published / revision:** 2021-11-26; arXiv **v1**; NeurIPS 2021 Datasets & Benchmarks
- **Accessed:** 2026-08-08
- **Source type:** independent academic position/measurement paper
- **Scores:** Credibility **5/5**; Recency **2/5**; Bias risk **1/5**

## Direct evidence and locations

Short excerpt (abstract): “construct validity issues in their framing as ... ‘general’ broad measures of progress.”

- The paper argues finite, contextual benchmark instances do not justify vague general-capability claims (HTML lines 3–14).
- It recommends contextualized claims, behavioral/error analysis and ablations rather than treating rank as a universal contest (lines 168–186).

## Supports / challenges

- **Supports H4:** ALE results should be scoped to its sampled workflows, tested system and evaluator contract.
- This is a general conceptual critique; it does not refute ALE's task realism or domain coverage.

