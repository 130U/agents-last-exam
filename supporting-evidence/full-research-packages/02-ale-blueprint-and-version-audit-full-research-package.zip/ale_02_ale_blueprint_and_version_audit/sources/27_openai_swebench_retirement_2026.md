# Source 27 — OpenAI: Why SWE-bench Verified no longer measures frontier coding capabilities

- **Title:** Why SWE-bench Verified no longer measures frontier coding capabilities
- **Author / institution:** OpenAI
- **URL:** https://openai.com/index/why-we-no-longer-evaluate-swe-bench-verified/
- **Published / revision:** 2026-02-23; no revision identifier shown
- **Accessed:** 2026-08-08
- **Source type:** credible industry re-audit of a widely used benchmark
- **Scores:** Credibility **5/5**; Recency **5/5**; Bias risk **2/5**

## Direct evidence and locations

Short excerpt (lines 43–48): “models that have seen the problems during training are more likely to succeed.”

- In 138 frequently failed tasks reviewed after 64 independent runs, 59.4% had material test-design or description problems (lines 63–69).
- All tested frontier models reproduced some gold patches or verbatim task details, indicating at least partial exposure (lines 43–48).
- Environment setup differences, including OS and Python version, could create spurious failures (lines 57–62).

## Supports / challenges

- **Supports H4:** evaluator weakness, data exposure and environment differences are live alternative explanations for scores.
- **Contamination control implication:** private authorship/rotation reduces risk but must be paired with exposure auditing and provider/data-use controls.
- The findings are SWE-bench-specific; they demonstrate failure modes, not their frequency in ALE.

