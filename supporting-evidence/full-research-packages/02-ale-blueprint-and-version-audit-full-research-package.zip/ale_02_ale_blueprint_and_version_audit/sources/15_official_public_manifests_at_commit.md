# Source 15 — ALE public manifests at pinned GitHub commit

- **Title:** `tasks/published_tasks.json` and `selected_tasks/full.txt`
- **Author / institution:** UC Berkeley RDI / ALE maintainers
- **URLs:**
  - https://github.com/rdi-berkeley/agents-last-exam/blob/1e615e456de7cef57706680613cb80ee13c7fc76/tasks/published_tasks.json
  - https://github.com/rdi-berkeley/agents-last-exam/blob/1e615e456de7cef57706680613cb80ee13c7fc76/selected_tasks/full.txt
- **Published:** file publication dates not stated; pinned snapshot commit 2026-08-05T19:19:49Z
- **Accessed:** 2026-08-08
- **Version / revision:** commit `1e615e456de7cef57706680613cb80ee13c7fc76`; blobs `aa3e251e...` and `d94c9854...`
- **Source type:** canonical primary manifest; counts below are reproducible researcher calculations

## Direct evidence and calculations

- `published_tasks.json` has **153 workflow keys** and **153 listed public variants**. Every key lists exactly one variant, but variant names are not always literally `base` (`images`, `variant_1`, `table2`, etc. also occur).
- `selected_tasks/full.txt` has **152 non-comment task paths**.
- The same-commit difference is exactly one path: `engineering/2d_drawings_to_3d_bridge_model` appears in `published_tasks.json` (line 743) but not `full.txt`.
- The tree contains 157 non-demo `tasks/**/main.py` workflow packages. Four are not in `published_tasks.json`: `visual_media/high_to_low_modeling`, `mota_reproduction`, `object_generation`, `scene_restoration`.
- Four audited examples are explicitly published: AAPL line 13; storyboard line 28; MicroDicom line 48; KiCad line 378.
- No private-instance or pending-QC manifest/count was found in the public repo paths searched (`README.md`, `tasks/`, `selected_tasks/`, `ale_run/`, `docs/`).

Reproduction formulas: count JSON object properties; sum their `variants` lengths; count non-comment lines in `full.txt`; count non-demo `main.py` files; set-difference the path lists.

## Assessment

- **Credibility: 5/5.** Immutable official manifests; calculations are mechanically reproducible.
- **Recency: 5/5.** Pinned 2026-08-05 snapshot.
- **Bias: 1/5.** Inventory data.

## Supports / challenges

- Supports: this commit exposes 153 manifest-listed runnable public variants, not a universal ALE corpus total.
- Challenges: treating “around 150,” `full.txt=152`, `published_tasks=153`, all task code `=157`, paper totals, private totals or live-site totals as interchangeable.
- Classification: file membership is **fact**; deciding which manifest defines a production quota is a **project decision**, not a source fact.

