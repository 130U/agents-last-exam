# Source 32 — RE-Bench matched-human design

- **Title:** RE-Bench: Evaluating Frontier AI R&D Capabilities of Language Model Agents against Human Experts
- **Authors:** Hjalmar Wijk et al.; METR
- **URL:** https://proceedings.mlr.press/v267/wijk25a.html
- **Published / revision:** arXiv 2024-11-22; ICML 2025 / PMLR 267; benchmark **v1**
- **Accessed:** 2026-08-08
- **Source type:** independent nonprofit/academic paper with environments, human data, code and trajectories
- **Scores:** Credibility **5/5**; Recency **4/5**; Bias risk **1/5**

## Direct evidence and locations

Short excerpt (METR release): “AI agents perform better ... at 2 hours, but ... worse at higher time budgets.”

- Seven environments; 71 eight-hour attempts by 61 human experts; comparisons use varying budgets and agent designs (PMLR abstract / METR lines 34–47, 160–167).
- Humans and AI receive the same environment, information and resources; the release explicitly documents remaining real-world differences such as clearer objectives and shorter feedback loops (METR lines 58–72).

## Supports / challenges

- **Human-baseline counterexample:** claims about relative human ability change with time budget and require matched conditions.
- **Supports H4:** without matched humans, ALE cannot alone establish human parity, productivity or job replacement.
- RE-Bench is one narrow occupation family; its human-relative result is not transferable to ALE domains.

