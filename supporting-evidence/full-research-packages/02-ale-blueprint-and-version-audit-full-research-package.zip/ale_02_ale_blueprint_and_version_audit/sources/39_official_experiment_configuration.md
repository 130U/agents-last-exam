# Source 39 — ALE experiment configuration

- **Title:** Configure an experiment | ALE Docs
- **Author / institution:** UC Berkeley RDI / ALE project team
- **URL:** https://agents-last-exam.org/docs/ale/pages/configure.html
- **Published:** living documentation; date not stated
- **Accessed:** 2026-08-08
- **Version / revision:** unversioned live docs snapshot; task lists/configs link to repository `main`
- **Source type:** canonical official framework documentation

## Direct evidence

- Experiment identity excerpt: “combines agent presets, one environment profile, and a task list.”
- Run-level controls include concurrency, wall time, auto-resume, maximum attempts, cleanup and prompt suffix; agent presets separately select harness, model, executor and provider-specific configuration.
- The framework runs the Cartesian product of selected agents and task units.
- Snapshot-specific lists on this page are: `ale_cli.txt` 105; `cpu_unlicensed.txt` 140; `unlicensed.txt` 145; `full.txt` 152, including seven licensed tasks.
- Text lists contain task paths; YAML lists can choose explicit variant indices.
- The documented retry field permits one to three attempts for newly failed run units. This is retry control, not evidence of repeated independent statistical trials.

## Assessment

- **Credibility: 5/5** for current configuration schema and displayed manifests.
- **Recency: 5/5** as the 2026-08-08 live docs snapshot; no immutable docs revision.
- **Bias: 2/5** (technical primary source).

## Supports / challenges

- Supports: H1; public manifest count of 152 for this live docs surface; environment/license splits; agent-run/retry distinctions.
- Challenges: calling `max_attempts` repeated trials; comparing scores without pinning task list, agent preset, environment and prompt suffix.
- Classification: **official implementation fact** for the live docs surface.

