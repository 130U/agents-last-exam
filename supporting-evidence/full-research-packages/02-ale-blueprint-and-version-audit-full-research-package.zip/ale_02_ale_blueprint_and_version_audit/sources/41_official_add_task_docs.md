# Source 41 — Official task-package authoring contract

- **Title:** Add a task | ALE Docs
- **Author / institution:** UC Berkeley RDI / ALE project team
- **URL:** https://agents-last-exam.org/docs/ale/pages/add-task.html
- **Published:** living documentation; date not stated
- **Accessed:** 2026-08-08
- **Version / revision:** unversioned docs snapshot; current repository conventions
- **Source type:** canonical official implementation documentation

## Direct evidence

- Package excerpt: “A task is a two-file package.”
- The documented package is `task_card.json` plus `main.py`; required metadata includes task ID/category, VM snapshot/resource hints and per-variant wall budget.
- `load()` returns one task object per variant; `start()` prepares a fresh VM; `evaluate()` returns normalized score(s), usually a value in `[0,1]`.
- Missing agent output should return `0.0`; evaluator exceptions are reserved for infrastructure failure.
- Reference hiding, idempotent start, dry-run, live run and inclusion in a curated task list are explicit authoring/testing controls.

## Assessment

- **Credibility: 5/5** for the live implementation contract.
- **Recency: 5/5** for 2026-08-08; no immutable docs revision.
- **Bias: 1/5** (low-interpretation technical primary source).

## Supports / challenges

- Supports: H2; minimum complete schema and acceptance gates; distinction between discoverable code and curated-release membership.
- Challenges: counting task ideas, untested packages or discovered-but-uncurated code as accepted benchmark instances.
- Classification: **official implementation fact**.
