# Source 40 — Official ALE harness analysis

- **Title:** Does the Harness Matter? Lessons from ALE-Claw on Agents’ Last Exam
- **Authors / institution:** Yixiao Huang and Yiyou Sun; ALE / UC Berkeley RDI
- **URL:** https://agents-last-exam.org/blogs/harness-matters
- **Published / last updated:** 2026-06-11
- **Accessed:** 2026-08-08
- **Version / revision:** dated official analysis page; live charts load from the results database
- **Source type:** official benchmark analysis, not independent replication

## Direct evidence

- Fixed-model comparison excerpt: harness sweeps span “5 to 6 points.”
- The page reports a fixed-OpenClaw model sweep of 18.0 pass-rate points, versus fixed-model harness spreads of 6.0 points (GPT-5.5) and 5.3 points (Claude Opus 4.7).
- ALE-Claw vs OpenClaw holds model and code family relatively close and reports similar mean score with materially different tokens/cost/time.
- The authors explicitly call ALE-Claw a product-layer comparison, not a full component ablation, and identify weaker-model, cross-run and component-ablation tests as future work.

## Assessment

- **Credibility: 4/5** (useful official controlled sweeps with linked code/results, but not peer-reviewed independent replication).
- **Recency: 5/5** (dated 2026-06-11; accessed 2026-08-08).
- **Bias: 4/5** (authors evaluate and promote their own lean harness; live charts may drift).

## Supports / challenges

- Supports: H1 and the claim that harness is a measured configuration variable; efficiency conclusions for the tested ALE/model/harness slice.
- Challenges: saying all performance is “just the harness”; but also challenges bare-model ranking because a 5–6 point spread is not zero.
- Failure condition: results need not transfer to weaker models, cross-run assistants, other task families, other budgets or a full factorial component ablation.
- Classification: numerical sweep is an **ALE author result**; general design conclusions are **author claims** pending independent replication.

