# Source 08 — ALE official agent harness configurations

- **Title:** Agent presets under `configs/agents/`
- **Author / institution:** UC Berkeley RDI / ALE maintainers
- **URL:** https://github.com/rdi-berkeley/agents-last-exam/tree/1e615e456de7cef57706680613cb80ee13c7fc76/configs/agents
- **Published:** individual publication dates not stated; pinned snapshot commit 2026-08-05T19:19:49Z
- **Accessed:** 2026-08-08
- **Version / revision:** commit `1e615e456de7cef57706680613cb80ee13c7fc76`; key blobs: Codex `bc5edfec...`, Claude Code `8ee11332...`, ALE-Claw `70c1a6e5...`
- **Source type:** canonical primary configuration/code

## Direct evidence and locations

- The pinned folder contains 15 YAML presets (researcher count), including Codex, Claude Code, ALE-Claw, Grok Build and Kimi Code.
- `codex.yaml` lines 10–46: harness `codex`, example model `openai/gpt-5.4`, sandbox executor, `danger-full-access`, non-interactive approvals and `reasoning_effort: high`.
- `claude_code.yaml` lines 10–80: harness/model, sandbox executor, unlimited turn setting, optional dollar budget, disabled tools and a pinned CLI version.
- `ale_claw.yaml` lines 12–88: host-side local executor, 100-turn ceiling, MCP substrate/GUI transport, main-computer/subagent switches, disabled tools and separate thinking controls.
- `grok_build.yaml` lines 4–46 and `kimi_code.yaml` lines 4–28 pin different models, reasoning controls, tool defaults, context and CLI versions.

## Assessment

- **Credibility: 5/5.** These files are the executable experiment presets.
- **Recency: 5/5.** Immutable 2026-08-05 snapshot.
- **Bias: 1/5.** Mostly operational configuration; comments about behavior remain maintainer statements unless traced into deployer code.

## Supports / challenges

- Supports: a leaderboard/run result is for `model + harness + executor + tools + budgets + versions`, not model alone.
- Challenges: cross-row model comparisons that omit harness/configuration and attempts.
- Classification: literal values are **facts at this commit**; any superiority interpretation is outside this source.

