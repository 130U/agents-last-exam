# Source 19 — ALE-V1 live leaderboard

- **Title:** Leaderboard | Agents' Last Exam
- **Author / institution:** UC Berkeley RDI / ALE project team
- **URL:** https://agents-last-exam.org/leaderboard
- **Published:** living page; rows include dated run/configuration snapshots
- **Accessed:** 2026-08-08
- **Version / revision:** visible label `ALE-V1`; unversioned page snapshot; DOM verified in the in-app browser
- **Source type:** canonical official results surface

## Direct evidence

- Metric excerpt: “Pass Rate is the share of runs that earned a perfect score.”
- `Score` is defined on-page as average partial-credit score; `Best of All Runs` uses each task's highest-scoring run.
- Rows separately identify `Harness`, `Model`, `Effort`, `Pass Rate`, `Score`, estimated cost, runtime and token use.
- The same model appears under different harnesses; the page also includes a synthetic `Best per task` row, which is not one deployable agent configuration.
- Runtime excludes queueing, environment setup, evaluation and output sync; the displayed methodology says it was updated 2026-07-10.
- The license toggle distinguishes a full set from an unlicensed subset because some tasks require licensed software or proprietary data.

## Assessment

- **Credibility: 5/5** for what the official live result surface displays; exact run provenance still depends on linked traces/configs.
- **Recency: 5/5** for 2026-08-08.
- **Bias: 3/5** (official benchmark operator; best-of and headline displays can invite over-comparison).

## Supports / challenges

- Supports: H1, because official rows make harness/model/effort first-class; run and repeated-trial distinctions; metric definitions.
- Challenges: reading a row as a bare-model score; reading `Best per task` as one agent; comparing costs/runtimes without exclusions.
- Classification: **official live snapshot fact** for displayed configurations; broader capability meaning is an **inference**.

