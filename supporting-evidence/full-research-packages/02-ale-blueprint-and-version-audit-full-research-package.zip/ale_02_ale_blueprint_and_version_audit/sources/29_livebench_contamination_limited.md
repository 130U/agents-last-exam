# Source 29 — LiveBench contamination-limited design

- **Title:** LiveBench: A Challenging, Contamination-Limited LLM Benchmark
- **Authors:** Colin White et al.
- **URL:** https://arxiv.org/abs/2406.19314v2
- **Published / revision:** v1 2024-06-27; **v2 2025-04-18**; ICLR 2025 Spotlight
- **Accessed:** 2026-08-08
- **Source type:** independent academic paper with public code/data
- **Scores:** Credibility **5/5**; Recency **4/5**; Bias risk **2/5**

## Direct evidence and locations

Short excerpt (abstract): “Questions are added and updated on a monthly basis.”

- Uses recent sources, objective ground truth and recurring updates to limit contamination (abstract lines 14–18).
- Current title deliberately says **contamination-limited**, not contamination-free.

## Supports / challenges

- **Supports rolling-holdout recommendation:** freshness and rotation reduce, but cannot prove the absence of, exposure.
- It is a non-agentic LLM benchmark; use its release logic, not its task schema, as cross-project evidence.

