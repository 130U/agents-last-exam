# Source 24 — On Randomness in Agentic Evals

- **Title:** On Randomness in Agentic Evals
- **Authors:** Bjarni Haukur Bjarnason, André Silva, Martin Monperrus
- **URL:** https://arxiv.org/abs/2602.07150v3
- **Published / revision:** v1 2026-02-06; **v3 2026-03-25**
- **Accessed:** 2026-08-08
- **Source type:** independent academic empirical study (60,000 SWE-bench Verified trajectories)
- **Scores:** Credibility **5/5**; Recency **5/5**; Bias risk **1/5**

## Direct evidence and locations

Short excerpt (abstract): “single-run pass@1 estimates vary by 2.2 to 6.0 percentage points.”

- Variation remained with standard deviations above 1.5 pp even at temperature 0; 2–3 pp improvements can be noise (abstract lines 16–18).
- Authors recommend multiple independent runs, power analysis and both optimistic `pass@k` and pessimistic `pass^k` (HF paper lines 67–70).

## Supports / challenges

- **Supports H4:** closely spaced single-run ALE leaderboard values should not be interpreted as robust ordering without ALE-specific uncertainty.
- Does not transfer its numerical variance estimate to ALE; task, scaffold and evaluator distributions differ.

