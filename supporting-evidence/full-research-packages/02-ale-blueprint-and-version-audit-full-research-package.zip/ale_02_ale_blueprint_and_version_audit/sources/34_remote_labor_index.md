# Source 34 — Remote Labor Index (RLI)

- **Title:** Remote Labor Index: Measuring AI Automation of Remote Work
- **Authors:** Mantas Mazeika et al.
- **URL:** https://arxiv.org/abs/2510.26787v1
- **Published / revision:** 2025-10-30; arXiv **v1**
- **Accessed:** 2026-08-08
- **Source type:** independent academic/industry benchmark with human deliverables and private holdout
- **Scores:** Credibility **4/5**; Recency **4/5**; Bias risk **2/5**

## Direct evidence and locations

Short excerpt (Sec. 3.1): “record the time and cost to produce the gold-standard human deliverable.”

- Each project binds brief, input files and a professional's human deliverable; time and cost are recorded (HTML lines 42–56).
- 230 of 240 projects are private to reduce contamination (lines 94–95).
- Automation Rate is the share of agent deliverables rated at or above the human gold-standard quality (lines 185–190).

## Supports / challenges

- **External-validity comparator:** economic-automation claims need explicit market sampling, human quality anchors and economic/time metadata.
- RLI still filters work that cannot fit its web platform and covers remote freelance work, so even it is not a universal labor-market measure.

