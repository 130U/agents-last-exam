# Source 21 — AI Agents That Matter

- **Title:** AI Agents That Matter
- **Authors:** Sayash Kapoor, Benedikt Stroebl, Zachary S. Siegel, Nitya Nadgir, Arvind Narayanan
- **URL:** https://arxiv.org/abs/2407.01502v1
- **Published / revision:** 2024-07-01; arXiv **v1**
- **Accessed:** 2026-08-08
- **Source type:** independent academic analysis with reproduction experiments
- **Scores:** Credibility **5/5**; Recency **3/5**; Bias risk **1/5**

## Direct evidence and locations

Short excerpt (abstract): “there is a lack of standardization in evaluation practices, leading to a pervasive lack of reproducibility.”

- Sec. 2 notes stochastic backbones and shows that extra calls can raise accuracy, so comparisons require cost control (HTML lines 16–21).
- Sec. 5 argues benchmark shortcuts/overfitting require holdouts at the same generality level as the intended claim (lines 180–189).
- Sec. 6 and Appendix E document implementation differences and errors that inflate accuracy estimates (lines 31–32, 234–235, 425–426).

## Supports / challenges

- **Supports H1/H4:** model, scaffold, cost and evaluation implementation jointly condition agent results.
- **Challenges leaderboard-only conclusions:** accuracy without budget/cost, holdout and reproducibility controls can reward expensive retries or benchmark-specific shortcuts.
- Not ALE-specific; use as cross-benchmark validity evidence, not as proof ALE has the same defect rate.

