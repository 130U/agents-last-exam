# Source 25 — Anthropic: Demystifying evals for AI agents

- **Title:** Demystifying evals for AI agents
- **Author / institution:** Anthropic Engineering
- **URL:** https://www.anthropic.com/engineering/demystifying-evals-for-ai-agents
- **Published / revision:** 2026-01-09; live article, no revision identifier shown
- **Accessed:** 2026-08-08
- **Source type:** credible industry methodology
- **Scores:** Credibility **4/5**; Recency **5/5**; Bias risk **3/5** (vendor-authored guidance)

## Direct evidence and locations

Short excerpt (lines 220–229): “a task that passed on one eval run might fail on the next.”

- Defines `pass@k` as at least one success and `pass^k` as success on all k trials (lines 224–229).
- Gives the product-reliability interpretation: a 75% per-trial success rate becomes about 42% all-three success, assuming independent identical trials (lines 225–227).
- Notes that agent tasks include tools, environment, multi-turn loop and grading logic (lines 24–31).

## Supports / challenges

- **Supports H1/H4:** evaluation subject includes the agent loop and environment; nondeterminism changes interpretation.
- The numerical example is a probability illustration, not an ALE result.

