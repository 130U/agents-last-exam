# Source 05 — Hugging Face task-card dataset at `a8c1fd1…`

## Source metadata

- **Title:** `agents-last-exam/agents-last-exam` — *Agents Last Exam — Task Card Metadata (v1.0)*
- **Author / institution:** `agents-last-exam` Hugging Face organization; first-party ALE release.
- **Canonical page:** https://huggingface.co/datasets/agents-last-exam/agents-last-exam
- **Commit history:** https://huggingface.co/datasets/agents-last-exam/agents-last-exam/commits/main
- **Pinned full revision:** `a8c1fd174a1f6cfa76526572a2e3ebece1276be2`
- **Pinned tree:** https://huggingface.co/datasets/agents-last-exam/agents-last-exam/tree/a8c1fd174a1f6cfa76526572a2e3ebece1276be2
- **Pinned Parquet:** https://huggingface.co/datasets/agents-last-exam/agents-last-exam/resolve/a8c1fd174a1f6cfa76526572a2e3ebece1276be2/task_cards.parquet
- **Parquet LFS object at this commit:** `sha256:b6661183018f65f332260d1981f656102fedcc17c8ee96c0dfe18a5af9c184e8`, size 190,675 bytes
- **Dataset config / split:** `default` / `v1.0`
- **Release date:** dataset card does not state one. Repository metadata for this pinned revision reports `2026-07-11T06:17:59Z`; commit SHA, not relative date text, is the reproducibility authority.
- **Access / audit date:** 2026-08-08 (America/New_York)
- **License:** CC BY 4.0

## Revision pin result

**Successfully fixed.** On 2026-08-08 the live `main` tree identified the verified head as full SHA `a8c1fd174a1f6cfa76526572a2e3ebece1276be2`; the commit page exposes the Parquet LFS object above. The viewer and rows APIs are mutable `main` surfaces and do not provide a reliable revision selector, so future reproduction must use the pinned Parquet URL, then recompute row statistics locally.

## Source assessment

- **Credibility: 5/5 for the released task-card fields and repository state; 1/5 for unexposed private benchmark details.**
- **Recency: 5/5.** Current head was checked on the fixed 2026-08-08 access date.
- **Bias risk: 3/5.** First-party release; it is authoritative for its own rows but not independent evidence of benchmark validity or representativeness.

## Direct evidence

The pinned dataset card calls itself a “metadata-only release (v1.0) of 153 tasks” and says, “This dataset contains task cards only (one row per task).”

The current viewer and pinned card expose these fields:

| Field | Meaning on this source surface |
|---|---|
| `task_id` | Stable public card identifier, `<category>/<task_name>`. |
| `title`, `summary` | Human-readable card metadata. |
| `category` | Repository/path grouping; viewer has 14 values. |
| `subdomain` | Human-readable label. |
| `task_split` | Single metadata label: `near-term`, `full-spectrum`, `last-exam`; one row is blank. |
| `task_prompt` | Full task instruction shown to the agent. |
| `agent_must_do` | Public checklist, not executable evaluator. |
| `software` | Expected software list, not a versioned VM image. |
| `input_files` | Descriptors only (`name`, `format`, `path`, `description`), not file contents. |
| `taxonomy` | `domain_id`, `domain_code`, `subdomain_id`, `subdomain_code`, `subdomain_name`. |
| `source_repo_path` | Path to task directory in source repository. |

The dataset card explicitly excludes input bytes, software binaries, reference outputs, scoring fixtures, VM images, private `evaluation`, reference file lists, VM provisioning details and internal audit trails. It links separate open input-data and gated reference-data repositories.

## Fixed-revision row audit

Because `main` on the access date resolves to the same content-addressed SHA audited below, these counts are revision-pinned rather than inferred from a mutable label.

| Measure | Result at `a8c1fd1…` | Unit / warning |
|---|---:|---|
| Rows | 153 | public task-card metadata rows; not runnable instances by themselves |
| Unique `task_id` | 153 | public card identities |
| `task_split=near-term` | 67 | single-label metadata rows |
| `task_split=full-spectrum` | 47 | not the paper’s 55-member evaluation slice |
| `task_split=last-exam` | 38 | single-label metadata rows |
| blank `task_split` | 1 | `engineering/2d_drawings_to_3d_bridge_model` |
| observed `category` values | 14 | path/storage group, not formal taxonomy proof |
| observed structured `taxonomy.domain_code` values | 14 | includes `14 / other` in this release |
| unique structured subdomain mappings | 51 | public-row coverage; not the complete advertised 55 taxonomy |
| `category != taxonomy.domain_code` | 18 rows | proves the two fields are not interchangeable |
| duplicate `task_id` / `source_repo_path` | 0 / 0 | integrity check for this metadata file only |

Two rows carry structured `14 / other / 14.1 / sports / Sports`; this is evidence about the HF schema at this revision. It does **not** by itself prove that `Other` is a fourteenth formal domain in the v2 paper.

## Version-bound comparison with arXiv v2

| Surface | arXiv `v2` (2026-06-11) | HF `a8c1fd1…` (head checked 2026-08-08) | Determination |
|---|---|---|---|
| Counted object | 1,490 runnable task instances; 960 workflows | 153 task-card metadata rows | Non-equivalent units. |
| Public count | 150 release-state instances; elsewhere 152 distinct evaluation tasks | 153 rows | Snapshot/schema drift; do not “correct” one with another. |
| Tier representation | 67/55/38 memberships over 152 distinct tasks | 67/47/38 plus one blank single-label row | HF single label cannot reconstruct overlapping paper memberships. |
| Taxonomy | 13 formal domains / 55 subdomains; residual Figure 2 `Other → Sports` | 14 observed structured domain codes / 51 represented mappings | Public rows are incomplete and use a later schema. |
| Task specification | `main.py` + lifecycle + inputs + software + references + evaluator | prompt/checklist/software/input descriptors/path | HF table is an index/card layer, not the executable task. |
| Input/reference/evaluator | integral to runnable instance | omitted from this dataset | Task card alone cannot be executed or scored. |
| Agent/harness/budget/metrics | described in paper | not encoded in task cards | No HF-row score is comparable without external run configuration. |

## Fact / inference / recommendation boundary

- **Fact:** the first-party HF page reports `v1.0`, 153 rows, one row per task card and metadata-only scope.
- **Fact:** the access-date head and Parquet are pinned to the SHA/LFS object above.
- **Fact:** the file’s observed taxonomy/split counts are as listed.
- **Inference:** the 153-row release postdates or otherwise differs from the paper’s frozen public/evaluation manifests; HF does not publish a crosswalk proving which row is new or which split memberships overlap.
- **Recommendation:** count HF rows as **public task-card assets**, not as runnable ALE instances, workflows, submissions, commissioned tasks or agent runs. A production acceptance contract must separately require input bytes, environment image/versions, hidden reference, evaluator and run manifest.

## Supports / refutes / limitations

- **Supports H2:** a natural-language card is not sufficient for runnable task identity.
- **Supports H3:** paper and HF snapshots have different counts, taxonomy representation and schema roles.
- **Refutes any claim** that the HF dataset alone is the full 1,490-instance benchmark or complete 55-subdomain manifest.
- **Limitations:** public-only; gated references were not used; rows API itself is mutable; no public crosswalk maps this SHA to the exact arXiv experiment manifest.

