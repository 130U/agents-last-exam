# Source 09 — ALE task contract, loader and driver

- **Title:** Task specification, `TaskLoader` and `TaskDriver`
- **Author / institution:** UC Berkeley RDI / ALE maintainers
- **URLs:**
  - https://github.com/rdi-berkeley/agents-last-exam/blob/1e615e456de7cef57706680613cb80ee13c7fc76/docs/ale-docs-site/pages/tasks.html
  - https://github.com/rdi-berkeley/agents-last-exam/blob/1e615e456de7cef57706680613cb80ee13c7fc76/ale_run/tasks/loader.py
  - https://github.com/rdi-berkeley/agents-last-exam/blob/1e615e456de7cef57706680613cb80ee13c7fc76/ale_run/tasks/driver.py
- **Published:** file publication dates not stated; pinned snapshot commit 2026-08-05T19:19:49Z
- **Accessed:** 2026-08-08
- **Version / revision:** commit `1e615e456de7cef57706680613cb80ee13c7fc76`; blobs `7d3858a9...`, `77af1f0c...`, `9df5d95f...`
- **Source type:** canonical primary documentation and implementation

## Direct evidence and locations

- `tasks.html` lines 33–43: `load()` declares variants; `start()` stages inputs/apps/state; `evaluate()` reads output/reference after the run; one `main.py` is one workflow plus shared grading logic, while variants reuse it on concrete inputs.
- `tasks.html` lines 54–74: input is agent-visible; reference is hidden; the official sequence is stage input → agent → stage reference → grade.
- `loader.py` lines 56–63: `load()` returns a list and `variant_index` selects one returned `cb.Task`.
- `loader.py` lines 138–155: selected task fields are `description`, `metadata`, `computer` and derived OS/task-data fields; task-card VM settings are merged later (lines 207–241).
- `loader.py` lines 350–394: runnable identity/staging metadata includes domain, task, variant, input, software, reference and output paths.
- `driver.py` lines 338–405: the driver calls `start` and `evaluate`; a score list is reduced to its first element, while a dict passes through.

## Assessment

- **Credibility: 5/5.** Direct task-discovery and execution contract.
- **Recency: 5/5.** Immutable current snapshot.
- **Bias: 2/5.** Technical primary source; “grader that can’t be gamed” in docs is an unverified author claim.

## Supports / challenges

- Supports: `workflow ≠ variant ≠ runnable instance`; a task is more than a prompt.
- Challenges: counting expert submissions or task cards as runnable tasks without validating hooks/data/environment/evaluator.
- Classification: hook semantics and loader behavior are **facts**; unhackability is an **author claim**.

