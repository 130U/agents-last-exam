# Source 37 — ALE task specification and data staging

- **Title:** Task spec & data staging | ALE Docs
- **Author / institution:** UC Berkeley RDI / ALE project team
- **URL:** https://agents-last-exam.org/docs/ale/pages/tasks.html
- **Published:** living documentation; date not stated
- **Accessed:** 2026-08-08
- **Version / revision:** unversioned docs snapshot; references current repository `main`; DOM verified in the in-app browser
- **Source type:** canonical official framework documentation

## Direct evidence

- Identity excerpt: “A task is a single `main.py` with three functions.”
- `load()` declares the task and variants; `start(cfg, session)` stages inputs/apps/start state; `evaluate(cfg, session)` reads outputs/reference and returns scores after the agent finishes.
- One `main.py` is one workflow and one general grading logic; variants reuse that logic on concrete inputs; the public release ships only the base variant.
- Input is visible and staged before the run; reference is hidden and staged only after the agent finishes (or encrypted at rest in baked images).
- Deterministic and judge-based graders are supported; official docs state most tasks are deterministic.
- Natural-language submissions plus raw data are converted by the ALE team into runnable `main.py`, directly separating submission from runnable instance.

## Assessment

- **Credibility: 5/5** for task/runtime semantics.
- **Recency: 5/5** for the 2026-08-08 docs surface, but no immutable revision.
- **Bias: 2/5** (technical primary source; “can't be gamed” is aspirational and requires adversarial validation).

## Supports / challenges

- Supports: H2; workflow/variant/instance separation; hidden-reference staging; minimum schema.
- Challenges: treating a task description, submission, workflow or variant family as interchangeable counts.
- Classification: lifecycle statements are **official implementation facts**; unhackability is an **author claim**.

