# Source 18 — ALE submission guide

- **Title:** Agents' Last Exam is Defined by Domain Experts
- **Author / institution:** UC Berkeley RDI / ALE project team
- **URL:** https://agents-last-exam.org/submit
- **Published:** living page; date not stated
- **Accessed:** 2026-08-08
- **Version / revision:** unversioned live submission-page snapshot; DOM verified in the in-app browser
- **Source type:** canonical official contribution specification

## Direct evidence

- Criteria excerpt: “Complex”, “Representative”, “Verifiable”.
- Complexity is operationalized on the page as expert work taking days rather than minutes; representativeness requires real industry workflows and professional tools; verifiability requires deterministic outputs or a clear rubric.
- The displayed submission anatomy is: `Task Description`, `Input`, `Software`, `Output`, `Evaluation`.
- The page's verification tree asks for a unique deterministic output; otherwise a numerical metric; otherwise simple screenshot question/answer pairs; project files are the last resort.
- The page says the “Evaluate your task idea” interaction does not create or save a submission, proving an idea check is not itself a submitted/runnable task.

## Assessment

- **Credibility: 5/5** for current contribution requirements.
- **Recency: 5/5** for the live snapshot; no revision identifier.
- **Bias: 3/5** (recruitment-oriented official guidance; examples are illustrative).

## Supports / challenges

- Supports: task selection and expert-submission schema; H2's separation of task idea/submission from implemented runnable task.
- Challenges: a prompt-only or generic chat task as an ALE-style asset.
- Classification: **official fact about the current submission surface**; quality/economic-value claims remain **author claims**.

