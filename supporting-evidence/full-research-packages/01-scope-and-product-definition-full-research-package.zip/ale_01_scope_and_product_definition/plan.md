# ALE 1,000-asset scope and product definition — research plan

- Research date / access date: **2026-08-08**
- Object: **UC Berkeley RDI Agents' Last Exam (ALE), arXiv:2606.05405v2** only
- Genre: decision report for scoping and proposing an approximately 1,000-asset professional agent benchmark/data program
- Final report: `2026-08-08_decision_report.md`

## 1. Decision to make

Translate the ambiguous procurement phrase “生产 1,000 道 ALE-style tasks” into a contractible product definition: users, permitted uses, asset unit, workflow/instance counts, access tiers, evaluation system, expert and infrastructure obligations, QA/acceptance criteria, pilot variables, commercial rights, delivery schedule and cost model. No exact allocation, cost, duration, pass rate, or staffing number will be asserted without public evidence or pilot data.

## 2. Four falsifiable hypotheses

1. **H1 — Count-unit hypothesis.** The canonical ALE surfaces use workflow, task/variant and runnable instance as non-equivalent units; therefore “1,000 tasks” is not a sufficient production specification. Refuted if the pinned canonical sources define a single stable, one-to-one task unit across paper, site, repository and dataset.
2. **H2 — Access-purpose incompatibility.** With unchanged instance identity and access permissions, the same instances cannot function both as training/agent-improvement data and as a valid hidden final holdout. Refuted if accepted evaluation methodology shows exposure does not change the interpretation of held-out performance.
3. **H3 — Asset-completeness hypothesis.** An ALE-style deliverable is a runnable, versioned evaluation asset/system—not merely a natural-language prompt—and requires inputs/state, software/environment, reference/evidence, evaluator, metadata, execution contract and QA provenance. Refuted if canonical implementation and submission requirements accept prompt-only artifacts as runnable ALE tasks.
4. **H4 — Cost-driver hypothesis.** Unique workflows, evaluator families and software environments are stronger production-cost and schedule drivers than raw runnable-instance count; hence 1,000 independent workflows and 1,000 instances derived from fewer workflows are materially different products. Refuted if public evidence or pilot measurements show expert, evaluator and environment work scales mainly with instance count and is largely invariant to workflow diversity.

## 3. Required report blocks

1. Executive summary
2. Key definitions and unit hierarchy
3. Evidence/version matrix (paper, live site, submit page, repository revision, HF dataset revision, RDI blog, leaderboard if separately observed)
4. Findings: nine product interpretations, asset anatomy, access separation, workflow-vs-instance implications, data purchase vs benchmark-system purchase, pre-specifiable vs pilot-only variables
5. Counter-evidence, validity threats and uncertainty
6. At least four scope scenarios and a decision matrix
7. Decision implications for an approximately 1,000-instance program
8. Default recommended scope; 15–20 discovery questions; in/out proposal list; rigorous rewrite of “1,000 tasks”
9. Reusable schemas, checklists and formulas
10. Hypothesis verdicts: supported / refuted / underdetermined

## 4. Source strategy

### Canonical ALE sources (implementation facts take priority)

- arXiv HTML `2606.05405v2` plus arXiv metadata/version history
- `agents-last-exam.org/`
- `agents-last-exam.org/submit`
- GitHub `rdi-berkeley/agents-last-exam`, pinned to observed commit SHA
- Hugging Face dataset `agents-last-exam/agents-last-exam`, pinned to observed revision/commit
- Berkeley RDI blog post

### Independent triangulation classes

- Academic benchmark methodology/contamination evidence
- Code/data and benchmark cards documenting harness/evaluator/environment behavior
- Credible industry or standards material on data provenance, licensing, access control, dataset/benchmark commercialization

ALE-specific implementation facts will not be “triangulated” with derivative reposts. Cross-project synthesis will require at least three differently typed independent sources or will be marked **insufficient evidence**.

## 5. Opposition and disconfirmation queries

- ALE evaluator weakness, evaluator gaming, grading false positives/false negatives
- ALE benchmark contamination, leaked tasks/references, public-task overfitting
- harness sensitivity, agent scaffold/tool-budget effects, repeated-trial variance
- benchmark validity limitations and task representativeness
- hidden-test reuse after training exposure; validation overfitting
- parametric instance generation that does not preserve difficulty or validity
- executable benchmark licensing and third-party software/data redistribution constraints
- data-product versus managed evaluation/service economics

## 6. Source file contract and scoring

Every source gets one `sources/NN_slug.md` containing title, author/institution, URL, publication date, access date, version/revision, direct verbatim evidence, interpretation, what it supports/refutes, and three scores:

- **Credibility (1–5):** 5 = primary/versioned or peer-reviewed authoritative; 1 = unattributed/derivative.
- **Recency (1–5):** 5 = checked/current on 2026-08-08 or exact immutable revision; lower scores reflect stale snapshots for a mutable claim.
- **Bias risk (1–5):** 1 = low apparent incentive/selectivity; 5 = strong promotional or commercial incentive. This is not a “truthfulness” score.

Claims in the final report will be tagged: **[事实]**, **[作者/机构主张]**, **[研究员推断]**, **[项目建议]**.

## 7. Risk register

- Living-site counts drift relative to arXiv v2, repository and dataset.
- “task,” “variant,” “workflow,” “instance,” “submission” and “run” may be used inconsistently even within one source.
- Public dataset metadata may expose only a subset and cannot reconstruct the full private taxonomy/inventory.
- Two identical numbers may refer to different sets; equality will not imply identity.
- Claims about production cost/schedule are weakly evidenced publicly; use variable formulas and a pilot gate.
- Repeated agent trials are observations, not additional assets.
- Benchmark scores are joint outcomes of model, harness, environment, budget, evaluator and snapshot.

## 8. Stop criteria

Research is complete when: all six canonical sources are individually saved and version-pinned where possible; the requested nine product interpretations and four-plus scenarios are covered; every central thesis has either three source types or an insufficient-evidence label; an adversarial pass has tested evaluator, leakage, harness and licensing failure modes; citations/quotes are spot-checked; and `refresh_targets.md` records mutable fields.

## 9. Changelog

- 2026-08-08: plan created; incorporated an existing-work warning that ALE count surfaces must remain separate, pending live re-verification.
