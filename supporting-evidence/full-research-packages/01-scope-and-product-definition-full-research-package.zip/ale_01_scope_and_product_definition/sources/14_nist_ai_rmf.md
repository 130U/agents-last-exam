# Source 14 — NIST AI RMF 1.0

- Title: **Artificial Intelligence Risk Management Framework (AI RMF 1.0)**
- Institution: U.S. National Institute of Standards and Technology
- URL: https://doi.org/10.6028/NIST.AI.100-1
- Publication / revision: NIST AI 100-1, January 2023
- Accessed: 2026-08-08
- Scores: Credibility **5/5**; Recency **3/5**; Bias risk **1/5**
- Source type: independent public standard/risk framework

## Short verbatim evidence

> “Test sets, metrics, and details about the tools used during TEVV are documented.”

## Direct evidence relevant to scope

- The framework calls for construct validation, data selection documentation, test-set/metric/tool records, deployment-like conditions, generalizability limits and third-party software/data/IP risk management.

## Boundary / counter-evidence

- AI RMF is voluntary and not an ALE engineering specification; it supplies no staffing, schedule, cost or allocation numbers.

## Supports / refutes

- Supports: acceptance documentation, deployment relevance and third-party-risk gates.
- Refutes: prompt delivery alone as adequate evidence of evaluation validity.

