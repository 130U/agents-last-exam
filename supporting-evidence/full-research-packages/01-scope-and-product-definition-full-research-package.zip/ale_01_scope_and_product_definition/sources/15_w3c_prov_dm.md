# Source 15 — W3C PROV-DM

- Title: **PROV-DM: The PROV Data Model**
- Editors / institution: Luc Moreau, Paolo Missier; W3C Provenance Working Group
- URL: https://www.w3.org/TR/2013/REC-prov-dm-20130430/
- Publication / revision: W3C Recommendation, 2013-04-30
- Accessed: 2026-08-08
- Scores: Credibility **5/5**; Recency **1/5** (stable normative recommendation); Bias risk **1/5**
- Source type: independent web standard

## Short verbatim evidence

> “entities, activities, and people involved in producing a piece of data”

## Direct evidence relevant to scope

- PROV-DM models entities, activities and agents plus generation, use, derivation, revision, attribution and responsibility.
- A benchmark asset can therefore record relationships among source data, input, reference, evaluator, environment build and QA/review activity rather than a single flat source string.

## Boundary / counter-evidence

- PROV-DM is a representation model, not proof that rights are cleared or content/evaluators are correct.

## Supports / refutes

- Supports: component-level provenance and revision chains.
- Refutes: one top-level `source` field as a sufficient audit trail.

