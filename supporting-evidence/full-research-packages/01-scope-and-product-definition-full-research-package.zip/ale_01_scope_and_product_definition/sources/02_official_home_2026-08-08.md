# Source 02 — ALE official homepage (living snapshot)

- Title: **AI Agent Benchmark for Real-World Professional Workflows**
- Institution: UC Berkeley RDI / RDI Foundation
- URL: https://agents-last-exam.org/
- Publication / revision: living page; no revision ID or public last-modified timestamp
- Accessed: 2026-08-08 (verified in the in-app browser and web reader)
- Scores: Credibility **4/5**; Recency **5/5**; Bias risk **4/5**
- Source type: canonical current product/communications surface

## Short verbatim evidence

> “1,500+ tasks collected toward a 5,000-task target”

## Direct evidence relevant to scope

- The current hero uses the generic unit **tasks**, 300+ experts and 55 targeted sub-industries. It does not state workflow/instance/release-state composition.
- The page separates domain-expert contribution (workflow data) from researcher/engineer work (setup, execution and evaluation).
- The footer separates dataset license (CC BY 4.0), code license (Apache-2.0) and Contributor Terms.

## Boundary / counter-evidence

- Current 1,500+ / 5,000 counters are collection-program claims, not arXiv v2's frozen 1,490-instance manifest and not a client production allocation.
- The site calls ALE largest-scale/broadest-coverage and its scores objective/comparable/meaningful; these are institution claims, not independent validations.
- Dataset/code licenses do not automatically clear third-party software, proprietary standards, confidential inputs, trademarks or contributor reference assets.

## Supports / refutes

- Supports: living-program and two-sided expert/engineering production model.
- Refutes: merging website counters into the paper or treating “5,000 target” as delivered runnable assets.

