# Source 13 — SWE-bench repository (adjacent implementation evidence)

- Title: **SWE-bench** repository README
- Authors / maintainers: SWE-bench organization; Carlos E. Jimenez, John Yang et al.
- URL: https://github.com/SWE-bench/SWE-bench/blob/main/README.md
- Observed file revision: README blob `16563c30931ca8e370da129f4f8aedefb39d76c9`
- Publication / revision: continuously updated `main`; observed 2026-08-08
- Accessed: 2026-08-08
- Scores: Credibility **5/5** for implementation facts; Recency **5/5**; Bias risk **3/5**
- Source type: independent adjacent benchmark code/documentation

## Short verbatim evidence

> “SWE-bench uses Docker for reproducible evaluations.”

## Direct evidence relevant to scope

- The repository separately delivers dataset loading, Docker setup, evaluation commands, logs/results and resource requirements.
- It keeps test-split evaluation private, illustrating an operational separation between public data/development and final evaluation.

## Boundary / counter-evidence

- Docker and code-patch grading do not specify how ALE-style licensed desktop/spreadsheet/CAD workflows should run.
- A container claim still requires architecture, dependency and cross-machine acceptance tests.

## Supports / refutes

- Supports: dataset purchase versus runnable benchmark-system purchase; private final evaluation as a real operating model.
- Refutes: equating task records with execution, grading and audit infrastructure.

