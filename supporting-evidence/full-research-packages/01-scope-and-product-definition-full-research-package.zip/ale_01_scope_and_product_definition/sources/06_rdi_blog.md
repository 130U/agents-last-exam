# Source 06 — Berkeley RDI ALE blog

- Title: **Agents' Last Exam**
- Authors / institution: Yiyou Sun et al.; UC Berkeley RDI
- URL: https://rdi.berkeley.edu/blog/agents-last-exam/
- Publication: June 2026 (no day shown on page)
- Revision: no public revision ID/timestamp
- Accessed: 2026-08-08
- Scores: Credibility **4/5**; Recency **5/5**; Bias risk **5/5**
- Source type: canonical institutional overview / promotional claim surface

## Short verbatim evidence

> “No vibes. No human judges. Fully reproducible.”

## Direct evidence relevant to scope

- The page says tasks derive from real completed projects, uses 300+ experts/100+ institutions and 1,500+ tasks.
- It positions ALE as full GUI+CLI, outcome-based evaluation and says model failure patterns differ on identical tasks.
- It reports cases where agents declare success despite missing/incorrect outputs or violated constraints, supporting artifact-completeness gates.

## Qualification / counter-evidence

- The quoted reproducibility statement is an **author/institution claim**. Paper v2 reports some LLM judging, human expert QC and private/licensed tasks; runtime automation is not the same as universal third-party reproducibility.
- The blog's 55 “occupations/industry domains” and 1,500+ generic tasks are looser units than the paper's formal taxonomy and instance manifest.

## Supports / refutes

- Supports: public positioning and need for outcome/completeness QA.
- Refutes: treating promotional phrasing as proof of perfect evaluator validity or unrestricted reproducibility.

