# Source 07 — ALE-V1 leaderboard snapshot

- Title: **Leaderboard | Agents' Last Exam**
- Institution: UC Berkeley RDI project
- URL: https://agents-last-exam.org/leaderboard
- Snapshot labels observed: “Best-per-task (Jul 4, 2026)”; runtime methodology updated 2026-07-10
- Accessed: 2026-08-08 in the in-app browser
- Scores: Credibility **4/5**; Recency **5/5**; Bias risk **3/5**
- Source type: canonical living result surface; not the arXiv v2 table

## Short verbatim evidence

> “Pass Rate is the share of runs that earned a perfect score”

## Direct evidence relevant to scope

- The page distinguishes Pass Rate, mean partial-credit Score and “Best of All Runs,” where each task contributes its best run.
- Rows identify **harness, model and effort**, plus estimated cost, runtime and tokens. The score is therefore a configured agent-system/run result, not a bare-model property.
- Runtime excludes queueing, environment setup, evaluation and output sync.
- Cost can be logged or estimated from token counts/list prices and may deviate from invoices.
- The page has Full versus Unlicensed views because some tasks require commercial software, paid APIs or licensed data.

## Boundary / counter-evidence

- “Best per task” is selection over runs and should not be compared as though it were one consistent deployable system.
- Leaderboard run cost is not task-authoring/implementation/QC/licensing cost.
- Current split names/results are a later living snapshot and must not replace paper v2's experiment manifest.

## Supports / refutes

- Supports: strict agent-run/repeated-trial/configuration units; licensed-infrastructure and cost-accounting requirements.
- Refutes: calling leaderboard numbers pure model scores or using API run cost as production cost.

