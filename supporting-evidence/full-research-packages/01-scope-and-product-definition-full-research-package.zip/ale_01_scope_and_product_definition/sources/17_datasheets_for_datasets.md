# Source 17 — Datasheets for Datasets

- Title: **Datasheets for Datasets**
- Authors: Timnit Gebru, Jamie Morgenstern, Briana Vecchione, Jennifer Wortman Vaughan, Hanna Wallach, Hal Daumé III, Kate Crawford
- URL: https://arxiv.org/abs/1803.09010
- Publication / revision: v1 2018-03-23; **arXiv v8 2021-12-01**, corresponding to CACM version
- Accessed: 2026-08-08
- Scores: Credibility **5/5**; Recency **2/5**; Bias risk **1/5**
- Source type: independent peer-reviewed dataset-documentation framework

## Short verbatim evidence

> “motivation, composition, collection process, recommended uses”

## Direct evidence relevant to scope

- The framework covers motivation, composition, collection, uses, distribution, maintenance, assumptions, risks and restrictions.

## Boundary / counter-evidence

- Documentation does not guarantee content correctness, legal rights or executable environments and supplies no ALE production rate.

## Supports / refutes

- Supports: dataset/product documentation, intended-use and maintenance records.
- Refutes: a schema-only README as sufficient for safe reuse or OTS sale.

