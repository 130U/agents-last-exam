# Source 04 — ALE GitHub repository and README at observed head

- Title: **rdi-berkeley/agents-last-exam**
- Institution / maintainers: Berkeley RDI project repository
- Repository: https://github.com/rdi-berkeley/agents-last-exam
- Pinned observed head: `1e615e456de7cef57706680613cb80ee13c7fc76` (2026-08-05T19:19:49Z)
- Pinned README: https://github.com/rdi-berkeley/agents-last-exam/blob/1e615e456de7cef57706680613cb80ee13c7fc76/README.md
- Accessed: 2026-08-08 through the GitHub connector
- Scores: Credibility **5/5**; Recency **5/5**; Bias risk **3/5**
- Source type: canonical code / implementation surface

## Short verbatim evidence

> “one agent × one environment × one task”

## Direct evidence relevant to scope

- The README calls the repository the open evaluation framework plus around 150 public tasks, not the full paper inventory.
- `selected_tasks/full.txt` contains **152 unique curated workflow paths**. The three tier files contain `67+55+38=160` memberships but only 152 unique paths because 8 paths occur in two tiers.
- The runner selects variant index 0 by default for each path. All 152 curated paths expose `load()`, `start()` and `evaluate()`; 165 total code directories under `tasks/` include demo/non-curated directories and are not a public benchmark count.
- A run provisions a sandbox, stages inputs, runs the agent, stages the hidden reference only after completion, grades outputs and collects logs/trajectory/artifacts.
- The task is executable `main.py` containing instruction, input data and hidden reference; `evaluate()` returns a score in `[0,1]`.
- Supported infrastructure spans multiple cloud VM providers, QEMU/KVM, local Docker for a subset and existing sandboxes; licensed/custom-image tasks are separately recognized.
- Software is Apache-2.0; benchmark content is CC BY 4.0.

## Boundary / counter-evidence

- The open repository is a changing implementation snapshot and exposes only the public/reference tree.
- “around 150” cannot be used as an exact frozen manifest without a commit-pinned task list.
- Current public card IDs show 14 distinct `domain_id` and 51 distinct `subdomain_id` values; this code/data snapshot must not be merged into the paper's formal 13/55 taxonomy.
- Cross-provider support does not prove every task is portable or license-free; README explicitly distinguishes licensed/custom-image tasks and a lighter Docker subset.

## Supports / refutes

- Supports: H3; data purchase versus runnable system distinction; infrastructure and audit-record requirements.
- Refutes: treating a dataset card or prompt table as equivalent to the runnable benchmark framework.
