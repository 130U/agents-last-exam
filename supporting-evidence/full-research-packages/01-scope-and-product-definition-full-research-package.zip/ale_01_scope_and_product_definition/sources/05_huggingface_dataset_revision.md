# Source 05 — ALE Hugging Face metadata dataset

- Title: **agents-last-exam/agents-last-exam**
- Publisher: agents-last-exam organization
- URL: https://huggingface.co/datasets/agents-last-exam/agents-last-exam
- Pinned revision: `a8c1fd174a1f6cfa76526572a2e3ebece1276be2`
- API lastModified: 2026-07-11T06:17:59Z
- Accessed: 2026-08-08 via HF dataset page and public API
- Scores: Credibility **5/5**; Recency **5/5**; Bias risk **3/5**
- Source type: canonical data/metadata snapshot

## Short verbatim evidence

> “v1.0 · 153 rows”

## Direct evidence relevant to scope

- The public dataset surface exposes 153 metadata rows with fields such as `task_id`, `title`, `summary`, `category`, `subdomain`, `task_split`, `task_prompt`, `agent_must_do`, `software`, `input_files`, `taxonomy` and `source_repo_path`.
- The repository contains only `.gitattributes`, `README.md` and `task_cards.parquet`; it is a metadata-only release at this revision.
- The dataset is public, ungated and tagged CC BY 4.0.
- Compared with GitHub `selected_tasks/full.txt@1e615e...`, HF has exactly one extra row, `engineering/2d_drawings_to_3d_bridge_model`, with null split. GitHub has code for it but omits it from the curated full manifest.
- HF split rows are 67 near-term, 47 full-spectrum, 38 last-exam and 1 null. GitHub's 55 full-spectrum is tier-list membership with cross-tier duplicates, not the same unit.

## Boundary / counter-evidence

- 153 metadata rows are not the paper's 150 inventory, 152 evaluated tasks, 960 workflows or 1,490 instances; each is a different surface/snapshot.
- A public task card does not include every hidden reference, licensed environment, executable grader, access policy or run history needed for a full system.
- `category` and observed taxonomy rows cannot reconstruct the full private taxonomy or production allocation.
- Three current curated GitHub cards omit a card-level `evaluation` field despite executable `evaluate()` implementations, so metadata-field completeness alone is not runtime acceptance.

## Supports / refutes

- Supports: minimum metadata fields and revision pinning.
- Refutes: equating metadata-table row count with full runnable benchmark assets.
