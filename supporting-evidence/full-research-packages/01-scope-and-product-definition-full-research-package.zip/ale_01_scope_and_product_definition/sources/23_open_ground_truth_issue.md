# Source 23 — Open ground-truth concern in an ALE public task

- Title: **Is `SHIP` the intended ground truth for this A/B test?**
- Reporter / repository: `wanyichen06`; rdi-berkeley/agents-last-exam
- URL: https://github.com/rdi-berkeley/agents-last-exam/issues/62
- Status / date: opened 2026-08-04; still open when accessed 2026-08-08
- Accessed: 2026-08-08
- Scores: Credibility **3/5**; Recency **5/5**; Bias risk **3/5**
- Source type: unadjudicated implementation counterevidence

## Short verbatim evidence

> “This looks like a tracking or data-generation problem.”

## Direct evidence relevant to scope

- The issue questions whether a task's expected recommendation is valid given apparently inconsistent downstream event data.
- The grader-hardening PR explicitly did not resolve this ground-truth question.

## Boundary / counter-evidence

- This is a specific reproducible concern, not a confirmed task defect or evidence that ALE evaluators generally fail.
- Its unresolved state is nevertheless enough to show that final-QC status and deterministic code do not eliminate reference/ground-truth challenge processes.

## Supports / refutes

- Supports: issue/adjudication workflow, gold-data validation and post-release defect handling.
- Refutes: treating public inclusion alone as proof that every reference/evaluator is beyond dispute.

