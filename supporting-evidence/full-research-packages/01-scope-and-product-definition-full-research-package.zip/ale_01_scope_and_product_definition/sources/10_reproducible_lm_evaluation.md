# Source 10 — Lessons from the Trenches on Reproducible Evaluation of Language Models

- Title: **Lessons from the Trenches on Reproducible Evaluation of Language Models**
- Authors / institutions: Stella Biderman, Hailey Schoelkopf, Lintang Sutawika et al.; EleutherAI and academic collaborators
- URL: https://arxiv.org/html/2405.14782v3
- Publication / revision: v1 2024-05-23; **v3 2026-05-31**
- Accessed: 2026-08-08
- Scores: Credibility **4/5**; Recency **5/5**; Bias risk **3/5**
- Source type: independent/adjacent evaluation-method paper

## Short verbatim evidence

> “Provide Evaluation Code.”

## Direct evidence relevant to scope

- Small prompt and implementation choices can materially change scores and even rankings.
- The authors call for exact code, prompts, methods, outputs and statistical analysis.
- They distinguish variation over repeated model runs from task-sampling uncertainty.

## Boundary / counter-evidence

- The empirical focus is language-model evaluation, not long-horizon professional desktop agents; effect sizes cannot be imported into ALE.

## Supports / refutes

- Supports: executable evaluator delivery, version binding, logs and variance reporting.
- Refutes: score comparability without matching code/configuration and treating task bootstrap as a substitute for repeated trials.

