# Source 11 — LiveBench v2

- Title: **LiveBench: A Challenging, Contamination-Limited LLM Benchmark**
- Authors: Colin White et al.
- URL: https://arxiv.org/abs/2406.19314
- Publication / revision: v1 2024-06-27; **v2 2025-04-18**; ICLR 2025 Spotlight
- Accessed: 2026-08-08
- Scores: Credibility **4/5**; Recency **4/5**; Bias risk **3/5**
- Source type: independent adjacent benchmark paper

## Short verbatim evidence

> “Questions are added and updated on a monthly basis.”

## Direct evidence relevant to scope

- LiveBench uses recent sources, objective ground truth and continuing updates while making questions/code/answers public.
- The v2 title changed from “Contamination-Free” to “Contamination-Limited,” a useful correction against absolute cleanliness claims.

## Boundary / counter-evidence

- Public rotation can improve freshness/transparency but cannot prevent future training exposure forever.
- This QA/LLM benchmark does not establish an ALE workflow-to-instance ratio or environment cost.

## Supports / refutes

- Supports: public development/audit set plus rotation as a complement to private holdout.
- Refutes: “public and permanently hidden” as a coherent access state and “contamination-free” as a durable guarantee.

