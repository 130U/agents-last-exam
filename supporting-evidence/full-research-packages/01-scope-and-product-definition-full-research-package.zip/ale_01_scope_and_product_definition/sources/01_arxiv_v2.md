# Source 01 — Agents' Last Exam (arXiv v2)

- Title: **Agents' Last Exam**
- Authors / institution: Yiyou Sun et al.; leading institution UC Berkeley
- URL: https://arxiv.org/html/2606.05405v2
- Publication / revision: v1 2026-06-03; **arXiv:2606.05405v2**, revised 2026-06-11
- Accessed: 2026-08-08
- Scores: Credibility **5/5**; Recency **4/5**; Bias risk **3/5**
- Source type: canonical primary paper; author-evaluated preprint

## Short verbatim evidence

> “task workflow for an end-to-end professional procedure”

> “task instance for one runnable case”

## Direct evidence relevant to scope

- §2.1 defines admission around **Representative, Complex, Verifiable** professional workflows.
- Figure 5 partitions a 1,490-**instance** snapshot by provenance: 960 external submissions + 530 commissioned tasks; and by release state: 150 public + 1,017 private + 323 pending QC.
- §3 says a workflow is the professional procedure; an instance is a concrete runnable input/output case sharing the workflow's `evaluate()`.
- Appendix C.3.7 separately says 960 workflows and 1,490 instances. The paper does not prove that its two “960” sets are identical.
- §2.3 documents expert sourcing, portal submission, first review/revision, engineering implementation/dry-run, and final expert QC. A submission is therefore not an accepted runnable instance.
- §3.1 requires an executable `main.py`, input assets, software/environment, hidden reference assets, evaluation criteria, `load()/start()/evaluate()`, and separated `input/software/output/reference` directories.
- §2.3 motivates a private/rotating pool with contamination and task-specific optimization risk. Rotation is an intended design, not evidence of an executed contamination audit.
- Table 1 notes three repeated runs only for a subset of configurations. One repeated run is an observation, not another benchmark asset.
- Appendix D.1's representativeness result is one system's cluster-level correlation (`r=0.89`); it does not establish proportional sampling across every domain/tier/source/difficulty.

## Internal drift / counter-evidence

- Paper surfaces use 150 public in the inventory but 152 in the experiment section.
- Paper surfaces use 250+ and 300+ expert/practitioner language.
- The evaluator mix (93.2% code, 6.8% LLM judge) is static analysis of the open-source reference tree, not a full-private-pool statistic.
- Production staffing, authoring hours, evaluator error, acceptance yield, software-license cost and end-to-end schedule are not reported.

## Supports / refutes

- Supports: H1, H2 and H3; workflow/instance separation; a benchmark-system rather than prompt-list scope.
- Partially supports H4 architecturally, but does not provide production-cost measurements.
- Refutes: using 1,490/960 as a production quota or treating public/private/pending as one final accepted pool.

