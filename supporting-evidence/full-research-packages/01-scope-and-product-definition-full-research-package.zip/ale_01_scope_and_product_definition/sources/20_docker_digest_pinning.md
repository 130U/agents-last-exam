# Source 20 — Docker image digest pinning

- Title: **Building best practices: Pin base image versions**
- Institution: Docker documentation team
- URL: https://docs.docker.com/build/building/best-practices/#pin-base-image-versions
- Publication / revision: living official documentation
- Accessed: 2026-08-08
- Scores: Credibility **5/5** for Docker behavior; Recency **5/5**; Bias risk **2/5**
- Source type: authoritative industry implementation documentation

## Short verbatim evidence

> “Image tags are mutable.”

## Direct evidence relevant to scope

- A tag can point to changed content; pinning a digest makes pulls resolve to the same image content.
- Digest pinning trades automatic security updates for controlled update/audit responsibility.

## Boundary / counter-evidence

- An image digest does not freeze external APIs, license servers, hardware, clocks, network, secrets or user/account state.

## Supports / refutes

- Supports: environment digests plus update/deprecation policy.
- Refutes: a mutable `latest`/version tag or container alone as full reproducibility proof.

