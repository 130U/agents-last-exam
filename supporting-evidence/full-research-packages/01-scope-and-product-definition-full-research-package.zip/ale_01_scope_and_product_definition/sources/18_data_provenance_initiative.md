# Source 18 — Data Provenance Initiative audit

- Title: **The Data Provenance Initiative: A Large Scale Audit of Dataset Licensing & Attribution in AI**
- Authors / institutions: Shayne Longpre, Robert Mahari, Anthony Chen et al.; MIT, Cohere For AI and collaborators
- URL: https://arxiv.org/abs/2310.16787
- Publication / revision: v1 2023-10-25; **v3 2023-11-04**
- Accessed: 2026-08-08
- Scores: Credibility **4/5**; Recency **3/5**; Bias risk **2/5**
- Source type: independent academic audit

## Short verbatim evidence

> “mistaking licenses attached to code … for licenses attached to data.”

## Direct evidence relevant to scope

- The audit traces dataset source/creator/license chains and reports common license omission/miscategorization on hosting and aggregation surfaces.
- It directly warns against treating a code repository's license as a dataset license.

## Boundary / counter-evidence

- Its sample centers on text/alignment/finetuning collections; professional files, software and sector data add different rights risks.
- Legal implications vary by jurisdiction and contract; this is not legal advice.

## Supports / refutes

- Supports: component-level license evidence and rights review for OTS eligibility.
- Refutes: assuming HF or repo top-level license metadata clears every input/reference/software component.

