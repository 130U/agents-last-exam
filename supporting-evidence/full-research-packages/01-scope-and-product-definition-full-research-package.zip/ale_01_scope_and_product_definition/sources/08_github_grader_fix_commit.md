# Source 08 — Grader-hardening head commit

- Title / message: **fix(tasks): harden graders and sync visual-media evaluators**
- Institution / maintainers: Berkeley RDI project repository
- URL: https://github.com/rdi-berkeley/agents-last-exam/commit/1e615e456de7cef57706680613cb80ee13c7fc76
- Commit: `1e615e456de7cef57706680613cb80ee13c7fc76`
- Date: 2026-08-05T19:19:49Z
- Accessed: 2026-08-08 through the GitHub connector
- Scores: Credibility **5/5**; Recency **5/5**; Bias risk **2/5**
- Source type: canonical implementation-change evidence

## Short verbatim evidence

> “fix/tasks: harden graders”

## Direct evidence relevant to scope

- The merge fixes grader false-zero and visual-media evaluator synchronization issues, adds defensive parsing and component-level partial scoring, and adds regression tests.
- The diff changes what valid-but-differently-formatted outputs receive credit for and how missing/unreadable components affect partial credit.

## Boundary / counter-evidence

- This is direct evidence that evaluator implementation can under-credit, over-credit or change scores after release; it is not proof that all current evaluators are weak.
- A versioned benchmark delivery must bind result records to evaluator commit, environment image and task revision and must support re-grading/regression tests.

## Supports / refutes

- Supports: evaluator QA, change control, regression suites and score-version provenance.
- Refutes: assuming a deterministic grader is automatically correct or immutable.

