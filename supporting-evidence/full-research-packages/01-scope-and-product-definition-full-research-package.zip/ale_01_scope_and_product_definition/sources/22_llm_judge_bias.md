# Source 22 — Judging LLM-as-a-Judge

- Title: **Judging LLM-as-a-Judge with MT-Bench and Chatbot Arena**
- Authors / institutions: Lianmin Zheng, Wei-Lin Chiang et al.; UC Berkeley, CMU and collaborators
- URL: https://proceedings.neurips.cc/paper_files/paper/2023/hash/91f18a1287b398d378ef22505bf41832-Abstract-Datasets_and_Benchmarks.html
- Publication / revision: NeurIPS 2023 Datasets and Benchmarks Track
- Accessed: 2026-08-08
- Scores: Credibility **5/5**; Recency **3/5**; Bias risk **3/5**
- Source type: independent/adjacent peer-reviewed judge-method study

## Short verbatim evidence

> “position, verbosity, and self-enhancement biases”

## Direct evidence relevant to scope

- The study reports useful agreement with human preferences in its settings while documenting judge biases and limited reasoning.
- It supports calibration, order/swap tests, reference anchoring and human escalation rather than an absolute ban or blanket trust.

## Boundary / counter-evidence

- Chat-preference agreement is not professional-artifact grader accuracy and cannot be used as an ALE evaluator error rate.

## Supports / refutes

- Supports: special QA and versioning for LLM-judged components.
- Refutes: “LLM judge always invalid” and “LLM judge automatically objective” as universal claims.

