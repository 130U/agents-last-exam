# Source 12 — Developers Should Report Train–Test Overlap

- Title: **Position: Language Model Developers Should Report Train-Test Overlap**
- Authors / institutions: Andy K. Zhang, Kevin Klyman, Yifan Mai, Yoav Levine, Yian Zhang, Rishi Bommasani, Percy Liang; Stanford CRFM and collaborators
- URL: https://proceedings.mlr.press/v267/zhang25dt.html
- Publication / revision: ICML 2025, PMLR 267
- Accessed: 2026-08-08
- Scores: Credibility **4/5**; Recency **4/5**; Bias risk **2/5**
- Source type: independent peer-reviewed position paper

## Short verbatim evidence

> “correctly interpreting evaluation results requires knowledge of train-test overlap.”

## Direct evidence relevant to scope

- The paper defines overlap as training on the same data used for evaluation and argues that developers should disclose it.
- Exposure does not make a known-task regression test useless, but it changes the performance claim from unseen generalization to known-task optimization.

## Boundary / counter-evidence

- It is a position paper; it does not prove a uniform score-inflation magnitude for every overlap type.

## Supports / refutes

- Supports: H2 and an explicit `trained_on/tested_on` relationship in the asset manifest.
- Refutes: using exposed training instances as an undisclosed hidden final benchmark.

