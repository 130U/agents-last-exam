# Source 09 — AI Agents That Matter

- Title: **AI Agents That Matter**
- Authors / institutions: Sayash Kapoor, Benedikt Stroebl, Zachary S. Siegel, Nitya Nadgir, Arvind Narayanan; Princeton and collaborators
- URL: https://arxiv.org/html/2407.01502
- Publication / revision: arXiv:2407.01502v1, 2024-07-01
- Accessed: 2026-08-08
- Scores: Credibility **4/5**; Recency **4/5**; Bias risk **2/5**
- Source type: independent academic evaluation-method study

## Short verbatim evidence

> “many agent benchmarks have inadequate holdout sets”

## Direct evidence relevant to scope

- The paper argues that the holdout level must match the intended generalization claim and documents shortcut/overfitting risks.
- Its reproduction work shows evaluator scripts, task subsets/order, external environments and implementation bugs can produce incomparable results.
- It notes agent evaluations often omit repeated-trial error bars and that multiple attempts change pass probability.

## Boundary / counter-evidence

- This is not an ALE validation and its selected benchmark cases cannot yield ALE production costs.
- The paper also notes that excluding human assistance may understate practical usefulness; benchmark bias is not always upward.

## Supports / refutes

- Supports: H2, harness/environment/version disclosure and repeated-trial planning.
- Refutes: treating a single run or public-set optimization as unseen generalization.

