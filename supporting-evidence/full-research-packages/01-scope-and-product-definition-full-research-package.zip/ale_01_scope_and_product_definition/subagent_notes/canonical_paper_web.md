# ALE canonical paper/web evidence memo

Research cut-off / access date: **2026-08-08**  
Scope: UC Berkeley RDI **Agents' Last Exam (ALE)** only; excludes other ALE/ALE-Bench projects.  
Purpose: evidence hand-off for `ale_01_scope_and_product_definition`; this is not the final report.

## Evidence-label convention

- **[FACT]** Directly stated or mechanically implied by the named source at the pinned snapshot.
- **[AUTHOR CLAIM]** ALE/RDI's interpretation, quality claim, or future commitment; not independently validated here.
- **[INFERENCE]** Researcher synthesis from the cited facts.
- **[PROJECT IMPLICATION]** Proposed use in a 1,000-asset scope; not a claim about ALE's own production budget.

Score scale: Credibility and Recency are `1 (weak/old)–5 (strong/current)`; Bias is **risk**, `1 (low)–5 (high)`. All four sources are first-party and therefore are not independent corroboration of ALE's validity.

## Source 1 — arXiv paper v2

**Title:** Agents' Last Exam  
**Authors / institution:** Yiyou Sun et al.; leading institution UC Berkeley; 310 authors shown by arXiv metadata  
**URL:** https://arxiv.org/html/2606.05405v2  
**Version / revision:** `arXiv:2606.05405v2`; v1 submitted 2026-06-03; v2 revised 2026-06-11 10:09:39 UTC  
**Accessed:** 2026-08-08  
**Scores:** Credibility **5/5**; Recency **4/5**; Bias risk **3/5** (primary technical description, but the authors evaluate and promote their own benchmark)

### Short verbatim evidence (within quotation limit)

- §3 terminology: “task workflow for an end-to-end professional procedure”; “task instance for one runnable case”.
- Appendix C.3.7: “960 task workflows and 1,490 task instances”.

### Direct evidence and exact anchors

1. **Identity and revision.** arXiv abstract page records v1 on 2026-06-03 and v2 on 2026-06-11. HTML header is `arXiv:2606.05405v2 [cs.AI] 11 Jun 2026`. The abstract says 13 industry clusters, 55 subfields, 1K+ tasks, and 250+ industry experts. [FACT; arXiv header/Abstract]

2. **Admission criteria.** ALE admits workflows that are representative of professional practice, complex/end-to-end rather than a local action, and objectively verifiable through deterministic checks or an unambiguous artifact-tied rubric. [FACT; §2.1]

3. **Exact unit hierarchy.** The paper defines workflow as the end-to-end professional procedure and instance as a runnable concrete input/output case that shares a workflow's `evaluate()` but has different input/output data. A bare “task” is normally used at instance level. [FACT; §3, Terminology]

4. **Workflow-to-instance multiplicity.** Appendix C.3.7 says one `main.py` exposes a `VARIANTS` list. The manufacturing/G-code workflow has 18 workpiece instances with different input/reference data and a shared collision-gate-plus-surface evaluator. Instance scores aggregate to workflow, then industry, then cluster. [FACT; §3.3; Appendix C.3.7]

5. **Inventory/provenance/release-state snapshot.** Figure 5 captions the 1,490 instance inventory as 960 **external submissions** plus 530 **commissioned tasks**; by release state it is 150 public, 1,017 private, and 323 unverified/pending QC. These are two distinct partitions of the same 1,490-item Figure 5 inventory. [FACT; §2.3, Figure 5]

6. **Submission is not yet a runnable accepted instance.** Five gates are: expert sourcing; submission/editing; first-pass review; engineering implementation; final QC/acceptance. First-pass decisions can require revision. Only after conversion to runnable assets/software/evaluation, engineer dry-run, and final expert-committee QC is a task admitted. [FACT; §2.3; Appendix B.2]

7. **Expert and engineering roles.** Practitioners upload prior projects said to have taken days/weeks; portal tools assist specification. Engineers translate intent into runnable assets, provision software, codify evaluation, and dry-run. Expert committees check reference correctness, evaluator-bound calibration, and context sufficiency. [FACT about documented process; the authenticity/rigor outcome is an AUTHOR CLAIM; Appendix B.2]

8. **Five submission components vs executable asset.** Portal submission specifies description, inputs, target software/tools, expected deliverable, and evaluation specification. The executable `main.py` encodes description, input assets, required software, **reference assets**, and evaluation criteria, plus:
   - `load()` — declarative task metadata and compute requirements;
   - `start()` — deterministic VM preparation;
   - `evaluate()` — score output/reference or rubric to `[0,1]`.
   The VM contract separates read-only `input/`, pre-installed `software/`, writable `output/`, and hidden `reference/`. [FACT; §3.1; Appendix C.1–C.2]

9. **Provenance evidence.** For source-grounded tasks, papers, datasets, standards, and workflow documents may define inputs/labels/references; the task bundle retains those source records as material provenance. [FACT; Appendix B.2]

10. **Evaluation modes.** Artifact modes include exact/hash, structured numeric/tabular with tolerance, geometric/spatial, visual, behavioral state, free-text/semantic, and executable artifacts. Most workflows combine modes; gate-and-score is common. [FACT; §3.3; Appendix C.3.2–C.3.3]

11. **Evaluator distribution is not a full-private-pool statistic.** Static analysis of the **open-sourced reference task tree** reports 93.2% code-based and 6.8% LLM-as-judge at workflow level, plus 88.5% host-side and 11.5% VM-side verifier. The paper does not establish that these percentages describe all 960 workflows, all 1,490 instances, or pending-QC material. [FACT + boundary; Appendix C.3.5]

12. **Reference isolation and reproducibility record.** Reference assets remain outside the agent workspace; missing-reference checks return zero rather than inflate scores. For LLM-judged workflows, judge model/prompt are recorded and saved artifacts permit re-derivation. [FACT; Appendix C.3.6]

13. **Agent/run/trial units.** The evaluated subject is the complete agent system (foundation model plus harness/tool interface), not a bare model. A run is one agent-system attempt on one instance, capped at five hours in reported experiments. Standard deviations shown in Table 1 use three independent runs of the same instance, but only for a subset of configurations due to compute limits. [FACT; §3.1–3.3; §4; Table 1 note]

14. **Public/private release policy.** v2 releases 150/1,490 publicly and proposes rotating private instances into public while retiring prior public items. The motivation is pre-training overlap and task-specific optimization. The rotation language is prospective; v2 does not document an executed cadence, retirement manifest, or contamination audit. [FACT for design; AUTHOR CLAIM for maintaining an uncontaminated surface; §2.3]

15. **Representativeness evidence is narrow.** Appendix D.1 correlates cluster pass rates for one system (Claude Code + Opus 4.7) on public vs full pool: Pearson `r=0.89`, `p<0.001`. It also says the public pool is harder because it contains the full Last-Exam tier. This supports similar domain-difficulty ordering for that system, not proportional sampling by domain/tier/source or universal representativeness. [FACT + INFERENCE; Appendix D.1]

16. **Production cost data are absent.** §4 reports that one frontier-agent run on a public instance averages USD 3–10 and tens of minutes to hours. That is inference/evaluation expense, not expert-authoring, implementation, licensing, QC, or asset-production cost. No public per-task production hours, staffing ratios, or end-to-end yield are reported. [FACT + boundary; §4]

### Internal paper inconsistencies / limitations

- **Two different `960`s.** Figure 5 labels 960 external submissions; Appendix C.3.7/Conclusion labels 960 task workflows. The paper supplies no mapping proving identity. Do not infer 960 experts, 960 accepted submissions, or one external submission per workflow. [FACT + INFERENCE]
- **150 vs 152 public.** §2.3/Figure 5/Appendix B.3.2 use 150 public/selected tasks; §4 calls the evaluated public set 152 tasks. Preserve both snapshots; reproduce only from a frozen manifest. [FACT]
- **250+ vs 300+.** Abstract/Introduction use 250+ experts; Related Work/Conclusion prose refers to 300+ practitioners. Treat as internal revision/count drift, not a single exact staffing figure. [FACT]
- **Private vs pending-QC arithmetic.** §2.3 prose says the remainder after 150 public is held private, while Figure 5 explicitly separates 1,017 private and 323 pending QC. Use the Figure 5 three-state partition; do not call all 1,340 non-public items final private holdout. [FACT + reconciliation]
- **No dedicated limitations section.** The paper does not quantify evaluator false-positive/false-negative rates, inter-rater agreement for expert QC, software-license failure rates, instance-construction hours, or final acceptance yield. [FACT]
- **Evaluator weakness remains possible.** Final QC explicitly checks for bounds that are too narrow or spuriously permissive, which acknowledges the failure mode; no public aggregate calibration study shows it has been eliminated. [INFERENCE]
- **Saturation/GDP meaning is an author interpretation.** The claim that saturation would signal industrially sufficient professional work is not backed by a matched human baseline, labor-market weighting, or deployment outcomes in v2. [AUTHOR CLAIM + limitation; Introduction/Conclusion]

### What this source supports / refutes

- **Supports:** ALE-style is a runnable benchmark system, not a prompt list; workflow and instance are distinct; evaluator/environment/reference reuse occurs at workflow level; instance QA remains case-specific; public/private/pending are release states, not task genres.
- **Refutes:** treating all 1,490 as public, accepted, or final-QC assets; treating 1,490/960 as a required production ratio; pricing a 1,000-asset project from reported agent-run cost.

## Source 2 — current official website

**Title:** AI Agent Benchmark for Real-World Professional Workflows  
**Institution:** UC Berkeley RDI / RDI Foundation  
**URL:** https://agents-last-exam.org/  
**Publication / revision:** living page; no public version ID or revision timestamp exposed  
**Accessed:** 2026-08-08  
**Scores:** Credibility **4/5**; Recency **5/5**; Bias risk **4/5** (canonical current product surface, strongly promotional and unversioned)

### Short verbatim evidence

- Hero: “1,500+ tasks collected toward a 5,000-task target”; “300+ industry experts”; “55 targeted sub-industries”.

### Direct evidence and boundaries

- [FACT, current page snapshot] Current hero uses the generic unit **tasks**, not workflow or instance. It says 1,500+ collected and a 5,000-task target. This is a living collection target, not the v2 1,490-instance manifest and not a production allocation for this client.
- [FACT] Current site markets 55 targeted “sub-industries” and 300+ experts. Paper v2's formal taxonomy is 13 domains / 55 subdomains; terminology has drifted.
- [FACT] Site distinguishes domain-expert contribution (real workflow data, no coding required) from researcher/engineer work (setup, execution, evaluation). This corroborates a two-sided production model.
- [FACT] Footer states dataset `CC BY 4.0`, code `Apache-2.0`, and links separate Contributor Terms.
- [LIMITATION] Dataset/code licenses do not by themselves clear third-party software, confidential work files, proprietary standards, reference outputs, trademarks, or commissioned-task IP. Public sources do not provide an asset-by-asset rights matrix.
- [AUTHOR CLAIM] The site describes ALE as largest-scale/broadest-coverage and scores as objective/comparable/meaningful. Those are project claims, not independent validation.

### What this source supports / refutes

- **Supports:** a living collection program and separate expert vs engineering roles; license metadata must distinguish code from data.
- **Refutes:** silently freezing current homepage counts as v2 paper counts or quoting 5,000 as a delivered/runnable benchmark size.

## Source 3 — current `/submit` page

**Title:** Agents' Last Exam — Shape the Benchmark / Contribute  
**Institution:** UC Berkeley RDI  
**URL:** https://agents-last-exam.org/submit  
**Publication / revision:** living page; no public version ID or revision timestamp exposed  
**Accessed:** 2026-08-08  
**Scores:** Credibility **4/5**; Recency **5/5**; Bias risk **3/5** (authoritative intake specification; incentives and promotional framing remain)

### Short verbatim evidence

- Criteria: “Complex / Representative / Verifiable”.
- Submission fields: “Task Description / Input / Software / Output / Evaluation”.
- Complexity cue: “Takes experts days, not minutes”.

### Direct evidence and boundaries

- [FACT] The intake page asks for professional-grade software work rather than simplified chat interactions and gives explicit bad/good counterexamples for complexity, tool representativeness, and verifiability.
- [FACT] Verifiability decision tree prefers, in order: deterministic output files; numeric metric plus original output; narrow screenshot question/answer pairs plus original output; as last resort, a professional project file so the team can identify a verifiable subtask.
- [FACT] The five visible contributor fields are description, input, software, output, and evaluation. The task-idea precheck explicitly says it does not create/save a submission.
- [FACT] Page offers insight, possible manuscript co-authorship, and monetary awards for high-impact contributions. These incentives may shape the submitted population; no public sampling-bias correction is documented.
- [FACT] Footer again separates dataset CC BY 4.0 from code Apache-2.0 and links contributor terms.
- [LIMITATION] The page does not promise that an idea, proposal, or upload is accepted, implemented, runnable, private, public, or final-QC. It also provides no SLA, acceptance rate, evaluator-build time, expert-hour requirement, or ownership clearance procedure.

### What this source supports / refutes

- **Supports:** a submitted task is a proposal bundle, not yet a benchmark instance; output/reference design begins before implementation; task selection rejects wrong tools and unbounded outputs.
- **Refutes:** counting task ideas, form submissions, accepted specs, commissioned builds, and runnable instances as the same production unit.

## Source 4 — Berkeley RDI blog

**Title:** Agents' Last Exam  
**Authors / institution:** Yiyou Sun, Xinyang Han, Weichen Zhang, Yuanbo Pang, Tianyu Wang, Yuhan Cao, Yixiao Huang, et al.; UC Berkeley RDI  
**URL:** https://rdi.berkeley.edu/blog/agents-last-exam/  
**Publication:** June 2026 (day not shown on page)  
**Revision:** no public revision ID/timestamp exposed  
**Accessed:** 2026-08-08  
**Scores:** Credibility **4/5**; Recency **5/5**; Bias risk **5/5** (official overview/launch copy, not methods documentation)

### Short verbatim evidence

- “Every task is derived from a real project”; “No vibes. No human judges. Fully reproducible.”
- “1,500+ expert-sourced tasks”.

### Direct evidence and boundaries

- [FACT about page wording] Blog uses 55 “occupations” and later 55 “industry domains”, plus 300+ experts/100+ institutions and 1,500+ tasks. These labels differ from v2's formal 13 domains/55 subdomains and 1,490 instances.
- [AUTHOR CLAIM] Blog says all tasks come from previously completed real projects, use objective grading, need no human judges at runtime, and are fully reproducible.
- [QUALIFICATION] Paper v2's provenance figure separates 960 external submissions from 530 commissioned tasks; public evidence does not show how every commissioned asset inherits a prior shipped project. Runtime scoring can avoid human judges while human experts still author, review references, and perform final QC.
- [QUALIFICATION] Paper Appendix C.3.5 reports an LLM-as-judge minority in the open-source tree, so “objective grading” should not be rewritten as “100% deterministic code”. Private tasks and licensed environments also prevent unrestricted third-party reproduction.
- [FACT] Blog reports agents declaring success despite missing/incorrect outputs and constraint violations. This is relevant evidence for explicit completeness checks and artifact-shape gates in acceptance testing.

### What this source supports / refutes

- **Supports:** public-facing positioning around real project work and outcome verification; completeness/self-verification should be a QA dimension.
- **Refutes:** using promotional “fully reproducible” language as proof that private and licensed workflows are independently reproducible.

## Version / unit matrix (do not merge)

| Source surface | Snapshot / revision | Exact unit labels used | Count(s) | Safe interpretation |
|---|---|---|---:|---|
| arXiv v2 Abstract/Introduction | 2026-06-11 | industry clusters, subfields, task instances, domain experts | 13; 55; 1K+; 250+ | paper headline, not exact staffing ledger |
| arXiv v2 Figure 5 | 2026-06-11 | task instances; external submissions; commissioned tasks; release state | 1,490 = 960 + 530; 150 public + 1,017 private + 323 pending QC | provenance and release partitions of paper inventory |
| arXiv v2 Appendix C.3.7/Conclusion | 2026-06-11 | task workflows; task instances | 960 workflows; 1,490 instances | structural count; no mapping to Figure 5's 960 shown |
| arXiv v2 §4 | 2026-06-11 | public tasks / evaluated public set | 152 | experiment snapshot; conflicts with 150 inventory |
| Official homepage | live, accessed 2026-08-08 | tasks collected; target; experts; targeted sub-industries | 1,500+; 5,000 target; 300+; 55 | living program/marketing counters; no workflow-instance split |
| Submit page | live, accessed 2026-08-08 | task idea / submission / workflow | no inventory count | intake specification only |
| RDI blog | June 2026 page accessed 2026-08-08 | tasks; occupations / industry domains; experts / institutions | 1,500+; 55; 300+ / 100+ | first-party overview; unit terminology is looser than paper |

## Unit-safe implications for a 1,000-asset scope

1. **1,000 independent workflows** implies up to about 1,000 distinct evaluator contracts (`main.py`/scoring logic), workflow-specific environment/software decisions, expert provenance/reference packages, engineering dry-runs, and final workflow-level QC. [INFERENCE from C.3.7 architecture]
2. **1,000 instances from fewer workflows** can reuse the workflow evaluator and environment pattern, but each instance still needs distinct inputs, references/configuration, deterministic start-state validation, rights checks, and regression execution. Evaluator count scales chiefly with workflows; reference/input QA and run capacity scale with instances. [INFERENCE]
3. `1,490 / 960 ≈ 1.55` is only an observed v2 inventory average. It does not imply every workflow should have multiple instances or that a client should buy 1.55 instances/workflow. [INFERENCE]
4. Training/SFT/RL instances and hidden evaluation instances cannot retain unchanged access while serving both roles: once prompts/inputs/references/evaluator signals are exposed for optimization, later scores no longer estimate unseen generalization. A separated holdout, ownership boundary, access logs, and rotation pool are therefore design requirements. [PROJECT IMPLICATION grounded in §2.3]
5. A complete deliverable should extend ALE's documented task specification with explicit operational records: immutable asset ID/version; license/IP/PII clearance; source/provenance; environment image and dependency lock; runner; hidden-reference/evaluator version; dry-run logs; expert/engineering QC decisions; known evaluator limitations; public/private/train/dev/validation/final designation; and change history. The **extra records** are project recommendations—ALE's public sources do not document a complete per-task schema for all of them. [PROJECT IMPLICATION]
6. Public material is insufficient to quote exact production headcount, calendar time, acceptance yield, software-license cost, or expert/evaluator cost. Those require a pilot measuring at least: candidate-to-accepted yield, expert authoring/revision hours, engineering implementation hours by evaluator mode, environment setup failure rate, QC cycles, rights-clearance rate, instance expansion yield, run flake/retry rate, and compute/software cost. [PROJECT IMPLICATION]

## Strongest adversarial conclusions for the parent report

- **When conclusions fail:** If customer assets are short QA prompts, not professional artifact workflows; if evaluator/reference rights cannot be secured; if software cannot be deterministically provisioned; if workflows lack stable outputs; or if hidden evaluation is exposed for training, “ALE-style” construct and score validity collapse.
- **Snapshot-only numbers:** 1,490, 960, 150/1,017/323, 152, 250+, 300+, 1,500+, and 5,000 target are all pinned to different surfaces or units. None is a production quota.
- **Success may be evaluator/harness-driven:** Narrow/permissive verifiers can over-credit; brittle verifiers can under-credit; LLM judges add model/prompt drift; GUI/CLI substitution and harness tools alter reachable actions; repeated-trial coverage is incomplete.
- **Private is not automatically uncontaminated:** secrecy reduces straightforward exposure but does not prove no pretraining overlap, expert leakage, customer reuse, or evaluator leakage. Rolling evaluation is a design commitment, not evidence of executed clean rotation.
- **Reasonable but unsupported recommendations:** exact workflow-to-instance ratio, number of experts, reviewer load, production duration, cost per asset, domain allocation, rotation cadence, and acceptable flake/evaluator-error thresholds all require a pilot/client policy.

## Hugging Face paper-page provenance warning (method note, not an ALE implementation source)

The explicitly requested Hugging Face paper API was checked on 2026-08-08. It correctly links paper ID `2606.05405`, the official project page, and GitHub repository, but its stored summary still reports a 2.6% hardest-tier average, whereas arXiv v2's abstract says below 1%. Therefore HF paper metadata is not a safe proxy for v2 content; pin arXiv v2 directly. The separate HF **dataset** revision should be handled in its own source memo/version matrix.

