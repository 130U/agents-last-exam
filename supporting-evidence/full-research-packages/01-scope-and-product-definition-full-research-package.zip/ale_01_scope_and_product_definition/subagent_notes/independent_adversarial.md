# 独立与反方证据备忘录：1,000 个 ALE-style assets 的系统范围

研究日期与所有网页访问日期：**2026-08-08**  
限定用途：为 UC Berkeley RDI Agents' Last Exam（ALE）风格的 1,000-asset 项目提供**跨 benchmark 的方法学证据**；下列相邻 benchmark 只用于论证 holdout、contamination、harness、environment、evaluator、provenance、licensing 与可复现性，不用于推断 ALE 的当前数量、组织规模或生产配额。

## 0. 评分与证据标签

- `Credibility`：1–5，5 为最强。标准/规范、正式同行评审论文、可核查的一手实现通常较高。
- `Recency`：1–5，5 为截至研究日最新；稳定老标准虽 recency 低，不等于失效。
- `Bias risk`：1–5，1 为偏差风险最低，5 为利益相关或自我宣传风险最高。
- `[事实]`：来源直接陈述或代码/规范直接显示。
- `[作者主张]`：作者对其方法、数据或意义的解释，尚未在本项目中独立复现。
- `[研究员推断]`：本备忘录根据多源证据作出的解释。
- `[项目建议]`：面向 1,000-asset 项目的可执行建议，不冒充公开事实。

## 1. 可直接用于总报告的独立结论

### 1.1 Training data 与 hidden final evaluation 不能在访问权限不变时由同一批 instance 同时承担

1. `[事实]` 学术文献一致把训练时接触到测试实例定义为 train–test overlap / benchmark contamination；这会使分数不能再被解释为对**未见实例**的泛化（Sources 1、3、4）。对 agent 更严重：除模型权重记忆外，开发者还可以把公开 instance、reference 或 evaluator 的特征直接写进 harness、policy、retrieval、prompt 或规则中（Source 1）。
2. `[研究员推断]` 因而，“同一 instance 同时做 training 和 hidden final eval、且访问权限不变”在逻辑上矛盾：一旦训练者可访问该 instance，它便不再 hidden。它仍可测量**对已知任务的优化效果、记忆、格式遵循或回归稳定性**，但不能支持“unseen-task generalization”或采购方的最终验收推断。
3. `[反例/边界]` 公开 evaluation data 并非毫无价值。LiveBench 公开题目、代码和答案，同时通过持续更新与客观 ground truth 降低长期污染；SWE-bench Multimodal 则把 test evaluation 设为 private（Sources 3、6）。这说明可选择 public reproducibility/rotation 或 private holdout，两者服务不同成功标准。**公开 set 可以兼作 development/demo/audit set，但不能在不改变解释口径的情况下兼作永久 hidden final holdout。**
4. `[项目建议]` 按 intended generality 决定 holdout 的层级：若声称跨 instance 泛化，hold out instances；若声称跨 workflow 泛化，至少 hold out workflows；若声称跨 subdomain/domain 泛化，则需要更高层 holdout。除 prompt/input 外，reference、evaluator logic、gold artifacts、environment secrets 与详细 grader feedback 也必须受同一访问控制。

### 1.2 分数是“agent system × harness × environment × evaluator × run policy”的观测，不是裸模型属性

1. `[事实]` 相同 benchmark 的 prompt、answer extraction、task subset、test ordering、external rate limit、evaluation script 与环境差异可改变绝对分数甚至模型排序（Sources 1、2）。SWE-bench 的一手实现将 dataset、Docker environment、patch application、tests、run logs 与 result aggregation分开交付（Sources 6、7）。MLPerf 则显式定义 System Under Test、LoadGen、scenario、accuracy checker、submission checker 与 system description（Sources 16、17）。
2. `[研究员推断]` 因而购买“1,000 条数据”与购买“1,000-instance runnable benchmark system”不是同一产品。前者可以止于 schema-conformant records；后者至少还需要可复位环境、版本锁定的软件、执行与隔离、grader、日志、结果聚合、失败分类、访问控制、维护与验收。
3. `[项目建议]` 每个结果必须绑定：`task_manifest_revision + instance_revision + environment_digest + harness_commit + evaluator_version + agent_configuration + budget/time limit + retry policy + trial seed/run_id + timestamp`。缺任一关键字段时，不应与另一次 run 当作可比结果。

### 1.3 Evaluator 既可能漏判，也可能被系统性利用；deterministic 不等于 valid

1. `[事实]` agent 评测复现研究发现不同脚本、遗漏任务、错误标记成功、任务顺序与 rate limit 会制造不可比分数（Source 1）。LM evaluation 研究表明“细小”prompt/实现差异可以改变排名（Source 2）。
2. `[事实]` LLM-as-a-judge 的原始研究同时给出优点与缺陷：强 judge 在其研究设置中与人类偏好达到较高 agreement，但存在 position、verbosity、self-enhancement bias 与有限推理能力（Source 5）。因此“全用 LLM judge”与“绝不用 LLM judge”都缺乏普遍证据。
3. `[研究员推断]` ALE-style 文件/软件状态任务的 evaluator weakness 可能表现为：只检查表面字段、忽略错误副作用、reference 泄漏、路径/文件名捷径、对额外输出不敏感、judge 偏好冗长解释、环境残留导致假阳性、agent 修改 grader 可见状态、gold 本身无法通过。
4. `[项目建议]` evaluator QA 最少包含：gold/reference pass；明确的 negative controls fail；近似但错误输出 fail；format-only 与 content checks 分离；副作用/残留检测；evaluator 不可被 agent 写入；抽样人工复核；版本差异回放；grader disagreement/adjudication 记录。LLM judge 仅在 rubric、reference、校准集、稳定性测试和人工升级路径明确时使用。

### 1.4 Repeated trial 是独立计量单位；单次 run 不能隐含成系统能力

1. `[事实]` agent 与 LM 输出具有随机性；高运行成本使 agent benchmark 常缺少 repeated trials 与 error bars（Sources 1、2）。同一模型多次调用本身即可提高 pass probability，因而 retry budget 是被测系统的一部分（Source 1）。
2. `[研究员推断]` 需要分开两种不确定性：
   - **run stochasticity**：同一固定 instance、同一配置的多次 trial 变化；
   - **task-sampling uncertainty**：这些 instances 是否代表目标 workflow/domain 分布。
   对 tasks 做 bootstrap 不能替代对 stochastic agent 做 repeated trials；反之亦然（Source 2）。
3. `[项目建议]` 先由 pilot 估计方差和失败率，再确定 trial 数。报告 `n_instances`、`n_trials_per_instance`、retry policy、失败/超时处理、置信区间方法和聚合层级；不得把 1,000 instances × R trials 写成“1,000 tasks”。

### 1.5 Container 是必要基础设施之一，但不是完整 reproducibility 保证

1. `[事实]` SWE-bench 使用 Docker 让 repository tests 在一致环境执行；SWE-bench-Live 为 task 配 dedicated Docker image（Sources 6–8）。Docker 官方文档同时指出 tags 是 mutable；要获得同一 image content，应 pin digest（Source 15）。
2. `[研究员推断]` 即使 image digest 固定，外部 API、live web、许可证服务器、时钟、随机源、GPU/CPU architecture、字体、locale、网络、账户状态和 secret rotation 仍可造成漂移。container 只能封装被明确纳入 image/config 的部分。
3. `[项目建议]` 环境交付至少包括：image/VM digest、OS/architecture、软件与字体版本、locale/timezone、dependency lock、seed policy、network policy、fixture/initial state、reset/cleanup、health check、resource limits、secret injection、known nondeterminism、build provenance、SBOM、启动与验证脚本。

### 1.6 Provenance 与 license 不是一个顶层字符串；OTS 商业化需要逐组件权利链

1. `[事实]` W3C PROV-DM 用 entity–activity–agent、derivation、attribution 与 revision 表达来源链（Source 10）。SPDX 3.0.1 可表达 software、datasets、build inputs/outputs/environment、licenses、versions 与 relationships，并分别设有 Dataset、AI、Build、Licensing profiles（Source 11）。Datasheets for Datasets 要求记录 motivation、composition、collection、uses、distribution、maintenance（Source 12）。
2. `[事实]` Data Provenance Initiative 对大规模 finetuning data 的审计发现 hosting metadata 中 license 缺失或误分类很常见，且代码仓库 license 经常被误当成 dataset license（Source 13）。Creative Commons 明确提醒：发布者必须有权许可，第三方内容与未覆盖权利需另行标示（Source 14）。
3. `[研究员推断]` repo 根目录的 `MIT`、dataset card 的一个 `license` 字段、或专家提交协议中的单一授权，均不能自动覆盖 input documents、images、fonts、templates、software、reference output、synthetic model output、个人数据、商标或数据库权利。
4. `[项目建议]` 每个 asset 建 provenance/rights manifest：`component_id, component_type, source_url/origin, creator/rightsholder, acquisition_date, transformation/derivation, license_id+version, license_evidence_url/file, ToU, permitted_uses, attribution, redistribution, commercial_use, privacy/PII, consent, export/sector restrictions, reviewer, review_date, unresolved_risk`。是否可进入 OTS 销售必须是 legal/rights gate，不是 QA 后自动推断。（非法律意见。）

## 2. “数据”与“可运行 benchmark system”的证据化产品边界

| 交付层 | 最低资产 | 可以合理声称 | 不能自动声称 |
|---|---|---|---|
| Dataset / task records | prompt、input pointers/files、metadata、可能含 reference | 记录数量、schema 完整、内容已审 | 可执行、可复现、分数有效、软件可合法分发 |
| Runnable instance package | 上述 + pinned environment、initial state、reference、evaluator、run/reset scripts、manifest、license/provenance、QA record | 在支持平台按验收步骤可运行并产出 instance-level result | 跨 workflow 代表性、长期维护、hidden integrity |
| Benchmark harness | 上述 + orchestration、isolation、timeouts、budget、retry、logging、aggregation、versioning、failure taxonomy | 多 instance 在固定 protocol 下可比较 | 分数等于真实生产能力；对任意 harness 可比 |
| Managed private benchmark service | 上述 + identity/access、secret store、submission API、scheduler、artifact store、audit log、monitoring、rotation、incident response | 私有 holdout 与受控重复评测 | 永久无污染；没有泄漏/侧信道 |
| OTS commercial data/system | 上述 + commercial rights chain、redistribution terms、security/support/SLA、documentation、update/deprecation policy | 在合同与许可范围内销售/授权 | 所有客户用例适用；第三方权利零风险 |

`[项目建议]` 接受标准应匹配采购对象：dataset 的验收可以是 schema/content/rights completeness；runnable system 的验收还必须做 clean-room install、gold pass、negative controls、reset/replay、cross-machine smoke test、log completeness、holdout access audit 与 failure recovery。

## 3. 主动反方审查：当前结论何时会失效

1. **“训练与评测必须完全不同”并非无条件成立。** 若目标明确是 curriculum mastery、known-task regression、记忆/检索能力，训练过的同一 instance 可以被再次测量；但 success criterion 必须改名，不能称 hidden/generalization benchmark。
2. **同一 underlying source 可以产生不同用途的资产。** 例如同一 workflow family 可衍生 train instances 与不可见 final instances；前提是具体 inputs、references、secrets 与 evaluator attack surface 独立，并且按目标泛化层级防止 template-level leakage。仅换数字、文件名或表面措辞可能不构成独立 holdout。
3. **公开 benchmark 可以更易审计。** 私有 holdout 降低污染，却削弱外部错误发现、代表性审计与复现。应提供 public development/audit slice 与 private final/rotation pool，而不是把“全部私有”当作唯一正确答案。
4. **LLM judge 并非必然无效。** Source 5 在特定聊天偏好任务上报告了与人类偏好可比的 agreement，说明强 judge 可成为可扩展近似；但这不验证其对 ALE-style 专业文件/软件状态的正确性。需要任务级 calibration，而非套用其 headline 数字。
5. **Container 不等于机器无关。** architecture、GPU driver、closed-source desktop software、OS licensing 和 live services 可能迫使使用 VM、golden image、remote lab 或 managed service。Docker 是实现选项，不应写死为所有 workflow 的唯一环境。
6. **高 benchmark 分数不一定是 capability 增长。** 它可能来自 evaluator 漏洞、reference/gold 泄漏、hardcoded task policy、retry/token budget 增加、task filtering、不同 harness、环境残留、LLM judge 偏差或挑选 favorable trials（Sources 1、2、5）。
7. **低 benchmark 分数也不一定说明无用。** 缺少 human-in-the-loop、错误的 deployment simulation、过严或错误 grader、环境故障，都会低估现实价值（Source 1）。
8. **Provenance metadata 不是权利保证。** SPDX/PROV 能标准化记录，但不能替代权属调查、合同或法律判断；记录为“commercial”也可能源自错误 metadata（Sources 11、13、14）。

## 4. 公开证据不能支持的数值，以及只能由 pilot 得出的变量

### 4.1 不能外推为本项目配额的数字

- 相邻 benchmark 的 instance 数、repository 数、expert 数、构建年限、单次 agent run 成本、container 存储要求、重复次数，只是其特定 snapshot、task type、harness 和基础设施的事实。
- Source 1 用某个 code-agent benchmark 举例说明一次全量 run 可能昂贵；该例不能换算为 ALE-style spreadsheet/CAD/web/desktop workflows 的单题成本。
- SWE-bench-Live 不同论文 revision 本身出现不同 inventory 数；这正说明 snapshot 数必须 versioned，不能合并，更不能拿来设 1,000-asset 配额。
- 公开资料不足以给出本项目的精确专家人数、每 workflow evaluator 数、每人日产量、周期、预算、通过率、domain allocation 或 trials 数。

### 4.2 Pilot 必须测的变量

- `p_accept`: 从候选 submission 到经权利、可运行、evaluator、QA 全部通过的 acceptance yield。
- `h_workflow_design`: 新 workflow 的专业设计与评审工时。
- `h_env_build`, `h_env_maintenance`: 每个独立软件栈/环境的构建与维护工时。
- `h_evaluator_build`, `h_evaluator_hardening`: grader 开发、negative/adversarial tests、复核工时。
- `h_instance_author`, `h_reference`, `h_QA`: 每 runnable instance 的制作、gold/reference、两级 QA 工时。
- `reuse_env`, `reuse_evaluator`: workflow 内 instance 对 environment/evaluator 的真实复用率。
- `failure_env`, `failure_eval`, `failure_content`, `failure_rights`: 失败分类比例与返工时间。
- `var_run`, `var_task`: stochastic run variance 与 task-sampling variance；由此决定 trial 数/样本数。
- `c_run`: 按 agent configuration、token/tool/API、sandbox duration、license seat 计算的每 run 成本。
- `parallelism_effective`: 受软件 seat、专家 review、environment build、API quotas 限制的有效并行度。

### 4.3 可直接复用的成本公式（不填伪精确参数）

```text
C_total = C_scope_and_taxonomy
        + Σ_workflow (C_design + C_env + C_evaluator + C_rights_review)
        + Σ_instance (C_input + C_reference + C_metadata + C_QA + C_packaging)
        + Σ_agent_config Σ_instance Σ_trial (C_inference + C_sandbox + C_grading)
        + C_harness + C_security + C_storage + C_program_management
        + C_maintenance_and_rotation + contingency

T_project = max(critical paths across expert production,
                environment/evaluator engineering,
                rights clearance,
                QA/rework,
                infrastructure hardening)
```

`[项目建议]` 先用分层 pilot 覆盖不同 domain、软件栈、workflow 复用模式与 evaluator 类型；用 pilot 的实际分布而非单点平均值做 P50/P80 计划。公开证据只能说明应测什么，不能替代这些参数。

## 5. 逐来源证据卡

### Source 1 — *AI Agents That Matter*

- 作者/机构：Sayash Kapoor, Benedikt Stroebl, Zachary S. Siegel, Nitya Nadgir, Arvind Narayanan；Princeton University 等。
- URL：https://arxiv.org/html/2407.01502
- 发布/版本：arXiv:2407.01502v1，2024-07-01；截至访问日仅 v1。
- 访问：2026-08-08。
- 原文短证据：
  - “many agent benchmarks have inadequate holdout sets, and sometimes none at all.”
  - “Evaluation scripts make assumptions about agent design that aren’t satisfied by all agents.”
  - “agent evaluations are rarely accompanied by error bars.”
- 直接相关事实：论文调查 agent benchmark 的 holdout 层级，展示 hardcoded policies/shortcuts；复现实验指出 evaluator script、task subset、task ordering、external environment 与实现 bug 可制造不可比分数；五次复现 run 的范围可与已报告结果错开。
- 支持：holdout 应与 intended generality 对齐；harness、环境与 trials 必须纳入产品；单次 run 不足。
- 反驳/边界：论文也指出缺少 human-in-the-loop 可能**低估**真实 usefulness；不是所有 benchmark 误差都只向上偏。
- 评分：Credibility **4/5**；Recency **4/5**；Bias risk **2/5**。理由：强方法学与复现证据，但 arXiv v1、样本为选定 benchmarks，不能直接产生 ALE 成本参数。

### Source 2 — *Lessons from the Trenches on Reproducible Evaluation of Language Models*

- 作者/机构：Stella Biderman, Hailey Schoelkopf, Lintang Sutawika 等 30 人；EleutherAI、Brown、CMU、Yale 等。
- URL：https://arxiv.org/html/2405.14782v3
- 发布/版本：初版 2024-05-23；**v3，2026-05-31**。
- 访问：2026-08-08。
- 原文短证据：
  - “these minor implementation or methodological details … significantly affect numerical scores.”
  - “Provide Evaluation Code.”
  - “reporting variance over several runs, or reporting statistical significance.”
- 直接相关事实：不同 prompt 与 evaluation implementation 能显著改分，甚至改变排序；作者要求 exact code、prompt、method、outputs、statistical analysis；区分 repeated-run variation 与 task-sampling bootstrap variation。
- 支持：完整 asset 必须包括 code/config/version/output logs；trial 与 task sampling 是不同计量层；报告 isolated number 不足。
- 反驳/边界：研究主要针对 LM evaluation，不是 desktop agent；具体效应大小不能搬到 ALE。
- 评分：Credibility **4/5**；Recency **5/5**；Bias risk **3/5**。理由：最新、经验丰富，但作者也是 lm-eval 维护者，对统一 harness 有直接投入。

### Source 3 — *LiveBench: A Challenging, Contamination-Limited LLM Benchmark*

- 作者/机构：Colin White 等；学术与产业多机构。
- URL：https://arxiv.org/abs/2406.19314
- 发布/版本：v1 2024-06-27；**v2 2025-04-18**；ICLR 2025 Spotlight。v2 将标题从 “Contamination-Free” 改为 “Contamination-Limited”。
- 访问：2026-08-08。
- 原文短证据：
  - “Test set contamination … can quickly render benchmarks obsolete.”
  - “Questions are added and updated on a monthly basis.”
- 直接相关事实：采用近期来源、客观 ground truth、持续更新；同时公开 questions、code、model answers。
- 支持：rotation/freshness 是 private holdout 之外的 contamination mitigation；public set 可服务 transparency/reproducibility。
- 反驳/边界：v2 标题本身承认只能 contamination-limited，不是永久 immune；公开后仍可能被未来训练吸收。
- 评分：Credibility **4/5**；Recency **4/5**；Bias risk **3/5**。理由：同行评审，但作者评价自有 benchmark，contamination 主张不能视为绝对保证。

### Source 4 — *Position: Language Model Developers Should Report Train-Test Overlap*

- 作者/机构：Andy K. Zhang, Kevin Klyman, Yifan Mai, Yoav Levine, Yian Zhang, Rishi Bommasani, Percy Liang；Stanford CRFM 等。
- URL：https://proceedings.mlr.press/v267/zhang25dt.html
- 发布/版本：ICML 2025，PMLR 267:82460–82482；正式会议版本。
- 访问：2026-08-08。
- 原文短证据：“correctly interpreting evaluation results requires knowledge of train-test overlap.”
- 直接相关事实：把 overlap 定义为模型在被测试的同一数据上接受训练，并主张开发者披露。
- 支持：相同 instance 进入 training 后，final score 必须披露 overlap，不能默认为 unseen generalization。
- 反驳/边界：这是 position paper；它支持 disclosure/interpretation 原则，不单独证明所有 overlap 必然带来相同幅度的分数膨胀。
- 评分：Credibility **4/5**；Recency **4/5**；Bias risk **2/5**。

### Source 5 — *Judging LLM-as-a-Judge with MT-Bench and Chatbot Arena*

- 作者/机构：Lianmin Zheng, Wei-Lin Chiang 等；UC Berkeley、CMU 等。
- URL：https://proceedings.neurips.cc/paper_files/paper/2023/hash/91f18a1287b398d378ef22505bf41832-Abstract-Datasets_and_Benchmarks.html
- 发布/版本：NeurIPS 2023 Datasets and Benchmarks Track；DOI 10.52202/075280-2020。
- 访问：2026-08-08。
- 原文短证据：
  - “position, verbosity, and self-enhancement biases, as well as limited reasoning ability.”
  - “strong LLM judges … can match both controlled and crowdsourced human preferences well.”
- 直接相关事实：论文同时报告 judge bias/attack failure 与特定设置中对 human preference 的高 agreement。
- 支持：LLM evaluator 需 calibration、swap/order tests、reference anchors 与人工 escalation。
- 反驳/边界：该研究是 chat preference，不是 professional artifact correctness；其 agreement 数字不可作为 ALE grader accuracy。
- 评分：Credibility **5/5**；Recency **3/5**；Bias risk **3/5**。理由：正式同行评审原始研究，但评价自有 MT-Bench/Chatbot Arena。

### Source 6 — SWE-bench repository `README.md`

- 作者/机构：SWE-bench organization；Carlos E. Jimenez、John Yang 等维护者。
- URL：https://github.com/SWE-bench/SWE-bench/blob/main/README.md
- 版本/revision：访问时 `main`；GitHub API 返回 README **blob SHA `16563c30931ca8e370da129f4f8aedefb39d76c9`**。动态分支，不能视为永久版本。
- 发布/访问：repo 持续更新；访问 2026-08-08。
- 原文短证据：
  - “SWE-bench uses Docker for reproducible evaluations.”
  - “we've kept evaluation for the test split private.”
- 直接相关事实：repo 把 dataset loading、Docker setup、evaluation command、logs、results、resource requirements 与 private test submission 分开；训练与 inference 另有模块。
- 支持：data delivery 与 runnable benchmark system 是不同层；private final test 是真实运营选项。
- 反驳/边界：这是相邻 code benchmark 的自有实现；Docker/资源形态不能直接规定 ALE desktop/spreadsheet workflow。
- 评分：Credibility **5/5**（仅对其实现事实）；Recency **5/5**；Bias risk **3/5**。

### Source 7 — SWE-bench *Evaluation Guide*

- 作者/机构：SWE-bench maintainers。
- URL：https://github.com/SWE-bench/SWE-bench/blob/main/docs/guides/evaluation.md
- 版本/revision：访问时 `main`；文件 **blob SHA `a9c8a44f3788cb9cd4260056bc01061cbcf585f1`**。
- 发布/访问：持续更新；访问 2026-08-08。
- 原文短证据：“applying their generated patches … and running the repository's tests.”
- 直接相关事实：规定 prediction schema、containerized evaluation、instance selection、cache/cleanup、per-instance logs 与 result metrics。
- 支持：一个 runnable benchmark 需要 prediction contract、executor、environment、grader、logs、aggregation 与 resource management，而不仅是问题文字。
- 反驳/边界：文档声称 Docker 跨平台一致，但 ARM support 等限制说明实际 portability 仍需验收。
- 评分：Credibility **5/5**（仅对实现）；Recency **5/5**；Bias risk **3/5**。

### Source 8 — *SWE-bench Goes Live!*

- 作者/机构：Linghao Zhang, Shilin He, Chaoyun Zhang 等；Microsoft、Shanghai AI Laboratory。
- URL：https://openreview.net/forum?id=OGWkr7gXka （论文 PDF：https://openreview.net/pdf?id=OGWkr7gXka）
- 发布/版本：NeurIPS 2025 Datasets and Benchmarks Track；OpenReview 显示 2025-09-18 发布、2026-04-23 last modified。arXiv 初版 2505.23419 为 2025-05-29，inventory 数与后续版不同。
- 访问：2026-08-08。
- 原文短证据：
  - “Each task is accompanied by a dedicated Docker image.”
  - “an automated curation pipeline … from instance creation to environment setup.”
- 直接相关事实：把 issue/patch pair、tests、environment construction、verification 和 image packaging 作为连续 pipeline；用 live updates 缓解 static benchmark staleness。
- 支持：instance scale 不等于只写 prompts；environment/evaluator automation 是扩展瓶颈与产品组成。
- 反驳/边界：这是作者对自有 benchmark 的主张；自动化成功率、人工返工与 ALE 可迁移性均未由公开数据验证。不同 revision 数字不得合并。
- 评分：Credibility **4/5**；Recency **5/5**；Bias risk **4/5**。

### Source 9 — NIST *Artificial Intelligence Risk Management Framework (AI RMF 1.0)*

- 作者/机构：U.S. National Institute of Standards and Technology。
- URL：https://doi.org/10.6028/NIST.AI.100-1 （PDF：https://nvlpubs.nist.gov/nistpubs/ai/NIST.AI.100-1.pdf）
- 发布/版本：NIST AI 100-1，**AI RMF 1.0，January 2023**。
- 访问：2026-08-08。
- 原文短证据：
  - “Test sets, metrics, and details about the tools used during TEVV are documented.”
  - “demonstrated for conditions similar to deployment setting(s).”
- 直接相关事实：要求记录 construct validation、data selection、test sets/metrics/tools、deployment-like conditions、generalizability limits、第三方 software/data 与 IP risk。
- 支持：benchmark acceptance 需要 test methodology、deployment relevance、third-party risk 和 limitations，不是仅交付 prompts。
- 反驳/边界：AI RMF 是自愿风险框架，不是 ALE-specific engineering spec，也不规定项目工期/成本。
- 评分：Credibility **5/5**；Recency **3/5**；Bias risk **1/5**。

### Source 10 — W3C *PROV-DM: The PROV Data Model*

- 作者/机构：Luc Moreau、Paolo Missier 编辑；W3C Provenance Working Group。
- URL：https://www.w3.org/TR/2013/REC-prov-dm-20130430/
- 发布/版本：W3C Recommendation，**2013-04-30**；稳定 normative recommendation。
- 访问：2026-08-08。
- 原文短证据：“entities, activities, and people involved in producing a piece of data or thing.”
- 直接相关事实：提供 entity/activity/agent、usage/generation、derivation/revision、attribution/responsibility 的跨域 provenance 模型。
- 支持：task、input、reference、evaluator、environment 和 QA artifacts 应有来源、版本、派生与责任链。
- 反驳/边界：PROV-DM 只规定通用表示，不告诉项目哪些 legal rights 已清理，也不替代内容 QA。
- 评分：Credibility **5/5**；Recency **1/5**；Bias risk **1/5**。

### Source 11 — *SPDX Specification 3.0.1*

- 作者/机构：SPDX Project / Linux Foundation；开放标准社区。
- URLs：
  - Scope：https://spdx.github.io/spdx-spec/v3.0.1/scope/
  - Conformance：https://spdx.github.io/spdx-spec/v3.0.1/conformance/
  - Relationships：https://spdx.github.io/spdx-spec/v3.0.1/model/Core/Vocabularies/RelationshipType/
- 发布/版本：**SPDX 3.0.1**；正式可用通知 2024-08-21，访问的是 versioned spec path。
- 访问：2026-08-08。
- 原文短证据：
  - “datasets, versions, sources, associated metadata, licensing information.”
  - “inputs, outputs, procedures/instructions, environments and actors … with the associated evidence.”
- 直接相关事实：Scope 覆盖 software composition/build、AI models、datasets、identity、provenance/integrity、licenses/copyright、relationships；Dataset/AI/Build/Licensing 是不同 conformance profiles；关系可区分 `trainedOn`、`testedOn`、`hasTest`、`hasInput`、`hasOutput`。
- 支持：建议对 benchmark system 交付 dataset + environment + build + license/provenance 的机器可读 manifest，并明确 train/test 关系。
- 反驳/边界：支持一个 profile 不自动意味着支持其它 profile；SPDX metadata 不是法律结论，也不证明 artifact 可运行。
- 评分：Credibility **5/5**；Recency **4/5**；Bias risk **1/5**。

### Source 12 — *Datasheets for Datasets*

- 作者/机构：Timnit Gebru, Jamie Morgenstern, Briana Vecchione, Jennifer Wortman Vaughan, Hanna Wallach, Hal Daumé III, Kate Crawford。
- URL：https://arxiv.org/abs/1803.09010 （CACM 2021, DOI 10.1145/3458723）
- 发布/版本：初版 2018-03-23；**arXiv v8 2021-12-01**，对应 CACM 版本。
- 访问：2026-08-08。
- 原文短证据：“motivation, composition, collection process, recommended uses, and so on.”
- 直接相关事实：把 datasheet 作为 creator/consumer communication；覆盖 creation、distribution、maintenance、assumptions、risks、restrictions 与 intended use。
- 支持：每 task/dataset release 需要 documentation、use restrictions、maintenance plan；单纯 schema README 不足以支撑复用。
- 反驳/边界：是文档框架，不保证内容正确、许可有效、环境可运行，也不提供 ALE production rate。
- 评分：Credibility **5/5**；Recency **2/5**；Bias risk **1/5**。

### Source 13 — *The Data Provenance Initiative: A Large Scale Audit of Dataset Licensing & Attribution in AI*

- 作者/机构：Shayne Longpre, Robert Mahari, Anthony Chen 等；MIT、Cohere For AI 等跨学科团队。
- URL：https://arxiv.org/abs/2310.16787
- 发布/版本：初版 2023-10-25；**v3 2023-11-04**。
- 访问：2026-08-08。
- 原文短证据：
  - “trace the lineage of these datasets, from their source, creators, series of license conditions.”
  - “contributors … mistaking licenses attached to code … for licenses attached to data.”
- 直接相关事实：审计 1,800+ text datasets；报告多个 hosting/aggregator 表面的 license omission 与 miscategorization；人工重新审查常发现更严格条件。
- 支持：不能把 repo/license metadata 当作可销售数据的充分证明；需要原始 source、creator、license URL、conditions 与 downstream use 链。
- 反驳/边界：样本集中在 text alignment/finetuning collections，不能直接外推到所有 professional files；文中的法律讨论受 jurisdiction/risk tolerance 影响。
- 评分：Credibility **4/5**；Recency **3/5**；Bias risk **2/5**。

### Source 14 — Creative Commons *Frequently Asked Questions: Data and CC licenses*

- 作者/机构：Creative Commons。
- URL：https://creativecommons.org/faq/#frequently-asked-questions-about-data-and-cc-licenses （稳定内容镜像：https://wiki.creativecommons.org/index.php/Frequently_Asked_Questions）
- 发布/版本：动态 FAQ，无固定 revision；访问日快照 2026-08-08。
- 原文短证据：“database providers should first make sure they have all rights necessary to do so.”
- 直接相关事实：CC 4.0 可覆盖 copyright 与适用的 sui generis database rights；dataset provider 可能不拥有每项内容；未获许可部分应明确排除；license version 与 covered components 必须清楚。
- 支持：asset-level rights map、license version、third-party exclusions 与 attribution 是 OTS gate。
- 反驳/边界：CC FAQ 自称非法律意见；不同 jurisdiction、privacy、contract、trademark 等可能另行适用。
- 评分：Credibility **5/5**（对 CC 工具解释）；Recency **3/5**；Bias risk **2/5**。

### Source 15 — Docker Docs *Building best practices: Pin base image versions*

- 作者/机构：Docker, Inc. documentation team。
- URL：https://docs.docker.com/build/building/best-practices/#pin-base-image-versions
- 发布/版本：动态官方文档，无固定 release tag；访问日快照 2026-08-08。
- 原文短证据：
  - “Image tags are mutable.”
  - “pin the image version to a specific digest.”
- 直接相关事实：tag 可被 publisher 更新；digest pin 可保证拉取同一 image content，但会放弃自动 security updates，需要受控更新与 audit trail。
- 支持：environment manifest 要记录 digest，而非只写 `latest` 或 major/minor tag；还需 update/deprecation policy。
- 反驳/边界：digest 只固定 image content，不固定外部服务、hardware、runtime secrets 或组织拥有运行权利。
- 评分：Credibility **5/5**（对 Docker 行为）；Recency **5/5**；Bias risk **2/5**。

### Source 16 — MLPerf Inference *Submission Guide*

- 作者/机构：MLCommons MLPerf Inference Working Group。
- URL：https://docs.mlcommons.org/inference/submission/
- 发布/版本：动态官方文档；页面要求使用 latest round branch/tag；访问日快照 2026-08-08。
- 原文短证据：“Query generation and scheduling; logging; Latency tracking; Accuracy validation; Final metric computation.”
- 直接相关事实：完整流程含 agreements、benchmark environment、source/dataset/model、System Under Test、scenario/division、LoadGen、accuracy checker、system description、results structure、submission checker 与 final package。
- 支持：成熟 benchmark product 由规则、资产、harness、环境、SUT description、验证与结果包共同构成；纯 dataset 不是可运行系统。
- 反驳/边界：MLPerf 衡量性能/效率，非 ALE professional-task correctness；具体字段只能作为架构类比。
- 评分：Credibility **5/5**；Recency **5/5**；Bias risk **2/5**。

### Source 17 — MLCommons *MLPerf Endpoints v0.7*

- 作者/机构：MLCommons。
- URL：https://mlcommons.org/benchmarks/endpoints/
- 发布/版本：页面链接 **Endpoints v0.7 Results**；访问日快照 2026-08-08。
- 原文短证据：
  - “a combination of hardware, software, and a deployed AI model.”
  - “information about the system under test and the artifacts needed to reproduce it.”
- 直接相关事实：把实际系统、模型、software stack、operating points、peer review、audit、availability status、reproduction artifacts 与采购用途联系起来。
- 支持：采购一个可运行 benchmark/system 包含 configuration disclosure、可复现 artifacts、review/audit 与 availability，而非只购买测试数据。
- 反驳/边界：页面面向行业采购并推广自有标准，营销倾向较强；不能把 v0.7 的运行时长、点数或流程直接写成 ALE 验收要求。
- 评分：Credibility **4/5**；Recency **5/5**；Bias risk **4/5**。

## 6. 给主报告的最短可复用表述

> `[研究员推断]` “1,000 道 ALE-style tasks”若只指 1,000 条 prompt/input records，是数据采购；若要求每条在固定软件环境中可复位执行、用 versioned evaluator 评分并产生可审计结果，则是 benchmark system 采购。后者的工作量由 unique workflows、environment/evaluator 复用率、rights clearance、QA/返工和 repeated trials 决定，不能由 instance 数单独推导。

> `[项目建议]` 默认采用三层资产池：公开 development/demo slice、权限隔离的 validation pool、私有 final holdout + rotation reserve。training 数据不得与 final instances 重合；如复用 workflow family，必须通过 pilot 验证 template leakage、evaluator shortcut 与环境复用边界。

> `[公开资料不足]` 现有跨 benchmark 证据足以证明必须把 environment、evaluator、harness、provenance、license、versioning 与 QA 纳入范围，却不足以给出 ALE-style 1,000-asset 项目的精确专家数、日生产率、预算、排期、通过率或 workflow:instance 配比；这些必须由代表性 pilot 估计。
