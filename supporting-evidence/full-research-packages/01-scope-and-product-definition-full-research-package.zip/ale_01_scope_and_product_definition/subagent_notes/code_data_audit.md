# ALE canonical code/data snapshot audit (2026-08-08)

## Scope and method

Read-only audit of the two requested canonical implementation/data surfaces, pinned to immutable revisions rather than `main` alone:

- GitHub: `rdi-berkeley/agents-last-exam`, default branch `main`, observed HEAD `1e615e456de7cef57706680613cb80ee13c7fc76`, commit/merge time `2026-08-05T19:19:50Z`.
- Hugging Face: `agents-last-exam/agents-last-exam`, default branch `main`, observed HEAD `a8c1fd174a1f6cfa76526572a2e3ebece1276be2`, commit time `2026-07-11T06:17:59Z`, dataset-card release label `v1.0`.
- Access date for every source below: `2026-08-08`.

The GitHub SHA/default branch were verified both with the connected GitHub app and a read-only clone. The HF SHA was verified with `git ls-remote` and a read-only clone; `task_cards.parquet` was parsed locally at that SHA. Counts below retain their unit (workflow path, metadata row, tier-list membership, run unit).

## Findings: facts observable in code/data

### 1. Public manifest counts are snapshot-specific

| Surface/revision | Observable unit | Exact observation |
|---|---:|---|
| Paper `2606.05405v2` (2026-06-11) | task instance | 1,490 total = 150 public + 1,017 private + 323 pending QC; Appendix C.3.7 separately says 960 workflows and 1,490 instances. |
| HF `a8c1fd1` (2026-07-11) | metadata row | 153 rows, 153 unique `task_id`; one row per card by the card's own definition. |
| GitHub `1e615e4` (2026-08-05) | curated workflow path | `selected_tasks/full.txt` has 152 non-comment, unique task paths. |
| GitHub `1e615e4` | tier-list membership | `near-term=67`, `full-spectrum=55`, `last-exam=38`: 160 memberships but only 152 distinct paths because 8 paths appear in two tier lists. |
| GitHub `1e615e4` | all code directories | 165 directories under `tasks/` contain `main.py` + `task_card.json`; this is **not** the public benchmark count (8 are `demo/*`; 5 more are outside `full.txt`). |
| Live site/README, accessed 2026-08-08 | approximate marketing count | “around 150” public; live homepage says “1,500+ tasks collected”. These are not manifests. |

The HF-vs-GitHub one-row mismatch is exactly identifiable:

- HF has `engineering/2d_drawings_to_3d_bridge_model`; current GitHub has its code/card but omits it from `selected_tasks/full.txt`.
- No path in current `selected_tasks/full.txt` is absent from HF.
- HF split counts are `near-term=67`, `full-spectrum=47`, `last-exam=38`, plus 1 null split (the bridge row). HF assigns one split per row; the GitHub tier files include 8 cross-tier duplicate memberships. Therefore `55` (GitHub full-spectrum memberships) and `47` (HF normalized full-spectrum rows) are different units, not arithmetic errors.

The 8 duplicated GitHub tier memberships are: `visual_media/inkscape_cultural_poster_design`, `engineering/abb_irb6700_asset_to_urdf_instance_1`, `visual_media/skeletal_animation_reproduction`, `engineering/aerospace_low_thrust_trajectory`, `business_finance/legal_ma_consistency_audit_01`, `engineering/mold-flow`, `computing_math/cfr_game_theory_equilibrium`, and `education_info/yi_manuscript_translation_1`.

Taxonomy is also snapshot-bound: both current HF metadata and the current 152-path GitHub manifest contain 14 distinct `taxonomy.domain_id` values and 51 distinct `taxonomy.subdomain_id` values. Do **not** merge these into the paper's formal 13-domain/55-subdomain taxonomy; report the code/data manifest as a separate surface. The GitHub README's “all 55 subdomains” is not reproduced by the current card-ID count.

### 2. Workflow, instance, and run are distinct in the current code

- Current docs define one `tasks/<category>/<task>/main.py` as one workflow plus shared grading logic; `load()` can expose multiple variants (concrete instances) sharing `evaluate()`.
- All 152 curated paths at this commit define all three hooks: `load()`, `start()`, and `evaluate()`.
- A `.txt` task list is parsed as one `TaskSpec(path, variants=[0])`. Thus `selected_tasks/full.txt` selects the base/variant-0 case for each of 152 workflow paths; it does not enumerate every variant available in every `main.py`.
- A YAML task list may request explicit integer variant indices. The runner then forms the Cartesian product `agents × tasks × variants`; one `RunUnit` is one `(agent_id, task_path, variant_index)` execution. Retry attempts are stored separately and are not new task instances.

**Implication:** the current public default is reasonably described as “152 selected workflow paths executed at variant index 0,” not “the ALE corpus has 152 workflows/instances” and not “152 agent runs.”

### 3. A runnable asset is more than a prompt

Directly observable asset contract:

- `task_card.json`: identifier/title/summary, prompt, required actions, software, input/reference file descriptors, evaluation description, VM snapshot/machine/timeout, taxonomy, and required system packages (fields are not perfectly uniform).
- `main.py`: executable `load()` / `start()` / `evaluate()` lifecycle and instance metadata.
- Task-side implementation support: 206 Python files beyond the 165 `main.py` files were observed (scorers, verifiers, helpers, and package files); code-based and judge-based patterns coexist.
- External task data layout: `<domain>/<task>/<variant>/{input,software,reference}`. Input is staged before the run; the reference is staged/decrypted only after the agent finishes.
- Experiment/system layer: agent presets, provider profiles, selected-task manifests, task-data fetch scripts, orchestration, trajectory/log/result collection.

Important negative observation: the GitHub `tasks/` tree contains task code/cards/scorer fixtures, not the substantive input/reference payloads. The canonical HF metadata repo also explicitly excludes input bytes, software binaries, reference outputs, scoring fixtures, and VM images. ALE publishes input data in a companion open repo and reference data in a gated companion repo; local Docker uses a gated archive fetched by `scripts/fetch_task_data.sh`.

Metadata completeness is not a reliable acceptance criterion by itself: among the 152 curated current cards, 3 omit the `evaluation` card field even though their executable `main.py` contains `evaluate()`. No standardized per-task QA acceptance record, reviewer sign-off, evaluator test report, or per-asset license/provenance object is present across the public cards.

### 4. Environment/runtime is a product layer

- Framework `pyproject.toml`: Python `>=3.12,<3.14`; pins `openenv-core==0.3.0` and `cua-bench==0.2.7`; agent harness dependencies live in separate workspace packages.
- Providers exposed by the current repo/docs: Google Cloud VM, AWS EC2, Alibaba ECS, QEMU/KVM, local Docker subset, and static/existing sandbox.
- Current 152-path task-card snapshot requests: `cpu-free-ubuntu=105`, Windows `cpu-free=35`, `gpu-free=5`, `cpu-license=3`, `gpu-license=4`. These are task-card counts, not infrastructure quotas.
- `selected_tasks/licensed.txt` contains 7 paths. Current docs say all seven are Windows tasks; credentials/installers/licenses are intentionally not committed. Therefore “data access” does not by itself make every public task runnable.
- 74/152 current cards declare at least one `requiredSystemPackages` entry (117 declarations total, with repeats across tasks). Version-pinned installer/verification metadata lives under `env/packages-*`; Python runtime dependencies can be staged per task.

### 5. License and access boundaries need contract clarification

- Repository software license: Apache-2.0.
- Repository benchmark-data license: CC BY 4.0; `LICENSE-DATA` says it applies to `tasks/`, `selected_tasks/`, and related task content.
- HF metadata card: CC BY 4.0.
- Current public task cards do not expose a uniform per-input-file license field. Licensed commercial applications require separate customer entitlements.
- The companion gated reference/archive pages add operational access conditions (including no training/no redistribution language) even while repository/data-card surfaces display CC BY 4.0. This is a real contract-layer ambiguity: legal counsel/data owner must state which terms govern derived training products, redistribution, customer transfer, and references. Do not infer OTS resale rights from the repository license badge alone.

### 6. Evaluator quality is mutable; scores depend on grader revision

The current HEAD post-dates the HF metadata snapshot and includes PR #64, “harden graders and sync visual-media evaluators.” The merged PR reports fixes for schema-only false zeroes, malformed component handling, weighted partial credit, and visual-media evaluator synchronization. This is direct evidence that an unchanged agent artifact can receive a different score under a repaired evaluator revision.

An unresolved issue (#62, opened 2026-08-04) questions whether the A/B-test task's expected `SHIP` recommendation is valid given apparently inconsistent downstream event data. PR #64 explicitly says it did not resolve that ground-truth question. Treat this as a credible counterexample/request for investigation, **not** a confirmed task defect.

**Required pin for any result:** Git SHA, task path + variant index, task data revision, VM image/snapshot, evaluator code/reference revision, judge model/prompt where applicable, agent harness/model/config, budget, and retry policy.

## What public data cannot establish

- Exact contents or QC status of the private and pending-QC pools at 2026-08-08.
- A complete public mapping from the paper's 960 workflows/1,490 instances to current GitHub/HF IDs.
- Expert headcount per workflow, production labor, cost, elapsed production time, rejection rate, or evaluator-maintenance cost.
- Whether every input/reference asset has rights adequate for training, redistribution, or commercial resale.
- Human performance baselines, evaluator false-positive/false-negative rates across all tasks, or independent replication of grader validity.
- Number of repeated agent trials from manifests alone. Runs/trials belong to experiment output, not task inventory.

## Source records

### S1 — GitHub repository snapshot

- Title/owner: *Agents' Last Exam* / `rdi-berkeley` (UC Berkeley RDI × RDI Foundation)
- URL: https://github.com/rdi-berkeley/agents-last-exam/tree/1e615e456de7cef57706680613cb80ee13c7fc76
- Version/revision: `main@1e615e456de7cef57706680613cb80ee13c7fc76`; committed 2026-08-05; accessed 2026-08-08.
- Direct evidence (short excerpt): “one `main.py` is one workflow plus one general grading logic.”
- Exact evidence paths: `README.md`; `selected_tasks/full.txt`; `selected_tasks/full/*.txt`; `ale_run/orchestration/config_loader.py`; `ale_run/orchestration/runner.py`; `ale_run/tasks/loader.py`; `docs/ale-docs-site/pages/tasks.html`; `docs/ale-docs-site/pages/add-task.html`; `pyproject.toml`; `LICENSE`; `LICENSE-DATA`; `scripts/fetch_task_data.sh`; `env/README.md`.
- Scores (1 low–5 high): Credibility 5; Recency 5; Bias risk 2 (author-owned implementation and docs; authoritative for code behavior, not independent validation).
- Supports: executable asset/lifecycle contract, current public manifest, environment/provider/license structure. Challenges: using paper/site headline counts as the current runnable manifest.

### S2 — Hugging Face metadata dataset snapshot

- Title/owner: *Agents Last Exam — Task Card Metadata (v1.0)* / `agents-last-exam`.
- URL: https://huggingface.co/datasets/agents-last-exam/agents-last-exam/tree/a8c1fd174a1f6cfa76526572a2e3ebece1276be2
- Version/revision: `main@a8c1fd174a1f6cfa76526572a2e3ebece1276be2`; committed 2026-07-11; accessed 2026-08-08.
- Direct evidence (short excerpt): “This dataset contains task cards only (one row per task).”
- Exact files: `README.md`, `task_cards.parquet`; 153 parsed rows and 12 top-level columns.
- Scores: Credibility 5; Recency 4; Bias risk 2 (official publication; metadata-only and older than current GitHub HEAD).
- Supports: metadata schema, 153-row snapshot and deliberate payload exclusions. Challenges: treating HF rows as current runnable/selected tasks.

### S3 — ALE paper v2

- Title/authors: *Agents' Last Exam* / Yiyou Sun et al.
- URL: https://arxiv.org/html/2606.05405v2
- Version/revision: arXiv `2606.05405v2`, dated 2026-06-11; accessed 2026-08-08.
- Direct evidence (short excerpt): “The current ALE release contains 960 task workflows and 1,490 task instances in total.”
- Scores: Credibility 5; Recency 4; Bias risk 2 (primary technical report and author claims; not independent replication).
- Supports: workflow/instance definitions and June paper snapshot. Challenges: merging 150, 152, and 153 across later surfaces.

### S4 — GitHub PR #64 (merged)

- Title/author: *fix(tasks): harden graders and sync visual-media evaluators* / `sunyiyou`.
- URL: https://github.com/rdi-berkeley/agents-last-exam/pull/64
- Version/revision: merged into `main` as `1e615e4` on 2026-08-05; accessed 2026-08-08.
- Direct evidence (short excerpt): “Missing or malformed components no longer erase credit for independent correct outputs.”
- Scores: Credibility 5 for the code change; Recency 5; Bias risk 2.
- Supports: evaluator revision materially affects scoring; grader regression tests/fixtures are required deliverables.

### S5 — GitHub issue #62 (open counterevidence)

- Title/reporter: *Is `SHIP` the intended ground truth for this A/B test?* / `wanyichen06`.
- URL: https://github.com/rdi-berkeley/agents-last-exam/issues/62
- Version/status: opened 2026-08-04, still open when accessed 2026-08-08.
- Direct evidence (short excerpt): “This looks like a tracking or data-generation problem.”
- Scores: Credibility 3; Recency 5; Bias risk 3 (specific reproducible concern, but unadjudicated).
- Challenges: assuming every reference/evaluator is validated merely because a task is in the public release.

### S6 — Live official site/docs

- Title/institution: *Agents' Last Exam* / UC Berkeley RDI.
- URLs: https://agents-last-exam.org/ and https://agents-last-exam.org/docs/ale/index.html
- Version/revision: live mutable pages; no public commit ID exposed; accessed 2026-08-08.
- Direct evidence (short excerpt): “around 150 public tasks ... from a 1,000+ task corpus.”
- Scores: Credibility 4; Recency 5; Bias risk 3 (official, but marketing/approximate and mutable).
- Supports: overall product positioning. Challenges: using live approximate counts as an exact production quota or frozen benchmark manifest.

## Bottom-line use in the scope report

Treat the deliverable as a versioned benchmark system, not a table of prompts. At minimum its acceptance package needs: workflow spec, explicit instance manifest, input payloads, environment/image/software bill of materials, reference, evaluator + tests/fixtures, run/orchestration config, metadata/taxonomy, per-asset rights, QA/reviewer record, and immutable version IDs. The ALE public code/data snapshots demonstrate all of these layers except complete rights provenance and complete QA records; those missing layers must be explicit client deliverables rather than inferred from ALE.
