# ALE scope research — refresh targets

基准研究日期：2026-08-08。以下字段属于 mutable surface；在 proposal 签署、pilot 结束、正式冻结 benchmark、每次 leaderboard 发布前重新核验。不得把刷新后的数字回填到旧快照而不改变版本标签。

| Target | 2026-08-08 pin / baseline | Refresh trigger | Refresh action |
|---|---|---|---|
| arXiv paper | `2606.05405v2`, revised 2026-06-11 | 新 arXiv version、正式 proceedings 版本 | 保存新版本为独立来源；逐项 diff 定义、Figure 5、Appendix C、指标与 limitations |
| Official homepage | unversioned living page；显示 `1,500+ tasks`、`300+ experts`、`55` targeted sub-industries、目标 `5,000` | proposal/采购签署前；任何官网数字变化 | 保存访问日期和页面证据；保持与 paper snapshot 分列 |
| Submit page | unversioned living page；Complex / Representative / Verifiable；五类可见组件 | 作者更新提交规则或 verifiability flow | 保存页面快照；更新 acceptance schema 与 pilot gate |
| GitHub code | `main@1e615e456de7cef57706680613cb80ee13c7fc76`，2026-08-05 | 每次生产环境冻结；grader/harness PR 合并 | 记录 commit SHA；重算 curated paths、tier membership、load/start/evaluate coverage；运行 regression suite |
| Public curated list | `selected_tasks/full.txt` = 152 unique paths；tier membership = 160、unique = 152 | task selection 文件变化 | 重新计算 unique path、variant、cross-tier overlap；不得用 code directory 数替代 public instances |
| Hugging Face metadata | `main@a8c1fd174a1f6cfa76526572a2e3ebece1276be2`，v1.0，153 rows | dataset commit/schema/terms 变化 | pin exact revision；导出 schema、row/split/domain/subdomain counts；diff GitHub curated list |
| Inputs / references / archives | companion repos；部分 gated | 客户访问策略、许可证、商业软件 entitlement 变化 | 逐组件建立 access-control 与 license manifest；验证 clean-room evaluator path |
| Leaderboard | ALE-V1；Best-per-task Jul 4 2026；runtime methodology updated Jul 10 2026 | 新 evaluation batch、harness/model/effort 或统计口径变化 | 保存 leaderboard snapshot；同时 pin agent system、trial count、budget、retry、licensed/unlicensed view、runtime boundaries |
| Evaluators | current head 已包含 grader hardening；issue #62 ground-truth concern open at research date | grader/reference/score aggregation 变化；appeal | bump evaluator version；重跑 golden/adversarial/regression cases；保留旧分数与新分数映射 |
| Expert counts / taxonomy | paper、homepage、GitHub/HF 数字处于不同快照与单位 | staffing/coverage quota 决策前 | 只用项目自有 roster 和冻结 taxonomy 做配额；外部数字仅作背景，不直接转化为 production quota |
| Contamination / exposure | public metadata/code 与 hidden evaluation 分层 | 任何 instance、reference、evaluator、trace 或 score feedback 扩权/泄露 | 记录 exposure event；从 final holdout 退役或移入 development/training；替换并重新校准 |
| Rights and commercial use | code Apache-2.0；benchmark content CC BY 4.0；第三方软件/数据另审 | OTS 销售、客户部署、地域/供应商变化 | 运行逐组件 rights review；记录 attribution、redistribution、commercial-use、gating、revocation 与 substitution |

## Minimum refresh record

每次刷新至少保存：`surface`、`URL/repository`、`retrieved_at`、`version_or_sha`、`content_hash`、`observed_unit`、`old_value`、`new_value`、`change_reason`、`impact_on_scope`、`reviewer`。若数值单位不明，填 `unit_unknown`，不得自行映射为 workflow 或 runnable instance。
