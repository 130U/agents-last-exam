# F3 — Cost drivers and scope scenarios

## Thesis

Unique workflow specifications, evaluator contracts and environment profiles create workflow-level fixed work; inputs/references, rights checks and runtime QA create instance-level variable work. Therefore 1,000 workflows and 1,000 instances from fewer workflows are materially different scopes.

## Evidence

- ALE binds a workflow to one `main.py`/shared `evaluate()` and allows multiple instance-specific inputs/references. [Source 01]
- ALE's current framework spans VM/container providers, licensed tasks and harness integrations. [Sources 04, 07]
- SWE-bench-Live/SWE-bench and MLPerf independently show that environment/evaluator/harness packaging is a separate engineering layer. [Sources 13, 21]
- Public ALE sources do not report expert hours, production acceptance yield, evaluator build time, environment failure rate or rights-clearance cost. [Sources 01–08]

## Verdict

The architecture supports H4's direction, but its numerical magnitude is **underdetermined**. Use a representative pilot to estimate workflow fixed cost, instance marginal cost, reuse validity and critical-path distributions; do not quote the paper's `1,490/960` ratio as a target.

