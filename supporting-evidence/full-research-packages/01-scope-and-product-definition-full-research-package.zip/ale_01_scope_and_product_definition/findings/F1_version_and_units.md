# F1 — Version and unit reconciliation

## Thesis

`1,000 tasks` is not a contractible unit until workflow, runnable instance, submission/provenance, release state and run/trial are separated.

## Evidence

- arXiv v2 Figure 5: 1,490 **instances** = 960 external submissions + 530 commissioned tasks; separately 150 public + 1,017 private + 323 pending QC. [Source 01]
- arXiv v2 Appendix C.3.7: 960 **workflows**, 1,490 instances; no mapping proves its 960 equals Figure 5's 960 submissions. [Source 01]
- Current homepage/blog: 1,500+ generic tasks, 300+ experts; homepage adds a 5,000 target. [Sources 02, 06]
- GitHub head: open framework plus around 150 public tasks. [Source 04]
- HF revision `a8c1fd...`: 153 metadata rows. [Source 05]
- Paper experiment text uses 152 public tasks, another internal snapshot. [Source 01]

## Implication

All proposal and acceptance documents must include a unit dictionary, frozen manifest/revision, and non-overlapping count rules. Equality of two numbers is not evidence of set identity.

