# F4 — Adversarial validity and QA

## Strongest counterarguments

1. Private sets reduce direct exposure but weaken external audit and do not prove absence of pretraining/expert/customer leakage. [Sources 09, 11, 12]
2. Deterministic graders can still be wrong; the current ALE head includes grader-hardening and false-zero fixes. [Source 08]
3. LLM judges can be useful but have position/verbosity/self-enhancement biases; use narrow rubric/reference calibration and human escalation. [Sources 01, 22]
4. Harness, budget, retries, environment and evaluator versions can change scores/rankings; one score is a configured system/run observation. [Sources 07, 09, 10]
5. Container tags are mutable and a digest does not freeze external services, hardware or license servers. [Source 20]
6. A dataset/code license does not clear every embedded third-party input/reference/software right. [Sources 15–19]

## Acceptance consequences

Require gold pass, negative controls, near-miss tests, side-effect checks, clean reset/replay, evaluator immutability, version-diff regrading, run variance measurement, provenance/rights review and access auditing. Exact thresholds remain pilot/client policy because public evidence is insufficient.

