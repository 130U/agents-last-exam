# F2 — Product and access boundary

## Thesis

A prompt/input dataset, a runnable instance package, a benchmark harness, a managed private benchmark service and an OTS commercial product are successively larger products with different acceptance criteria.

## Evidence

- ALE paper/repository require executable specification, environment, hidden reference, evaluator and run record. [Sources 01, 04]
- HF surface is metadata-only at the pinned revision. [Source 05]
- SWE-bench and MLPerf independently separate datasets, environments/harnesses, accuracy checking, logs/configuration and final result packaging. [Sources 13, 21]
- NIST calls for test-set/metric/tool documentation and deployment-relevant conditions. [Source 14]

## Access conclusion

The same instance may be reused for known-task regression or mastery, but after training/development exposure it cannot truthfully remain a hidden final holdout under unchanged permissions. Holdout level must match the claim: instance, workflow family or domain. [Sources 01, 09, 11, 12, 16]

## Implication

The default manifest needs separate `purpose_primary` and `visibility` fields. Training/dev/validation/final/rotation are purposes; public/restricted/private are access states. Do not double count public views as extra assets.

