# Hugging Face public task-card taxonomy audit

## Source metadata

- **Dataset:** `agents-last-exam/agents-last-exam`
- **Dataset purpose:** public task-card metadata, one row per released task card
- **Config / split:** `default` / `v1.0`
- **Rows observed:** 153
- **Repository revision:** `a8c1fd174a1f6cfa76526572a2e3ebece1276be2`
- **Repository last modified:** `2026-07-11T06:17:59Z`
- **Retrieved / audited:** 2026-08-06
- **License:** CC BY 4.0
- **Dataset page:** https://huggingface.co/datasets/agents-last-exam/agents-last-exam
- **Dataset card:** https://huggingface.co/datasets/agents-last-exam/agents-last-exam/blob/main/README.md
- **Viewer:** https://huggingface.co/datasets/agents-last-exam/agents-last-exam/viewer/default/v1.0
- **Metadata API:** https://huggingface.co/api/datasets/agents-last-exam/agents-last-exam
- **Rows API, rows 0–99:** https://datasets-server.huggingface.co/rows?dataset=agents-last-exam%2Fagents-last-exam&config=default&split=v1.0&offset=0&length=100
- **Rows API, rows 100–152:** https://datasets-server.huggingface.co/rows?dataset=agents-last-exam%2Fagents-last-exam&config=default&split=v1.0&offset=100&length=100
- **Exact-revision Parquet:** https://huggingface.co/datasets/agents-last-exam/agents-last-exam/resolve/a8c1fd174a1f6cfa76526572a2e3ebece1276be2/task_cards.parquet

### Source assessment

- **Credibility:** high for the fields actually released; this is ALE's first-party Hugging Face organization.
- **Recency:** pinned to the repository SHA above, not merely to the mutable `main` branch.
- **Bias / scope:** this is a public release surface. It is not the full private benchmark and must not be treated as the complete canonical taxonomy.

## Verbatim scope evidence

The dataset card describes the release as:

> “A metadata-only release (v1.0) of 153 tasks from the Agents Last Exam (ALE) benchmark for evaluating computer-use agents on long-horizon professional work.”

It also warns:

> “This dataset contains task cards only (one row per task). No input data, software binaries, reference outputs, scoring fixtures, or VM images are included here.”

The rows API schema exposes both a top-level `category`/`subdomain` pair and a structured `taxonomy` object with five fields:

```json
{"domain_id":"string","domain_code":"string","subdomain_id":"string","subdomain_code":"string","subdomain_name":"string"}
```

These two classification surfaces are not interchangeable.

## Executive result

1. The 153 public rows contain **14 observed `taxonomy.domain_code` values** and **51 unique structured subdomain mappings**.
2. IDs `1` through `13` are the named professional domains. The public rows additionally encode `domain_id="14"`, `domain_code="other"`, with `14.1 / sports / Sports`.
3. The top-level repository field `category` also has 14 values, but it is a **task-path/storage category**, not a reliable canonical taxonomy parent. It equals the first segment of both `task_id` and `source_repo_path` for all 153 rows.
4. **18 of 153 rows** have `category != taxonomy.domain_code`.
5. The public rows alone cannot reconstruct the advertised complete 55-subdomain taxonomy: they expose only 51 unique structured mappings. Any 55-row canonical list must be sourced from the frozen paper and/or the live official taxonomy, with version differences stated explicitly.

## Repository `category` values

| `category` | Public rows |
|---|---:|
| `agriculture_env` | 2 |
| `business_finance` | 21 |
| `computing_math` | 23 |
| `education_info` | 4 |
| `engineering` | 20 |
| `health_medicine` | 26 |
| `legal` | 2 |
| `life_sciences` | 19 |
| `other` | 2 |
| `physical_sciences` | 15 |
| `psychology_neuro` | 3 |
| `social_sciences` | 1 |
| `transport_safety` | 3 |
| `visual_media` | 12 |
| **Total** | **153** |

Audit check: `category == first(task_id.split('/'))` for **153/153** rows, and `category == second(source_repo_path.split('/'))` for **153/153** rows.

## Structured taxonomy domain counts

These counts use `taxonomy.domain_id/domain_code`, not the repository `category`.

| Domain ID | `domain_code` | Public rows | Unique observed subdomains |
|---:|---|---:|---:|
| 1 | `engineering` | 20 | 8 |
| 2 | `physical_sciences` | 11 | 4 |
| 3 | `life_sciences` | 23 | 4 |
| 4 | `health_medicine` | 21 | 5 |
| 5 | `psychology_neuro` | 3 | 2 |
| 6 | `business_finance` | 20 | 8 |
| 7 | `legal` | 2 | 2 |
| 8 | `visual_media` | 15 | 3 |
| 9 | `computing_math` | 24 | 7 |
| 10 | `transport_safety` | 1 | 1 |
| 11 | `education_info` | 4 | 3 |
| 12 | `agriculture_env` | 3 | 2 |
| 13 | `social_sciences` | 4 | 1 |
| 14 | `other` | 2 | 1 |
| **Total** |  | **153** | **51** |

## All 51 structured mappings observed in the public rows

The final column is the number of public task cards carrying that exact five-field mapping.

| Domain ID | Domain code | Subdomain ID | Subdomain code | Subdomain name | Rows |
|---:|---|---:|---|---|---:|
| 1 | `engineering` | 1.1 | `aerospace_mech` | Aerospace & Mechanical Engineering | 1 |
| 1 | `engineering` | 1.2 | `electronics` | Electronics Engineering | 3 |
| 1 | `engineering` | 1.3 | `civil_geo` | Civil, Architectural & Geospatial Engineering | 4 |
| 1 | `engineering` | 1.5 | `manufacturing` | Manufacturing & Industrial Systems | 3 |
| 1 | `engineering` | 1.6 | `energy_power` | Energy, Power & Nuclear Engineering | 2 |
| 1 | `engineering` | 1.8 | `semiconductor` | Semiconductor & Microelectronics Design | 2 |
| 1 | `engineering` | 1.10 | `urban_planning` | Urban & Spatial Planning | 2 |
| 1 | `engineering` | 1.11 | `robotics` | Robotics & Autonomous Systems | 3 |
| 2 | `physical_sciences` | 2.1 | `physics` | Physics | 2 |
| 2 | `physical_sciences` | 2.2 | `chemistry_materials` | Chemistry & Materials Computation | 7 |
| 2 | `physical_sciences` | 2.3 | `astronomy` | Astronomy & Astrophysics | 1 |
| 2 | `physical_sciences` | 2.4 | `earth_atmo` | Earth & Atmospheric Sciences | 1 |
| 3 | `life_sciences` | 3.1 | `biomolecular` | Biomolecular Structure & Design | 5 |
| 3 | `life_sciences` | 3.2 | `genomics` | Genomics & Sequence Analysis | 10 |
| 3 | `life_sciences` | 3.3 | `cell_imaging` | Cell & Imaging Biology | 6 |
| 3 | `life_sciences` | 3.4 | `systems_microbial` | Systems & Microbial Biology | 2 |
| 4 | `health_medicine` | 4.1 | `clinical_diagnostics` | Clinical Diagnostics & Imaging | 5 |
| 4 | `health_medicine` | 4.2 | `therapeutic_oncology` | Therapeutic & Oncology Services | 4 |
| 4 | `health_medicine` | 4.3 | `clinical_informatics` | Clinical Informatics & Care Operations | 2 |
| 4 | `health_medicine` | 4.4 | `public_health` | Public Health & Epidemiology | 7 |
| 4 | `health_medicine` | 4.5 | `clinical_trials` | Clinical Research & Trial Operations | 3 |
| 5 | `psychology_neuro` | 5.1 | `comp_neuro` | Computational Neuroscience | 1 |
| 5 | `psychology_neuro` | 5.2 | `exp_psychology` | Experimental Psychology & Neuroimaging | 2 |
| 6 | `business_finance` | 6.1 | `accounting` | Accounting & Finance | 6 |
| 6 | `business_finance` | 6.2 | `actuarial_risk` | Actuarial & Risk Modeling | 1 |
| 6 | `business_finance` | 6.3 | `enterprise_analytics` | Enterprise Analytics & Planning | 5 |
| 6 | `business_finance` | 6.4 | `compliance` | Compliance & Regulatory | 3 |
| 6 | `business_finance` | 6.5 | `hr_pm` | HR & Project Management | 1 |
| 6 | `business_finance` | 6.6 | `sales_marketing` | Sales & Marketing | 2 |
| 6 | `business_finance` | 6.7 | `quant_finance` | Quantitative Finance & Trading | 1 |
| 6 | `business_finance` | 6.8 | `supply_chain` | Supply Chain & Logistics | 1 |
| 7 | `legal` | 7.1 | `litigation` | Litigation Support & Discovery | 1 |
| 7 | `legal` | 7.2 | `legal_research` | Doctrinal Legal Research | 1 |
| 8 | `visual_media` | 8.1 | `animation_3d` | 3D, Animation & Interactive Media | 10 |
| 8 | `visual_media` | 8.2 | `graphic_design` | Graphic, Visual & Product Design | 2 |
| 8 | `visual_media` | 8.4 | `audio_music` | Audio, Music & Post-Production Media | 3 |
| 9 | `computing_math` | 9.1 | `software_eng` | Software Engineering | 2 |
| 9 | `computing_math` | 9.2 | `data_analytics` | Data & Analytics Engineering | 4 |
| 9 | `computing_math` | 9.3 | `ai_cs_research` | AI Engineering, Safety & CS Research | 3 |
| 9 | `computing_math` | 9.4 | `math_ops_research` | Mathematical & Operations Research | 5 |
| 9 | `computing_math` | 9.5 | `cybersecurity` | Cybersecurity & Digital Forensics | 4 |
| 9 | `computing_math` | 9.6 | `infra_cloud` | Infrastructure Engineering & Cloud Operations | 3 |
| 9 | `computing_math` | 9.7 | `quantum` | Quantum Computing | 3 |
| 10 | `transport_safety` | 10.3 | `fire_safety` | Fire Science & Public Safety | 1 |
| 11 | `education_info` | 11.1 | `edtech` | Educational Technology | 2 |
| 11 | `education_info` | 11.2 | `library_info` | Library & Information Science | 1 |
| 11 | `education_info` | 11.3 | `translation` | Translation & Localization | 1 |
| 12 | `agriculture_env` | 12.1 | `env_water` | Environmental Modeling, Engineering & Water Resources | 1 |
| 12 | `agriculture_env` | 12.2 | `precision_ag` | Precision Agriculture | 2 |
| 13 | `social_sciences` | 13.1 | `economics` | Economics & Quantitative Social Research | 4 |
| 14 | `other` | 14.1 | `sports` | Sports | 2 |

## Integrity checks: blanks, duplicates, and collisions

### Blank classification fields

Zero blank/null values were found in each of:

- `category`
- top-level `subdomain`
- `taxonomy.domain_id`
- `taxonomy.domain_code`
- `taxonomy.subdomain_id`
- `taxonomy.subdomain_code`
- `taxonomy.subdomain_name`

One row, `engineering/2d_drawings_to_3d_bridge_model`, has a blank `task_split`; that is a release-metadata issue but not a taxonomy-mapping issue.

### Duplicate identities

- Duplicate `task_id`: **0**
- Duplicate `source_repo_path`: **0**
- Contradictory `domain_id → domain_code` mappings: **0**
- Contradictory `domain_code → domain_id` mappings: **0**
- Contradictory `subdomain_id → subdomain_code/subdomain_name` mappings: **0**
- Top-level `subdomain != taxonomy.subdomain_name`: **0**

The 51 mapping tuples naturally repeat across 153 tasks; this is not a duplicate-data defect. Their usage distribution is:

| Tasks per mapping | Number of mappings |
|---:|---:|
| 1 | 14 |
| 2 | 13 |
| 3 | 9 |
| 4 | 5 |
| 5 | 4 |
| 6 | 2 |
| 7 | 2 |
| 10 | 2 |

## `category` versus structured taxonomy: 18 mismatches

| Task ID | Repository `category` | `taxonomy.domain_code` | Taxonomy subdomain |
|---|---|---|---|
| `business_finance/legal_ma_consistency_audit_01` | `business_finance` | `legal` | 7.1 Litigation Support & Discovery |
| `business_finance/saas_onepager_brand_refresh_instance_1` | `business_finance` | `visual_media` | 8.2 Graphic, Visual & Product Design |
| `computing_math/go_game_reconstruction_1` | `computing_math` | `other` | 14.1 Sports |
| `engineering/robotics_blender_tabletop_reconstruction` | `engineering` | `visual_media` | 8.1 3D, Animation & Interactive Media |
| `health_medicine/causal_ihdp_ite_estimation_6a_v1` | `health_medicine` | `social_sciences` | 13.1 Economics & Quantitative Social Research |
| `health_medicine/Clinical_Variant_Annotation` | `health_medicine` | `life_sciences` | 3.2 Genomics & Sequence Analysis |
| `health_medicine/healthcare_variant_annotation_pipeline` | `health_medicine` | `life_sciences` | 3.2 Genomics & Sequence Analysis |
| `health_medicine/ltmle_targeted_bootstrap_simulation_study` | `health_medicine` | `social_sciences` | 13.1 Economics & Quantitative Social Research |
| `health_medicine/scene3_skullstrip_qc` | `health_medicine` | `psychology_neuro` | 5.2 Experimental Psychology & Neuroimaging |
| `legal/agora_governance_classify_instance_1` | `legal` | `business_finance` | 6.4 Compliance & Regulatory |
| `other/mota_exploration` | `other` | `visual_media` | 8.1 3D, Animation & Interactive Media |
| `physical_sciences/adapt_vqe_molecular_energy` | `physical_sciences` | `computing_math` | 9.7 Quantum Computing |
| `physical_sciences/gillespie_gene_regulatory_network` | `physical_sciences` | `life_sciences` | 3.4 Systems & Microbial Biology |
| `physical_sciences/glm_lake_calibration` | `physical_sciences` | `agriculture_env` | 12.1 Environmental Modeling, Engineering & Water Resources |
| `physical_sciences/lenacapavir_sar_table2_extraction` | `physical_sciences` | `life_sciences` | 3.1 Biomolecular Structure & Design |
| `psychology_neuro/reddit_ai_post_codebook_boolean_coding` | `psychology_neuro` | `social_sciences` | 13.1 Economics & Quantitative Social Research |
| `transport_safety/abm_hangzhou_metro` | `transport_safety` | `engineering` | 1.10 Urban & Spatial Planning |
| `transport_safety/capacitated_vehicle_routing_problems` | `transport_safety` | `computing_math` | 9.4 Mathematical & Operations Research |

Two exact API examples make the distinction explicit:

```json
{"task_id":"legal/agora_governance_classify_instance_1","category":"legal","subdomain":"Compliance & Regulatory","taxonomy":{"domain_id":"6","domain_code":"business_finance","subdomain_id":"6.4","subdomain_code":"compliance","subdomain_name":"Compliance & Regulatory"},"source_repo_path":"tasks/legal/agora_governance_classify_instance_1"}
```

```json
{"task_id":"other/mota_exploration","category":"other","subdomain":"3D, Animation & Interactive Media","taxonomy":{"domain_id":"8","domain_code":"visual_media","subdomain_id":"8.1","subdomain_code":"animation_3d","subdomain_name":"3D, Animation & Interactive Media"},"source_repo_path":"tasks/other/mota_exploration"}
```

Therefore, any taxonomy extraction that groups by the visible `category` column will misclassify at least these 18 public rows. Use `taxonomy.*` for formal mapping and retain `category` only as repository provenance.

## `Other` / Sports audit

### Rows formally mapped to Sports

Exactly two public rows carry `14 / other / 14.1 / sports / Sports`:

```json
{"task_id":"computing_math/go_game_reconstruction_1","category":"computing_math","subdomain":"Sports","taxonomy":{"domain_id":"14","domain_code":"other","subdomain_id":"14.1","subdomain_code":"sports","subdomain_name":"Sports"},"source_repo_path":"tasks/computing_math/go_game_reconstruction_1"}
```

```json
{"task_id":"other/aerobics_wc2026_portugal_trio_difficulty_scoring","category":"other","subdomain":"Sports","taxonomy":{"domain_id":"14","domain_code":"other","subdomain_id":"14.1","subdomain_code":"sports","subdomain_name":"Sports"},"source_repo_path":"tasks/other/aerobics_wc2026_portugal_trio_difficulty_scoring"}
```

### Why `category="other"` is not equivalent to `taxonomy.domain_code="other"`

- The formal Sports mapping has 2 rows, but only one has repository `category="other"`; the Go reconstruction task is stored under `computing_math`.
- Repository `category="other"` also has 2 rows, but one of them, `other/mota_exploration`, is formally mapped to `visual_media / 8.1` rather than to Sports.

This explains how the Dataset Viewer can show 14 category classes without establishing that `Other` is a fourteenth formal occupational domain. The public row schema does encode it as an additional residual `domain_id=14`, but the frozen paper's claim remains “13 domains / 55 subdomains”; that semantic reconciliation belongs to the cross-source synthesis, not to the public subset alone.

## What is missing from this public subset?

### From the Hugging Face rows alone

Only 51 structured subdomain IDs are observable. The absent IDs and names cannot be safely invented from gaps in the numbering. In particular, observed engineering IDs skip `1.4`, `1.7`, and `1.9`, while transportation exposes only `10.3`; an ID gap proves non-observation, not the missing label's canonical wording.

### Cross-source comparison boundaries

- Compared with the **frozen v2 Figure 2 list** saved separately in `01_arxiv_v2_taxonomy.md`, the public rows do not expose four paper subdomains: Chemical & Process Engineering; Mining, Petroleum & Geological Engineering; Aviation & Airspace Operations; and Maritime & Port Operations. Sports is present in both surfaces.
- The **live taxonomy site is a different mutable surface**: it contains a Marine & Naval Engineering card not printed in Figure 2 and organizes the `Other/Sports` question differently. A current-site comparison must therefore be versioned separately rather than forced into the frozen paper list.

## Reproducibility method

1. Read repository metadata from the metadata API and pin the returned SHA.
2. Fetch rows `0–99` and `100–152` from the Dataset Server rows API.
3. Project each row to:
   - `task_id`
   - `category`
   - top-level `subdomain`
   - all five `taxonomy.*` fields
   - `source_repo_path`
4. Group by the complete five-field taxonomy tuple.
5. Check blanks, task/path duplicates, key collisions, top-level subdomain disagreement, and `category != taxonomy.domain_code`.
6. Audit `Other` and `Sports` by both repository field and structured taxonomy field.

## Limitations

- This is only the 153-row public task-card release, not the full 1,490-instance v2 paper snapshot or any private task pool.
- A task card is metadata; it does not expose reference outputs, evaluators, full fixtures, or VM images.
- The rows API is mutable when queried at `main`; the audit therefore records the repository SHA. The Dataset Server URL itself did not expose a revision selector in this extraction.
- Row counts show public release coverage, not intended taxonomy weights or economic importance.
- `domain_id=14 / other` is a real structured value in the public rows, but this fact alone does not resolve whether `Other` is a formal fourteenth domain, a residual implementation bucket, or a display convention. The paper and live-site evidence must control that interpretation.
