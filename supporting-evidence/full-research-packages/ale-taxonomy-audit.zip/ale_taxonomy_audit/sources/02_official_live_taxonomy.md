# Source note 02 — current official ALE taxonomy surface

## Metadata

- **Primary source:** [ALE Industry Taxonomy](https://agents-last-exam.org/taxonomy)
- **Publisher / authority:** UC Berkeley RDI / Agents' Last Exam team
- **Source type:** living first-party website; not a frozen paper snapshot
- **Accessed:** 2026-08-06 (America/New_York)
- **Extraction method:** inspected the rendered taxonomy page and extracted its heading hierarchy. On this page, `H3` is the domain level, `H4` is the subdomain level, and `H5` is the benchmark-leaf level.
- **Cross-check:** [official framework repository README](https://github.com/rdi-berkeley/agents-last-exam/blob/main/README.md) and selected public `task_card.json` files at repository search snapshot commit [`1e615e456de7cef57706680613cb80ee13c7fc76`](https://github.com/rdi-berkeley/agents-last-exam/tree/1e615e456de7cef57706680613cb80ee13c7fc76).
- **Scope warning:** this note records the **current live website** exactly. It does not silently replace or normalize the arXiv v2 Figure 2 taxonomy, the Hugging Face release, or repository storage categories.

## Short verbatim evidence

The live page says:

> “13 domains, 55 subdomains, and 100 benchmark leaves”

It also labels the classification basis as:

> “O*NET / SOC 2018 + OECD FORD + NSF / NIH / DARPA frontier fields”

The current official repository README independently summarizes ALE as organizing work into:

> “55 subdomains across 13 industry clusters”

The framework documentation describes the evaluation object concisely as:

> “Measure agents on real work, in real sandboxes.”

Documentation URL: [ALE framework overview](https://agents-last-exam.org/docs/ale/index.html).

## Exact current-live mapping

The numeric prefixes below are **audit indices derived from the live page order**. The live page itself does not render machine-readable `domain_id`, `domain_code`, `subdomain_id`, or `subdomain_code` fields.

### 1. Engineering & Architecture — 11 subdomains

1. Aerospace & Mechanical Engineering
2. Electronics Engineering
3. Civil, Architectural & Geospatial Engineering
4. Chemical & Process Engineering
5. Manufacturing & Industrial Systems
6. Energy, Power & Nuclear Engineering
7. Mining, Petroleum & Geological Engineering
8. Semiconductor & Microelectronics Design
9. Marine & Naval Engineering
10. Urban & Spatial Planning
11. Robotics & Autonomous Systems

### 2. Physical Sciences — 4 subdomains

1. Physics
2. Chemistry & Materials Computation
3. Astronomy & Astrophysics
4. Earth & Atmospheric Sciences

### 3. Life Sciences — 4 subdomains

1. Biomolecular Structure & Design
2. Genomics & Sequence Analysis
3. Cell & Imaging Biology
4. Systems & Microbial Biology

### 4. Health & Medicine — 5 subdomains

1. Clinical Diagnostics & Imaging
2. Therapeutic & Oncology Services
3. Clinical Informatics & Care Operations
4. Public Health & Epidemiology
5. Clinical Research & Trial Operations

### 5. Psychology & Neuroscience — 2 subdomains

1. Computational Neuroscience
2. Experimental Psychology & Neuroimaging

### 6. Business & Finance — 7 subdomains

1. Accounting & Finance
2. Actuarial & Risk Modeling
3. Enterprise Analytics & Planning
4. Compliance & Regulatory
5. HR & Project Management
6. Sales & Marketing
7. Quantitative Finance & Trading

### 7. Legal — 2 subdomains

1. Litigation Support & Discovery
2. Doctrinal Legal Research

### 8. Visual & Media Arts — 4 subdomains

1. 3D, Animation & Interactive Media
2. Graphic, Visual & Product Design
3. Fashion & Apparel
4. Audio, Music & Post-Production Media

### 9. Computing, Data & Mathematical Sciences — 7 subdomains

1. Software Engineering
2. Data & Analytics Engineering
3. AI Engineering, Safety & CS Research
4. Mathematical & Operations Research
5. Cybersecurity & Digital Forensics
6. Infrastructure Engineering & Cloud Operations
7. Quantum Computing

### 10. Transportation & Safety Operations — 3 subdomains

1. Aviation & Airspace Operations
2. Maritime & Port Operations
3. Fire Science & Public Safety

### 11. Education & Information Services — 3 subdomains

1. Educational Technology
2. Library & Information Science
3. Translation & Localization

### 12. Agriculture & Environment — 2 subdomains

1. Environmental Modeling, Engineering & Water Resources
2. Precision Agriculture

### 13. Social Sciences — 1 subdomain

1. Economics & Quantitative Social Research

## Count check

| Live domain | Subdomain count |
|---|---:|
| Engineering & Architecture | 11 |
| Physical Sciences | 4 |
| Life Sciences | 4 |
| Health & Medicine | 5 |
| Psychology & Neuroscience | 2 |
| Business & Finance | 7 |
| Legal | 2 |
| Visual & Media Arts | 4 |
| Computing, Data & Mathematical Sciences | 7 |
| Transportation & Safety Operations | 3 |
| Education & Information Services | 3 |
| Agriculture & Environment | 2 |
| Social Sciences | 1 |
| **Total** | **55** |

Arithmetic check: `11 + 4 + 4 + 5 + 2 + 7 + 2 + 4 + 7 + 3 + 3 + 2 + 1 = 55`.

## Machine IDs and codes: what is and is not exposed

The live page exposes only display names. Public repository task cards expose a separate operational metadata schema, for example:

- [`tasks/engineering/aerospace_low_thrust_trajectory/task_card.json`](https://github.com/rdi-berkeley/agents-last-exam/blob/1e615e456de7cef57706680613cb80ee13c7fc76/tasks/engineering/aerospace_low_thrust_trajectory/task_card.json) contains `domain_id: "1"`, `domain_code: "engineering"`, `subdomain_id: "1.1"`, `subdomain_code: "aerospace_mech"`, and the matching display name.
- Other task cards similarly use codes such as `physical_sciences`, `life_sciences`, `health_medicine`, `psychology_neuro`, `business_finance`, `legal`, `visual_media`, `computing_math`, `transport_safety`, `education_info`, `agriculture_env`, and `social_sciences`.

These task-card fields must not be treated as a lossless serialization of the current live page without a pinned central taxonomy manifest. The repository contains reclassification history and storage-category drift.

## Exact representation of `Other` and `Sports`

### Current live taxonomy page

- There is **no `Other` H3 domain**.
- There is **no `Sports` H4 subdomain**.
- Neither string appears in the current 13-domain / 55-subdomain heading mapping.
- Therefore, on the current living website, `Other/Sports` is not part of the displayed formal 13×55 taxonomy.

### Current public repository task-card surface

The repository nevertheless contains an operational catch-all record:

- File: [`tasks/other/aerobics_wc2026_portugal_trio_difficulty_scoring/task_card.json`](https://github.com/rdi-berkeley/agents-last-exam/blob/1e615e456de7cef57706680613cb80ee13c7fc76/tasks/other/aerobics_wc2026_portugal_trio_difficulty_scoring/task_card.json)
- `category`: `other`
- `taxonomy.domain_id`: `14`
- `taxonomy.domain_code`: `other`
- `taxonomy.subdomain_id`: `14.1`
- `taxonomy.subdomain_code`: `sports`
- `taxonomy.subdomain_name`: `Sports`

This is direct evidence that the repository/data-release surface can represent `Other → Sports` as `14 → 14.1`, even while the current official taxonomy webpage presents exactly 13 domains and 55 subdomains with neither label.

## Unresolved differences that must remain explicit

1. **Living page versus repository release:** the live site presents 13×55; at least one public repository card presents `14 / other / 14.1 / sports`. These are different observable surfaces, not a single silently harmonized taxonomy.
2. **Business & Finance drift:** the live site has seven H4 subdomains and places `Supply Chain & Logistics` below `Enterprise Analytics & Planning` as an H5 leaf. A public repository card for `tasks/business_finance/odoo` instead carries `subdomain_id: "6.8"`, `subdomain_code: "supply_chain"`, `subdomain_name: "Supply Chain & Logistics"`. Thus H4/H5 depth and task-card `subdomain_id` are not guaranteed to match the live page.
3. **Storage category is not taxonomy parent:** [`tasks/transport_safety/abm_hangzhou_metro/task_card.json`](https://github.com/rdi-berkeley/agents-last-exam/blob/1e615e456de7cef57706680613cb80ee13c7fc76/tasks/transport_safety/abm_hangzhou_metro/task_card.json) remains stored under/category-labeled `transport_safety`, while its current taxonomy metadata reclassifies it under Engineering → Urban & Spatial Planning and preserves the prior Transportation assignment in `classifier.previous`.
4. **Paper Figure 2:** this note intentionally does not decide whether the paper's visual `Other` strip is a fourteenth formal domain, an auxiliary display band, or a release-specific category. That comparison belongs to the pinned arXiv-v2 audit and must cite the frozen paper directly.
5. **No central live manifest located in this audit:** because the page does not expose IDs/codes, the exact current-live canonical answer is the H3/H4 display-name mapping above. Repository IDs/codes should be reported as a separate implementation/release surface.

## Audit conclusion

As of 2026-08-06, the current official ALE taxonomy page has an internally consistent **13-domain / 55-subdomain** hierarchy. `Other/Sports` is absent from that hierarchy but present in the public repository's task-card metadata as `domain 14 / subdomain 14.1`. Any final answer should show the current 13×55 list first and then explain `Other/Sports` as a version/surface discrepancy rather than silently adding it as a fourteenth current-live domain.
