# ALE arXiv v2 taxonomy audit

## Source metadata

- **Title:** Agents' Last Exam
- **arXiv:** 2606.05405v2 [cs.AI]
- **Version date:** 11 June 2026
- **HTML:** https://arxiv.org/html/2606.05405v2
- **Abstract/version record:** https://arxiv.org/abs/2606.05405v2
- **Retrieved:** 6 August 2026
- **Primary locations used:** Figure 2 and its caption; Section 2.2; Appendix B.1, especially B.1.1 (Taxonomy Definition)

## What the paper formally claims

Section 2.2 says the taxonomy is grounded in SOC 2018 and O*NET and groups the retained digital workflows into 13 domains spanning 55 subdomains. Appendix B.1.1 explains that occupation-level evidence is consolidated into workflow-level subdomains, with frontier additions for work not adequately represented by SOC/O*NET.

Short verbatim checks from Appendix B.1.1:

> “This process yields 51 SOC-anchored subdomains.”

> “The final taxonomy contains 55 workflow-level subdomains grouped into 13 domains.”

Appendix B.1.1 also reports four frontier subdomains and seven frontier extensions to existing SOC-anchored subdomains. The paper does **not** publish a row-level mapping from the displayed subdomains to the retained SOC base codes.

## Full Figure 2 extraction

Names below preserve the English labels and abbreviations printed in Figure 2. The number after each domain is the domain total; the number after each subdomain is its task-instance count in the v2 snapshot.

### 1. Engineering & Architecture (368)

1. Manufacturing & Indust. Sys. — 173
2. Aerospace & Mech. Eng. — 47
3. Civil, Arch. & Geospatial Eng. — 33
4. Robotics & Auton. Systems — 29
5. Semiconductor & Microelectronics Design — 28
6. Electronics Engineering — 23
7. Chemical & Process Engineering — 17
8. Mining, Petroleum & Geological Engineering — 9
9. Urban & Spatial Planning — 5
10. Energy, Power & Nuclear Engineering — 4

Count check: 10 subdomains; 173 + 47 + 33 + 29 + 28 + 23 + 17 + 9 + 5 + 4 = **368**.

### 2. Life Sciences (111)

1. Biomolecular Struct. & Design — 55
2. Genomics & Sequence Analysis — 30
3. Cell & Imaging Biology — 13
4. Systems & Microbial Biology — 13

Count check: 4 subdomains; total **111**.

### 3. Education & Info. (33)

1. Educational Technology — 18
2. Library & Information Science — 9
3. Translation & Localization — 6

Count check: 3 subdomains; total **33**.

### 4. Agriculture & Env. (19)

1. Env. Modeling & Water Resources — 11
2. Precision Agriculture — 8

Count check: 2 subdomains; total **19**.

### 5. Computing & Math Sci. (237)

1. Data & Analytics Eng. — 57
2. AI Engineering & CS Res. — 50
3. Software Engineering — 38
4. Math. & Operations Research — 35
5. Cybersecurity & Forensics — 28
6. Quantum Computing — 16
7. Infrastructure Engineering & Cloud Operations — 13

Count check: 7 subdomains; total **237**.

### 6. Health & Medicine (155)

1. Clinical Diagnostics & Imaging — 71
2. Clinical Informatics & Care — 27
3. Therapeutic & Oncology — 25
4. Public Health & Epi. — 19
5. Clinical Research & Trial Operations — 13

Count check: 5 subdomains; total **155**.

### 7. Transport. & Safety (35)

1. Fire Science & Public Safety — 19
2. Aviation & Airspace Operations — 13
3. Maritime & Port Operations — 3

Count check: 3 subdomains; total **35**.

### 8. Psychology & Neuroscience (27)

1. Exp. Psychology & Neuroimg. — 19
2. Computational Neuroscience — 8

Count check: 2 subdomains; total **27**.

### Figure-only residual strip: Other (3)

1. Sports — 3

Count check: 1 subdomain; total **3**.

### 9. Visual & Media Arts (226)

1. 3D, Animation & Interactive — 133
2. Audio, Music & Post-Prod. — 69
3. Graphic, Visual & Product — 24

Count check: 3 subdomains; total **226**.

### 10. Business & Finance (189)

1. Accounting & Finance — 115
2. Enterprise Analytics & Plan. — 42
3. Sales & Marketing — 8
4. Actuarial & Risk Modeling — 7
5. Compliance & Regulatory — 5
6. HR & Project Management — 5
7. Quantitative Finance & Trading — 5
8. Supply Chain & Logistics — 2

Count check: 8 subdomains; total **189**.

### 11. Physical Sciences (46)

1. Chemistry & Materials Comp. — 17
2. Physics — 14
3. Earth & Atmospheric Sciences — 10
4. Astronomy & Astrophysics — 5

Count check: 4 subdomains; total **46**.

### 12. Social Sciences (26)

1. Economics & Quant. Social Res. — 26

Count check: 1 subdomain; total **26**.

### 13. Legal (15)

1. Litigation Support & Discovery — 11
2. Doctrinal Legal Research — 4

Count check: 2 subdomains; total **15**.

## Global count checks

- Thirteen numbered, named domains above contain **54** subdomains and **1,487** task instances.
- The Figure 2 `Other` strip contributes **Sports**, 1 additional subdomain and 3 additional instances.
- Including `Sports`: **55 subdomains** and **1,490 task instances**.
- Domain/strip arithmetic: 368 + 111 + 33 + 19 + 237 + 155 + 35 + 27 + 3 + 226 + 189 + 46 + 26 + 15 = **1,490**.
- Therefore Figure 2 visually contains **14 group headers** if `Other` is counted as a header: 13 named domains plus `Other`.

## Sports / Other determination

The paper presents a small internal inconsistency:

1. The abstract, Section 2.2, Appendix B.1.1, and the Figure 2 caption all state **13 domains / 55 subdomains**.
2. Figure 2 visibly lists 13 named domain bands **plus** a separate `Other (3)` band containing `Sports 3`.
3. Excluding `Other/Sports` leaves only 54 displayed subdomains, while including it yields the claimed 55.

The most conservative paper-only interpretation is:

- `Sports` is counted as one of the 55 subdomains in the v2 Figure 2 snapshot.
- `Other` is a visual residual container rather than one of the 13 formal named domains.
- The paper does not state which of the 13 formal domains, if any, owns `Sports` outside that visual container.

Do **not** silently call `Other` a fourteenth formal domain, and do **not** assign `Sports` to another named domain without an additional authoritative source.

## IDs and SOC codes

- Figure 2 gives English labels and snapshot counts, but no taxonomy IDs.
- Appendix B.1.1 reports that 117 unique SOC base codes survived screening, but it does not print the code-to-subdomain assignments.
- No SOC codes or internal ALE IDs can therefore be attached to the 55 rows from the paper alone.

## Uncertainties and evidence boundary

- Several Figure 2 names are abbreviated (`Indust.`, `Mech.`, `Arch.`, `Auton.`, `Info.`, `Env.`, `Sci.`, `Eng.`, `Res.`, `Epi.`, `Neuroimg.`, `Post-Prod.`, `Plan.`, `Comp.`). This note preserves those printed forms and does not infer expansions.
- The live ALE taxonomy website may use expanded names, add benchmark leaves, or omit/re-home categories. Those are a separate, mutable source and should not be substituted for the v2 paper snapshot without an explicit cross-version comparison.
- Figure 2 is the only location in the v2 paper that enumerates all displayed labels. Appendix B.1.1 explains derivation and counts but does not provide a 55-row table.
