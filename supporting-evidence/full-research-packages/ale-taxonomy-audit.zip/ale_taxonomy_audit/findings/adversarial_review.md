# Adversarial review of the ALE taxonomy presentation

## Verdict

The proposed presentation — current live list first, followed by a four-item structural diff against arXiv v2 — is accurate **if the four-item claim is explicitly limited to subdomain membership after normalizing abbreviations and treating renamed/expanded labels as the same lineage**. It is not accurate to say there are only four exact-label differences.

## 1. Frozen arXiv v2: confirmed, with an internal presentation inconsistency

Independent inspection of the official v2 Figure 2 image confirms:

- 13 ordinary named domain headers contain 54 displayed subdomain rows and 1,487 instances.
- A separate `Other (3)` header contains `Sports 3`, supplying the additional displayed row and 3 instances.
- Therefore the graphic has 14 visible group headers, 55 subdomain rows, and 1,490 instances.
- The arithmetic in `sources/01_arxiv_v2_taxonomy.md` is correct: the 13 ordinary-domain totals sum to 1,487; adding `Other / Sports = 3` gives 1,490. Its per-domain row counts also sum to 54 + 1.

The inconsistency is in the paper itself: Figure 2's caption says all 55 rows are grouped under 13 top-level domains, while the graphic visibly places `Sports` under an additional `Other` header. The paper does not explain which of the 13 domains owns `Sports`, nor does it explicitly define `Other` as a “residual container.” That phrase is a reasonable reviewer inference, not paper terminology.

Use this exact caveat:

> In arXiv v2, Figure 2 displays 13 ordinary domain headers containing 54 subdomains, plus a separate `Other` bucket containing `Sports`, which brings the displayed total to 55. The text nevertheless declares 13 domains / 55 subdomains and does not explain where `Sports` belongs in that 13-domain hierarchy; therefore `Other` should be described as a figure-level bucket, not asserted to be a formal fourteenth domain.

Also avoid saying Figure 2 “numbers” the domains: the numbering in the source note is editorial. Prefer “the 13 domain sections in this extraction.” Avoid ordinal wording such as “Sports is literally the 55th row”; say it “supplies the additional row needed to reach 55.”

Primary evidence: [arXiv v2 Figure 2 and caption](https://arxiv.org/html/2606.05405v2), [v2 version record](https://arxiv.org/abs/2606.05405v2).

## 2. Current live taxonomy: confirmed as a distinct 13 / 55 / 100 hierarchy

The official live taxonomy page retrieved 2026-08-06 renders and computes:

- 13 domains
- 55 subdomains
- 100 benchmark leaves

The live hierarchy has no `Other` domain and no `Sports` subdomain. Compared with v2, the four structural membership changes are:

| Status | Subdomain | Live treatment |
|---|---|---|
| Live-only | Marine & Naval Engineering | New subdomain under Engineering & Architecture |
| Live-only | Fashion & Apparel | New subdomain under Visual & Media Arts |
| v2-only at subdomain level | Supply Chain & Logistics | Demoted to a benchmark leaf under Enterprise Analytics & Planning |
| v2-only | Sports | Absent from the live hierarchy |

This preserves 55 subdomains: +2 and -2. The live `100 benchmark leaves` are a third taxonomy level, not tasks, task instances, SOC codes, or a v2 count.

Primary evidence: [official live taxonomy](https://agents-last-exam.org/taxonomy).

## 3. Required corrections and wording limits

1. Qualify the “four-item diff.” Exact labels also changed. Examples include `Therapeutic & Oncology` → `Therapeutic & Oncology Services`, `Clinical Informatics & Care` → `Clinical Informatics & Care Operations`, `AI Engineering & CS Res.` → `AI Engineering, Safety & CS Research`, `Cybersecurity & Forensics` → `Cybersecurity & Digital Forensics`, and several abbreviation/descriptor expansions. Say “four membership changes after label normalization,” and list renames separately if exact nomenclature matters.

2. Fix the plan's stop criterion. A “55-row canonical mapping with unique subdomain IDs” cannot come from v2 Figure 2: the figure publishes labels and instance counts, not IDs. Replace it with “a 55-row frozen v2 label/count extraction.” Any IDs taken from the living release must be labeled as release-snapshot IDs and must not be projected backward onto v2 without an official crosswalk.

3. Strengthen the Hugging Face caveat. The current 153-row official metadata release exposes 14 `category` values and 14 structured `taxonomy.domain_code` values, including `other`, and only 51 distinct subdomain IDs are represented in those public rows. It therefore does not equal either the complete live 13/55/100 web hierarchy or a complete frozen-v2 mapping. `taxonomy.*` is better than the flat `category` field for interpreting a row, but it still describes that release snapshot; it does not prove a v2 crosswalk.

4. Do not silently merge the sources. Present three separately dated surfaces: frozen arXiv v2 Figure 2; current live taxonomy page; current public task-card metadata. Their mismatches are version/surface evidence, not arithmetic errors to normalize away.

Primary release evidence: [official Hugging Face task-card dataset](https://huggingface.co/datasets/agents-last-exam/agents-last-exam/viewer/default/v1.0).
