# F1 — The phrase “ALE's 13 domains and 55 subdomains” is version-sensitive

**Verdict:** confirmed.

## Evidence synthesis

- The frozen arXiv v2 paper says 13 domains and 55 subdomains, but Figure 2 visually contains 13 named domain bands with 54 subdomains plus `Other → Sports`; including Sports gives 55.
- The current official taxonomy page has a clean 13-domain / 55-subdomain / 100-leaf hierarchy and omits `Other/Sports`.
- The current Hugging Face public task-card release still exposes `14 / other → 14.1 / sports`, while only 51 unique structured subdomain mappings occur in the released rows.
- HF `category` is a repository/path grouping and differs from `taxonomy.domain_code` on 18 of 153 rows, so it cannot be used as the domain definition.

## Required reporting rule

Pin one of these surfaces before listing categories. For the paper's 1,490-instance snapshot, report the Figure 2 residual-strip anomaly explicitly. For the living current taxonomy, use the official H3/H4 hierarchy and describe repository/HF `Other/Sports` as a separate implementation or release surface.
