# ALE taxonomy audit plan

- Date: 2026-08-06
- Decision: identify the exact frozen arXiv v2 13-domain / 55-subdomain taxonomy and explain why Figure 2, the live site, repository categories, and Hugging Face rows can appear to show `Other` or fewer/more labels.
- Genre: canonical reference mapping plus version-drift audit.

## Falsifiable hypotheses

1. The v2 paper defines exactly 13 formal top-level domains and 55 subdomains.
2. `Other` is not necessarily a fourteenth occupational-taxonomy domain; it may be a visualization or repository grouping, with Sports represented through that surface.
3. Current Hugging Face `category` values are storage labels and cannot safely reconstruct the frozen paper taxonomy without reading structured `taxonomy.*` fields.
4. The live website and paper may use different snapshots or display conventions; any mismatch must be reported rather than silently normalized.

## Source strategy

- Canonical frozen source: arXiv:2606.05405v2, especially Figure 2 and Appendix B.1 taxonomy tables.
- Canonical living source: official ALE taxonomy page and project documentation.
- Released-data check: Hugging Face dataset card/rows API and structured taxonomy fields.
- Implementation check: official GitHub task cards or taxonomy data used by the live site.
- Independent evidence is not expected to define ALE's own taxonomy; first-party sources are authoritative for nomenclature but do not independently validate representativeness.

## Risks and opposition checks

- Count domain bands, domain IDs, repository categories, and taxonomy domain codes separately.
- Do not infer missing subdomains from the public task subset.
- Search explicitly for `Sports`, `Other`, blank IDs, duplicate IDs, and category/domain mismatches.
- Pin source version/date and preserve original English names before translating.

## Stop criteria

- A 55-row frozen-v2 label/count extraction; do not require IDs that Figure 2 does not publish.
- A separate current-live 13-domain / 55-subdomain / 100-leaf display-name extraction.
- A reconciled explanation of every observed `Other`/Sports/14-category discrepancy.
- Direct source links and saved evidence for each mapping surface.
