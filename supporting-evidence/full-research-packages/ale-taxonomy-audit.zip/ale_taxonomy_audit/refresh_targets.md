# Refresh targets

- Recheck the mutable live taxonomy page before quoting the current 13×55×100 hierarchy.
- Recheck the Hugging Face repository SHA, public row count, and structured taxonomy mappings before citing public-release statistics.
- Keep arXiv:2606.05405v2 frozen when comparing against Figure 2; do not silently substitute a later paper version.
- If the ALE team publishes a central machine-readable taxonomy manifest, replace the current cross-surface reconstruction with that manifest and preserve its revision.
