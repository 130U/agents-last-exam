param(
    [string]$ProjectRoot = $PSScriptRoot
)

$sourceRoot = Join-Path $ProjectRoot 'sources'
$outputPath = Join-Path $ProjectRoot 'sources.csv'

function First-Match {
    param([string[]]$Lines, [string[]]$Patterns)
    foreach ($pattern in $Patterns) {
        foreach ($line in $Lines) {
            if ($line -match $pattern) {
                return $Matches[1].Trim().Trim('*').Trim('`')
            }
        }
    }
    return ''
}

$records = Get-ChildItem -LiteralPath $sourceRoot -File -Filter '*.md' |
    Where-Object { $_.Name -ne '.gitkeep' } |
    Sort-Object Name |
    ForEach-Object {
        $lines = Get-Content -LiteralPath $_.FullName -Encoding utf8
        $title = (($lines | Where-Object { $_ -match '^#\s+' } | Select-Object -First 1) -replace '^#\s+', '').Trim()
        $authors = First-Match $lines @('^-\s*(?:\*\*)?(?:作者/机构|Authors?/Institution|Author/Institution|机构)(?:\*\*)?[：:]\s*(.+)$')
        $url = First-Match $lines @('^-\s*(?:\*\*)?(?:URL|网址|Project page|Homepage|Repo(?:sitory)?|GitHub|HF(?: dataset)?)(?:\*\*)?[：:]\s*(https?://\S+)')
        if (-not $url) {
            $url = First-Match $lines @('(https?://[^\s)＞>]+)')
        }
        $published = First-Match $lines @('^-\s*(?:\*\*)?(?:首次提交|发布(?:日期|/更新)?|页面最后更新|Publication date|Published)(?:\*\*)?[：:]\s*(.+)$')
        $accessed = First-Match $lines @('^-\s*(?:\*\*)?(?:访问日期|Accessed|Access date)(?:\*\*)?[：:]\s*(.+)$')
        $version = First-Match $lines @('^-\s*(?:\*\*)?(?:固定版本|固定 revision|本版修订|版本/revision|版本|Version/revision|Version|Revision|Repo revision|Dataset revision|Commit)(?:\*\*)?[：:]\s*(.+)$')
        if (-not $version) {
            $version = First-Match $lines @('^-\s*(?:数据说明|发布日期)[：:]\s*(.+ALE-V1.+)$')
        }
        $credibility = First-Match $lines @('Credibility[^0-9]*(\d(?:/5)?)')
        $recency = First-Match $lines @('Recency[^0-9]*(\d(?:/5)?)')
        $bias = First-Match $lines @('Bias[^0-9]*(\d(?:/5)?)')
        [PSCustomObject]@{
            source_id = [IO.Path]::GetFileNameWithoutExtension($_.Name)
            title = $title
            authors_institution = $authors
            url = $url
            published = $published
            accessed = $accessed
            version_revision = $version
            credibility = $credibility
            recency = $recency
            bias = $bias
            local_file = "sources/$($_.Name)"
        }
    }

$records | Export-Csv -LiteralPath $outputPath -NoTypeInformation -Encoding utf8
Write-Output "Wrote $($records.Count) source records to $outputPath"
