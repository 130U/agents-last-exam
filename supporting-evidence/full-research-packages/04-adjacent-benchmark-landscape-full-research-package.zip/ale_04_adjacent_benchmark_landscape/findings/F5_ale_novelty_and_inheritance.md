# F5 — ALE 的新增设计与继承问题

- 结论类型：**[事实] + [研究员推断]**

## ALE 真正新增的组合

1. 把跨 13 domain clusters / 55 subdomains 的专业 workflow、可执行 Windows/Linux 环境、task-specific `load/start/evaluate` 合同、隐藏 reference/evaluator 与 public/private/pending-QC 生命周期纳入同一 benchmark architecture。
2. 在同一资产框架中支持 artifact/state/executable evaluator 和 partial credit，而不是只做网页 final state、单元测试或人类偏好。
3. 明确区分 workflow 与 runnable instance，并将外部专家 submission、commissioned build、工程实现、reference/evaluator、committee QC 组织为生产漏斗。
4. 通过小 public set、较大 private pool、计划轮换与 live leaderboard 尝试兼顾开放开发和污染控制。

这些是**设计组合与规模/广度上的新增**，不等于每个部件均由 ALE 首创：WebArena/OSWorld 已有状态 evaluator，SWE-bench/Terminal-Bench 已有 executable task contract，RLI/GDPval 已有专业 deliverable 与专家评价，GAIA 有 private leaderboard，living benchmark 思路也早已存在。

## 继承或尚未解决

- 分数仍是 model × harness × tools × environment × budget × evaluator 的联合属性。
- 自动 evaluator 仍可能 false positive/negative、漏掉等价专业解或被 gaming；LLM judge 还有 nondeterminism/bias。
- long-horizon 与经济价值主要是作者/机构 construct claim；full private pool 的 provenance、matched human time/baseline 和 labor-market weighting 未公开独立验证。
- public/private/rotation 降低 exposure，但实际轮换 cadence、泄漏审计和长期有效性证据不足。
- 论文、官网、GitHub、HF、leaderboard 的数字和系统快照漂移；版本治理本身是产品要求。
- 任务生产/维护总成本、各 gate yield、rework、专家供给与环境 refresh 的公开资料不足，不能从 ALE 当前漏斗反推客户项目配额。

## 证据

ALE canonical sources 01–06、14；相邻实现 sources 20–79；方法/审计 sources 07–13。
