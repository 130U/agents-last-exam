# F3 — 观察到的高难度可能来自环境、工具、预算或 evaluator

- 假设映射：H3
- 判定：**strongly supported**
- 结论类型：**[事实] + [研究员推断]**

## 证据链

1. **官方/原始论文**：ALE 明确定义 agent 为 harness + foundation model，并承认基础设施、GUI/browser、timeout/resource 影响；Harness-Bench 在相同任务上观察显著 model–harness pairing 差异。见 sources 01、11。
2. **代码/运行环境**：OSWorld、Windows Agent Arena、Terminal-Bench 的 VM、parser、resource config、network/tool policy 是 protocol 的一部分；Terminal-Bench 独立报告把资源配置差异与 pod errors量化为结果混淆。见 sources 20–24、47–52、57–59。
3. **独立 evaluator 审计**：WebArena Verified、SWE-bench audits、Terminal verifier hardening 与 NIST cheating taxonomy 分别发现 false negatives、测试错配、grader exploitation、solution contamination 风险。见 sources 09、27、44–45、53。

## 反方证据

- 环境和 evaluator 是任务定义的一部分；完全剔除它们可能把“能在真实不完美环境中交付”的能力也剔除。
- 若所有 configurations 在完全相同、健康且审计过的 protocol 下比较，分数仍可作为该完整系统的可复现结果。

## 失效条件

若 factorial pilot 固定环境并跨 harness、budget、parser 与 evaluator revision 复现相同排序，且失败 taxonomy 显示环境/判分贡献可忽略，则“难度主要由混淆造成”的版本应被反驳。

## 对项目的含义

正式声明对象必须是完整 configuration；记录 immutable manifest，设置 environment health checks、oracle run、failure codes 和 evaluator FP/FN audit，并报告 capability failure 与 infrastructure failure。
