# F2 — GUI 操作串联不自动构成真实 long-horizon workflow

- 假设映射：H2
- 判定：**supported**
- 结论类型：**[研究员推断]**

## 证据链

1. **官方/原始论文**：ALE 把 workflow 定义为端到端专业过程，并排除少量局部 UI 操作；METR 要求 coherent task 不可平凡拆为并行独立子题。见 sources 01、12。
2. **代码/数据/基准设计**：WorkArena++ 用依赖图组合 L2/L3 workflow，CRAB 用 evaluator DAG 表达跨环境前置依赖；OfficeBench 的 1–3 apps、最多 50 actions 仅证明动作链长度。见 sources 29–31、54–56、76–77。
3. **独立/人类证据**：Windows Agent Arena 报告 human steps 与 success/perceived difficulty 关系很弱，反驳把 click/step count 当 horizon proxy。见 sources 57–59。

## 反方证据

- 短操作如果共享持久状态、包含信息传递和错误恢复，也可以形成真实 workflow；“由短步骤构成”本身不是缺陷。
- 一些专业任务确实短而高价值，long-horizon 不应成为普遍准入门槛。

## 失效条件

若某 benchmark 对串联任务提供真实工作样本、matched human time、跨阶段依赖与不可平凡分解证据，则不能因其由 GUI 微操作构成而否认其 long-horizon validity。

## 对项目的含义

验收 workflow 时审查 goal coherence、跨阶段依赖、持久状态、专业判断、错误恢复与最终 deliverable；不以 turns、clicks、apps 或 token 数单独定级。
