# F1 — 高真实性、广覆盖与完全自动验证存在结构性张力

- 假设映射：H1
- 判定：**supported（结构性压力；不是不可能性定理）**
- 结论类型：**[研究员推断]**

## 证据链

1. **官方/原始论文**：ALE 同时把 representativeness、complexity、verifiability 设为准入原则，却仍需专家提供专业 reference 与 evaluator 规格；RLI、GDPval 越接近真实职业 deliverable，越把核心判分交给人工/职业专家。见 sources 01、60、66。
2. **代码/数据/运行面**：SWE-bench、SpreadsheetBench 2、OfficeBench 通过测试、表格状态或 API 状态实现高自动化，但 construct 分别缩到 issue resolution、spreadsheet transformation、synthetic office API routing。见 sources 42、72–77。
3. **独立方法/审计**：NIST AI 800-2 IPD 要求把 construct fit、baseline matching、环境故障与 grader validity 分开；PatchDiff、Terminal verifier 审计显示 executable grader 仍可能过/欠约束或被利用。见 sources 08、45、53。

## 反方证据

- ALE、CRAB 等用 task-specific state/artifact evaluators与 partial credit，说明真实性和自动化可以同时提高，并非二选一。
- 窄域内若输出结构稳定、专业质量可完全形式化，三者可能局部兼得。

## 失效条件

若 pilot 能在广领域真实工作样本上证明：自动 evaluator 对专家 gold 的 FP/FN、等价解覆盖、跨软件版本稳健性均达到预设阈值，且无需显著人工 adjudication，则本结论应降级或反驳。

## 对项目的含义

不要追求单一 universal grader。按 artifact/evaluator archetype 分层，保留人工 gold、盲审和争议裁决预算，并把“自动运行”与“无需人工维护”分开。
