# F4 — 静态公开 benchmark 缺少 holdout/轮换时长期有效性面临衰减

- 假设映射：H4
- 判定：**supported for mechanism；“快速”速度 underdetermined**
- 结论类型：**[研究员推断]**

## 证据链

1. **官方/原始论文**：ALE 用 private pool 与滚动轮换，RLI 用 10 public/230 private；Terminal-Bench 作者预期 saturation 并规划新 challenge sets。见 sources 01、47、60。
2. **代码/数据快照**：SWE-bench Original/Verified、SpreadsheetBench 2、OfficeBench 当前任务/evaluator高度公开；其静态 revision 可被开发与训练反复吸收。见 sources 41–42、72–77。
3. **独立研究/审计**：AI Agents That Matter、SWE-rebench、BenchJack/NIST hacking 共同支持 contamination、benchmark-specific shortcut 与 protocol exploitation 的机制。见 sources 07、09、28、46。

## 反方证据

- 公开可复现性有巨大价值；静态集仍可用于回归、诊断与低成本开发。
- 没有跨 benchmark 的统一纵向因果研究量化有效性下降速度；某些任务因解空间广、难以背诵而衰减较慢。

## 失效条件

若长期独立审计显示公开静态集的 task-specific exposure 不提高分数、跨新鲜任务/新环境泛化不变、无 grader gaming，H4 应被反驳。

## 对项目的含义

把 public dev、private test、pending-QC、retired-contaminated 分开；按 workflow family/source/evaluator exposure切分，保存 exposure ledger，并通过 fresh challenge/版本轮换而非只换 leaderboard 名称维护有效性。轮换比例与周期必须由 pilot 和 threat model 决定。
