# Desktop / Web / General Assistant benchmark working matrix

研究日：**2026-08-08**。本文件仅提供给总报告合并的矩阵行，不是最终报告。所有成绩数字只保留其原始 snapshot；BrowserGym 作为 harness，不计入 benchmark 数量。

证据标签：**[事实]**＝论文/代码/数据明确陈述；**[作者主张]**＝benchmark 作者尚未独立验证的真实性/代表性主张；**[研究员推断]**＝基于证据的推论；**[公开资料不足]**＝不得填精确值。

## 1. Version / unit ledger

| Benchmark family | Version surface (不得合并) | 数量及严格单位 | 直接证据 |
|---|---|---|---|
| OSWorld | paper `2404.07972v2` | **369 runnable task instances**；134 unique evaluator functions；不是 369 workflows 或 runs | [20](../sources/20_osworld_arxiv_v2.md) |
| OSWorld | current repo + OSWorld-Verified | Verified 为原集合的清理/验证版本；当前 repo commit `091f…0108`；与 2024 paper snapshot 分列 | [21](../sources/21_osworld_repo_verified_snapshot.md) |
| OSWorld 2.0 | paper `2606.29537v2` | **108 end-to-end workflow instances**；每项均是一个可运行任务，不是 108 domains/trials | [22](../sources/22_osworld2_arxiv_v2.md) |
| OSWorld 2.0 | release `osworld-v2-2026.06.24` | 108 released tasks；code/task classes/assets/websites/provider image 为联合 release；main 不可替代 tag | [23](../sources/23_osworld2_repo_release.md) |
| WebArena | paper `2307.13854v4` | **241 intent templates → 812 runnable test instances**；平均每 template 3.3 instantiations | [25](../sources/25_webarena_arxiv_v4.md) |
| WebArena | repo current | repo commit `dce0…987b`；`v0.2.0` 是 bug-fix 面；不得回写成论文原始数据 | [26](../sources/26_webarena_repo_snapshot.md) |
| WebArena-Verified | OpenReview revision / implementation | 全量 audit 812；Hard 是 **258-instance subset**，不是 258 workflows；submission withdrawn | [27](../sources/27_webarena_verified_openreview.md) |
| WorkArena L1 | current repo | **33 atomic task definitions → 19,912 potential unique runnable instances**；instance count 不等于 workflow breadth | [30](../sources/30_workarena_repo_snapshot.md) |
| WorkArena++ | paper `2407.05291v2` | **341 workflows × 两种 presentation (L2/L3) = 682 tasks**；agent curriculum 采 470 runnable instances | [29](../sources/29_workarena_plus_arxiv_v2.md) |
| GAIA | paper `2311.12983v1` | **466 question instances**；questions 公开，论文称保留 300 answers | [32](../sources/32_gaia_arxiv_v1.md) |
| GAIA | current HF revision | card 写 more than 450；public dev/validation 与 private-answer test；不能与论文数强行对齐 | [33](../sources/33_gaia_hf_dataset_pinned.md) |
| GAIA | Princeton HAL reliability | **165 validation tasks**，每 task 多个 agent trials；165 不代表全 benchmark | [34](../sources/34_princeton_hal_gaia_reliability.md) |
| AssistantBench | paper `2407.15711v2` | **214 runnable answer tasks**；70 seed → crowdworker-expanded total 172，另 42 expert tasks；53 contributors/35 experts | [35](../sources/35_assistantbench_arxiv_v2.md) |
| AssistantBench | current HF revision | **33 public validation rows** + test file/split；validation answers/URLs/explanations可见 | [36](../sources/36_assistantbench_hf_pinned.md) |
| AssistantBench | Princeton HAL | **33 validation tasks**, 15 evaluation entries, 1 scaffold, each current entry 1 run；不是全 214 | [38](../sources/38_princeton_hal_assistantbench_snapshot.md) |

## 2. Unified comparison — construct, task, production, environment

| Benchmark | Evaluation construct | Task unit | Domain coverage | Real vs synthetic | Workflow length | Software / environment | Expert involvement | Task sourcing |
|---|---|---|---|---|---|---|---|---|
| **OSWorld v1 / Verified** | [事实] configured computer-use agent 在真实桌面/网页 app 中从指定初态完成任务后的 functional state；部分 reward | [事实] runnable desktop task instance；paper 未公开稳定 workflow-template ledger | [事实] web/desktop apps、OS file I/O、multi-app；应用驱动而非职业抽样 | [事实] Ubuntu VM 中真实 apps；任务初态/目标人工构造；live web 可参与 | [事实] launch harness 最多 15 steps；paper 人类时长不是统一长流程定义 | Ubuntu VM 为主；Windows 子集；账号、cloud/proxy/Google services；环境 reset | 9 位 CS-background authors 标注；Verified 又作人工检查；职业专家结构公开资料不足 | 作者探索 apps 后构造任务；Verified 吸收社区 bug feedback。**[作者主张]**代表开放式真实计算机任务 | 
| **OSWorld 2.0** | [事实] 端到端 professional desktop workflow；过程按多个 checkpoints 评分；functional checks 优先，少量 model-based | [事实] workflow = runnable task；108 | 7 professional domains、21 subcategories；Research/Education+Creative >40%，非平衡劳动力样本 | real/adapted artifacts + stateful self-hosted services；synthetic proposals 只作 ideation | 熟练人类 active median ~1.6h；69.6% >1h；agent rollout平均318 calls；均为作者 snapshot | 31 self-hosted services、Linux desktop、mock sites、GitLab、Docker/AWS；release 联合 pin | professional interviews + trained internal annotators；最终 90% tasks 来自内部受训标注者；专家人数公开资料不足 | interviews、tutorials/docs/forums、标注者工作经验；synthetic proposals 因浅拼接/不真 artifacts/reward hacking 被限制 |
| **WebArena** | self-hosted网站中 browser agent 完成 intent 后的 information/state functional correctness | runnable instance，由 intent template 参数化；241→812 | 四类站点：shopping、forum、GitLab、CMS；附 map/knowledge tools | 网站类型来自作者真实 browsing history、内容 real-derived；执行是 self-hosted replicas | 作者称 long-horizon；launch最多30 state transitions；没有职业 active-time基线 | Docker/self-hosted replicas、Playwright/Chromium；reset与账号/URL | authors/annotators 构造；answers double-check + third adjudication；5 CS grad human subset | ~200 browsing-history segments选站；annotators探索并写 templates；ChatGPT 可作灵感 |
| **WorkArena++** | ServiceNow enterprise web agent 对组合任务的 binary success；规划/推理/检索/记忆/上下文 | 341 workflows，各有 L2 explicit 与 L3 ticket presentation = 682 tasks；按 seed 生成 instance | 单平台 enterprise knowledge work；KB/forms/catalog/lists/menus/dashboards | fictitious brands/data，运行在真实 ServiceNow product；workflow由 atomic tasks程序化组合 | oracle action count；agent cap 50；L3改变目标隐含度，不改变底层 workflow | remote ServiceNow Personal Developer Instance + BrowserGym/Playwright | benchmark authors；human study 15人，其中11名 ServiceNow employees；非广泛职业专家样本 | 从33 atomic task definitions作逻辑组合，使用约10个 fictitious brand themes 与配置采样 |
| **GAIA** | tool-augmented general assistant 对 multi-step question 给 single final answer；不评过程/side effects | question + optional attachment + one closed-form answer | broad open-world reasoning、web、coding、multimodal；无职业/经济配额 | human-authored questions，依赖真实 web/docs或附件；答案设计为单一 | L1约≤5/one tool；L2约5–10/multiple；L3任意更长；是steps heuristic，不是 workflow duration | 无统一交互环境；submitter自选 search/browser/code/plugins，harness差异大 | creator + 两名独立 annotators；human validation约92%；专业专家非必要 | 人工设计 unambiguous questions；623 candidates validation，68%原样通过，其余修/删 |
| **AssistantBench** | open-web assistant 对耗时 information-seeking request 输出结构化/closed-form answer | 214 question tasks；不是 GUI state-changing workflow | 15+ domains、525 pages、258 sites；人类需求驱动但无劳动力权重 | real human needs + live public web；筛选相对不易近期变化的答案 | 人类应需数分钟 browsing；无跨阶段 deliverable/state依赖证明 | live web；作者 SPA 与后来 BrowserGym/HAL harness surfaces 分离 | 53 contributors、其中35 experts；每题两位作者复核；非每题两专家 | 70 seed from 18 users → crowdworker expansion至172；42 expert tasks |

## 3. Unified comparison — evaluator, split, reliability, cost, validity

| Benchmark | Evaluator type / human dependency | Public / private split | Contamination policy | Repeated-run policy | Human baseline | Cost evidence | Known validity problems | Saturation / benchmark-specific optimization |
|---|---|---|---|---|---|---|---|---|
| **OSWorld v1 / Verified** | 134 task-specific functions；file/app/system state；部分分；manual examination 用于 Verified；未测安全副作用 | v1 tasks/evaluators公开；Verified仍公开；无正式 hidden holdout | 无强私有隔离；公开 gold/task metadata曾被 exploit；Verified是否逐漏洞修复须按 revision复测 | 统一 repeated trials 公开资料不足 | paper 72.36%，仅原 snapshot、特定人类 protocol | repo称AWS并行全跑<1h为机构主张；真实 cloud/API/人工成本不足 | service config、live web、evaluator false pos/neg、agent-readable gold、shared-state tampering；效率/latency被 success隐藏 | 高风险：static public 369 + public evaluator；社区 Verified 修订证明原集会成熟/漂移 |
| **OSWorld 2.0** | 平均27.25 checkpoints/task；functional优先；model-based仅总score 11.53%、per task≤50%；unit tests+双人复跑+frontier/adversarial audits | task classes/完整assets gated；release组件versioned；并非未暴露统计 holdout | gated logic防在线找答案；release manifest pin；长期rotation cadence未知 | paper正式aggregation公开资料不足；frontier rollouts用于QA不等于benchmark repeated trials | skilled-human active time用于长度；完整matched success baseline公开资料不足 | interviews昂贵/问卷低留存是定性证据；精确人数/美元/任务成本不足 | 31 services/provider/image/500-step budget；LLM grader仍有11.53%暴露面；domain mix偏斜；独立复现不足 | gating + release优于v1；但108小集合且长期轮换尚未证明；task-family tuning仍可能 |
| **WebArena / Verified** | original：exact/must-include/GPT-4 fuzzy + DB/API/JS state；Verified：type-aware normalization、backend/network-trace、deterministic status | 812全公开；无 hidden split；Hard为公开258 subset | original config含references；RDI演示file:// lookup/DOM/LLM prompt injection；Verified为修订而非private holdout | 原 benchmark无统一trials；某 baseline 10 retries不可推广；Verified建议CI但不是跨run reliability | 5 CS grads做170-template subset，78.24%；与agent条件不完全同等 | Docker reset数秒至约1分钟；完整hosting/API/annotation美元不足；Hard声称runtime -68.2%仅作者结果 | Verified withdrawn论文报告false-negative下降11.3pp；goal ambiguity、substring、LLM judge、state reset、site drift | 高风险：公开241 templates/812 instances、agent/harness专项优化；per-template macro比micro更合适 |
| **WorkArena++** | 每task human-coded Playwright oracle + binary validator；DB/page checks；自动 ground-truth trajectories | generators/oracles公开；seeds 0–9 reserved evaluation但非hidden workflows；论文称hidden test为未来 | parameterization降低逐实例记忆；底层33 atomic/341 workflows公开；无正式private workflow holdout | paper建议 multiple seeds；evaluation seeds 0–9；需明确每task seed/trials | 15人/98-task subset 93.9%；11名员工、平台熟悉偏差、human无同50-action cap | 无补偿human volunteers；ServiceNow/API/人工/维护成本精确值不足 | composition realism未独立职业验证；single-platform；human sample偏；generator/oracle leakage；release/config drift | 高：数千 configs 不等于新的 construct；agent可对33 atomic families/341 workflows专项训练 |
| **GAIA** | normalized exact/string/number/comma-list matcher；human只在制作/歧义修订；不验trace/citations | paper questions公开、300 answers retained；HF validation answers public、test answers/metadata private | gating阻bot scraping；validation可lookup；RDI展示normalizer/answer exploit；作者预警contamination/link rot | paper部分API baseline 3 runs平均；非所有submission统一；HAL显示同task多trial高variance | validation annotators约92%；与开放submitter harness不匹配 | 约2 annotator-hours/question是paper观察；HAL API run costs为特定系统；生产美元不足 | ambiguity、website/API failure、tool quota、normalizer false pos/neg、answer lookup、unreproducible plugin stack；correct answer可来自错误过程 | validation接近饱和/污染风险高；private answers减缓但questions固定；需annual add/remove和fresh set |
| **AssistantBench** | type-specific F1/precision/EM/partial numeric；每题两作者核验；不验evidence chain | 33 validation answers公开；test submission evaluator私有面；HF/BrowserGym/HAL surfaces需分版 | validation无抗lookup；test答案相对隐藏；没有明确rolling rotation | original统一政策不足；HAL当前每entry仅1 run，不能估variance | matched overall human success公开资料不足；只规定任务需人类数分钟 | HAL给33-task特定API cost且不含cache；不能用于制作成本；annotation美元不足 | live URLs/answer aging；closed-form scorer可放过来源/过程错误；official repo复现面不完整；harness差异 | public 33易优化且已被HAL重复使用；214 test仍固定；网页/答案漂移会造成假失败 |

## 4. BrowserGym 的位置（不可作为 corpus benchmark 行）

- **[事实]** BrowserGym 是跨 MiniWoB/WebArena/WebArenaVerified/VisualWebArena/WorkArena/AssistantBench 等的统一 Gym/Playwright framework；证据 [31](../sources/31_browsergym_repo_snapshot.md)。
- **[研究员推断]** 它降低 integration/trace collection 成本，但不会统一 task sourcing、ground truth、网站托管、private split 或 human baseline。
- 任一 BrowserGym run 至少固定：framework commit/package versions、benchmark package revision、browser/viewport、observation channels、action schema、prompt/tools、step/time/token budget、retry、reset、error policy、model/API revision。

## 5. Cross-source adversarial findings for synthesis

1. **Evaluator security is construct validity，不是附加安全项。** Berkeley RDI 演示 WebArena reference lookup/DOM/LLM-judge attacks、GAIA public-answer/normalizer attack、OSWorld gold/state attack；这不证明 leaderboard entrants 作弊，但证明高分在弱隔离下不唯一对应目标能力。[28](../sources/28_rdi_benchjack_webarena_gaia_osworld.md)
2. **同一 task 的多次 agent trials 可产生不同解释、工具路径、答案和成本。** Princeton HAL 在 GAIA 165-task面展示 ambiguity、tool failure与perturbation导致run variance；pass@1不能代替reliability。[34](../sources/34_princeton_hal_gaia_reliability.md)
3. **Model 与 configured system 不是同一 measurement object。** HAL variance decomposition 在 AssistantBench/GAIA 数据上显示 model–scaffold ranking 与 model-only ranking reliability 可相反；仅增加同质 items 不必然提升 model ranking reliability。[39](../sources/39_agent_leaderboard_variance.md)
4. **效率与success必须并列。** OSWorld-Human 给每个原 task 人工轨迹，并发现模型调用/规划反思与冗余steps主导latency；success相同的agents部署价值可不同。[24](../sources/24_osworld_human_efficiency.md)
5. **Verified release 不是自动等同 private holdout。** OSWorld-Verified/WebArena-Verified主要清理/修正 task/evaluator；它们提高当前内部效度，但仍公开，长期污染/专项优化问题未消失。[21](../sources/21_osworld_repo_verified_snapshot.md) [27](../sources/27_webarena_verified_openreview.md)

## 6. 对 H1–H4 的本组证据状态（供总报告裁决）

- **H1：supported（本组）**。OSWorld 2.0 的真实性需要服务托管、双人复跑、密集checkpoint与mixed evaluator；GAIA/AssistantBench的广覆盖自动评分则通过缩窄为closed-form答案实现。没有来源证明真实性、广覆盖、完全自动且可靠可同时低成本达成。
- **H2：supported with nuance（本组）**。OSWorld 2.0 明确拒绝 repetition/concatenation；WorkArena++的逻辑组合比机械串联更强，却主要复用33 atomic families、单平台且L2/L3共享workflow，真实性仍需职业对照。
- **H3：strongly supported（本组）**。环境配置、action budget、harness、tool/API availability、evaluator false negatives/attacks和scaffold interactions都有直接反例。
- **H4：supported as risk, exact decay rate underdetermined（本组）**。GAIA作者主动预警decay，三套公开静态集出现lookup/专项优化面；gating/private answers/Verified修订可减缓，但没有长期独立研究量化“快速下降”的速度。

## 7. 明确的公开资料缺口（不得填精确值）

- 五个 benchmark 家族均没有可直接迁移到 ALE-style 1,000-task 项目的完整：专家人数模型、每角色工时分布、工资/合同价、acceptance rate、端到端 QA pass rate、维护年成本。
- OSWorld 2.0 未公开可用于配额的各 domain production yield；其 108-task领域分布也不是劳动力抽样框。
- WebArena/WorkArena++ 的 template/config 数不能作为“需要多少独立 workflow”的生产比例。
- GAIA/AssistantBench 的 per-question effort/cost不能外推专业桌面 workflow；需要 pilot 测量 creation、environment build、evaluator coding、double solve、adversarial audit、maintenance 各自工时。
- 所有 leaderboard 数均需在提交前 refresh；本组不建议在最终决策报告中用当前排名作 task portfolio依据。
