# Labor-value / professional-file benchmark 统一矩阵

研究截点：**2026-08-08**。本文件的数字均绑定下面的 source surface/version；“公开资料不足”不是 0 或“没有”，而是未找到可核验证据。

## 1. Canonical identity 与版本矩阵

| Benchmark surface | Canonical identity / revision | 本矩阵采用面 | 不得合并的数字或歧义 |
|---|---|---|---|
| Remote Labor Index (RLI) | arXiv `2510.26787v1`；repo `c101682…`；HF `9082f65…`；live site/leaderboard 2026-08-08 | 论文 240-instance snapshot + 明示 10 public/230 private；当前 repo/HF 仅说明公开面 | 240 benchmark instances ≠ 10 public instances ≠ 230 private instances ≠ evaluator ratings ≠ agent runs |
| GDPval | arXiv `2510.04374v1`；HF `11e7900…`；live OpenAI blog/grading 2026-08-08 | 论文 1,320-instance snapshot；HF 当前 220 gold public instances | HF commit label “GDPval v2”是 dataset release（rubrics+deliverables），不是 arXiv paper v2；1,320 full ≠ 220 public gold ≠ 3 agent samples ≠ 3 human ratings/sample |
| SpreadsheetBench family | V1 arXiv `2406.14991`；本矩阵主项 V2 arXiv `2606.29955v1`；repo `599b24a…`；HF `9dea600…` | **SpreadsheetBench 2**，321 runnable instances | V1 912 questions、后续 400 verified subset、V2 321 instances 不能求和；V2 论文“三类”与表中四 operational groups 是层级差，不是两个计数版本 |
| OfficeBench | arXiv `2407.19056v1`；repo `b978b80…` | 2024 language-agent benchmark | 不得与 2007 年同名 Windows/Office PC performance benchmark 混同；300 tasks ≠ 300 workflows ≠ 300 repeated trials |
| MBABench（替换/补充候选） | arXiv `2605.22664v4` | 仅作 professional spreadsheet validity 对照 | 早期检索/页面的 `WorkstreamBench` 与当前 canonical title MBABench 不作为两个 benchmark 计数 |

## 2. Construct、任务单位、覆盖和真实性

| 统一字段 | RLI | GDPval | SpreadsheetBench 2 | OfficeBench |
|---|---|---|---|---|
| evaluation construct | [作者主张] agent system 能否完成可付费 remote project、产出可被合理客户接受的 deliverable；另比较 human deliverable | [作者主张] 模型在经济相关专业 deliverable 上相对职业专家的质量 | agent 在受控 spreadsheet runtime 中完成 end-to-end business workbook transformation | language agent 能否通过工具 API 完成单/多应用 office-automation instruction |
| task unit | 1 个 `runnable task instance/project` = brief + inputs + human deliverable；不是整个 occupation/job | 1 个 `runnable task instance` = self-contained prompt + reference files → deliverable；不是真实 ongoing workflow | 1 个 `runnable task instance` = instruction + in-progress workbook → output workbook | 1 个 `runnable task instance` = synthetic instruction/state → state/file output；一次 execution 才是 `agent run` |
| domain coverage | 23 Upwork categories；仅 remote/self-contained/evaluable work | 9 sectors、44 occupations、30 tasks/occupation（paper full snapshot） | finance/business spreadsheets：modeling、template、debugging、visualization | 9 Python-tool applications、1–3 app composition；不是职业 domain taxonomy |
| real vs synthetic | 较高真实性：真实 marketplace/commissioned/permitted projects；仍经筛选为无客户交互、可独立评价 | 专业人士基于职业工作创建，但 prompt 被清洗为一次性 fully specified task；非原始工作日志 | 真实公开 financial files + expert-constructed removals/errors/specs；mixed real-source/synthetic-transformation | 高度 synthetic：ChatGPT/random generators 生成 tasks/documents/email/calendar，以规避隐私 |
| workflow length | 人类工时均值 28.9h/中位 11.5h是历史项目耗时；agent 通常单 session、默认约 1h。耗时不等于 benchmark 内跨阶段 workflow | 人类 gold 均值约 404min，存在极长 outlier；仍是 one-shot deliverable，不含澄清/协作/组织状态 | 最多 50 agent turns；平均 11.8 sheets、593.5 modified cells。动作长但缺少真实跨日/跨人阶段 | 最多 50 actions、1–3 apps，5 次重复动作停机；是 action-chain proxy，不是已验证的 real long-horizon workflow |
| occupational/economic weighting 是否真实 | [事实] 历史 project price/time 可形成 task-level economic proxies；[作者主张] Upwork category 分布具有代表性。自报/缺失和过滤限制外推 | [事实] sector/occupation selection 使用 GDP、wage/compensation 与数字化阈值；[研究员推断] headline task average 并未公开证明为 task-level GDP-weighted production quota | 无 occupation/economic weighting；finance source 真实性不等于经济代表性 | 无 occupation/economic weighting；app-count 分层不等于 labor value |

## 3. 生产、环境、evaluator 与运行政策

| 统一字段 | RLI | GDPval | SpreadsheetBench 2 | OfficeBench |
|---|---|---|---|---|
| software/environment | benchmark 不强制单一 authoring app；实验有 integrated agents、CUA、OpenHands/CLI 和专业 media tools | 输出多种 professional file formats；任务 fully specified，一般不要求 live proprietary systems | Docker/Python 3.11、openpyxl/LibreOffice UNO、SWE-agent tools、no network、50 turns | Docker + Python APIs：System/Word/Excel/PDF/Calendar/Email/OCR/ChatGPT/Shell；非真实 Office GUI |
| expert involvement | 358 freelancers 贡献初始/保留项目；人工 evaluator；项目过滤与 artifact review | 至少 4 年经验、均值 14 年；每 occupation ≥5 experts；每 task ≥3 reviews、均值 5 | >1,500 expert-hours 不含 QA；每 task 两名非创建者专家独立求解/纠正 | 任务/数据主要生成；human baseline 仅 2 名 CS 研究生；职业专家生产证据公开资料不足 |
| task sourcing | 207 marketplace + 7 commissioned long-tail + 33 permitted online，初始 550 筛至 240 | 职业专家创建，经 screening/training/review；每 occupation 固定 30 | public financial reports/corporate filings，经专家构造 transformation | ChatGPT + random generators synthetic generation |
| evaluator type | blinded human reasonable-client acceptance；多数票 automation rate；pairwise Elo；人工 audit | 标准是 occupation-expert blind pairwise preference；GPT-5-high automated judge 仅近似 | exact/programmatic workbook comparison；visualization 用 rubric + GLM-4.6V | per-task exact/fuzzy/execution-based checks，pass rate |
| human evaluation dependency | 高：核心 leaderboard validity 依赖人类；自动化判断三人/多数票，Elo 2–3 ratings | 高：gold 标准为职业专家，单次 comparison 均值 >1h；auto judge 有 12/220 ungradable | 中：生产/QA 高；运行时多数程序化，visualization 依赖 VLM，关键误差仍需专家审计 | 运行时低；主要自动 evaluator。人工只用于作者基线/开发，未见持续专家 adjudication |
| public/private split | 10 public / 230 private（paper v1）；private 用于定量评价 | 220 public gold / 1,320 full paper set；其余未公开，但官方未把它完整定义为 rotating private leaderboard holdout | 321 当前全公开；未见 private/pending-QC split | 300 当前全公开；未见 private/pending-QC split |
| contamination policy | private set；作者称 brief 无法搜索、long-tail domain blocklist；未见轮换 cadence | 未见 rotation/contamination audit；公开 gold 的 prompts/rubrics/deliverables 可被吸收 | 未见 hidden holdout/rotation；公开 source docs/tasks/evaluator | 未见 hidden holdout/rotation；公开 tasks/evaluator |
| repeated-run policy | agent generation repeated trials：公开资料不足；2–3 是 human ratings，不是 agent trials | 论文 gold 实验为每 model/prompt 3 samples × 每 sample 3 graders；未来/服务 policy 公开资料不足 | 论文因 API 成本未给 error bars/CI；明确 repeated trials 数公开资料不足 | 公开资料不足；榜单/论文未给稳定性分布 |

## 4. Human baseline、成本与效度风险

| 统一字段 | RLI | GDPval | SpreadsheetBench 2 | OfficeBench |
|---|---|---|---|---|
| human baseline | **部分匹配**：每任务有真实 freelancer deliverable，Elo human 固定 1000；但人类不是在同一 agent runtime/预算下重跑 | **最接近职业匹配**：task creator 的 expert deliverable；但 creator/reference advantage、任务清洗和非同条件执行需注意 | **不匹配/未报告**：专家 gold/QA 不是 timed human baseline；30-task human operation 是代操作产品，不是职业能力 | **不匹配**：2 名 CS 研究生、93.33%；非 occupation-matched、N 太小 |
| cost evidence | 原项目 >6,000h、>$140k；均值/中位成本有缺失/自报；agent API avg $2.34、<30 美元但不含全栈人工评测 | creator 时间均值 404min；BLS wage 推算 human value/成本均值 $361，review 均值 109min/推算 $86；总建设成本公开资料不足 | >1,500 expert-hours（不含 QA）；API inference 被称昂贵到未跑 CI；货币成本公开资料不足 | 人数/工期/monetary cost 公开资料不足 |
| known validity problems | 只测可远程、独立、可渲染、无 live client 的项目；cost/time 非统一实验；harness/tool access 强影响；人工 acceptance 主观 | 44 occupations/数字知识工作；一次性完整上下文过于干净；judge agreement/自偏好；public gold 泄漏；win rate≠job automation | finance-only；exact match 低估语义等价、又可能放过专业质量问题；VLM judge noise；no CI；所有任务公开 | synthetic、API 而非 GUI；fuzzy checks 可能漏细节；action vocabulary/50-step/stagnation 限制；多 app≠真实 workflow；human baseline 不匹配 |
| saturation / benchmark-specific optimization | private set 降低当前 saturation；无轮换披露，scaffold/tool tuning 仍可能过拟合 | public 220 风险高；full set 未公开不等于已验证 holdout policy；基线更新不能解决 prompt contamination | 高风险：data/evaluator 全公开；暂无 longitudinal saturation audit | 高风险：static 300 全公开；暂无 longitudinal audit |

## 5. 跨项判断：事实、主张、推断、建议

### [事实]

1. 四项中，RLI/GDPval 用人类专业 deliverable 作核心参考，SpreadsheetBench 2/OfficeBench 更依赖程序化或模型 evaluator。
2. 只有 RLI 明确公开/私有 split；GDPval 有未公开 full set，但官方资料不足以把它定义为 rotating holdout。SpreadsheetBench 2 与 OfficeBench 当前任务面公开。
3. RLI 的 cost/time、GDPval 的 GDP/wage sourcing 是两种不同经济连接：前者较 task-level，后者较 sampling-frame-level。
4. OfficeBench 的应用是 Python APIs，不是 GUI；其 300 项均为 synthetic task instances。

### [作者/机构主张]

1. RLI 作者主张其 marketplace 分布能代表 remote labor；GDPval 作者主张 44 occupations 的 deliverables 更接近经济价值。
2. SpreadsheetBench 2 把 321 项描述为 end-to-end business workflows；OfficeBench 把多 app action chains 与 long-horizon office automation 联系起来。

### [研究员推断]

1. H1 **supported in this subgroup**：更真实/更广的 RLI、GDPval 需要昂贵人工 evaluator；更自动的 spreadsheet/office tests 以缩窄 domain 或 synthetic/exact construct 为代价。
2. H2 **supported in this subgroup**：人类历史耗时、50 turns 或 1–3 apps 都不足以证明真实 long-horizon；还需跨阶段依赖、持久状态、澄清、错误恢复和可审计 deliverable。
3. H3 **supported in this subgroup**：CLI/CUA、tool APIs、turn budget、exact/fuzzy/VLM judge 都可改变得分。
4. H4 **provisionally supported, longitudinal evidence underdetermined**：private split 设计上更抗污染；但公开资料没有跨年因果研究能量化“快速下降”速度。

## 6. 对 1,000-task 生产的可执行影响

1. [项目建议] 先定义 sampling frame，再定 task 配额：`occupation/domain weight → workflow family → runnable instance`；不得从 RLI/GDPval 当前快照直接抄比例。
2. [项目建议] 每个 task manifest 同时记录 `source_realism`（真实/改写/合成）、`economic_weight_basis`（GDP/wage/project price/none）和证据时间戳。
3. [项目建议] 真实 deliverable 类实行 creator + independent solver + evaluator 三角色隔离；pilot 测量创建、修订、grader、adjudication 工时分布。
4. [项目建议] evaluator 采用多通道：deterministic checks + rubric judge + 专家抽审；按 domain/artifact type 报告 agreement、false positive/negative。
5. [项目建议] 专业文件至少分别评估 correctness、formula/provenance、editability、format/readability、requirement coverage，避免单一 cell exact match。
6. [项目建议] `agent run` 日志固定 model、prompt/scaffold、tool schema、container digest、budget、retry/recovery 和 evaluator revision；至少 pilot repeated trials 再决定正式次数。
7. [项目建议] 建立 public dev / private test / pending-QC / retired-contamination 四态；公开比例和轮换周期由 pilot 与泄漏风险决定，公开资料不足以给精确比例。
8. [项目建议] human baseline 必须职业匹配，并尽量同 brief、input、时间/工具条件；gold creator deliverable 和研究生代操作均不能替代 matched baseline。
9. [项目建议] 成本模型分账：`C_total = C_source + C_creator + C_independent_solver + C_QA + C_eval_runs + C_adjudication + C_infra + C_rotation`；每项用 pilot 的分位数而非公开均值硬套。
10. [项目建议] 对 headline score 同时报 task-macro、occupation/domain-weighted、economic-weighted（若权重有依据）与 failure taxonomy；禁止用单一分数外推 job automation。

## 7. OfficeBench 去留/替换建议

- [项目建议] **身份歧义已解决，不必因同名删除。** 若矩阵需要 synthetic multi-application/tool-routing 对照，保留 OfficeBench，但标签必须是 `synthetic API office automation`，不要写成真实 Microsoft Office GUI 或真实职业 workflow。
- [项目建议] 若 12–16 项矩阵只有一个 professional-file slot，**用 MBABench 替换 OfficeBench，或在 SpreadsheetBench 2 后追加 MBABench、删除 OfficeBench**。理由是 MBABench 明确测 Accuracy/Formula/Format/editability，并用职业相关专家校验，和 1,000-task 的专业交付/QA 决策更相关。
- [项目建议] 若核心问题是跨 session long-term context，可考虑 OdysseyBench 替代 OfficeBench；但它继承/生成 synthetic dialogue history，不能解决真实职业数据问题。
- [公开资料不足] 尚无跨这些 benchmark 的统一独立实验，在同模型、同工具预算、同 evaluator reliability 下证明哪个 benchmark 更能预测生产劳动价值；替换是 construct fit 建议，不是已验证 superiority claim。

