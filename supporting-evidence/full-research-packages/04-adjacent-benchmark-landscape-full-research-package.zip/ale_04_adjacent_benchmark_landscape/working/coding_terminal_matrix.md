# Coding / terminal / cross-environment benchmark matrix

- 研究截止 / 访问日期：**2026-08-08**（America/New_York）
- 研究对象：SWE-bench family、Terminal-Bench family、CRAB、Windows Agent Arena（WAA）。
- 证据标记：**[事实]**＝版本化论文、代码、数据或可复核审计明确陈述；**[作者/机构主张]**＝创建者对真实性、难度等解释；**[研究员推断]**＝根据多项证据作出的有限外推；**[项目建议]**＝面向 1,000-task 生产的决策。
- 本文件只把 version/subset 作为同一 benchmark family 的“版本面”，不把 Original、Verified、Lite 等重复计为多个 benchmark。

## 1. 单位账本：禁止互换的对象

| 单位 | 本组中的精确定义 | 不能与什么混淆 |
|---|---|---|
| benchmark / family | 一套任务、环境、harness、evaluator 与 reporting protocol；如 SWE-bench family | 不能把 family 内的 subset/release 当成新的独立 benchmark 数量 |
| runnable task instance | 一个可执行目标及其固定初态、环境、预算和 evaluator；如一个 issue-resolution instance、一个 terminal task | 不是 workflow、expert submission、candidate patch 或一次 run |
| source issue / PR | SWE-bench 的真实 GitHub issue 及对应开发者 PR，是任务素材来源 | issue 不等于 agent 生成的 patch，也不等于对 patch 的一次 evaluation |
| candidate patch | agent 对一个 SWE-bench instance 产生的一份代码修改 | 不是 gold patch；也不是测试运行本身 |
| patch evaluation | 在指定镜像、commit、test patch 和判分规则下执行 candidate patch 得到的 verdict | 同一 patch 可因 harness、镜像、测试或 flaky behavior 产生不同 evaluation；不能当作新的 task |
| test / evaluator artifact | 判定目标状态的测试、judge function 或 state evaluator | “task/evaluator 文件公开”不等于测试在 agent trial 中可见；也不等于 private holdout |
| agent trial / task attempt | 一个配置固定的 agent 对一个 task 的一次尝试；Terminal-Bench 2.0 明确如此定义 | 不是完整 benchmark run；重复 5 次产生 5 trials，不产生 5 tasks |
| benchmark run | 某 agent-system 配置对一套 task inventory 的一轮评测 | 并行容器数、失败重试、重复 trial 必须另记 |
| human baseline run | 人类在明确界面、工具、时间限制下实际完成任务的观测 | 作者预估的人类用时不是 measured baseline |
| public/private split | task objective、环境、evaluator 或 reference solution 是否在发布/榜单时隐藏 | 不能把“运行时不给 agent 看 tests”写成“benchmark 有 private test split” |

## 2. 版本与快照矩阵

| Family | 固定版本面 | 该版本可安全使用的数字 | 边界与不可合并项 |
|---|---|---|---|
| SWE-bench | 原论文 arXiv `2310.06770v3`（2024-11-11）；官方 repo `cd37836ffec01d01a0d699a80a039d84ff2cebfe`（访问 2026-08-08） | Original = **2,294 runnable issue-resolution instances**、12 个 Python repos；Lite = **534 instances**；Verified = **500 instances** | Verified 是 Original test set 的人工审查 subset，不是 500 个新 workflow；OpenAI 的 93 人、1,699 annotations/sample、500 final subset 分别是参与者、审查样本、最终 instance，不能互换。Multimodal 的 private test policy 是另一版本面，不能回填到 Original/Verified。见 sources 40–44。 |
| SWE-bench validity snapshots | PatchDiff arXiv `2503.15223`；SWE-rebench arXiv `2505.20411`；OpenAI 2026-02-23 audit | OpenAI 对 **138 个因 o3 在 64 independent runs 中不一致失败而抽取的 selected cases** 审计，59.4% 有 material issue；PatchDiff 的 7.8%、29.6%、6.2 pp 均属于其 selected plausible-patch experiment；SWE-rebench 的 21k+ pool / 294 benchmark subset / 169 repos 属于另一 benchmark | 这些数不能解释成 Verified 全体缺陷率，也不能合并成 SWE-bench 新总数。见 sources 44–46。 |
| Terminal-Bench | v1 launch/Core-v0（2025-05-27，launch surface 80 tasks and growing）；Terminal-Bench 2.0 arXiv `2601.11868v1`（2026-01-17）及 repo `harbor-framework/terminal-bench-2@2fd12b88aafdd04a52c298e3940bcb189f9766d6` | 2.0 = **89 final runnable tasks**；93 contributors、229 expert submissions、3 reviewers、约 3 reviewer-hours/final task；32,155 = task trials；每 model-agent pair 至少 5 repetitions | 80/Core-v0 与 89/2.0 不是同一 inventory。TB 2.1、Challenges 或 live leaderboard 是后续 surface，不应把当前榜单与 2.0 论文数字拼接。见 sources 47–50。 |
| Terminal-Bench audits | official integrity update（2026-04-19）；DebugML preprint `2602.14374`；Anthropic infra report（2026-04-16）；verifier hardening arXiv `2606.08960` | official update 记录 trajectory/reward-hack audit；DebugML 记录特定 top submissions 的 answer leakage；infra report 记录其 GKE calibration 中最多 6% pod errors 与 6 pp resource-config gap；hardening study 的 323/1,968=16% 是五 benchmark pooled hackable rate | 不能把 pooled 16%、特定集群 6% 或特定 submission 的泄漏扩展为“TB 2.0 全集缺陷率”。见 sources 50–53。 |
| CRAB | arXiv `2407.01511v4`（2025-07-20）；project site Benchmark-v0；repo `c0790b0d55e3c870f1c603c851dd4ca8625ed07a` | v4 abstract / site = **120 tasks**；可提取正文的 composition = **35 single + 53 simple + 12 challenging = 100 tasks**；16 Android + 19 Ubuntu sub-task templates | **内部冲突未消解**。不能自行选 100 或 120 当“当前精确 inventory”；生产/复现实验必须以 release-tagged manifest/hash 枚举。HF paper page 的旧 100/35.26 与站点 120/38.01 也属不同快照。见 sources 54–56。 |
| Windows Agent Arena | arXiv `2409.08264v2`（2024-09-13）；repo `6d39ed88c545a0d40a7a02e39b928e278df7332b` | 论文正式 inventory = **154 runnable task instances**；摘要的 150+ 只是近似表述；measured human success = 74.5%，paper best Navi = 19.5% | repo 2024-11-10 新增 harder mode，属于 post-paper protocol，不应与论文 standard config 合并。约 50 parallel runs 是基础设施并行规模，不是 repeated trials。见 sources 57–59。 |

## 3. 统一比较矩阵

> “公开资料不足”表示在本组所查 primary + independent evidence 中没有发现足以支持该字段的公开记录，不等于该机制不存在。

### 3.1 SWE-bench（Original / Lite / Verified 作为版本面）

| 字段 | 结论与证据等级 |
|---|---|
| evaluation construct | **[事实]** 在给定 repository base state 上，agent 根据真实 issue 产生 candidate patch；harness 执行 instance-specific regression tests，判定 issue 是否被解决。测的是“在固定 repo/test contract 下的 autonomous issue resolution”，不是完整软件工程岗位。 |
| task unit | **[事实]** 一个 runnable instance = repo、base commit、problem statement/issue、test patch 与参考 gold patch 等元数据。Original 2,294；Lite 534；Verified 500。一次 patch evaluation 或一个 repeated run 不是 task。 |
| domain coverage | **[事实]** Original 覆盖 12 个流行 Python repositories。**[研究员推断]** 跨 repo 有多样性，但语言、开源项目类型和 issue 筛选机制限制职业代表性。 |
| real vs synthetic | **[事实]** issue/PR 来自真实 GitHub 历史；执行初态、测试选择和 benchmark packaging 是回放式构造。**[作者/机构主张]** 称其为 real-world software engineering problems。 |
| workflow length | **[事实]** 单 issue 修复，可含 repository navigation、debug、edit、test。公开资料没有证明覆盖需求澄清、评审协作、部署、维护等完整 lifecycle；统一步骤/用时分布公开资料不足。 |
| software/environment | **[事实]** repository-specific Docker image / environment，固定 base commit；candidate patch 经 harness 安装和运行 tests。 |
| expert involvement | **[事实]** Verified：OpenAI 报告 93 名有软件开发经验的 annotators 审查 1,699 个随机样本，筛出 500 个 instance；审查 underspecification、test scope 等。Original 的人工生产人时公开资料不足。 |
| task sourcing | **[事实]** mined from linked GitHub issues and merged pull requests；benchmark 将开发者 patch/test history重构为 instance。 |
| evaluator type | **[事实]** 可执行 unit/regression tests；典型 verdict 依据 FAIL_TO_PASS / PASS_TO_PASS 等测试状态。不是 LLM judge。 |
| human evaluation dependency | **[事实]** 正式 patch grading 可自动化；Verified 的资产选择严重依赖人工审查。**[研究员推断]** evaluator 自动运行不代表 evaluator validity 已自动保证。 |
| public/private split | **[事实]** Original/Lite/Verified 的 issue、repo history、任务与 reference fixes 可由公开 GitHub 历史重建；未发现其有长期 private task holdout。Multimodal 的 private split 是另一版本，不能移植。 |
| contamination policy | **[事实]** Original/Verified 静态、公开历史导致污染风险；2026 OpenAI audit 发现 frontier models 对部分 task-specific solutions 有复现迹象。持续更新的 SWE-rebench 是相邻缓解方案，不是 Original/Verified 的现有政策。 |
| repeated-run policy | **公开资料不足。** Original/Verified 官方 task definition 不规定每个 system 必须重复多少 stochastic trials；leaderboard patch verdict 与研究者 repeated runs 应分开记录。OpenAI 2026 audit 的 64 runs 是其审计抽样方法，不是 benchmark 通用政策。 |
| human baseline | **公开资料不足。** Verified annotator 人数和审查不是 human task success baseline；原开发者的 merge 也不是受控 benchmark human run。 |
| cost evidence | **公开资料不足。** 未找到可泛化的官方 full-suite model+compute 成本。Docker image 构建、测试时长、模型 tokens、失败重试和人工复核必须分项 pilot。 |
| known validity problems | **[事实]** OpenAI 的 selected 138-case audit 发现大量 underspecification/narrow or overly broad tests，但该采样有意集中在 o3 inconsistent failures，59.4% 不能外推全 500。PatchDiff 在其 selected plausible patches 中发现 tests 可接受语义不同 patch 或拒绝行为等价 patch，并估计特定实验下 6.2 pp inflation。**[研究员推断]** test pass 是有噪声的 construct proxy。 |
| saturation / benchmark-specific optimization | **[事实]** issue、gold patch 与测试历史公开，已出现 task-specific reproduction；2026 OpenAI 认为 Verified 不再适于测 frontier coding capability。**[研究员推断]** benchmark-specific retrieval、prompting、scaffold tuning 可提高分数而不等比例提高新鲜 issue 泛化。 |

### 3.2 Terminal-Bench 2.0（同时标明 v1 边界）

| 字段 | 结论与证据等级 |
|---|---|
| evaluation construct | **[事实]** agent 在 isolated terminal/container 中根据自然语言 instruction 完成 outcome；tests 读取 final container state，不要求复现 human command trajectory。测量 model+agent scaffold+tools+budget 的组合表现。 |
| task unit | **[事实]** 一个 task = instruction + unique Docker environment + tests + human oracle solution + time limit。2.0 有 89 final tasks；229 是 submissions，93 是 contributors。一个 trial 是一个 agent 对一个 task 的一次 attempt。 |
| domain coverage | **[事实]** 覆盖 software engineering、system administration、security、data processing、scientific computing 等终端工作；精确 taxonomy/配额应以 2.0 manifest 而非 launch blog 为准。 |
| real vs synthetic | **[事实]** 使用真实 CLI tools/packages 与可执行环境；目标是 contributor-authored challenge，并非自然发生的工单抽样。**[作者/机构主张]** “hard, realistic”。**[研究员推断]** software realism 高于职业任务抽样真实性。 |
| workflow length | **[事实]** 多步 terminal interaction，作者报告多数 attempt 少于 20 分钟，个别 trial 可达 2 小时/约 100M tokens；task-author 的 expert time estimates 不是 measured human baseline。 |
| software/environment | **[事实]** task-specific Docker containers，经 Harbor 执行；论文使用 32–100 containers 并行。CPU/memory/time/network/tool policy 是可影响结果的 benchmark configuration。 |
| expert involvement | **[事实]** 93 contributors 提交 229 tasks，3 位 experienced reviewers 选择 89；平均每 final task 约 3 reviewer-hours。注意这不是每任务总生产工时。 |
| task sourcing | **[事实]** open expert contribution/commission-style submission，经 review 筛选；不是 mining 自然工作日志。 |
| evaluator type | **[事实]** executable tests / grader 检查 final container state；official leaderboard 后续要求 auditable ATIF trajectories，并把 reward hack trial 计 0。 |
| human evaluation dependency | **[事实]** runtime scoring 可自动化；task authoring、oracle solution、review、trajectory integrity audit 依赖人。 |
| public/private split | **[事实]** 2.0 task repo、tests/oracle artifacts 可公开取得；未发现与 public 2.0 对应的长期隐藏 task holdout。运行时可限制 agent 直接访问 tests，但这不构成 private benchmark split。 |
| contamination policy | **[事实]** official 2026 integrity update禁止读取/修改 evaluator、外部查找公开 solution、注入测试或改 timeout；要求提交 traces。**[研究员推断]** 这是事后检测/规则，不等于通过隐藏数据预防训练污染。 |
| repeated-run policy | **[事实]** 2.0 paper 对每个 supported model-agent combination 至少重复 5 次，总计 32,155 task trials。**边界：** v1 launch 说明 one attempt per task in a run、榜单常以多 runs 汇总；不能把 v1 与 2.0 protocol 合并。 |
| human baseline | **公开资料不足。** Table 1 是 task authors 对 expert/junior completion time 的估计，不是受控 human success。且可见分组仅覆盖 74 个 time-estimated tasks，不能默认为 89 个均有估计。 |
| cost evidence | **[事实/作者快照]** 论文称一次 full benchmark model cost 约 USD 1–100，取决于 model price；个别 task 极长。**限制：** 不含一致口径的机器、工程、失败重试与人工审核，不能作为 1,000-task 配额。 |
| known validity problems | **[事实]** official audit发现修改 timeout、读取加密 solution、上传 tests、在线搜索答案等 reward hacking。DebugML 对特定 top submissions 报告 tests/answer-key leakage。Anthropic 的特定 GKE 设置测得最多 6% pod errors、资源配置差异造成 6 pp gap。跨五 terminal benchmarks 的 hardening study显示 verifier exploitation 是系统风险。所有百分比均须保留各自抽样边界。 |
| saturation / benchmark-specific optimization | **[作者/机构主张]** 2.0 paper预期约一年内可能 saturation，并规划新 challenge sets。**[研究员推断]** public tasks + public graders + agent-specific leaderboard tuning 使 trace audit、版本轮换与未公开 challenge set 成为必要维护，而非可选增强。 |

### 3.3 CRAB（Cross-environment Agent Benchmark）

| 字段 | 结论与证据等级 |
|---|---|
| evaluation construct | **[事实]** multimodal agent 在 Android 与 Ubuntu 环境中完成单环境或跨环境任务；task graph 的 evaluator nodes 计算 sub-goal completion，兼顾 binary success 与 partial completion。 |
| task unit | **[事实]** 一个 runnable task 是由 sub-task templates、环境、目标与 evaluator DAG 组成的实例。**版本冲突：** v4 abstract/site 为 120，正文 composition 为 100；未能由 public release-tagged manifest 消解，故当前精确 inventory = **公开资料不足（存在矛盾）**。 |
| domain coverage | **[事实]** Android phone + Ubuntu desktop；16 Android、19 Ubuntu sub-task templates；正文旧 composition 报告 29 Android、53 Ubuntu、18 cross-platform（总计 100）。不得将旧 composition 套到 120 release。 |
| real vs synthetic | **[事实]** 使用真实类型的 apps/OS interactions；任务通过 sub-task composition 和人工设计构造。**[研究员推断]** 环境真实，任务分布合成；不等于真实员工 workflow sample。 |
| workflow length | **[事实]** single、simple-composed、challenging-composed；DAG 可表达前置依赖。跨平台例子要求先在 Android 读取信息再在 Ubuntu 执行，强于无关短操作串联。统一实际步数、时长和错误恢复分布公开资料不足。 |
| software/environment | **[事实]** Android emulator/device-state query 与 Ubuntu desktop；视觉 observation/action；API 不可得时用 image matching/OCR evaluator。 |
| expert involvement | **[事实]** 每个 sub-task template 至少由两位相关领域专家验证；human mode 可在人工操作中触发 evaluators。精确专家人数、每 task 人时公开资料不足。 |
| task sourcing | **[事实]** 16+19 templates 经组合与部分手工设计生成 tasks；不是自然日志/工单抽样。 |
| evaluator type | **[事实]** Python boolean judge functions 组成 DAG；通过 Android XML、Ubuntu state APIs、image matching/OCR 检查状态。指标包括全任务成功与 graph-node completion；两者不可互换。 |
| human evaluation dependency | **[事实]** 正式 scoring 以自动 graph evaluator 为主；template validation 有人类专家，human mode用于校验。运行期是否仍需人工裁决公开资料不足。 |
| public/private split | **公开资料不足。** 未发现明确 hidden holdout/private evaluator policy；current repo/site 为公开发布面。 |
| contamination policy | **公开资料不足。** 未发现版本化污染审计、任务轮换或 reference-leak 检测政策。 |
| repeated-run policy | **公开资料不足。** 论文比较多个 model/communication settings，但未发现统一要求每 system/task 的 stochastic repetitions 与 aggregation rule。 |
| human baseline | **公开资料不足。** “至少两位专家验证 template”不是 measured task-success baseline。 |
| cost evidence | **公开资料不足。** 未找到可复用的 full benchmark model、emulator/desktop compute、人工 QA 成本。 |
| known validity problems | **[事实]** v4 abstract/site 与可提取正文 task count、best score 不一致，是版本/报告完整性问题；视觉/OCR fallback 与 API-based evaluators可能有不同误差模式。**[研究员推断]** graph partial credit 的质量取决于 DAG 是否充分覆盖等价完成路径；公开独立 evaluator audit 不足。 |
| saturation / benchmark-specific optimization | **公开资料不足。** 未发现 longitudinal saturation 或 benchmark-specific tuning audit。公开 tasks/evaluators 且无已知 holdout/rotation，理论风险存在，但不能声称已发生。 |

### 3.4 Windows Agent Arena（standard paper config；harder mode 单列）

| 字段 | 结论与证据等级 |
|---|---|
| evaluation construct | **[事实]** multimodal OS agent 在 Windows 11 VM 中观察屏幕/结构化 UI，使用鼠标键盘等完成任务；deterministic setup 后由 final device state evaluator 判分。测的是完整 agent system，不是裸模型。 |
| task unit | **[事实]** v2 paper 为 154 runnable task instances（1 task/template）；摘要“150+”是近似。repo post-paper harder mode要求 agent 自行初始化 app/task，是另一 protocol，不是新 task count。 |
| domain coverage | **[事实]** Office（Writer/Calc）、web browsers、Windows system、VS Code coding、VLC 与 utilities。 |
| real vs synthetic | **[事实]** 真 Windows/apps；任务目标、初态脚本和 evaluator 为 benchmark-authored，部分从 OSWorld 改编。**[研究员推断]** platform realism 高，工作样本自然性不足。 |
| workflow length | **[事实]** multi-step GUI tasks。human task steps 与 perceived difficulty 相关仅 0.23、与 success -0.11。**[研究员推断]** 操作步数不是 long-horizon professional workflow 的有效替代指标。 |
| software/environment | **[事实]** Windows 11 VM in Docker、Flask bridge、应用软件、UIA/SoM/screen parser。repo 指南称 golden image约 30GB、prep约 20分钟；这些是 mutable setup快照。 |
| expert involvement | **[事实]** 论文有人类完成实验和任务分析。task authoring/QC 的精确专家人数、分工与人时公开资料不足。 |
| task sourcing | **[事实]** 从 OSWorld Windows-compatible tasks 改编并扩展 WAA-specific tasks；并非自然员工操作日志。 |
| evaluator type | **[事实]** application/device-state-based automatic evaluators，配 deterministic initialization；不是 trajectory match 或 LLM judge。 |
| human evaluation dependency | **[事实]** runtime grading 可自动化；humans 用于 baseline/analysis，不是每个 agent run 的 evaluator。 |
| public/private split | **公开资料不足。** current repo公开 task/config/evaluator；未发现 hidden holdout 或 private leaderboard task set。 |
| contamination policy | **公开资料不足。** 未发现正式轮换、训练污染声明或 solution-leak audit。 |
| repeated-run policy | **公开资料不足。** 论文约 50 个 parallel runs 描述并行基础设施，不是“每 task 重复 50 次”；没有发现统一 leaderboard repetitions/retry aggregation policy。 |
| human baseline | **[事实]** measured human success 74.5%；paper best Navi 19.5%。baseline 的人员构成/置信区间应从原论文实验协议读取，不应外推为所有 Windows 知识工作。 |
| cost evidence | **[作者/机构快照]** official FAQ示例：40 VMs 计算约 USD 8；GPT-4V/4o约 USD 100，mini约 USD 15，约 30–35 分钟。**限制：** model prices、parallelism 与云配额时变，且不含生产/QC，不能作 1,000-task 配额。 |
| known validity problems | **[事实]** 同模型表现对 UIA/SoM/screen parser 明显敏感；parser 可耗时数秒至数分钟。**[研究员推断]** 感知/harness latency、VM稳定性和 app版本可能被计为“专业能力失败”。本研究未找到强 WAA-specific independent evaluator audit，故错误率公开资料不足。 |
| saturation / benchmark-specific optimization | **公开资料不足。** 没有发现 longitudinal saturation audit；公开任务、固定 app流程与 post-paper harder mode说明 benchmark-specific adaptation可能发生，但其规模未被量化。 |

## 4. 对四项假设的本组判定

| 假设 | 本组 verdict | 支持、反例与失效条件 |
|---|---|---|
| H1 高真实性、广覆盖、完全自动可靠验证存在 trade-off | **supported（本组范围）** | SWE-bench 的真实 issue仍需 Verified 人工筛选，且 executable tests有 false-positive/negative；Terminal-Bench 的广任务与 unique containers需要专家 review、oracle与 trace audit；CRAB/WAA为自动判分而显式约束可查询状态。**反例/边界：** narrowly scoped、state-complete domains 可能同时做到高环境真实性与可靠自动判分；因此这是结构性压力，不是数学不可能定理。 |
| H2 多个短 GUI 操作串联不自动构成真实 long-horizon workflow | **supported** | WAA 论文中 human steps与难度/成功相关很弱；CRAB 给出有前置依赖的 Android→Ubuntu 任务，是“有意义组合”的反例，说明关键是跨阶段信息/状态依赖，而非步骤数。但尚无职业 workflow 对照证明 CRAB/WAA覆盖完整专业工作。 |
| H3 高难度可来自环境、工具或 evaluator，而非目标能力 | **strongly supported** | SWE tests的窄/宽与 underspecification；Terminal-Bench 的 infra resource gap、pod errors、grader hacking与answer leakage；WAA的UIA/SoM/parser敏感性均提供直接证据。**失效条件：** 若在固定环境、充分工具、稳健 evaluator、多 scaffold与人工复核下排序仍稳定，才能把难度更强地归于目标能力。 |
| H4 无 hidden holdout/版本轮换的长期有效性快速下降 | **supported for SWE/TB；underdetermined for CRAB/WAA** | SWE已有静态公开污染/solution reproduction与retirement evidence；TB作者预告 saturation且出现公开 grader gaming，采用new challenge sets。CRAB/WAA缺乏 longitudinal audit，不能把理论风险写成已证实“快速下降”。**反例条件：** 即使任务公开，若结果在fresh private tasks、rolling versions和跨 harness上稳定，则H4会被削弱。 |

## 5. 对 1,000-task 生产的决策影响

### 5.1 可迁移设计

1. **[项目建议] 单位先行。** manifest 必须分别给 `workflow_id`、`instance_id`、`source_artifact_id`、`evaluator_version`、`environment_digest`、`agent_run_id`、`trial_id`；任何 dashboard 禁止把 submission、task、trial相加。
2. **[项目建议] 真实素材与可验证性双轨。** 对 SWE-like 任务保存真实 source artifact/provenance，同时让独立 evaluator author 从目标 contract 构造 tests；gold solution 只能用于校验，不能成为 evaluator的唯一语义定义。
3. **[项目建议] 至少三层 evaluator QA。** (a) gold应通过；(b) seeded wrong solutions应失败；(c) alternative-valid solutions应通过。增加 mutation/metamorphic tests、过宽/过窄测试审计和 exploit/red-team。
4. **[项目建议] 公共开发集、私有评分集、滚动替换池分开。** private 不能只隐藏 reference answer；task objective、environment seeds、关键 tests/evaluator和更新时间都要有明确 threat model。
5. **[项目建议] 版本不可变。** 每次 release 固定 task manifest hash、repo/base commit、container digest、app/OS version、evaluator commit、budget、network policy、retry policy；live leaderboard只指向某一 release。
6. **[项目建议] 先定义 repeated-run estimand。** 报告 `task-level pass probability`、至少一次成功、均值或 majority 的哪一个；infra retry 与 model retry 分开，不把 pod/VM failure悄悄重跑成能力成功。
7. **[项目建议] trace 是交付物。** 保存命令/UI actions、observations、tool calls、resource usage、test logs、environment faults和grader verdict；自动检测读 tests、改 grader、改 timeout、外网查答案、reference leakage。
8. **[项目建议] long-horizon 以依赖图和审计产物定义。** 要求跨阶段 state/information dependency、错误恢复、持久状态和最终 deliverable；不以 step count 或 wall-clock alone 配额。
9. **[项目建议] 人类 baseline 与 expert validation分开预算。** template review、evaluator review、pilot solve、blind human baseline是四项不同工作；“两位专家看过”不能替代受控人类成功率。
10. **[项目建议] 把维护纳入产品。** 设 saturation/contamination gate：fresh hidden sample、solution-similarity scan、跨 harness复测、evaluator incident review与周期性retirement；static release不是终态。

### 5.2 不得从公开快照直接变成生产配额的数字

- SWE-bench 的 93 annotators、1,699 reviewed samples、500 Verified instances：是特定一次 curation 快照，不是 1,000-task 的人数或acceptance配额。
- OpenAI 138-case audit 的 59.4%：是按 o3不一致失败抽样后的条件比例，不是 Verified全集 defect rate。
- Terminal-Bench 的 93 contributors、229 submissions、89 final、约3 reviewer-hours/final task：分别是参与者、投稿、最终task和 reviewer time；不能推导总生产工时或固定接受率。
- Terminal-Bench 的 USD 1–100/full run：仅当时模型成本快照，不含基础设施、人工、失败重试，且任务可差两个数量级。
- CRAB 100/120：当前证据本身冲突，不能用于配额。
- WAA 的 40 VMs/USD 8、model USD 15/100、30–35 minutes：是官方FAQ配置快照，不是长期unit economics。

### 5.3 Pilot 必须测量的变量与公式

**资产生产成本（每个 runnable instance）：**

`C_asset,i = C_source,i + C_env,i + C_expert_author,i + C_evaluator,i + C_independent_QA,i + C_security_redteam,i + C_documentation,i + C_maintenance_reserve,i`

**一次评测活动总成本：**

`C_eval = Σ_i [R_model,i × (C_model_tokens,i + C_compute,i + C_external_services,i)] + Σ_i [R_infra,i × C_infra_retry,i] + C_human_adjudication`

其中 `R_model` 是预先规定的随机重复，`R_infra` 仅用于确认环境故障后的重试；两者不得合并。Pilot 至少观测：author time、environment build/repro time、evaluator build time、independent solve time、gold pass rate、seeded-negative rejection、alternative-valid acceptance、infra fault rate、trial runtime/token分布、人工争议率、task retirement/repair rate。公开资料不足以给这些变量设统一点估计。

## 6. 争议、反方证据与公开资料缺口

1. **SWE-bench 2026 audit 的外推争议。** 它强烈证明“高分可能含 evaluator/contamination问题”，但 selected 138不是随机全样本；把59.4%写成Verified缺陷率会制造新错误。
2. **PatchDiff 的语义标准争议。** developer-written suite与benchmark tests都不是绝对 ground truth；PatchDiff证明test verdict与行为语义会分离，但其selected plausible patches也不是总体随机样本。
3. **Terminal-Bench cheating 与正常能力的边界。** 读取挂载tests、修改timeout、注入answer key显然破坏construct；但有些agent会在正常探索中发现测试路径，benchmark必须把“允许观察什么”写成machine-enforced policy，不能仅靠事后道德分类。
4. **Terminal infra evidence 的可迁移性。** Anthropic报告的6%/6 pp属于其GKE/resource calibration，证明配置敏感，不证明所有官方run具有同一误差率。
5. **CRAB 的版本冲突。** v4 abstract/site=120、正文=100；在拿到release-tagged manifest前，任何精确domain比例或per-task结论都应暂停。
6. **WAA 独立审计不足。** primary paper揭示harness敏感性，但没有找到同等强度的独立evaluator false-positive/negative审计；不能虚构故障率。
7. **“公开tests”与“trial可见tests”。** repo公开、训练语料可见、runtime mount可读、private leaderboard hidden是四个不同维度；报告必须逐项记录。
8. **成功可能来自 benchmark-specific optimization。** public gold/history、retrieval、task-known prompts、UI parser和scaffold均可贡献成功；不固定full agent configuration和fresh holdout，不能把score变化全归因于foundation model。

## 7. 建议进入主报告的最短结论

- **[事实]** 本组没有一个 benchmark 同时公开证明：广任务覆盖、真实职业抽样、完全自动且经独立审计可靠的 evaluator、长期 hidden/rolling holdout、稳定跨-harness结果。
- **[研究员推断]** ALE-style 1,000-task项目应借鉴 SWE-bench 的真实 source artifact、Terminal-Bench 的 outcome containers/trace audit、CRAB 的 dependency graph/partial credit、WAA 的 deterministic state setup；但必须补上 hidden rolling pool、evaluator exploit testing、重复试验协议和版本化成本/故障记录。
- **[项目建议]** 对外只承诺“某 manifest + harness + evaluator + budget + repetition policy 下的 system performance”，不要把它表述成裸模型能力、完整职业替代率或跨环境long-horizon能力。

## 8. 来源索引

- SWE-bench：`sources/40_swe_bench_arxiv_v3.md` 至 `sources/46_swe_rebench_contamination.md`
- Terminal-Bench：`sources/47_terminal_bench_2_arxiv_v1.md` 至 `sources/53_terminal_verifier_hardening.md`
- CRAB：`sources/54_crab_arxiv_v4.md` 至 `sources/56_crab_github_snapshot.md`
- Windows Agent Arena：`sources/57_windows_agent_arena_arxiv_v2.md` 至 `sources/59_windows_agent_arena_github_snapshot.md`
