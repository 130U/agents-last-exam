# ALE unified comparison row — arXiv v2 + 2026-08-08 live surfaces

| Field | Evidence-bounded value |
|---|---|
| evaluation construct | Pinned end-to-end Generalist Computer-Use Agent system: foundation model + harness + GUI/CLI/tool/context machinery completing professional deliverables in a provisioned Windows/Linux environment; score bounded by task-specific evaluator. |
| task unit | Paper distinguishes `task workflow` from runnable `task instance`; expert submission and commissioned proposal are upstream production units, not automatically runnable instances. |
| domain coverage | Paper v2: 13 clusters / 55 subdomains, SOC/O*NET anchored and supplemented with frontier subdomains; not labor-market weighted. |
| real vs synthetic | Authors state tasks derive from experts’ prior professional projects; some source-grounded assets can use public datasets/papers/standards. Independent provenance audit across full private pool is unavailable. |
| workflow length | Admission asks past work taking experts days/weeks and rejects local UI actions; no public matched human-time distribution for the full pool. |
| software/environment | Remote Windows/Linux VMs; real/professional software; GCP default in paper, repo also supports AWS/AliCloud/QEMU/Docker subset/static. Per-task compute varies. |
| expert involvement | Sourcing, proposal, revision, reference output, evaluation specification, final committee QC; engineering team implements and dry-runs. Paper says 250+ experts; live pages say 300+. |
| task sourcing | External expert submission + commissioned/internal build; Figure 5 provenance numbers are instance-level and must not be equated with Appendix workflow count. |
| evaluator type | Artifact/state/executable task-specific code; exact/hash, tabular, geometric, visual, behavioral, free text. Open reference tree static analysis: 93.2% workflow code-based, 6.8% LLM judge. |
| human evaluation dependency | Runtime scoring aims automatic; human dependency remains high in sourcing, reference/rubric creation, implementation review, calibration, QC and incident adjudication. |
| public/private split | Paper Figure 5: 150 public, 1,017 private, 323 pending-QC among 1,490 instances. HF revision has 153 metadata rows; repo says around 150; keep separate. |
| contamination policy | Small public subset, gated references, hidden reference staging, private pool and planned rotation. Longitudinal effectiveness and actual rotation cadence are not yet independently established. |
| repeated-run policy | Table `±` uses 3 runs only for selected configurations; most cells single-run. No uniform full-benchmark repetition rule. |
| human baseline | No matched human performance baseline across evaluated instances. Expert historical time claims are sourcing criteria, not a score baseline. |
| cost | Evaluation cost per frontier-agent run reported as roughly $3–10 average in paper; public full-set configurations report API/wall-clock/token totals. Task production/maintenance cost is public资料不足. |
| known validity problems | Joint system construct; evaluator calibration/gaming; LLM-judge nondeterminism; licensed software/provider drift; task/run failures; public subset representativeness tested internally with one configuration; no matched human baseline; no labor weighting; version/count drift. |
| saturation/benchmark-specific optimization | Authors call hardest tier unsaturated and design rotation against optimization. Static public subset can still be optimized; private pool/rotation reduce but do not prove elimination. |

## Version matrix

| Surface frozen on 2026-08-08 | Version/revision | Reported scale/unit | Boundary |
|---|---|---|---|
| arXiv paper | `2606.05405v2`, revised 2026-06-11 | 1,490 task instances; 960 workflows; Figure 5 150 public/1,017 private/323 pending; 960 external-submission instances + 530 commissioned instances | Two `960` values are different labeled units. |
| official live homepage | access-date snapshot | 1.5K+ tasks collected; 300+ experts; 55 sub-industries | No manifest/unit definition; live marketing counter. |
| submit page | access-date snapshot | No corpus count; five-component expert submission | Submission is not runnable asset. |
| GitHub repo | commit `1e615e456de7cef57706680613cb80ee13c7fc76` | around 150 public tasks; open framework + task tree | Public code snapshot only. |
| HF metadata | revision `a8c1fd174a1f6cfa76526572a2e3ebece1276be2`, card v1.0 | 153 rows, one task card per row | Metadata-only; inputs/reference/evaluator separate. |
| RDI blog | 2026-06 page, accessed 2026-08-08 | 1,500+ expert-sourced tasks; 300+ experts; 55 occupations | Institution narrative/claim surface. |
| live leaderboard | ALE-V1; accessed 2026-08-08; best-per-task 2026-07-04; runtime method 2026-07-10 | live agent-system rows with harness/model/effort/cost/runtime/tokens; includes configurations newer/different from paper table | Results surface, not corpus manifest; best-per-task is an oracle envelope, not one agent. |
