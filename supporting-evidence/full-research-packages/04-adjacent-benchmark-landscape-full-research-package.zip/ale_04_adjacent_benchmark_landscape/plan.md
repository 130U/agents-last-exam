# ALE 邻近 benchmark landscape：研究计划

- 研究日期 / 访问截止：**2026-08-08**（America/New_York）
- 固定研究对象：**UC Berkeley RDI Agents' Last Exam（ALE），arXiv `2606.05405v2`**；排除其他同名 ALE / ALE-Bench。
- 决策：为约 1,000 个 ALE-style benchmark assets 确定产品范围、task selection、专家组织、生产流程、evaluation、基础设施、QA、成本模型、排期变量与交付标准。
- 报告类型：decision-oriented benchmark landscape；不是排行榜综述。

## 1. 可证伪假设

1. **H1 — 真实性/覆盖/自动验证 trade-off。** 高真实性、广领域覆盖与完全自动且可靠的验证之间存在结构性 trade-off。若跨 benchmark 证据显示三者可同时稳定实现，且没有显著 human-review、evaluator validity 或环境成本，则反驳。
2. **H2 — GUI 串联不等于 long-horizon workflow。** 把多个短 GUI 操作串联起来，并不自动构成真实 long-horizon professional workflow；只有具备跨阶段依赖、持久状态、专业判断、错误恢复和可审计 deliverable 的任务才满足较强定义。若 benchmark 的长链任务虽由短操作构成但经人类 workflow 对照证明代表真实工作，则反驳。
3. **H3 — 难度来源可混淆。** 高难度可能来自环境脆弱、工具不足、harness/budget 限制或 evaluator strictness，而非目标专业能力。若控制这些因素后 benchmark 难度排序与能力解释保持稳定，则反驳。
4. **H4 — 无隐藏 holdout/轮换会衰减。** 没有隐藏 holdout、版本轮换或持续新增任务的 benchmark，其长期测量有效性会因公开暴露、训练吸收和 benchmark-specific optimization 快速下降。若长期、独立审计显示公开静态集仍维持无污染、跨配置稳健和外部效度，则反驳。

## 2. 初始 benchmark 集合（证据不足时可增删）

统一矩阵目标为 12–16 个 benchmark，初始纳入：ALE、OSWorld/OSWorld 2.0、WebArena、WorkArena++/BrowserGym、GAIA、AssistantBench、SWE-bench（含 Verified 作为版本面）、Terminal-Bench、CRAB、Remote Labor Index、GDPval、Windows Agent Arena、SpreadsheetBench、OfficeBench。家族中的版本、subset 或 harness 不自动计为独立 benchmark；最终矩阵会标明实际采用的版本面。

## 3. 单位账本

每个数字必须标记为：`benchmark`、`domain`、`subdomain`、`workflow`、`runnable task instance`、`expert submission`、`commissioned task`、`public/private/pending-QC instance`、`agent run` 或 `repeated trial`。同值不证明同一集合；无法判定单位时保持“ambiguous”。

## 4. 统一比较字段

`evaluation construct`、`task unit`、`domain coverage`、`real vs synthetic`、`workflow length`、`software/environment`、`expert involvement`、`task sourcing`、`evaluator type`、`human evaluation dependency`、`public/private split`、`contamination policy`、`repeated-run policy`、`human baseline`、`cost evidence`、`known validity problems`、`saturation/benchmark-specific optimization`。

## 5. 来源策略与能力路由

- ALE canonical 起点：固定 arXiv v2、官网、submit、GitHub（commit SHA）、Hugging Face dataset（revision）、RDI blog；实现事实以这些 primary sources 为准。
- 邻近 benchmark：优先原始论文、官方 repo/data card/evaluator code；再用独立学术研究与可信行业资料验证跨项目结论。多个转载或同一机构的镜像不算独立来源。
- Hugging Face/arXiv：优先可版本化 Markdown/API；失败时回退到 arXiv HTML/PDF，而不是把访问错误当证据。
- 官网动态状态：用内置浏览器读取可见页面；代码、数据和版本元数据优先 Git/API/CLI 或直接文件。
- 每个核心综合命题原则上需要至少三种独立来源类型；不足则明确标记 **公开资料不足**。

## 6. 来源文件合同与评分

每个来源单独保存为 `sources/NN_slug.md`，必须包含：标题、作者/机构、URL、发布日期、访问日期、版本/revision、与问题直接相关的原文证据、证据解释、支持/反驳的结论，以及：

- **Credibility 1–5**：5 = 版本化 primary / peer-reviewed authoritative；1 = 无署名衍生材料。
- **Recency 1–5**：5 = 2026-08-08 当日核验的 mutable source 或 immutable pinned revision。
- **Bias 1–5**：5 = 激励冲突低且主动披露限制；1 = 强宣传/选择性激励。该分数不等同“真实性”。

最终陈述统一使用：**[事实]**、**[作者/机构主张]**、**[研究员推断]**、**[项目建议]**。

## 7. 对抗性搜索与风险登记

- evaluator false positive/false negative、grader gaming、reference leakage、public-task memorization。
- model 与 harness/scaffold/tools/context/budget/retry policy 混淆；环境 failure 被计入能力 failure。
- static benchmark saturation、benchmark-specific prompting/fine-tuning、污染检测不足。
- human baseline 不匹配、任务代表性与职业/经济权重外推。
- live site、论文、repo、HF 与 leaderboard 快照漂移；不得合并成统一数字。
- workflow length 以操作步数冒充真实跨阶段工作；自然语言“long-horizon”缺乏可复核定义。
- 公开成本、人数、工期、配额往往缺失；只给变量公式和 pilot gate，不编造点估计。

## 8. 交付结构与停止条件

输出 `sources.csv`、逐源 `sources/`、原子 `findings/`、`refresh_targets.md` 和 `2026-08-08_landscape_report.md`。报告固定包含 Executive summary、关键定义、证据与版本矩阵、主要发现、反方证据与不确定性、1,000-task 决策影响、建议、待确认问题、可复用矩阵/schema/checklist/formula、A–E 五项最终输出及 H1–H4 verdict。

停止条件：六个 ALE canonical source 均单独落盘且完成版本钉住；最终 12–16 个 benchmark 的全部字段有证据或“公开资料不足”；四个假设经过反方证据审查；核心综合命题达到三类来源或降级；引用与原文证据抽检通过；mutable 字段进入 refresh list。

## 9. 变更记录

- 2026-08-08：初始化；复用既有 ALE 研究仅作为线索，所有 mutable 数字与 revision 在本研究中重新核验。
