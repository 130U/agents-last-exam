# GAIA：论文版本面

- **标题**：GAIA: a benchmark for General AI Assistants
- **作者/机构**：Grégoire Mialon、Clémentine Fourrier、Craig Swift、Thomas Wolf、Yann LeCun、Thomas Scialom；Meta AI、Hugging Face、AutoGPT 等（按论文署名）
- **URL**：https://arxiv.org/abs/2311.12983v1
- **发布日期**：2023-11-21
- **访问日期**：2026-08-08
- **版本/revision**：arXiv `2311.12983v1`；ICLR 2024 conference version
- **来源类型**：原始论文 / benchmark 作者
- **评分**：Credibility **5/5**；Recency **5/5**（pinned）；Bias **3/5**

## 与本研究直接相关的原文证据

> “we devise 466 questions and their answer”

摘要说明公开 questions、保留其中 300 个 answers 供 leaderboard。任务要求 reasoning、multimodality、web browsing 与 tool use；最终评分为单一短答案的 quasi-exact automatic matching，而不是过程或副作用检查。Level 1/2/3 大致按 annotator 所需 steps/tools 分层：L1 通常至多约 5 steps/单工具，L2 约 5–10 steps/多工具，L3 可更长且多工具。

制作流程：annotator 先设计并给出答案/trace；两个新 annotators 独立重做。623 个候选经复核，68% 可直接保留，其余修正或删除。作者估计每题含验证约两 annotator-hours；human validation accuracy 约 92%。API 允许时 baseline 以 3 runs 求平均；GPT-4+plugins 的手工 oracle 设置不可稳定复现。

论文限制部分明确预期 benchmark 会因 pretraining contamination 或网页信息消失而衰减，需要逐年增删。

## 证据解释与单位边界

- **[事实]** `466` 是论文 snapshot 的 **questions/runnable answer instances**；不是 466 个 workflows，也不是 466 runs。
- **[事实]** task unit 是自然语言 question + optional file + one final answer；它测 tool-augmented assistant research，不测可持续修改软件状态的 professional workflow。
- **[事实]** `300 retained answers` 是 private-answer evaluation 面；questions 公开。它不是完全隐藏 prompts 的 holdout。
- **[作者主张]** “real-world”与 general assistant construct 由作者提出；单答案正确性不证明中间研究过程可靠、来源可审计或安全。
- **[事实]** 约两小时/题是该流程的观察性估计，不是 ALE-style 专业 workflow 的生产成本；美元成本和专家工资公开资料不足。

## 支持或反驳的结论

- 支持 H1：广主题与廉价自动评分通过收窄为 closed-form answer 实现，牺牲过程/状态验证。
- 支持 H3：web/tool availability、plugin stack 与 ambiguity 会改变难度。
- 直接支持 H4：作者自己预测 contamination/link rot，并建议持续更新。
- 支持 repeated-run 需求，但论文 3-run 做法仅针对部分 baseline，不是稳定全局 protocol。

