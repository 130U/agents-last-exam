# AssistantBench：Princeton HAL cost / run 当前快照

- **标题**：HAL: AssistantBench Leaderboard
- **作者/机构**：Princeton University SAgE / HAL team
- **URL**：https://hal.cs.princeton.edu/assistantbench
- **发布日期**：公开页面未标明单独发布日期；HAL 平台持续更新
- **访问日期**：2026-08-08
- **版本/revision**：mutable leaderboard snapshot；页面注明已暂停新增模型、转向 reliability
- **来源类型**：独立第三方 harness / leaderboard
- **评分**：Credibility **4/5**；Recency **5/5**；Bias **4/5**

## 与本研究直接相关的原文证据

> “33 Total Tasks”

当日页面列 15 evaluations、1 scaffold（Browser-Use）与各 run 的 accuracy、total API cost、runs、encrypted traces。页面解释 cost 不含 caching benefits；若有多 runs，confidence interval 显示 min–max，但当前表中所列模型均为 `1 run`。

## 证据解释与版本边界

- **[事实]** HAL 的 `33` 是 AssistantBench public validation subset，不是原 benchmark 的 214 tasks。
- **[事实]** 15 evaluations 是 **model/scaffold evaluation entries**；每项当前 1 run，不是 15 tasks 或 15 repeated trials/task。
- **[事实]** 页面美元数是某模型定价、某 scaffold、33 tasks、当时 cache accounting 下的 total API cost；不是 task 制作或全 benchmark 运行成本。
- **[研究员推断]** 单 scaffold + 单 run 不能把差异归因给 base model，也不能估计 within-task stochastic variance；leaderboard 排名是 system snapshot。
- **[事实]** HAL reproducibility 标记与 downloadable traces 增强审计性，但不修复 AssistantBench ground-truth drift 或 public validation contamination。

## 支持或反驳的结论

- 强支持 H3：model、scaffold、cost accounting 与 run count 共同定义观察值。
- 支持 1,000-task 项目把 cost 分成 production cost、infra fixed cost、agent inference cost、human review cost，禁止混报。
- 支持 repeated runs 与 uncertainty；当前单 run 表本身不能证明排名稳定。

## 限制

这是 2026-08-08 可变快照；所有分数和美元数只用于说明 measurement design，不用于当前模型排行榜结论或生产预算。

