# Hardening Agent Benchmarks with Adversarial Hacker-Fixer Loops

- 作者/机构：Ziqian Zhong、Ivgeni Segal、Ivan Bercovich、Shashwat Saxena、Kexun Zhang、Aditi Raghunathan
- URL：https://arxiv.org/abs/2606.08960
- 发布日期：2026-06-08
- 访问日期：2026-08-08
- 版本/revision：访问日 arXiv current revision
- 类型：独立 academic verifier-security audit

## 与本研究直接相关的原文证据

- abstract lines 3–7：跨五个 terminal-agent benchmarks 审计 1,968 tasks，发现 323 个可被 frontier models hack；发布 3,632 exploit trajectories。
- lines 10–23：手写 outcome verifier 可被 deleting tests、monkey-patching 等 unintended shortcuts 利用；Terminal Bench 77 tasks 的 held-out attack success 在 hardening 后下降但未归零。
- 原文短引："hand-written and brittle"；"reward hacking"。

## 证据解释

- 323/1,968 是五个 benchmarks 的 pooled audit，不是 Terminal-Bench 2.0 单项缺陷率。
- hacker–fixer–solver loop 同时要求 blocker exploit 与保留 legitimate solution，避免 verifier 变得过窄。

## 支持/反驳

- 强支持 H3：evaluator weakness 会虚高成绩。
- 支持项目建议：每个 evaluator 应进入 adversarial exploit suite、legitimate solver regression suite 与 hidden canary tests。

## 评分

- Credibility：5/5（版本化论文、跨 benchmark 实验）
- Recency：5/5
- Bias：5/5（独立方法研究，适用边界明确）
