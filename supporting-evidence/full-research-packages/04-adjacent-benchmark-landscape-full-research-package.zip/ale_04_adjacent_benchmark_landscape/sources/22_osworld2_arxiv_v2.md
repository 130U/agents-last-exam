# OSWorld 2.0：论文版本面

- **标题**：OSWorld 2.0: Benchmarking Computer Use Agents on Long-Horizon Real-World Tasks
- **作者/机构**：Mengqi Yuan 等；HKU、McGill、Salesforce、Amazon、Alibaba、University of Wisconsin–Madison 等
- **URL**：https://arxiv.org/html/2606.29537v2
- **发布日期**：2026-06-28；v2 更新 2026-07-13
- **访问日期**：2026-08-08
- **版本/revision**：arXiv `2606.29537v2`
- **来源类型**：原始预印本 / benchmark 作者
- **评分**：Credibility **4/5**；Recency **5/5**；Bias **3/5**

## 与本研究直接相关的原文证据

> “difficulty should come from interdependent workflow structure rather than repetition or concatenated subtasks.”

论文 abstract、§3–4 与 tables 报告：共 108 end-to-end workflows；熟练人类 active operation median 约 1.6 小时，69.6% 超过一小时；Claude Opus 4.7 maximum-thinking rollout 平均 318 tool calls，而 OSWorld v1 约 30；最终 90% tasks 来自内部受训标注者。benchmark 涵盖 7 professional domains、21 subcategories、31 self-hosted services，任务平均涉及 2.44 applications、27.25 checkpoints。evaluator 优先 functional checks；model-based grader 只贡献总分的 11.53%，且单 task 最多 50%。每项任务经过 code-agent unit tests、两名独立人员重新执行、frontier-agent rollout、false-negative 与 reward-hacking audit。

## 证据解释与单位边界

- **[事实]** `108` 是 **workflow / runnable task instances** 的一一任务集合；不是 108 个 domains、submission 或 repeated trials。
- **[事实]** workflow 长度以熟练人类 active operation time 和 agent tool calls 两个不同量度报告；两者不能相互替代。
- **[事实]** 任务来源包括专业人士访谈、受训内部标注者、tutorials/docs/论坛与标注者经验。论文称访谈昂贵难扩展、问卷留存低；synthetic proposals 仅作 ideation，因为曾产生不真实 artifacts、浅层拼接和 reward-hacking 风险。
- **[作者主张]** 108 项“realistic end-to-end”与 domain authenticity 是作者经 QA 后的主张，尚缺独立职业效度研究。
- **[研究员推断]** 其明确排斥机械串联，直接支持 H2；但 Research & Education、Creative Production 占比超过 40%，不能据此推断广义劳动力代表性。
- **[事实]** 专家总人数、单位人工时、美元成本与稳定 repeated-run policy 为 **公开资料不足**。

## 支持或反驳的结论

- 支持 H1：真实性提高伴随专业访谈、服务托管、密集 checkpoints、双人复跑和 grader audit。
- 强支持 H2：作者把跨阶段依赖而非 repetition/concatenation 设为难度标准。
- 支持 H3：500-step budget、31 services、mixed graders 仍是成绩构成的一部分。
- 部分回应 H4：gated task logic 和 versioned release 优于完全公开静态集；但长期 rotation 频率仍未知。

## 限制

所有领先模型表现和“48× longer”均为作者定义与该 harness snapshot 下的结果；尚无独立复现，不可转成 1,000-task 配额或成本。
