# SpreadsheetBench 2 官方代码

- 标题：RUCKBReasoning/SpreadsheetBench-2
- 作者/机构：RUCKBReasoning
- URL：https://github.com/RUCKBReasoning/SpreadsheetBench-2
- 发布日期：2026
- 访问日期：2026-08-08
- 版本/revision：Git HEAD `599b24aa479242d39e1e50eb5a85830a823ffdfc`

## 与本问题直接相关的原文证据

- 英文短引（GitHub repository name field）："SpreadsheetBench-2."
- [事实] 仓库公开 Docker/runtime、task manifests、agent scaffold 和 evaluator，支持 321 个实例的本地运行。
- [事实] 环境限制无网络、50 turns；提交单位是 output workbook。一次 repository evaluation entry 可能对应 321 个 agent runs，不能称为 321 个 workflows。
- [事实] 程序化 evaluator 对 workbook 结构/单元格进行严格比较；visualization 使用另一路 multimodal judging。

## 解释、支持与反驳

- [研究员推断] 公开代码提高可复现性，同时允许 benchmark-specific tool/prompt/evaluator 优化；没有 hidden manifest 时长期 validity 风险高。
- [项目建议] 固定 container digest、LibreOffice 版本、scaffold commit、turn budget 和 retry policy；否则不同 leaderboard run 不可比。

## 评分

- Credibility：5/5（官方、commit-pinned）
- Recency：5/5
- Bias：3/5
