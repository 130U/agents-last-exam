# Terminal-Bench 2.0 dataset and Harbor surface

- 作者/机构：Terminal-Bench / Harbor Framework team
- URL：https://huggingface.co/datasets/harborframework/terminal-bench-2.0
- primary repo：https://github.com/harbor-framework/terminal-bench-2
- 发布日期：2025-11-07（2.0 announcement）
- 访问日期：2026-08-08
- 版本/revision：dataset `terminal-bench@2.0`；repo `main` commit `2fd12b88aafdd04a52c298e3940bcb189f9766d6`
- 类型：官方 dataset mirror + primary task repo

## 与本研究直接相关的原文证据

- HF lines 163–176：HF 页面声明 leaderboard 非官方、primary source 在 GitHub，并记录 mirror migration。
- lines 196–217：tasks 处于 containerized environments，通过 Harbor 下载并可用 oracle agent 执行。
- lines 246–248：每 task 有若干小时 human + LM-assisted validation；Harbor 为 reliability、observability、scalability、performance 重写 harness。
- Browser live snapshot：GitHub redirect 到 `harbor-framework/terminal-bench-2`，latest commit 为 `2fd12b88...`；目录展示逐 task folder。
- 原文短引："containerized environments"；"primary source for the benchmark"。

## 证据解释

- 2.0 task files、tests 与 oracle/reference solution 公开；没有独立 private holdout split 的公开证据。
- official leaderboard 需要记录 agent harness 和公开 verified trajectories；不应使用 HF 自动聚合 leaderboard 作为官方 benchmark result surface。
- repo current commit 可能晚于论文和 leaderboard run；复现必须 pin task repo 和 Harbor harness。

## 支持/反驳

- 支持：task package/schema 与 runner 分离有利于版本管理。
- 限制：公开 oracle 和开放网络环境扩大 contamination 与 reward-hacking attack surface。

## 评分

- Credibility：5/5（官方数据/代码）
- Recency：5/5（访问日 commit pin）
- Bias：4/5（维护者自述）
