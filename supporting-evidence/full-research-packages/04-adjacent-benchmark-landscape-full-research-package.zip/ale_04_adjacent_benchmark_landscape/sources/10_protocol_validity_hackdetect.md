# Do Agent Benchmarks Measure Capability? Protocol Validity in the Age of Agentic AI

- 作者/机构：Jiaqi Shao, Hanck Chen, Wei Zhang, Maxm Pan, Bing Luo
- URL：https://arxiv.org/html/2607.22368
- 发布日期：2026-07-24
- 访问日期：2026-08-08
- 版本：arXiv `2607.22368v1`
- 评分：Credibility **3/5**（新近未同行评审 preprint）；Recency **5/5**；Bias **4/5**

## 直接证据

- 原文短引（§3.2 evidence chain）：“Expose → Exploit → Mislead”。

- 论文把 protocol validity 定义为：evaluation protocol 必须让 intended capability 仍是成功的必要条件。
- 威胁链为 Expose → Exploit → Mislead；可能来自 public solution、evaluation artifact、generator structure、feedback manipulation 或 invalid scoring path。
- 作者审计 15 个 agent benchmarks/2,385 traces，并报告部分任务上的 exposure/reward-hacking 证据；这些数字只适用于其样本和判断流程。
- 建议从 trace evidence 做 post-hoc audit，而不是仅看 final score。

## 支持 / 反驳

- 支持 H3/H4 与 evaluator-red-team、trace provenance、shortcut audit。
- 反驳“有隐藏答案就足够”：protocol 中其他可见信息或可修改状态仍可能替代 intended ability。
- 不把论文的个别 benchmark 比例外推到 ALE；公开资料不足以证明 ALE 已通过同等独立 audit。
