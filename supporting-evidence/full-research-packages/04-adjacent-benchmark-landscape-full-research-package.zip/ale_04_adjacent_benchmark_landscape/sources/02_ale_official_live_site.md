# ALE official live site

- 标题：AI Agent Benchmark for Real-World Professional Workflows
- 作者/机构：Agents’ Last Exam / UC Berkeley RDI × RDI Foundation
- URL：https://agents-last-exam.org/
- 发布日期：页面未给出；living site
- 访问日期：2026-08-08
- 版本/revision：无公开 commit；按访问日冻结
- 评分：Credibility **4/5**；Recency **5/5**；Bias **2/5**（官方展示面）

## 直接证据

- 原文短引（homepage metric）：“1.5K+ Tasks Collected”。

- 2026-08-08 页面显示 **55 Sub-Industries Covered / 1.5K+ Tasks Collected / 300+ Experts**。
- 首页差异定位：Broadest Coverage、Verifiable Outcomes、Long-Horizon、Economically Valuable。
- task cards 展示 After Effects、Siemens NX、Unreal Engine、Moldex3D、Rhino 3D、FSLeyes 等专业软件。

## 支持 / 反驳

- 支持 ALE 的 live positioning 与软件覆盖展示。
- 反驳“canonical surfaces 数字稳定一致”：官网 `1.5K+ / 300+` 与 arXiv v2 `1,490 / 250+` 是不同日期与口径。
- 官网未给 1.5K+ 的 manifest 或 workflow/instance 定义，不能把它用作生产配额。
- “Broadest”等为机构主张，未独立验证。
