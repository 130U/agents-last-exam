# SpreadsheetBench 2 Hugging Face 数据

- 标题：KAKA22/SpreadsheetBench-v2
- 作者/机构：SpreadsheetBench 2 团队
- URL：https://huggingface.co/datasets/KAKA22/SpreadsheetBench-v2
- 发布日期：2026
- 访问日期：2026-08-08
- 版本/revision：HF git revision `9dea60025792fbac5928ce9f44812362dccbeecd`

## 与本问题直接相关的原文证据

- 英文短引（Hugging Face dataset ID field）："KAKA22/SpreadsheetBench-v2."
- [事实] HF 数据面公开 321 个 task instances 及其 workbook artifacts；与论文 v1 当前计数一致。
- [事实] 当前 card 未定义 public/private split、hidden test set、版本轮换或污染检测。
- [事实] 任务为可运行实例；同一 input workbook 的多次模型执行是 repeated agent trials，不会增加 task-instance count。

## 解释、支持与反驳

- 支持 H4 风险侧；公开静态 artifacts 能促进复现，也会促进过拟合与训练吸收。
- [项目建议] 对 1,000-task 项目只公开 schema、少量 dev instances 与 evaluator compatibility tests；保留轮换 holdout。

## 评分

- Credibility：5/5（官方 revision-pinned data）
- Recency：5/5
- Bias：3/5
