# OSWorld：官方 repo 与 OSWorld-Verified 当前实现面

- **标题**：xlang-ai/OSWorld — Code, environment and data for OSWorld
- **作者/机构**：XLANG Lab / OSWorld authors
- **URL**：https://github.com/xlang-ai/OSWorld
- **发布日期**：repository 2024 起；README 更新日志含 2025-07-28 OSWorld-Verified
- **访问日期**：2026-08-08
- **版本/revision**：Git commit `091f5ef1d5544bc74953c77875d5feb5bed30108`
- **来源类型**：官方代码仓库 / mutable implementation snapshot
- **评分**：Credibility **5/5**（实现事实）；Recency **5/5**；Bias **3/5**

## 与本研究直接相关的原文证据

> “We release OSWorld-Verified, a cleaned and verified version of OSWorld”

README 2025-07-28 update 称团队通过 manual examination 检查每个 task 和 evaluation metrics，并称 AWS 并行评测可在一小时内完成全套。setup 同时要求为部分任务配置 Google Drive、ownCloud、proxy 等服务，并警告缺失配置会造成 task failure 或 lower scores；任务数据与 evaluator 代码可公开取得。

## 证据解释与版本边界

- **[事实]** `OSWorld-Verified` 是原 OSWorld 家族的清理/验证版本面，不应与论文 v2 的原始 369-instance snapshot 合并成一个无版本数字。
- **[机构主张]** “under one hour”是团队在 AWS 并行配置下的基础设施能力主张，不是每次 run 的通用成本或 wall-clock 保证。
- **[事实]** repo 明示第三方账号、代理、云环境和任务数据配置会影响结果；这使 environment failure 与 agent capability failure 可能混淆。
- **[研究员推断]** 手工修正社区反馈说明原始 task/evaluator 并非一次发布即可冻结；Verified 提高内部有效性，但所有任务和 evaluator 仍公开，不能等同隐藏 holdout。
- **[事实]** 当前 repo 未提供统一的生产人工时、单 task 成本、固定 repeated-run policy；均为 **公开资料不足**。

## 支持或反驳的结论

- 强支持 H3：外部账号、网络、服务配置和 evaluator bug 均可制造非目标难度。
- 支持 H4：公开静态集合需要 Verified 修订，但修订不是持续隐藏轮换。
- 支持项目采用 versioned task manifest、environment preflight 和 infra-failure 单独记账。

## 限制

此文件记录 2026-08-08 repo HEAD；不能将 README 的当前说明回写为 2024 论文已具备的功能。
