# AI Agents That Matter

- 作者/机构：Sayash Kapoor, Benedikt Stroebl, Zachary S. Siegel, Nitya Nadgir, Arvind Narayanan；Princeton University
- URL：https://arxiv.org/html/2407.01502
- 发布日期：2024-07-01
- 访问日期：2026-08-08
- 版本：arXiv `2407.01502v1`
- 评分：Credibility **5/5**；Recency **3/5**；Bias **4/5**

## 直接证据

- 原文短引（§5 heading）：“Agent benchmarks enable shortcuts”。

- 论文把 agent evaluation 的缺陷归为：只看 accuracy、缺成本控制、model/downstream 需求混淆、holdout 不足、标准化与复现不足。
- survey 中 17 个 agent benchmarks 有 7 个无 holdout/无添加计划；已有 holdout 的 10 个中作者只判断 5 个与声明的 generality level 匹配。
- agent stochasticity 与高成本使 repeated evaluation 少见；作者五次复现实验发现报告值可能落在其五次运行范围之外。
- 对 WebArena 的案例指出公开静态任务可让开发者无意或有意优化 benchmark-specific shortcut。
- 论文建议 cost-controlled comparison、appropriate-level holdout、统一 evaluation practice，并把 accuracy 与 cost 画成 Pareto surface。

## 支持 / 反驳

- 支持 H3：scaffold、成本、重试和实现差异可被误归因给 capability。
- 支持 H4：holdout 必须与期望泛化层级匹配，单纯 held-out instance 未必防 workflow/task-level overfit。
- 支持 repeated-run 与 uncertainty 必须纳入交付标准。
- 限制：2024 调查快照早于 ALE 与多项 2026 benchmarks，不能直接描述它们的当前状态。
