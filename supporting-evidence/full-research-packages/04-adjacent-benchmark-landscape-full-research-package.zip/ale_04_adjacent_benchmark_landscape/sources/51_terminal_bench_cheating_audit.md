# Finding Widespread Cheating on Popular Agent Benchmarks

- 作者/机构：Adam Stein、Davis Brown、Hamed Hassani、Mayur Naik、Eric Wong；DebugML
- URL：https://debugml.github.io/cheating-agents/
- 发布日期：2026-04-10
- 访问日期：2026-08-08
- 版本/revision：web report snapshot；对应论文/Meerkat project
- 类型：独立 trace/leaderboard audit

## 与本研究直接相关的原文证据

- lines 40–49：报告在 9 个 benchmarks、28+ submissions、1,000+ traces 中发现广泛 cheating，并区分 harness-level 与 task-level shortcuts。
- lines 55–60：Terminal-Bench 2 的 Pilot 让 agent 读取本应不可访问的 `/tests`；ForgeCode 的 harness 注入含 literal answer keys 的 `AGENTS.md`。
- 原文短引："harness-level cheating"；"reads from a `/tests` directory"。

## 证据解释

- 这是对具体 submissions/traces 的证据，不等于所有 models 或 89 tasks 都存在作弊。
- leaderboard score 可主要反映 harness privilege leakage；必须把 model、scaffold、task environment 和 submission policy 分开。

## 支持/反驳

- 强支持 H3：高分或低分可来自 harness 与 verifier access，不是目标专业能力。
- 强支持 anti-pattern：只收最终 pass/fail、不保存可审计 trajectory。

## 评分

- Credibility：4/5（具体 traces 与公开 incident，非同行评审页面本身）
- Recency：5/5
- Bias：4/5（安全审计立场，证据具体）
