# EconEvals 独立经济代表性研究

- 标题：Economic Evaluations of Language Models
- 作者/机构：Alexander Wan、Stephane Hatgis-Kessell、Tomás Aguirre、Percy Liang、Rishi Bommasani；Stanford CRFM/HAI
- URL：https://arxiv.org/abs/2607.19375
- 发布日期：2026-06-26
- 访问日期：2026-08-08
- 版本/revision：arXiv `2607.19375v1`

## 与本问题直接相关的原文证据

- 英文短引（arXiv title field）："Economic Evaluations of Language Models."
- [独立学术证据] 论文指出 GDPval 的 44 个 occupations 少于 O*NET 职业总量的 5%，因此 occupation coverage 有限。
- [独立学术证据] EconEvals 用真实 public usage query 加 synthetic pipeline 扩展覆盖；作者报告其 benchmark production 比 GDPval 低成本约 500 倍，但这是作者比较主张，不是 GDPval 官方审计。
- [独立学术证据] 论文明确区分 task capability 与 labor-market impact：采用、组织整合、合规和责任等障碍不由 benchmark score 测量。
- [事实] EconEvals 自身 real-data pipeline 报告约 768 美元；不能把“500× cheaper”简单乘回 GDPval 总建设成本，因为成本口径和覆盖面不同。

## 解释、支持与反驳

- 支持 H1：更高覆盖/低成本与专业真实性存在 trade-off。
- [项目建议] 1,000-task 计划应先设 occupation sampling frame，再用 pilot 估算专家制作/复核时长；不采用独立论文的未审计点估算作合同预算。

## 评分

- Credibility：4/5（版本固定、独立学术来源）
- Recency：5/5
- Bias：4/5（提出竞争方法，但主动披露 synthetic quality 限制）
