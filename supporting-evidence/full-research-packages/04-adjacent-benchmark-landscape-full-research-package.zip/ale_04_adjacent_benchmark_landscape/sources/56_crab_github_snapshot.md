# CRAB official repository snapshot

- 作者/机构：camel-ai / CRAB maintainers
- URL：https://github.com/camel-ai/crab
- 发布日期：持续维护
- 访问日期：2026-08-08
- 版本/revision：branch `main`，commit `c0790b0d55e3c870f1c603c851dd4ca8625ed07a`
- 类型：官方代码、task dataset、evaluator implementation

## 与本研究直接相关的原文证据

- Browser live DOM：latest commit `c0790b0...`；repo 含 `crab-benchmark-v0/`；页面显示 3 tags。
- repo/project surface 暴露 framework code、agent code、task dataset；task/evaluator 以 Python/Pydantic/NetworkX 图实现（与论文 Appendix 对照）。
- 原文可定位：GitHub commit URL `/camel-ai/crab/commit/c0790b0d55e3c870f1c603c851dd4ca8625ed07a`。
- 原文短引："crab-benchmark-v0"；"Cross-environment Agent Benchmark"。

## 证据解释

- current repo commit 晚于 2024-10-18 release；没有 tag-to-paper inventory audit 时，不应把 main 当作论文实验的严格复现 revision。
- public task definitions/evaluators 意味着没有 hidden holdout 的公开证据；contamination/benchmark-specific optimization 风险存在。
- repeated-run policy、human success baseline、完整 benchmark run cost：公开资料不足。

## 支持/反驳

- 支持项目建议：task/evaluator graph 应有 immutable release manifest，而不是只引用 rolling `main`。
- 支持 H4：公开静态 task/evaluator 没有 rotation policy 时需要单独私有 holdout。

## 评分

- Credibility：5/5（官方代码）
- Recency：5/5（访问日 commit pin）
- Bias：4/5
