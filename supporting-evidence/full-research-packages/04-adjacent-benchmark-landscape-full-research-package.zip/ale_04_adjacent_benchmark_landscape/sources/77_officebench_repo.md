# OfficeBench 官方代码与数据

- 标题：zlwang-cs/OfficeBench
- 作者/机构：OfficeBench authors
- URL：https://github.com/zlwang-cs/OfficeBench
- 发布日期：2024
- 访问日期：2026-08-08
- 版本/revision：Git HEAD `b978b808667c32b52ce19a67ce1def1de9ae02b7`

## 与本问题直接相关的原文证据

- 英文短引（GitHub repository name field）："OfficeBench."
- [事实] 仓库公开 300 个 tasks、Dockerized application tools 与 evaluator；license 为 Apache-2.0。
- [事实] task data 全公开，未见 private/pending-QC split、sealed reference、rotation manifest 或 contamination audit。
- [事实] tool wrappers 规定 agent 可执行的 action vocabulary；无法通过 wrapper 的现实操作不会被 benchmark 测量。

## 解释、支持与反驳

- [研究员推断] 可复现性强，但公开静态 task/evaluator 允许 benchmark-specific prompt/tool routing；长期 score 不能独立证明 office-work generalization。
- [项目建议] 对 1,000-task 项目记录 `environment_manifest + tool_schema + evaluator_version + run_policy`，并保留私有变体。

## 评分

- Credibility：5/5（官方 commit-pinned repo）
- Recency：5/5（访问日固定 HEAD）
- Bias：3/5
