# RLI Hugging Face public set

- 标题：cais/rli-public-set
- 作者/机构：Center for AI Safety
- URL：https://huggingface.co/datasets/cais/rli-public-set
- 发布日期：2025
- 访问日期：2026-08-08
- 版本/revision：HF git revision `9082f6552f35a12b4c792959d8352d092de35404`

## 与本问题直接相关的原文证据

- 英文短引（Hugging Face dataset ID field）："cais/rli-public-set."
- [事实] 数据面是 10 个 public runnable task instances，不等于论文的 240-task benchmark snapshot。
- [事实] 实例结构包含 task brief、input artifacts 和人类参考 deliverable，支持文件级产出而非只答文本。
- [事实] 该公开 revision 未给出 230 个 private instances、轮换 cadence 或未来污染刷新计划。

## 解释、支持与反驳

- 支持 H4 的风险侧：公开集可被定向优化；RLI 的长期有效性主要依赖 private set 管理。
- [项目建议] 不要把 public set 数量作为生产 quota；它是开发/格式兼容样本。

## 评分

- Credibility：5/5（官方、revision-pinned dataset）
- Recency：5/5
- Bias：3/5
