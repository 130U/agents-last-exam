# SpreadsheetBench 官方项目页

- 标题：SpreadsheetBench
- 作者/机构：SpreadsheetBench 团队
- URL：https://spreadsheetbench.github.io/
- 发布日期：2024；2026 页面含 SpreadsheetBench 2 更新
- 访问日期：2026-08-08
- 版本/revision：live site snapshot；浏览器实测页面标题 `SpreadsheetBench`

## 与本问题直接相关的原文证据

- 英文短引（live page title field）："SpreadsheetBench."
- [事实] 项目页同时承载 2024 SpreadsheetBench 与 2026 SpreadsheetBench 2 的家族入口。
- [事实] V1 是 912 个论坛来源 spreadsheet manipulation questions；后续 verified subset 为 400。V2 是 321 个端到端 business workbook instances。
- [事实] V1/V2 的 task construct、数据来源与 evaluator 不同，不能把 912、400、321 相加成当前 benchmark 配额。

## 解释、支持与反驳

- [研究员推断] 本 landscape 的 professional workflow 列采用 V2；V1 仅作为版本前史。
- [项目建议] benchmark family 必须有 release manifest，而不是用项目页标题隐含版本。

## 评分

- Credibility：4/5（官方项目页）
- Recency：5/5（live snapshot）
- Bias：3/5
