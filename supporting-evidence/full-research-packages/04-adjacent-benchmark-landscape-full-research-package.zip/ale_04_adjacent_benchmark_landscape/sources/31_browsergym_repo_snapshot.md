# BrowserGym：统一 harness / environment 层

- **标题**：ServiceNow/BrowserGym — A Gym environment for web task automation
- **作者/机构**：ServiceNow Research 与 BrowserGym contributors
- **URL**：https://github.com/ServiceNow/BrowserGym
- **发布日期**：2024 起；相关 ecosystem 论文发表于 TMLR 2025
- **访问日期**：2026-08-08
- **版本/revision**：commit `9e779f087de9a65668b6974d11f9ce9816026e96`
- **来源类型**：官方 framework repo / mutable implementation snapshot
- **评分**：Credibility **5/5**（framework 实现事实）；Recency **5/5**；Bias **3/5**

## 与本研究直接相关的原文证据

> “open, easy-to-use and extensible framework”

README 当日列入 MiniWoB、WebArena、WebArenaVerified、VisualWebArena、WorkArena、AssistantBench、WebLINX、OpenApps；不同 benchmark 分别安装 package 并遵循各自 setup。新增 benchmark 通过继承 `AbstractBrowserTask` 接入。相同框架提供 Gym reset/step/termination 接口、Playwright 和 experiment utilities。

## 证据解释与单位边界

- **[事实]** BrowserGym 是 **harness/framework**，不是与 WebArena/WorkArena/AssistantBench 同层级的 task corpus benchmark。
- **[事实]** 统一 API 并不统一各 benchmark 的 task source、evaluator、site hosting、hidden split 或 human baseline；这些仍由各 package 决定。
- **[研究员推断]** framework 标准化能减少实验 plumbing 差异，却也可能改变 observation（DOM/screenshot）、action schema、truncation 和 error handling；跨 leaderboard 仍必须 pin BrowserGym commit/package versions。
- **[事实]** repo 自称 research framework，“not meant to be a consumer product”；production SLA、安全隔离、每-run 成本为 **公开资料不足**。
- **[事实]** AssistantBench test 需要另行提交 hidden predictions；WebArena/WorkArena 则需要各自服务部署。public/private policy 不能从 BrowserGym 总表推断。

## 支持或反驳的结论

- 支持 H3：harness 是测量系统组成部分，不能把 benchmark 分数归因于裸模型。
- 对 H1 提供工程缓解：共享 framework 降低整合成本，但不能自动修复 evaluator validity。
- 对 H4 中性：framework 可承载版本化任务，却不自行提供隐藏 holdout 或轮换。

## 限制

此来源用于定义运行层与 benchmark corpus 的边界；不应引用它证明某一 corpus 的真实性或有效性。
