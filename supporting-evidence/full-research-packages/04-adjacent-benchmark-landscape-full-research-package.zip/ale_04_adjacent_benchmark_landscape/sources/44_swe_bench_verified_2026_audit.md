# Why SWE-bench Verified no longer measures frontier coding capabilities

- 作者/机构：OpenAI
- URL：https://openai.com/index/why-we-no-longer-evaluate-swe-bench-verified/
- 发布日期：2026-02-23
- 访问日期：2026-08-08
- 版本/revision：live article snapshot；2026-02-23
- 类型：创建合作方的后续审计/撤回使用建议

## 与本研究直接相关的原文证据

- lines 43–48：作者指出两个 major issues：tests 拒绝功能正确解，以及模型训练暴露于公开 issue/gold patch；因此不再用于 frontier launch capability progress。
- lines 52–62：原始 scoring 要求 `FAIL_TO_PASS` 与 regression tests 全部通过；环境差异也会造成 spurious failure；Verified 由每题三名专家独立审查后得到 500 instances。
- lines 65–69：对 138 个 o3 在 64 次独立 runs 中不稳定失败的问题审计，至少 59.4% 有 material issue；35.5% tests 过窄，18.8% 过宽。
- lines 260–278：公开 repo、release notes、tasks 和 gold patches 造成 contamination risk；作者做了跨模型 red-team probing。
- 原文短引："no longer suitable"；"all tests pass"。

## 证据解释

- 138 是经过 failure-conditioned 选择的 audited subset，不是对 500 的无偏缺陷率估计；59.4% 不能外推成 Verified 全集配额。
- 64 是每个候选问题的独立 o3 runs，用来识别“不稳定未解”样本；不是 benchmark 的官方 repeated-run policy。
- 这是 OpenAI 对其共同创建的 Verified surface 的自我修正，可信但仍需与独立学术审计交叉验证。

## 支持/反驳

- 强支持 H4：公开静态 issue、gold solution 与 tests 使长期有效性衰减。
- 强支持 H3：test strictness 与 environment configuration 会制造非能力失败。
- 反驳“人工 Verified 即永久可靠”。

## 评分

- Credibility：5/5（有样本设计、具体任务与审计方法）
- Recency：5/5（2026 审计）
- Bias：4/5（创建合作方主动否定既有推荐，但同时推荐自家后续 eval）
