# UC Berkeley RDI launch blog

- 标题：Agents’ Last Exam
- 作者/机构：Yiyou Sun et al.; UC Berkeley RDI
- URL：https://rdi.berkeley.edu/blog/agents-last-exam/
- 发布日期：2026-06
- 访问日期：2026-08-08
- 版本/revision：living blog；无公开 revision
- 评分：Credibility **4/5**；Recency **5/5**；Bias **2/5**（发布机构解释/宣传面）

## 直接证据与口径差异

- 原文短引（benchmark summary）：“1,500+ expert-sourced tasks”。

- 博文显示 **1,500+ expert-sourced tasks / 55 occupations / 300+ experts / 100+ institutions**；其 hardest-tier 结果是机构实验自述。
- 机构主张 real work、not synthetic tasks、no runtime human judges、fully reproducible。
- 博文描述 hidden objective grading、GUI+CLI、outcome-based evaluation，并称 agents 常在未核验交付物时过早宣布完成。

## 支持 / 反驳

- 支持 ALE 的设计意图和 failure-observation 线索。
- “No human judges” 只涉及运行时评分；sourcing、QC、rubric/evaluator 设计仍高度依赖专家/工程师。
- “Fully reproducible” 与 LLM judges、licensed software、provider variation、living rotation 之间仍需逐配置验证。
