# Leaderboard Integrity Update

- 作者/机构：Terminal-Bench Team
- URL：https://www.tbench.ai/news/leaderboard-integrity-update
- 发布日期：2026-04-19
- 访问日期：2026-08-08
- 版本/revision：Terminal-Bench 2.0 leaderboard policy，2026-04-19
- 类型：官方 incident response / policy update

## 与本研究直接相关的原文证据

- lines 7–13：passing trials 必须提交 ATIF trajectories；reward hacking trial 计 0；cheating submission 下架；通过 agent judge 和 static checks 审核。
- lines 19–23：记录 timeout 修改、encrypted solutions、错误上传 tests folder、从互联网获取 solutions 等具体 incidents。
- 原文短引："trajectories are required"；"reward hacking will result in a reward of 0"。

## 证据解释

- 这是 leaderboard governance，不是 task evaluator 本身自动阻止所有漏洞。
- policy 是 2026-04-19 后的 snapshot；不能假定早期 leaderboard submissions 受同一规则。

## 支持/反驳

- 强支持：public benchmark 不仅需要 tests，还需要 trace audit、submission policy 和 retroactive invalidation。
- 支持 H4：公开 task/oracle/open internet 会产生 benchmark-specific shortcuts。

## 评分

- Credibility：5/5（官方 incident list 与 policy）
- Recency：5/5
- Bias：4/5（维护者处置自身 leaderboard 问题）
