# GAIA：Hugging Face 当前数据版本面

- **标题**：gaia-benchmark/GAIA dataset card
- **作者/机构**：GAIA benchmark team / Hugging Face
- **URL**：https://huggingface.co/datasets/gaia-benchmark/GAIA/tree/682dd723ee1e1697e00360edccf2366dc8418dd9
- **发布日期**：2023-11；dataset format 于 2025-10 更新
- **访问日期**：2026-08-08
- **版本/revision**：HF commit `682dd723ee1e1697e00360edccf2366dc8418dd9`
- **来源类型**：官方数据仓库 / pinned snapshot
- **评分**：Credibility **5/5**；Recency **5/5**；Bias **3/5**

## 与本研究直接相关的原文证据

> “We added gating to prevent bots from scraping the dataset.”

dataset card 当日描述“more than 450” questions，三 levels；每 level 有 fully public dev/validation 面和 test split，后者 answers/metadata private。访问条件要求不把 validation/test 以 crawlable 形式重新发布。2025-10 起使用 Parquet-backed splits，字段包括 `task_id`、`Question`、`Level`、`Final answer`、`file_name/file_path`、`Annotator Metadata`。

## 证据解释与版本边界

- **[事实]** 当前 HF card 的“>450”和 split/schema 是 2026 snapshot；不能无说明地与 2023 paper 的 466/retained-300 合并。
- **[事实]** gating 是 anti-scraping/terms control；validation answers 已在可访问数据中，test answers/metadata private。二者污染风险不同。
- **[事实]** file attachments 使 task 运行依赖完整 snapshot；只保存 question text 会改变 evaluation input。
- **[研究员推断]** 接受 gating 不等于数据未进入训练集，也不等于每个 submitter 未人工解答 test；需 submission provenance、rate limits、attestation 和新任务轮换共同控制。
- **[事实]** 当前公开 card 未给固定 repeated-run aggregation、per-run tool budget 或 API cost。

## 支持或反驳的结论

- 部分支持 H4 的缓解：private test answers 优于完全公开答案；但 public questions、长期固定 test 和可人工求解仍使污染/leaderboard overfitting 未消失。
- 支持 version matrix：paper count、current dataset count、leaderboard subset 必须分别列。
- 支持交付 schema 包含 immutable data revision 和 attachment checksum。

## 限制

HF dataset card 是官方数据事实，不提供独立 evaluator-validity 结论；“prevent bots”是目的陈述而非效果测量。

