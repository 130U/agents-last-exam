# WebArena：官方 repo 当前实现面

- **标题**：web-arena-x/webarena — WebArena code and environment
- **作者/机构**：WebArena authors
- **URL**：https://github.com/web-arena-x/webarena
- **发布日期**：2023；README 记录 `v0.2.0` 于 2023-10-24 更新
- **访问日期**：2026-08-08
- **版本/revision**：commit `dce04686a56253aefba7b18a4fa0937cf1dc987b`
- **来源类型**：官方代码仓库 / mutable snapshot
- **评分**：Credibility **5/5**；Recency **5/5**；Bias **3/5**

## 与本研究直接相关的原文证据

> “After running all 812 examples, reset the environment to the initial state.”

README 将并行实验、统一 benchmark/leaderboard 和 edge-case 改善作为 BrowserGym/AgentLab 推荐理由；2023-10-24 的 `v0.2.0` update 称修复当时已报告的 annotation errors；并给出多个 Docker/self-hosted service、账号与 URL 的 setup。

## 证据解释与版本边界

- **[事实]** 当前 repo 是实现 surface；论文 v4、repo `v0.2.0`、2026 HEAD 不能当作同一静态版本。
- **[事实]** 812-instance 批量运行后需要环境 reset；若在中途失败、残留 state 或使用不同 reset 策略，会改变后续 instances。
- **[事实]** 所有 task configs/evaluators 公开；没有 repo 层面的 hidden test split。
- **[机构主张]** “fixing all reported annotation errors so far”只表示当时已知问题处理，不证明 evaluator 无 false positives/negatives。
- **[研究员推断]** 推荐外部 harness 意味“WebArena 分数”至少还需固定 observation、action space、browser driver、prompt、budget、retry、framework commit，不能只报 model name。
- **[事实]** repo 未规定跨团队统一 repeated trials，也未披露完整 infra/LLM 成本。

## 支持或反驳的结论

- 支持 H3：环境初始化、framework 和 task version 都是结果混杂项。
- 支持 H4：公开 task/evaluator 便于复现，也提高 lookup 和 benchmark-specific tuning 风险。
- 支持 1,000-task 项目将 environment reset test、state leakage test、harness manifest 设为交付项。

## 限制

repo README 能证明部署要求，不能单独证明任务真实性、human baseline 或当前 leaderboard 可比性。
