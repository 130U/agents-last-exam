# Windows Agent Arena: Evaluating Multi-Modal OS Agents at Scale

- 作者/机构：Rogerio Bonatti、Dan Zhao、Francesco Bonacci 等；Microsoft 等
- URL：https://arxiv.org/html/2409.08264v2
- 发布日期：2024-09-12；修订：2024-09-13
- 访问日期：2026-08-08
- 版本/revision：arXiv `2409.08264v2`
- 类型：原始论文

## 与本研究直接相关的原文证据

- arXiv abs lines 8–30：v2 current revision；150+ tasks 的 abstract surface。
- full paper lines 24、47–49、150–154：正式 inventory 为 154 task instances，1 task/template，覆盖 Office、web、Windows System、VS Code、VLC、utilities。
- lines 76、161–164：每 task deterministic initial-state script；final device-state evaluator；Windows 11 VM in Docker + Flask bridge。
- lines 161、216–224：human success 74.5%，best Navi 19.5%；performance 对 UIA/SoM/screen parser 高度敏感。
- lines 552–560：overall human task steps 与 perceived difficulty 相关 0.23，与 success rate 相关 -0.11；step count 不是难度/long-horizon 的充分代理。
- 原文短引："154 diverse and realistic multi-step tasks"；"device state"。

## 证据解释

- 154 是 runnable task instances，不是 154 workflows 或 154 repeated trials。
- human 74.5% 是 measured success baseline；但 paper 没有公开统一的 repeated-run leaderboard policy。
- 任务基于真实 Windows/apps，但 initial state 和 task objective 是 benchmark-authored；“real OS”不等于自然发生的真实工作记录。

## 支持/反驳

- 强支持 H2：paper 自身的低 step–difficulty/success correlation 说明 step length 不是 long-horizon validity 代理。
- 支持 H3：UIA/SoM 质量能显著改变同一 model 的结果，harness/perception 是 construct 的一部分。

## 评分

- Credibility：5/5（版本化原始论文）
- Recency：4/5（2024 release，repo 后续变化）
- Bias：4/5（创建者论文，实验细节充分）
