# OpenAI GDPval 官方介绍

- 标题：GDPval: Measuring the performance of AI models on real-world tasks
- 作者/机构：OpenAI
- URL：https://openai.com/index/gdpval/
- 发布日期：2025-09-25
- 访问日期：2026-08-08
- 版本/revision：live official article snapshot，2026-08-08

## 与本问题直接相关的原文证据

- 英文短引（official article title field）："Measuring the performance of AI models on real-world tasks."
- [事实] 官方文章把当前工作称为 GDPval 的 first version，聚焦 44 个美国职业中的知识工作 deliverables。
- [作者主张] 文章认为它比传统考试更接近“economically valuable work”；这是 construct 主张，不是就业替代的独立因果验证。
- [事实] 官方页面说明 gold tasks 由有经验的职业人员创建和 review，模型产出与 human output 比较。

## 解释、支持与反驳

- [研究员推断] 新闻稿中的经济意义定位应由论文采样和 evaluator 证据约束；不能把 44 个职业外推为全部经济活动。
- [项目建议] 产品文案应区分“职业相关 deliverable performance”和“worker/job automation”。

## 评分

- Credibility：4/5（官方一手说明）
- Recency：4/5
- Bias：2/5（公司产品/研究宣传）
