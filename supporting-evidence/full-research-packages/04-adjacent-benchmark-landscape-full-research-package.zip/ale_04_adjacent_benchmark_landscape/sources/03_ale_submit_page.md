# ALE submission guide

- 标题：Agents’ Last Exam is Defined by Domain Experts
- 作者/机构：Agents’ Last Exam
- URL：https://agents-last-exam.org/submit
- 发布日期：页面未给出；living guide
- 访问日期：2026-08-08
- 版本/revision：无公开 revision；按访问日冻结
- 评分：Credibility **5/5**（征集一手规范）；Recency **5/5**；Bias **3/5**

## 直接证据

- 原文短引（How to Prepare Your Submission）：“Every task submission follows a consistent structure.”

- 准入：Complex、Representative、Verifiable。
- Complex 操作化为专家 days, not minutes；`<10 steps` 的单一局部编辑是 bad example，但无全 corpus 人类时长分布。
- Representative 要求真实 industry workflow 与合适的 professional tools。
- Verifiable 依次优先唯一确定 output、numerical metric、简单证据问题的 screenshot/rubric；最后才从项目文件协助拆出可验证 subtask。
- submission 五部分：Task Description、Input、Software、Output、Evaluation。
- 激励包括 co-authorship qualification 与 monetary awards，但没有公开单项 compensation 或生产成本。

## 支持 / 反驳

- 支持 H2：长程不是动作数，而是端到端、专业工具、多阶段交付。
- 支持 H1：开放式专业工作需被工程化为可判定 artifact/rubric。
- 五部分只定义 expert submission schema，不能替代 implementation、dry run 与 final QC。
