# Agents’ Last Exam — arXiv v2

- 标题：Agents’ Last Exam
- 作者/机构：Yiyou Sun et al.; leading institution UC Berkeley
- URL：https://arxiv.org/html/2606.05405v2
- 首次提交：2026-06-03
- 本版修订：2026-06-11
- 访问日期：2026-08-08
- 固定版本：arXiv `2606.05405v2`
- 评分：Credibility **5/5**；Recency **5/5**（immutable revision）；Bias **3/5**（作者自述，方法信息强但有效性主张有利益相关）

## 直接证据

- 原文短引（§2.1）：“The key distinction is between a workflow and an action.”

- 摘要把 ALE 定义为 long-horizon、economically valuable、real-world 且结果可验证的 benchmark；`<1%` hardest-tier average full-pass 是作者实验结论。
- §2.1 准入原则：representativeness、complexity、verifiability；complexity 强调 end-to-end deliverable，而不是少量 UI 操作。
- §2.3/Figure 5：**1,490 runnable task instances**；来源为 **960 external-submission instances + 530 commissioned instances**；release state 为 **150 public / 1,017 private / 323 pending QC**。
- §3：`task workflow` 是端到端专业过程；`task instance` 是共享同一 `evaluate()` 但 input/output 不同的 runnable case。
- Appendix C.3.7 另报 **960 task workflows / 1,490 task instances**。这里的 `960 workflows` 不能自动等同 Figure 5 的 `960 external submissions`。
- runnable instance 绑定 `load()`、`start()`、`evaluate()`、输入、软件/环境、隐藏 reference 和 `[0,1]` evaluator；agent 是 **harness + foundation model**。
- evaluator modes：exact/hash、structured tabular、geometric、visual、behavioral state、free text、executable artifact；开放 reference task tree 静态分析称 **93.2% workflow code-based / 6.8% LLM-judge**，不是私有 1,490-instance 全池统计。
- 论文称约 10% 公开、私有池滚动轮换；公开代表性只用一个配置的 cluster-level correlation 做内部检验，不能证明对所有 agent/configuration 代表。
- Table 1 的 `±` 来自同一 instance 的三次独立运行，且只覆盖部分 configurations；不存在统一全量 repeated-run policy。
- 文内出现 150 selected public、152-task public set、HF 153 rows，以及 tier 标称 67/55/38；必须保持为不同表面/selection 快照。
- Appendix D 承认 infrastructure、GUI/browser、timeout/resource 与 harness 会影响结果；五小时 cap 是 evaluation condition。

## 支持 / 反驳

- 支持 H1：作者明确把 realism、breadth、verifiability 描述为结构性取舍，但这是作者比较框架。
- 支持 H2：明确区分 workflow 与 single action，并给出 coupled multi-stage deliverable。
- 支持 H3：environment、harness、budget、timeout 与 evaluator 均进入观测结果。
- 支持 H4：作者采用 private pool + rotation；长期效果尚未独立验证。

## 边界

- **[事实]** 版本、术语、生命周期、论文内数字与实验设置。
- **[作者主张]** real/economically valuable、broadest coverage、public subset representative、far from saturated。
- **[研究员推断]** 分数是 pinned agent system × environment × budget × evaluator 的联合结果。
