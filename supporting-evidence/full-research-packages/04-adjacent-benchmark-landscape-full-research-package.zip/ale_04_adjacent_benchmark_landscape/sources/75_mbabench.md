# MBABench：专业 spreadsheet validity 对照

- 标题：MBABench: Evaluating AI Agents on Real-World Professional Spreadsheets
- 作者/机构：论文署名团队
- URL：https://arxiv.org/abs/2605.22664
- 发布日期：2026-05；当前 revision 2026-06-22
- 访问日期：2026-08-08
- 版本/revision：arXiv `2605.22664v4`；早期检索/页面曾出现 `WorkstreamBench` 名称，不作为另一 benchmark 计数

## 与本问题直接相关的原文证据

- 英文短引（arXiv title field）："Evaluating AI Agents on Real-World Professional Spreadsheets."
- [独立学术证据] 论文把专业 spreadsheet quality 分为 Accuracy、Formula、Format/可读性与可编辑性；单纯 exact value 可能把 hard-coded、脆弱或 off-by-one workbook 误判为可接受。
- [事实] evaluator 以 408 个 expert annotations 校验，报告 accuracy 0.92、balanced accuracy 0.88、F1 0.85。
- [事实] 数据生产由 2 名 MBA 与 3 名 finance professionals 参与，累计 700+ 小时。
- [事实] proprietary GUI agents 与 API/tool agents 的表现/失败方式不同，表明 harness 选择影响测量。

## 解释、支持与反驳

- 支持 H1/H3：professional quality 需要多维 evaluator，且 harness 会混入难度。
- [研究员推断] 若 landscape 只能保留一个“专业文件质量”补充项，MBABench 比 OfficeBench 更接近专业 spreadsheet auditability；但它与 SpreadsheetBench 2 都偏 finance，不能声称覆盖通用 office work。
- [项目建议] 优先“SpreadsheetBench 2 + MBABench evaluator dimensions”；OfficeBench 仅保留为 synthetic cross-app tool-routing 对照。

## 评分

- Credibility：4/5（版本固定的相邻 primary paper）
- Recency：5/5
- Bias：3/5（提出自有 benchmark，但有专家校验）
