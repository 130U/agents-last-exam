# CRAB: Cross-environment Agent Benchmark for Multimodal Language Model Agents

- 作者/机构：Tianqi Xu、Linyao Chen、Dai-Jie Wu 等；KAUST、Eigent.AI、UTokyo、CMU 等
- URL：https://arxiv.org/abs/2407.01511
- 发布日期：2024-07-01；最后修订：2025-07-20
- 访问日期：2026-08-08
- 版本/revision：arXiv `2407.01511v4`；ACL Findings 2025
- 类型：原始论文

## 与本研究直接相关的原文证据

- arXiv abs lines 8–29：v4 current abstract 声称 120 tasks，best completion ratio 38.01%；v1–v4 revision history 明确。
- full-text extraction lines 19–25：graph evaluator 将 task 分解为 sub-goals/judge functions，并以 sub-task composition 构造跨环境任务。
- lines 137–144：16 Android + 19 Ubuntu templates；每 sub-task 至少两名相关领域专家验证；human mode 运行 evaluator；正文 composition 为 35 single + 53 simple + 12 challenging = 100 tasks。
- lines 291–315、342–378：evaluator 是返回 boolean 的 Python action；task graph 是多个 evaluator functions 的 DAG；JSON 保存 task/sub-task/adjacency list。
- 原文短引："graph evaluator"；"verified by at least two related field experts"。

## 证据解释

- 当前 arXiv v4 内部存在数量漂移：abstract=120，但可提取正文的 composition=100。不能擅自统一；应以 release-tagged dataset/repo manifest 作为 runnable inventory。
- task composition 把 sub-tasks 串成 DAG，提供 cross-environment dependency；但组合本身不证明是完整职业 workflow。
- graph completion ratio 是 evaluator-node credit；binary success rate 仍是全 task 完成。

## 支持/反驳

- 支持 H1：细粒度可自动验证依赖显式、可查询的 intermediate states，开放性越高越难覆盖。
- 部分反驳 H2 的最强版本：CRAB 至少展示跨 Android→Ubuntu 信息依赖，不只是无关 GUI steps 拼接；但职业真实性证据仍不足。

## 评分

- Credibility：5/5（原始论文）
- Recency：5/5（v4 pinned）
- Bias：3/5（创建者论文，且正文/abstract 数量不一致）
