# METR Task-Completion Time Horizons 1.1

- 作者/机构：METR
- URL：https://metr.org/time-horizons/
- 页面最后更新：2026-05-08
- 访问日期：2026-08-08
- 版本：Time Horizon 1.1 living snapshot
- 评分：Credibility **4/5**；Recency **5/5**；Bias **4/5**

## 直接证据

- 原文短引（task definition FAQ）：“a 1-hour task done 1000 times”。

- human time 主要来自受雇 skilled humans 成功完成任务的 geometric mean；大多与 agent 同 instructions/affordances。
- task suite 主要为 software engineering、ML、cybersecurity；因此不能外推到所有职业。
- METR 明确说 task duration 是人类完成时长，不是 agent 连续自治时间。
- coherent task 不能被轻易拆成并行独立子问题；“1000 个一小时问题”仍是 1-hour task repeated 1000 times。
- 典型 long task 是 stateful iterative debugging：每次修复暴露新问题，后续依赖之前尝试。
- 当前 protocol：小 dev set 选 scaffold，分离 test set；每 task 6 independent runs；reward-hack 自动+人工审查。
- 页面承认 human durations 可能高估日常熟悉情境下专业人士所需时间，超过 16 小时的估计不可靠。

## 支持 / 反驳

- 强支持 H2：long-horizon 需要不可平凡并行拆分的依赖链，而不是操作总数。
- 支持 repeated-run policy、dev/test separation、matched affordances 与 reward-hack review。
- 反驳把 human-time label 当作经济代表性或 job automation；METR 自身明确否认。
