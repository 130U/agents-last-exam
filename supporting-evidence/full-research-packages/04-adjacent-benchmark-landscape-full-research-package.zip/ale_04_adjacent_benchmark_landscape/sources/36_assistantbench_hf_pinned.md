# AssistantBench：Hugging Face 数据版本面

- **标题**：AssistantBench/AssistantBench dataset
- **作者/机构**：AssistantBench authors
- **URL**：https://huggingface.co/datasets/AssistantBench/AssistantBench/tree/482cbbc0400f6d048438c4021727f21a10cbff49
- **发布日期**：2024
- **访问日期**：2026-08-08
- **版本/revision**：HF commit `482cbbc0400f6d048438c4021727f21a10cbff49`
- **来源类型**：官方数据仓库 / pinned snapshot
- **评分**：Credibility **5/5**；Recency **5/5**；Bias **3/5**

## 与本研究直接相关的原文证据

> “validation · 33 rows”

固定 revision 的文件面包含 `assistant_bench_v1.0_dev.jsonl` 与 `assistant_bench_v1.0_test.jsonl`。Dataset Viewer 显示两 splits；validation/dev 33 rows，字段含 `id`、`set`、`task`、`answer`、`gold_url`、`explanation`、`metadata`、`difficulty`。公开 validation 行可见 gold answer、URLs 和 explanation。

## 证据解释与版本边界

- **[事实]** `33` 是 current public **validation runnable instances**，不是 AssistantBench 全部 214 tasks。
- **[事实]** validation 中 ground truth 公开，适合开发/诊断，不适合作为长期主 leaderboard 的无污染 holdout。
- **[事实]** test JSONL 的存在不等于 test answers 全公开；提交/评分权限需结合 leaderboard/BrowserGym 文档判断。
- **[研究员推断]** `gold_url` 是创建时证据而非永久 snapshot；网页内容、价格、可售性、位置与 API 都会漂移。应保存 retrieved evidence snapshot、as-of date 与 refresh status。
- **[事实]** 数据 card 没有记录 repeated-trial policy、运行预算、human baseline 或 per-task production cost。

## 支持或反驳的结论

- 支持 H4：开发集答案公开，必须与 private test/rolling fresh tasks 分离。
- 支持 H1：结构化 closed-form answers 方便自动评分，但 live web provenance 仍需维护。
- 支持 version matrix：论文 214、HF validation 33、leaderboard当前运行 33 是相关但不同单位/集合。

## 限制

HF Viewer 是 current mutable surface；本文件以 commit 固定，但第三方网站内容并未随 HF revision 自动冻结。

