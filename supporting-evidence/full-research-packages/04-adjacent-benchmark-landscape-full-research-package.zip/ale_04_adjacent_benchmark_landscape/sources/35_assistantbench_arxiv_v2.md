# AssistantBench：论文版本面

- **标题**：AssistantBench: Can Web Agents Solve Realistic and Time-Consuming Tasks?
- **作者/机构**：Ori Yoran、Samuel Joseph Amouyal、Chaitanya Malaviya、Ben Bogin、Ofir Press、Jonathan Berant；Tel Aviv University、University of Washington 等（按论文署名）
- **URL**：https://arxiv.org/abs/2407.15711v2
- **发布日期**：2024-07-22；v2 更新 2024-10-21
- **访问日期**：2026-08-08
- **版本/revision**：arXiv `2407.15711v2`；EMNLP 2024 main conference
- **来源类型**：原始论文 / benchmark 作者
- **评分**：Credibility **5/5**；Recency **5/5**（pinned）；Bias **3/5**

## 与本研究直接相关的原文证据

> “214 realistic tasks that can be automatically evaluated”

论文将 task unit 定义为 open-web information seeking：问题需要人类浏览数分钟，最终输出 closed-form answer；不是在业务软件中完成有持久副作用的 workflow。214 unique tasks 的论文口径为：18 位初始参与者贡献 70 seed tasks，经 crowdworkers 扩展到 172；另有 42 expert-set tasks。论文另处对早期 seed pipeline 使用 72 的中间数字，必须保留阶段差异，不能无说明合并。

总计涉及 53 people，其中 35 为不同领域 experts；覆盖 525 pages、258 sites、15+ domains。任务要求答案在近期不易变化，并由两位作者人工核验。评分按 answer type 使用 string/list/number/dictionary 的 F1、precision/answer rate、exact match 等；数值可有数量级 partial credit。

论文设 33-task dev/validation，剩余为 test 面；没有报告与 agent 完全同 protocol 的整体 human baseline。任务来源证明“人提出需求”，不等于测量人类完成率。

## 证据解释与单位边界

- **[事实]** `214` 是 **runnable answer tasks**；`70 seed`、`172 expanded total`、`42 expert tasks` 是 sourcing strata，不是 284 tasks。
- **[事实]** `53 people/35 experts` 是 contributors，不是每 task 双专家标注数；两位作者复核是 QA role。
- **[作者主张]** realistic/time-consuming 由人类需求与数分钟浏览标准支撑，但 task 构造刻意筛掉短期易变答案，牺牲了一部分 live-work realism。
- **[研究员推断]** closed-form automatic scoring 使跨域扩展可行，却不检验 evidence provenance、过程正确性、网页副作用或结果呈现质量。
- **[事实]** 固定 repeated-run policy、matched human success、生产美元成本与专家单价为 **公开资料不足**。

## 支持或反驳的结论

- 强支持 H1：广覆盖 + 自动验证通过限定 closed-form、相对静态答案实现。
- 支持 H3：开放网站可用性、搜索工具与 scorer tolerance 都可能影响难度。
- 支持 H4 风险：公开 validation、固定问题和网页 drift 使长期轮换必要；论文没有完整 rotation policy。

