# ALE live leaderboard — separate snapshot

- 标题：Leaderboard | Agents’ Last Exam
- 作者/机构：Agents’ Last Exam
- URL：https://agents-last-exam.org/leaderboard
- 发布日期：living leaderboard；页面标示 ALE-V1
- 访问日期：2026-08-08
- 版本/revision：ALE-V1 live snapshot；Best-per-task 2026-07-04；runtime methodology 2026-07-10
- 数据说明：Best-per-task 标示 2026-07-04；runtime methodology updated 2026-07-10
- 评分：Credibility **4/5**；Recency **5/5**；Bias **3/5**

## 直接证据

- 原文短引（ALE-V1 page summary）：“real-world professional workflows with verifiable success criteria.”

- 页面把 Pass Rate 定义为 perfect-score run share，Score 为 mean partial credit；“Best of All Runs” 对每个 task 只取最高分 run。
- leaderboard 按 Overall、ALE-CLI、Near-term、Full-Spectrum、Last-Exam 切分，并逐行绑定 harness、model、effort、cost、runtime、tokens。
- 当前 live rows 含论文发表后/不同 paper-table configuration 的系统，例如 Codex `gpt-5-6-sol`；因此不能与 arXiv v2 Table 1 合并成同一实验快照。
- runtime 排除 queueing、environment setup、evaluation、output sync；cost 对 rerun task 只计一次平均 run cost，并混合 runner-log 与 list-price token estimation。

## 支持 / 反驳

- 支持 system-level reporting：harness、model、effort、cost、runtime、tokens 必须一起保存。
- “Best per task” 是跨 run/configuration 的 oracle envelope，不是单一 deployable agent，不能当生产系统能力。
- leaderboard cost/runtime 字段有方法边界；不能用作 task production cost 或 end-to-end service latency。
