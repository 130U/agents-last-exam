# Remote Labor Index 论文

- 标题：The Remote Labor Index: Measuring AI Automation of Remote Work
- 作者/机构：Center for AI Safety；Scale AI；合作者见论文
- URL：https://arxiv.org/abs/2510.26787
- 发布日期：2025-10-30
- 访问日期：2026-08-08
- 版本/revision：arXiv `2510.26787v1`

## 与本问题直接相关的原文证据

- 英文短引（arXiv title field）："Measuring AI Automation of Remote Work."
- [事实] 论文的 benchmark 快照是 240 个 `project/task instance`，覆盖 23 个 Upwork category；每个实例包含 brief、input files 和原人类 freelancer deliverable。
- [事实] 论文报告这些项目的人类完成时间均值 28.9 小时、中位数 11.5 小时；成本均值 632.6 美元、中位数 200 美元。时间/成本来自原工作者或项目记录，并非统一计时实验；时间覆盖 84%，成本覆盖 95%。
- [事实] 数据来源为 207 个 marketplace 项目、7 个 long-tail commissioned 项目和 33 个经许可的 online projects；从 550 个初始项目筛选到 240 个。
- [事实] 主评价是专业人工对“合理客户是否会接受 agent output”进行判断；自动化率采用三人独立判断/多数票，Elo 采用 pairwise comparison。论文报告自动化判断的一致率 94.4%，Elo 判断一致率 56.9%。
- [事实] 10 个实例公开，230 个不公开；定量 leaderboard 使用非公开实例。论文称公开描述无法通过搜索找到原项目。
- [事实] 系统实验同时改变了模型、scaffold、工具和交互方式；论文中 GPT-5 CLI 与 CUA 的自动化率不同，不能归因于裸模型。
- [事实] 论文没有说明每个 agent/project 的 repeated generation trials；2–3 次重复是 evaluator ratings，不是 agent trial。

## 解释、支持与反驳

- [作者主张] 23 个类别和成本/工时权重使 RLI 接近“代表性的 remote work”测量。
- [研究员推断] 这种代表性只覆盖可远程、可独立交付、可即时评价的项目；自报工时和历史报价不能直接变成 1,000-task 生产配额。
- 支持 H1：真实输入/参考交付物带来昂贵人工 evaluator，而非完全自动验证。
- 支持 H3：CLI/CUA/scaffold 差异显示难度部分来自 harness/tool access。
- 部分支持 H4：230 个隐藏实例缓解公开污染，但论文未披露轮换机制。

## 评分

- Credibility：5/5（版本固定的 primary paper）
- Recency：4/5（2025 论文；2026-08-08 复核）
- Bias：3/5（作者是 benchmark 创建者，但披露多项限制）
