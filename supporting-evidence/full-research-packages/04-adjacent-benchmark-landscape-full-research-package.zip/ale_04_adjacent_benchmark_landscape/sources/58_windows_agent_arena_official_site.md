# Windows Agent Arena official project page

- 作者/机构：Microsoft Research / Windows Agent Arena team
- URL：https://microsoft.github.io/WindowsAgentArena/
- 发布日期：2024-09
- 访问日期：2026-08-08
- 版本/revision：live site snapshot；initial release surface
- 类型：官方项目页

## 与本研究直接相关的原文证据

- lines 22–24：real Windows OS、150+ tasks、parallel Azure run、Navi 19.5% vs human 74.5%。
- lines 29–38：initial release 明确 154 tasks；deterministic custom scripts 在 episode end 产生 reward；Docker hosts Windows 11 VM，Azure distributes tasks across workers。
- 原文短引："Task evaluation is deterministic"；"initial release consists of 154"。

## 证据解释

- 网站 headline 150+ 与正式 inventory 154 是同一快照的近似/精确表达，不应另算两套 task sets。
- deterministic 只说明同一观察状态由 script 判定，不证明 evaluator specification 完整，也不排除 environment drift。
- public/private split、contamination policy、rotation policy：公开资料不足。

## 支持/反驳

- 支持：真实 OS state verifier 可完全自动化不少 closed-ended GUI outcomes。
- 限制：开放式文档质量或审美 deliverable 仍可能需要 human review，WAA 不证明广泛专业产出都可自动验证。

## 评分

- Credibility：5/5（官方项目页）
- Recency：5/5（访问日 snapshot）
- Bias：3/5（项目宣传页）
