# WebArena：论文版本面

- **标题**：WebArena: A Realistic Web Environment for Building Autonomous Agents
- **作者/机构**：Shuyan Zhou、Frank F. Xu、Hao Zhu 等；Carnegie Mellon University 等
- **URL**：https://arxiv.org/html/2307.13854v4
- **发布日期**：2023-07-25；v4 更新 2024-04-16
- **访问日期**：2026-08-08
- **版本/revision**：arXiv `2307.13854v4`
- **来源类型**：原始论文 / benchmark 作者
- **评分**：Credibility **5/5**；Recency **5/5**（pinned）；Bias **3/5**

## 与本研究直接相关的原文证据

> “812 test examples derived from 241 templates”

论文 §4 说明每个 template 平均产生 3.3 examples，目标指标是 task completion 的 functional correctness；Table 4 报告 human 78.24%。WebArena 提供四类 fully functional self-hosted sites：e-commerce、social forum、collaborative software development、content management，并接入 map、calculator、scratchpad、knowledge resources。作者从约 200 段自身 browsing-history segments 选择网站类型，将真实网站内容抽样/导入自托管副本。intent templates 由标注者探索网站后创建，允许用 ChatGPT 作灵感。

evaluator 按任务类型组合：information tasks 用 exact match、must-include 或 GPT-4 fuzzy match；state-changing tasks 用 database/API/JavaScript locator 和内容检查。论文称 82 个 examples 使用 GPT-4 judging；人工抽查 40 个，其中 39/40 对齐。170-template human subset 由五名 CS graduate students 各做一项；launch agents 最多 30 state transitions。

## 证据解释与单位边界

- **[事实]** `812` 是 **runnable task instances/test examples**；`241` 是 intent **templates**。不能把 812 当作 812 个独立 workflows。
- **[事实]** 网站是从真实使用中选择、内容 real-derived，但运行环境是 self-hosted replicas；不等同 live production websites。
- **[作者主张]** “diverse, long-horizon, routinely performed”是作者主张。模板化实例与四类网站并不能证明总体互联网工作的代表性。
- **[事实]** human baseline 只覆盖 170 templates、人员为 CS 研究生，且 agent/human budget 未完全匹配；78.24% 是该 snapshot，不是 universal human ceiling。
- **[事实]** 原论文没有 private holdout、周期轮换或统一 repeated-run policy；Text-Bison 的十次 retry 是某 baseline 特例，不能推广为 benchmark policy。
- **[事实]** reset 时间从数秒至约一分钟；完整美元成本与标注人工时为 **公开资料不足**。

## 支持或反驳的结论

- 支持 H1：functional automation 依赖 site-specific evaluators，部分问题仍需 GPT-4/judgment audit。
- 支持 H3：30-step budget、self-hosting、reset、DOM/action representation 都可能影响难度。
- 支持 H4 风险：公开 templates、instances 和 evaluators 易形成 benchmark-specific optimization。
- 对 H2：多步 browser action 不自动等于专业 long-horizon workflow；论文没有跨阶段职业审计。
