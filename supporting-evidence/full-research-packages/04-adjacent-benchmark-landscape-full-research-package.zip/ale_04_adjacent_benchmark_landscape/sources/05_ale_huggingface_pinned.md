# ALE Hugging Face task-card metadata — pinned

- 标题：Agents Last Exam — Task Card Metadata (v1.0)
- 作者/机构：agents-last-exam organization
- URL：https://huggingface.co/datasets/agents-last-exam/agents-last-exam
- 发布日期：页面未给出
- 访问日期：2026-08-08
- dataset revision：`a8c1fd174a1f6cfa76526572a2e3ebece1276be2`
- dataset card version：`v1.0`
- 评分：Credibility **5/5**；Recency **5/5**；Bias **3/5**

## 直接证据

- 原文短引（Dataset Viewer）：“v1.0 · 153 rows”。

- Viewer 显示 **153 rows**，一行一个 task card；字段包括 task_id、title、summary、category、subdomain、task_split、task_prompt、agent_must_do、software、input_files、taxonomy、source_repo_path。
- dataset family：task metadata（open）、task input data（open）、reference ground truth（gated/manual approval）。
- metadata dataset 不含 input data、software binaries、reference outputs、scoring fixtures 或 VM images。

## 支持 / 反驳

- 反驳把 HF row 当作完整 runnable asset：它只是 metadata surface。
- 反驳把 153 rows、论文 150 selected public、repo around 150 合成一个无版本数字。
- reference gating 支持 contamination control，但 gated 不等于已证明无泄漏。
