# Are “Solved Issues” in SWE-bench Really Solved Correctly? An Empirical Study

- 作者/机构：独立学术研究团队；作者详见 arXiv `2503.15223`
- URL：https://arxiv.org/abs/2503.15223
- 发布日期：2025-03-19
- 访问日期：2026-08-08
- 版本/revision：访问日 arXiv current revision
- 类型：独立 validity audit

## 与本研究直接相关的原文证据

- abstract lines 4–6：研究使用 PatchDiff 对三个 SWE-bench Verified 工具的 plausible patches 做差分测试与人工检查。
- 报告 7.8% patches 被 SWE-bench 判为正确却未通过 developer-written suite；行为差异与 manual inspection 共同指向 reported resolution rate inflation。
- 原文短引："critical weaknesses"；"inflation of reported resolution rates"。

## 证据解释

- 这里的百分比以该研究选定的 generated plausible patches 为单位，不是 500 task instances 的 defect rate。
- test pass 是 evaluator verdict，不等同于 patch 与真实开发者期望在所有行为上等价。

## 支持/反驳

- 支持 H3：evaluator coverage weakness 可以产生 false positive。
- 支持项目建议：gold patch comparison 不能替代 mutation/differential/adversarial testing 与人工抽检。

## 评分

- Credibility：5/5（独立、方法清楚、可复核）
- Recency：5/5（2025–2026 frontier validity evidence）
- Bias：5/5（独立审计且披露适用样本）
