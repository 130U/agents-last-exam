# GDPval 论文

- 标题：GDPval: Evaluating AI Model Performance on Real-World Economically Valuable Tasks
- 作者/机构：OpenAI；Patwardhan 等
- URL：https://arxiv.org/abs/2510.04374
- 发布日期：2025-10-05
- 访问日期：2026-08-08
- 版本/revision：arXiv `2510.04374v1`；另获 ICLR 2026 接收，不改变 arXiv revision

## 与本问题直接相关的原文证据

- 英文短引（arXiv title field）："Evaluating AI Model Performance on Real-World Economically Valuable Tasks."
- [事实] 论文 benchmark snapshot 有 1,320 个 `task instances`、44 个 occupations、9 个 sectors；每个 occupation 恰为 30 个任务。公开 gold subset 为 220 个实例，即每 occupation 5 个。
- [事实] task unit 是一次性、self-contained prompt + reference files → professional deliverable，不是运行中的职业 workflow。
- [事实] sector 选自 2024 Q2 GDP 占比超过 5% 的行业；每行业从数字化程度和 total wage/compensation 选择 5 个职业。该 top-down 采样具有真实经济统计依据，但 headline aggregate 并非公开证明的 task-level GDP 加权配额。
- [事实] 专家至少 4 年经验，均值 14 年；每 occupation 至少 5 名专家。每个任务平均 5 次 review、至少 3 次。
- [事实] 主评价为职业专家 blind pairwise preference：agent deliverable 与任务创建者的人类 deliverable 比较。gold subset 的一次 comparison 平均超过 1 小时。
- [事实] 自动 grader（GPT-5-high）与人类 agreement 65.7%，人类 inter-rater agreement 70.8%；220 个公开任务中有 12 个无法自动评分。论文还观察到 judge 对同家模型产出存在偏好。
- [事实] 论文实验对每 prompt/model 采 3 个 agent samples，每个 sample 由 3 名 graders 评价，即 9 次 comparison；这是报告实验的 repeated-run policy，不自动适用于未来服务。
- [事实] 人类 creator 完成时间均值约 404 分钟；论文用 BLS wage 推算均值 361 美元，但承认可能低估真实专家市场成本。公开资料没有总建设成本。

## 解释、支持与反驳

- 支持 H1：广职业覆盖和真实 deliverable 依赖昂贵人工判断；自动 judge 仍显著弱于完全可靠。
- 支持 H2：长完成时间不自动使一次性 prompt 成为 long-horizon workflow。
- 支持 H4：公开 gold set 没有已披露的轮换/污染政策；完整 1,320 未发布，但不能无证据称为正式 hidden leaderboard holdout。
- [项目建议] 1,000-task 项目应分别记录 occupation sampling weight、task count、worker time、review time 和 agent trials，不能把这些单位互换。

## 评分

- Credibility：5/5（版本固定 primary paper）
- Recency：5/5（ICLR 2026；访问日核验）
- Bias：3/5（作者创建 benchmark，限制披露较充分）
