# NIST AI 800-2 IPD — Practices for Automated Benchmark Evaluations

- 作者/机构：NIST Center for AI Standards and Innovation
- URL：https://nvlpubs.nist.gov/nistpubs/ai/NIST.AI.800-2.ipd.pdf
- 发布日期：2026-01（initial public draft）
- 访问日期：2026-08-08
- 版本：`NIST AI 800-2 ipd`；非最终标准
- 评分：Credibility **5/5**；Recency **5/5**；Bias **5/5**

## 直接证据

- 原文短引（Table I.1）：“Automated benchmarks are not well-suited for all use cases.”

- benchmark 内容、format 与 grading 必须匹配 evaluation objective；简化 format 会为了实现便利牺牲某些 intended-use validity。
- 难度应匹配决策目的；过难或饱和都会降低比较价值。
- 人类 baseline 要在 protocol、工具与信息上可比，并具有足够数量与相应 expertise。
- contamination 可通过隐藏 benchmark data 或使用模型产生之后的数据降低。
- external validity 要把实际 scaffold 与 cost-performance setting 纳入 protocol。
- cost 应控制或与 performance 并报；否则更高执行预算会破坏可比性。
- 建议保存 full logs、exact model/system version、evaluation code/commit hashes。
- 明确列出 complex virtual environment 的 broken dependencies、networking、permissions、tool-calling errors 会让 test item 不可解或降低表现。

## 支持 / 反驳

- 支持 H1/H3/H4 及版本化、日志、环境 QA、baseline matching、成本披露。
- 反驳“全自动 evaluator 足以保证 validity”：NIST 要求另行证明 construct fit、solvability、external validity 与 contamination control。
- 限制：该文件是 initial public draft，部分条目标为 emerging practice。
