# WorkArena / WorkArena++：官方 repo 当前实现面

- **标题**：ServiceNow/WorkArena — WorkArena and WorkArena++
- **作者/机构**：ServiceNow Research
- **URL**：https://github.com/ServiceNow/WorkArena
- **发布日期**：2024 起持续更新
- **访问日期**：2026-08-08
- **版本/revision**：commit `a772230a94cf1caf4166b8ead3983f3b3786455b`
- **来源类型**：官方代码仓库 / mutable snapshot
- **评分**：Credibility **5/5**；Recency **5/5**；Bias **3/5**

## 与本研究直接相关的原文证据

> “19,912 unique instances drawn from 33 tasks”

README 的 Benchmark Contents 还说明：WorkArena++ 当前含 682 tasks，每项可从数千 potential configurations 中采样；其 atomic components 来自 WorkArena L1，并组合成用例。demo 明确区分 `cheat()` oracle 与真正 agent 的 `env.step()`。

## 证据解释与版本边界

- **[事实]** L1 的 `33` 是 **task definitions/atomic task families**，`19,912` 是 potential **unique runnable instances**；不应把 19,912 当作人工编写 workflows。
- **[事实]** WorkArena++ 的 `682` 是当前 repo 暴露的 task definitions/presentations；同一 task 还可按 seed/config 生成许多 runnable instances。
- **[事实]** oracle 是用于生成 ground-truth trajectory/验证的 privileged implementation，不能计为 human baseline 或普通 agent run。
- **[研究员推断]** 大规模 parameterization 可增强实例多样性，但若底层 33 atomic families 和 341 workflows 公开，仍可能产生 family-specific optimization；instance count 不等于 construct breadth。
- **[事实]** 运行依赖 gated ServiceNow instance access 和特定平台数据安装。setup/provider drift 可能成为 harness confound。
- **[事实]** 当前 repo 未披露每实例生产人工时、维护成本、正式 repeated-run aggregation 或 hidden workflow split。

## 支持或反驳的结论

- 支持 H1：自动规模化主要来自约束明确的单软件 schema 和 generator。
- 支持 H3：oracle、seed、ServiceNow release、BrowserGym version、账号状态均须进入 manifest。
- 支持 H4：parameterized instances 可减轻逐条记忆，但不能替代隐藏 workflow family 和轮换。

## 限制

repo 中“real-world use cases”仍是机构主张；当前数量不能回写为论文当时 snapshot，也不能直接转换成 1,000-task 生产配额。

