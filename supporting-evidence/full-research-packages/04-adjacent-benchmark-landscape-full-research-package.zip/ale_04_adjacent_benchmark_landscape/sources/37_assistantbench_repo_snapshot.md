# AssistantBench：官方 repo 实现可用性面

- **标题**：oriyor/assistantbench — implementation repository
- **作者/机构**：AssistantBench authors
- **URL**：https://github.com/oriyor/assistantbench
- **发布日期**：2024 起
- **访问日期**：2026-08-08
- **版本/revision**：commit `2ce557dca1fca5d746d1dee07dfa86018802763c`
- **来源类型**：官方代码仓库 / mutable snapshot
- **评分**：Credibility **5/5**（实现状态）；Recency **5/5**；Bias **3/5**

## 与本研究直接相关的原文证据

> “Code to run SPA and additional resources will be released soon!”

当日 repo README 链接 HF dataset 与 leaderboard，并包含 `SeePlanAct/`、images、resources；但仍保留上述未完成承诺。repo 没有 release tags，公开历史仅少量 commits；可运行 benchmark integration 还存在于独立 BrowserGym package。

## 证据解释与版本边界

- **[事实]** 论文方法描述、此 repo、HF data、BrowserGym runner 与 leaderboard 是不同 implementation surfaces；不能因有 GitHub repo 就假定端到端复现已完整。
- **[事实]** “released soon”在 2026-08-08 HEAD 仍出现，说明官方运行包/资源的发布状态至少在 README 中不完整或未同步。
- **[研究员推断]** 若复现实验使用 BrowserGym 而论文 baseline 使用作者 SPA code，分数变化可能来自 harness；必须记录 runner provenance。
- **[事实]** repo 未给 environment lockfile/release manifest、private test evaluator revision、rotation cadence、cost 或 repeated-run protocol。

## 支持或反驳的结论

- 强支持 H3：benchmark corpus 与具体 agent/harness implementation 分离，复现不能只 pin dataset。
- 支持 H4：无正式 release/version cadence 会削弱长期可比性。
- 支持交付标准要求 runnable reference harness、immutable release、smoke tests、offline scorer 与 provenance manifest，而非只交 task JSON。

## 限制

README 可能滞后于其他仓库；本证据只说明该 pinned repo surface，不证明 BrowserGym implementation 不完整。

