# RLI evaluation platform 官方代码

- 标题：RLI Evaluation Platform
- 作者/机构：Center for AI Safety
- URL：https://github.com/centerforaisafety/rli_evaluation_platform
- 发布日期：2025
- 访问日期：2026-08-08
- 版本/revision：Git HEAD `c101682830aa8985480e847e33737f182ad3efe8`

## 与本问题直接相关的原文证据

- 英文短引（GitHub repository title）："RLI Evaluation Platform."
- [事实] README 将该代码描述为对 RLI public set 的评估平台，支持 human comparison 和多种文件 viewer。
- [事实] 仓库面向 10 个 public task；它不是 230 个 private instances 的公开 evaluator/data release。
- [事实] evaluator workflow 依赖人类读取 brief、原 human deliverable 和 agent deliverable 后作比较。

## 解释、支持与反驳

- [研究员推断] 可公开复现的是 evaluator UI/公开样本，不是论文 leaderboard 的完整数据面。
- 支持“benchmark、public instance、private instance、agent run 必须分账”；反驳“repo 中 10 项就是整个 RLI”。
- [项目建议] 对 1,000-task 项目，应把 evaluator UI、artifact renderers、blind assignment 和 audit log 作为独立基础设施工件。

## 评分

- Credibility：5/5（官方、commit-pinned 代码）
- Recency：5/5（2026-08-08 固定 HEAD）
- Bias：3/5（官方实现；不能独立验证效度）
