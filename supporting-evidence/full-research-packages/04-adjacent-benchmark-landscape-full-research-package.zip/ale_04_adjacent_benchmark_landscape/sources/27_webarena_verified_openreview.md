# WebArena-Verified：独立 evaluator audit / 修订版

- **标题**：WebArena Verified
- **作者/机构**：Amine El hattami、Joel Bredeson、Megh Thakkar、Eric LaBouve、Nicolas Chapados、Christopher Pal；ServiceNow Research / Mila 等（以论文署名为准）
- **URL**：https://openreview.net/forum?id=CSIo4D7xBG
- **发布日期**：2025-09-19；最后修改 2025-11-19
- **访问日期**：2026-08-08
- **版本/revision**：ICLR 2026 **Withdrawn Submission**；OpenReview revision 2025-11-19
- **来源类型**：外部复核/衍生 benchmark；未按已发表论文对待
- **评分**：Credibility **3/5**（withdrawn）；Recency **4/5**；Bias **4/5**（主动审计问题，但也推广自家修订）

## 与本研究直接相关的原文证据

> “replace substring matching with type-aware exact matching with semantic normalization”

abstract 报告 audit 全部 812 tasks、false-negative rate 相比原 scorer 下降 11.3 percentage points，并定义 258-task Hard subset。作者还报告 mutation tasks 采用 backend-state checks；结构化 JSON status；per-template macro averaging、95% confidence intervals 与 failure-mode breakdown；Hard subset 声称减少 68.2% runtime。

## 证据解释与单位边界

- **[事实]** 审计对象是原始 `812 runnable instances`；Hard 的 `258` 是难度优先 **subset instances**，不是 258 个 workflows。
- **[作者主张]** false-negative 下降 11.3 percentage points、coverage/discriminative power 保持，是该 withdrawn submission 的结果，尚不能视为独立定论。
- **[反方证据]** 原 WebArena evaluator 的 goal underspecification、substring matching 与 misaligned checks 足以显著改变分数，反驳“固定 task intent 就有稳定 ground truth”。
- **[研究员推断]** per-template macro metric 可降低同模板多实例对总分的过度权重；这对 241-template/812-instance 架构尤其重要。
- **[事实]** 当前实现已另有 ServiceNow repo，但论文撤回原因、完整独立复现与长期轮换策略为 **公开资料不足**。

## 支持或反驳的结论

- 强支持 H1/H3：提高 evaluator validity 需要全量人工审计、类型化验证与 backend evidence；原始低分部分可能是 false negatives。
- 支持 H4：Verified 修订提高当前内部效度，但仍是公开静态 task family。
- 支持项目报告 task-level 与 template/workflow-level 两套聚合，并把 evaluator version 视为成绩版本的一部分。

## 限制

此来源状态为 withdrawn，不能把其数值当作 peer-reviewed fact；应与官方实现测试和第三方复现交叉验证。
