# Remote Labor Index 官方网站

- 标题：Remote Labor Index
- 作者/机构：Center for AI Safety
- URL：https://www.remotelabor.ai/
- 发布日期：2025
- 访问日期：2026-08-08
- 版本/revision：live site snapshot，2026-08-08

## 与本问题直接相关的原文证据

- 英文短引（official site title field）："Remote Labor Index."
- [事实] 官网把测量对象定义为对真实 remote-work projects 的自动化，并呈现 benchmark、paper、public tasks 和 evaluation 入口。
- [作者主张] 网站把成本和工作时长作为经济意义维度；这是机构提出的 construct，不等同于已验证的总体就业影响。
- [事实] 网站内容是 mutable surface；数字不得与 arXiv v1、HF revision 或 leaderboard 的其他日期合并。

## 解释、支持与反驳

- [研究员推断] 官网最适合核验当前产品边界和入口，不适合替代版本化论文/数据集作历史计数来源。
- [项目建议] 对 live benchmark 保留抓取时间、manifest hash 和 leaderboard snapshot。

## 评分

- Credibility：4/5（官方一手产品页面）
- Recency：5/5（访问日 live snapshot）
- Bias：2/5（宣传/定位激励较强）
