# Quantifying infrastructure noise in agentic coding evals

- 作者/机构：Anthropic Engineering
- URL：https://www.anthropic.com/engineering/infrastructure-noise
- 发布日期：2026-02（访问页显示 2026）
- 访问日期：2026-08-08
- 版本/revision：live engineering report snapshot
- 类型：独立行业实验（相对于 Terminal-Bench 维护者）

## 与本研究直接相关的原文证据

- lines 18–21：resource configuration alone 可造成超过 leaderboard margin 的差异；Terminal-Bench 2.0 不同资源 setup 的 gap 为 6 percentage points。
- lines 23–26：最多 6% tasks 因 pod errors 失败；hard ceiling 与 transient resource spike 可造成 OOM，而官方 provider 更宽松。
- 原文短引："infrastructure configuration alone"；"aren't taking the same test"。

## 证据解释

- 这些数值来自 Anthropic 的特定 GKE calibration，不应作为通用 error quota。
- 结论可推广到执行式 benchmark 的 protocol design：CPU/RAM/time/network/image/provider 都是 evaluation construct 的一部分。

## 支持/反驳

- 强支持 H3：环境失败会被误计为能力失败。
- 项目建议：必须报告 infra-failure rate，失败重试只能用于 infrastructure retry，不能与 model retry 混为一谈。

## 评分

- Credibility：4/5（有实验与机制解释，非同行评审）
- Recency：5/5
- Bias：4/5（模型供应商但批评跨供应商 benchmark protocol）
