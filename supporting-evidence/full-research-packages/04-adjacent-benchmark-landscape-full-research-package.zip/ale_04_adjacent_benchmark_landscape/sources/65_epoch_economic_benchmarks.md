# Epoch AI 对经济型 agent benchmarks 的独立评议

- 标题：How well can AI systems automate economically valuable tasks?
- 作者/机构：Epoch AI
- URL：https://epoch.ai/blog/how-well-can-ai-systems-automate-economically-valuable-tasks
- 发布日期：2026-02-14
- 访问日期：2026-08-08
- 版本/revision：网页快照，2026-08-08

## 与本问题直接相关的原文证据

- 英文短引（article title field）："How well can AI systems automate economically valuable tasks?"
- [独立行业分析] 文章比较 RLI、GDPval 与 APEX，认为这些 benchmark 更接近经济任务，但自包含任务的成功不等于整份工作的 wholesale automation。
- [独立行业分析] 对 RLI，低成功率可能部分来自 scaffold/工具和系统集成，而非仅模型推理能力。
- [独立行业分析] 对 GDPval，任务广但上下文“异常干净”：现实工作中的澄清、组织依赖和隐性信息被移除。

## 解释、支持与反驳

- 支持 H2/H3，并反驳从 deliverable completion 直接外推 job replacement。
- [项目建议] 同时报告 task completion、环境/harness failure、需要澄清次数和 human escalation；不要只报单一 pass rate。

## 评分

- Credibility：4/5（独立、方法导向研究机构）
- Recency：5/5
- Bias：4/5（非 benchmark 创建者，仍有研究议程）
