# OSWorld-Human：独立效率与轨迹反证

- **标题**：OSWorld-Human: Benchmarking the Efficiency of Computer-Use Agents
- **作者/机构**：Reyna Abhyankar、Qi Qi、Yiying Zhang；论文版本所列机构见原文
- **URL**：https://arxiv.org/abs/2506.16042
- **发布日期**：2025-06-19
- **访问日期**：2026-08-08
- **版本/revision**：arXiv `2506.16042`（访问日 arXiv 当前版本）；另有 workshop/OpenReview 面
- **来源类型**：衍生 benchmark / 独立学术预印本
- **评分**：Credibility **3/5**（预印本，方法有价值但非 OSWorld 官方审计）；Recency **4/5**；Bias **4/5**

## 与本研究直接相关的原文证据

> “contains a human-determined trajectory for each task”

摘要报告：planning/reflection 的大模型调用占整体 latency 主要部分；后期 step 可达早期的 3 倍；研究 16 agents，高分 agent 仍使用人类必要步骤的 `1.4–2.7x`。论文覆盖原 OSWorld 的 369 examples，并用人工轨迹建立效率参照。

## 证据解释与单位边界

- **[事实]** 人工轨迹是每个 OSWorld task 的 trajectory annotation，不是新的 369 个独立 professional workflows。
- **[事实]** 本研究的 evaluation construct 是效率/trajectory gap；它补充 task success，但不替代 OSWorld evaluator。
- **[研究员推断]** 同一 task 的延迟和步骤数取决于 scaffold 的 planning/reflection 设计、action grouping 与模型调用策略；只比较最终 pass rate 会隐藏大量运行成本。
- **[反方证据]** 论文摘要的 `1.4–2.7x` 与正文某些分组口径可出现不同倍数，提示 action grouping/统计子集会改变结论；不能抽成一个通用“agent 慢 X 倍”。
- **[事实]** 人工轨迹的 annotator 工资、全量制作成本、跨 annotator 一致性细节与固定 repeated trials 为 **公开资料不足**。

## 支持或反驳的结论

- 强支持 H3：高难度/低实用性可由 scaffold 调用延迟和冗余步骤造成，而不只由目标 GUI 能力造成。
- 支持 1,000-task 项目同时记录成功、agent active time、tool/model latency、steps、recovery 与 human reference trajectory。
- 不足以证明 OSWorld 的职业代表性；它只对原 task 集作效率参照。

## 限制

这是衍生研究而非 OSWorld 作者的 Verified audit；结论受所选 16 agents、action grouping 与当时 API latency 影响。
