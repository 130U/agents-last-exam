# Introducing Terminal-Bench

- 作者/机构：Terminal-Bench team
- URL：https://www.tbench.ai/news/announcement
- 发布日期：2025-05（页面/公开 release）
- 访问日期：2026-08-08
- 版本/revision：Terminal-Bench-Core / v1 launch snapshot；不是 2.0
- 类型：官方发布说明

## 与本研究直接相关的原文证据

- lines 9–16：first version；Core-v0 leaderboard 每 task 恰好一个 attempt，但多数 agents 的 accuracy 跨 multiple runs 平均。
- lines 26–28、77：terminal agent failure 包括 action chaining、long context、independence；harness 负责 multi-container、logging 和 final state verification。
- 当前 repo redirect（Browser 2026-08-08）：旧 repo 为 `harbor-framework/terminal-bench-1`，commit `d28711d0da2675d0bb1d56de45ae5df6082438a3`。
- 原文短引："exactly one attempt"；"averaged across multiple runs"。

## 证据解释

- v1/Core-v0 的 80-at-launch 或 growing task count、run policy 与 2.0 的 89 tasks/≥5 repetitions 不能合并。
- “one attempt per task”与“multiple benchmark runs”兼容：一个 run 内一个 task trial；重复整个 evaluation 产生多 trials。

## 支持/反驳

- 支持：必须明确 run、trial 和 repeat unit。
- 反驳：把 Terminal-Bench 视为单一不变数据集。

## 评分

- Credibility：5/5（官方 release）
- Recency：4/5（旧版本，但版本边界关键）
- Bias：4/5
