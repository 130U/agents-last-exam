# GAIA：Princeton HAL repeated-run reliability 反证

- **标题**：GAIA: Reliability Failure Analysis
- **作者/机构**：Princeton University HAL Reliability
- **URL**：https://hal.cs.princeton.edu/reliability/benchmark/gaia/analysis/
- **发布日期**：公开页面未标明发布日期
- **访问日期**：2026-08-08
- **版本/revision**：mutable live analysis，2026-08-08 snapshot；模型面为 Claude Opus 4.5、Gemini 2.5 Pro、GPT-5.4
- **来源类型**：独立学术 reliability analysis / current dashboard
- **评分**：Credibility **4/5**；Recency **5/5**；Bias **4/5**

## 与本研究直接相关的原文证据

> “same task multiple times”

页面说明对 GAIA 的 165 real-world tasks 做多次 repetitions，检查 wrong answers、self-disagreement、tool failures 与 input perturbations。分析指出：ambiguous questions 会让同一模型跨 run 选择不同解释而仍高置信；工具链顺畅会提升主观置信，即使答案错；访问源失败时会出现 fabrication、approximation 或 surrender。

实例显示同一 GPT-5.4 task 的五个 trials 得到多个答案；正确 run 未必最便宜或最自信。另一个 task 在 baseline、fault injection、structural perturbation 下得到三个数量级/符号不同的答案，并披露每 run 的 steps 与 API cost。

## 证据解释与单位边界

- **[事实]** `165` 是 HAL 当前评测的 GAIA **task subset/validation instances**；每个 task 有多个 **agent trials**。不能把 trial 数当作新 tasks。
- **[反方证据]** 单次 exact-answer pass 会把 stochastic tool availability、ambiguous interpretation 和 harness bugs 压成一个二元值；它不足以说明 reliability。
- **[研究员推断]** clean tool trace 不等于正确推理；难度可能来自 API quota、blocked sites、parser formatting 和 observation perturbation，直接支持 H3。
- **[事实]** 这是 live dashboard，模型与结果可变；当前 costs 只能作为特定 trials 的运行记录，不是生产 1,000 tasks 的成本依据。
- **[事实]** 页面没有公开统一的人类 matched repeated-run baseline。

## 支持或反驳的结论

- 强支持 H3：tool/harness failure 与 question ambiguity 可主导表现。
- 支持至少多 seed/repetition，并分别报告 pass@1、success probability、variance、infra-failure 与 ambiguity flags。
- 支持 H1：广域 open-web 真实性使稳定自动验证与重现实验更难。

## 限制

只覆盖三个模型与 HAL 自身 scaffold；不能据此推断所有 GAIA agents 的平均可靠性，也不能把页面当前 leaderboard 当 immutable source。
