# SWE-bench Datasets

- 作者/机构：SWE-bench team
- URL：https://www.swebench.com/SWE-bench/guides/datasets/
- 发布日期：网页未标明
- 访问日期：2026-08-08
- 版本/revision：live documentation snapshot；网页抓取日 2026-08-08
- 类型：官方数据文档

## 与本研究直接相关的原文证据

- lines 61–65：current guide 分列 original 2,294、Lite 534、Verified 500。
- lines 90–101：每个 instance 含 `instance_id`、repo、issue id、base commit、problem statement、patch 和 test patch 等字段。
- 原文短引："Expert-verified solvable problems"；"Gold solution patch"。

## 证据解释

- 这些值属于不同 dataset surface；不是同一套任务的可直接相加分片。
- `patch` 是开发者 gold patch；agent 提交的是 candidate patch。一次 candidate patch 的执行判定是 patch evaluation；一次 stochastic agent attempt 是 trial/run。
- 当前官方数据文档公开 gold patch 和 test patch；这意味着 original/Verified 并非隐藏 holdout。

## 支持/反驳

- 支持：单位账本和版本矩阵必须区分 original、Lite、Verified。
- 反驳：不能把 500 Verified 称为 500 个新采集 issue；它是 original test set 的人工筛选 subset。

## 评分

- Credibility：5/5（官方结构化数据文档）
- Recency：5/5（2026-08-08 live snapshot）
- Bias：4/5（官方维护者自述）
