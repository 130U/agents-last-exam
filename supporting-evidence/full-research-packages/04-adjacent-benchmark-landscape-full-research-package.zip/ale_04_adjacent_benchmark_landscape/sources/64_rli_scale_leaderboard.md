# RLI Scale Labs leaderboard

- 标题：Remote Labor Index Leaderboard
- 作者/机构：Scale AI
- URL：https://labs.scale.com/leaderboard/rli
- 发布日期：2025
- 访问日期：2026-08-08
- 版本/revision：live leaderboard snapshot，2026-08-08

## 与本问题直接相关的原文证据

- 英文短引（leaderboard title field）："Remote Labor Index Leaderboard."
- [事实] leaderboard 报告的是配置化 agent system 的结果，包括模型、scaffold/工具和执行预算；榜单行不是裸模型能力。
- [事实] 指标面包含 automation rate、与 human deliverable 的 Elo/比较和经济加权派生量；其分母来自 private evaluation instances。
- [事实] 页面未提供足以重建每个系统 repeated-run 分布和置信区间的公开 run-level log。

## 解释、支持与反驳

- 支持 H3：harness 差异可混入“模型难度”。
- [研究员推断] 当前榜单数值是 2026-08-08 快照，不能当作生产验收阈值或未来 saturation 证据。

## 评分

- Credibility：4/5（官方运行方）
- Recency：5/5
- Bias：2/5（leaderboard/商业展示激励）
