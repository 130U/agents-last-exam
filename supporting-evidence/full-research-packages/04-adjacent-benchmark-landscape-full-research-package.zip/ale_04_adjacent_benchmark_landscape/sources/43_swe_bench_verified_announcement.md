# Introducing SWE-bench Verified

- 作者/机构：OpenAI Preparedness + SWE-bench authors
- URL：https://openai.com/index/introducing-swe-bench-verified/
- 发布日期：2024-08-13
- 访问日期：2026-08-08
- 版本/revision：live article snapshot；发布日版本
- 类型：共同发布/人工审查方法说明

## 与本研究直接相关的原文证据

- lines 157–160：由 professional software developers 筛查 issue specification 与 tests；500 个样本来自 original test set；新的 Docker harness 与作者协作完成。
- lines 165–170：93 名有 Python 经验的软件开发者标注 original test set 的 1,699 个随机样本，并检查 underspecification 与 `FAIL_TO_PASS` 是否排斥有效解。
- lines 232–235：多数 original 样本被估计为有经验工程师一小时内任务；Verified 的筛选也改变 difficulty distribution。
- 原文短引："subset of the original test set"；"500 samples"。

## 证据解释

- Verified 是 500 个 runnable instances，不是 93 个专家、1,699 个 annotation records 或 500 次 agent trial。
- 93 是 annotator headcount；1,699 是被人工审查的 random sample count；500 是最终 subset size。
- 工程师给出的完成时间是估计，不是测得的 human success baseline。

## 支持/反驳

- 支持：高质量 benchmark 需要人类检查 specification–test alignment。
- 反驳：人工过滤不能保证零缺陷；后续公开审计发现残余问题。

## 评分

- Credibility：5/5（共同发布、方法与样本量披露）
- Recency：4/5（固定发布；后续被 2026 审计更新）
- Bias：3/5（创建方对自身 subset 的质量主张）
