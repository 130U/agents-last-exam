# SpreadsheetBench 2 论文

- 标题：SpreadsheetBench 2: Evaluating Agents on End-to-End Business Spreadsheet Workflows
- 作者/机构：论文署名团队；RUCKBReasoning
- URL：https://arxiv.org/abs/2606.29955
- 发布日期：2026-06-29
- 访问日期：2026-08-08
- 版本/revision：arXiv `2606.29955v1`

## 与本问题直接相关的原文证据

- 英文短引（arXiv title field）："Evaluating Agents on End-to-End Business Spreadsheet Workflows."
- [事实] 2026 版包含 321 个 runnable task instances：100 financial modeling、100 debugging、97 template、24 visualization。论文叙述称三大类，是因为 generation 下含 financial modeling 与 template；不可据此记为四个独立 benchmark。
- [事实] 每个实例是 natural-language instruction + in-progress workbook → output workbook；平均 11.8 sheets、593.5 modified cells。
- [事实] 来源为公开财务报告/企业 filings 等真实材料，但任务通过专家删除目标区域、注入错误、指定可视化等方式构造，且部分布局/数值被修改。应标为“真实源文件 + synthetic/constructed transformation”。
- [事实] 创建投入超过 1,500 expert-hours（不含 QA）；每个 task 再由两名非创建者专家独立完成并迭代纠正。
- [事实] Docker 环境使用 Python、openpyxl、LibreOffice UNO 等；SWE-agent scaffold 提供 bash、view_xlsx、submit，最多 50 turns，无网络。
- [事实] financial/template/debugging 使用与 gold workbook 的程序化 exact check；指标含修改区域 cell fraction 与 whole-workbook accuracy。visualization 由专家 rubric + GLM-4.6V 二元 criterion judge。
- [事实] 论文没有匹配的 professional human baseline；人类仅代操作 proprietary agents 的 30-task subset，并非人类能力基线。
- [事实] 因 API 成本高，论文没有 error bars 或 confidence intervals；公开资料没有 reported run 的明确 repeated-trial policy。

## 解释、支持与反驳

- 支持 H1：程序化验证规模化，但 exact match 无法容纳全部语义等价；可视化仍依赖 VLM judge。
- 支持 H3：50-turn/tool stack 和 exact evaluator 会把 harness/strictness 混入难度。
- 支持 H4 风险：321 项、任务源和 evaluator 均公开，未见 hidden holdout/rotation/contamination policy。
- [项目建议] 把“正确值、公式结构、可编辑性、格式/可读性”拆成评分维度，避免单一 exact-cell score。

## 评分

- Credibility：5/5（版本固定 primary paper）
- Recency：5/5
- Bias：3/5
