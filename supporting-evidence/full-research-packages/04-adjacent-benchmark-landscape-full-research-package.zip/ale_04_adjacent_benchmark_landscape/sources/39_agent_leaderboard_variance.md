# Agent leaderboard variance：AssistantBench/GAIA 的 model-vs-system 反证

- **标题**：How Reliable Are Agent Leaderboards? A Variance-Decomposition Analysis
- **作者/机构**：Michael Hardy、Anka Reuel、Ruhana Azam、Mykel Kochenderfer、Sanmi Koyejo（workshop 页面署名；PDF 版本为匿名稿）
- **URL**：https://openreview.net/pdf?id=GAu4q6OkLI
- **发布日期**：2026；RLEval/ACM CAIS 2026 workshop manuscript
- **访问日期**：2026-08-08
- **版本/revision**：OpenReview current manuscript snapshot，访问日未见 immutable arXiv revision
- **来源类型**：独立学术分析 / workshop manuscript
- **评分**：Credibility **3/5**（匿名/workshop manuscript，尚非稳定 archival revision）；Recency **5/5**；Bias **4/5**

## 与本研究直接相关的原文证据

> “model–scaffold rankings are reliable while model rankings are not”

论文用 HAL 的七个 agent benchmarks 做 generalizability-theory variance decomposition，明确拆分 model、item、scaffold 及交互。摘要报告：AssistantBench、GAIA、USACO 在其数据中 model–scaffold ranking 可较可靠，但 model-only ranking 不可靠；model 主效应约只占总分方差 3%。单 benchmark 只增加 items 时，model-ranking reliability 上限在其建模下约 0.52；增加 benchmark/context breadth 可提高。

论文建议每个分数声明 object of measurement，至少报告 point estimate、credible interval、measurement object、estimation method，并把 improvement 归给实际改变的 factor。

## 证据解释与单位边界

- **[反方证据]** 增加 1,000 个同质 instances 不必然得到可靠的“模型能力”排序；item count、workflow-family breadth、scaffold count 是不同设计变量。
- **[研究员推断]** 对 ALE-style 项目，默认 evaluation construct 应是 **configured agent system**；若客户要推断 base model，必须跨多个 scaffolds/harnesses 做因子设计。
- **[事实]** 0.52、0.88、3% 等是该 HAL dataset 与统计模型的估计，不是普适常数或生产配额。
- **[事实]** paper snapshot 仍是 workshop manuscript；需等待稳定发表版或独立复现。

## 支持或反驳的结论

- 强支持 H3：harness/scaffold 与模型交互可主导排名。
- 反驳“只要 task 数足够大，可靠性自然提高”的简单数量论。
- 支持 portfolio 设计优先增加独立 workflow contexts、environments 与 scaffolds，而非只复制更多同模板 instances。

## 限制

使用历史 HAL 数据，覆盖范围与 scaffold 分布有限；不能直接给 1,000-task 项目的最优分配比例。
