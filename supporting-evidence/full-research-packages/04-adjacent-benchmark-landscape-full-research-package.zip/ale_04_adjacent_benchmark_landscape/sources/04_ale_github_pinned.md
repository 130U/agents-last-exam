# ALE GitHub repository — pinned 2026-08-08

- 标题：rdi-berkeley/agents-last-exam
- 作者/机构：UC Berkeley RDI / RDI Foundation contributors
- URL：https://github.com/rdi-berkeley/agents-last-exam
- 发布日期：living repository
- 访问日期：2026-08-08
- 固定 revision：`1e615e456de7cef57706680613cb80ee13c7fc76`
- README blob SHA：`5b21e3feba8251d2935bc235913ad5176ad0d9e8`
- 评分：Credibility **5/5**；Recency **5/5**；Bias **3/5**

## 直接证据

- 原文短引（pinned README）：“plus around 150 public tasks across all 55 subdomains”。

- pinned README 把 repo 定义为 open evaluation framework：`ale_run`、sandbox provisioning、agent execution、grading，以及 around **150 public tasks**。
- 支持 GCP、AWS、Alibaba Cloud、QEMU/KVM、部分 Ubuntu Docker、existing sandbox；环境不是单一 container。
- agent 只收到 task description；hidden reference 在完成后 staging；run 保存 trajectory、raw logs、evaluation result 与 artifacts。
- executable `main.py` 把 instruction、input、hidden reference 与 `evaluate()` 绑定；一次 run 是 agent × environment × task。
- software 为 Apache-2.0，benchmark data 为 CC-BY-4.0；第三方软件/输入资产权利仍需逐任务核验。

## 支持 / 反驳

- 支持“asset 不是 prompt”：需要 runnable spec、环境、reference、grader、logs。
- 支持 H3：provider、image、CUA bridge、in/out-of-sandbox harness 都进入结果。
- repo 是 public snapshot，不证明 private pool 完整实现或全池 evaluator 分布。
