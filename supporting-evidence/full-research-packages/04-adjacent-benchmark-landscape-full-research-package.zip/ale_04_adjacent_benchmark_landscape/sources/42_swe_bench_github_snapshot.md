# SWE-bench official repository snapshot

- 作者/机构：SWE-bench maintainers
- URL：https://github.com/SWE-bench/SWE-bench
- 发布日期：持续维护
- 访问日期：2026-08-08
- 版本/revision：branch `main`，commit `cd37836ffec01d01a0d699a80a039d84ff2cebfe`
- 类型：官方代码/evaluation harness

## 与本研究直接相关的原文证据

- GitHub live DOM（2026-08-08）：latest commit link 指向 `cd37836ffec01d01a0d699a80a039d84ff2cebfe`。
- README live snapshot，lines 179–181：2025-01-13 的 Multimodal test evaluation 保持 private；2024-08-13 发布 500-instance Verified；2024-06-27 转向 Docker containerized harness。
- 原文短引："kept evaluation for the test split private"（仅 Multimodal entry）；"subset of 500 problems"（Verified）。

## 证据解释

- “private evaluation”是后续 Multimodal test surface 的政策，不能回写到 original/Verified。
- repo 同时承载多个 benchmark family surface；比较成绩必须记录 dataset name、commit、image/harness version、agent scaffold、model、budget 与 retry policy。

## 支持/反驳

- 支持：containerization 提升可复现性，但不消除 task/test mismatch、contamination 或 infrastructure noise。
- 支持：SWE-bench family 内部已出现不同 public/private policy。

## 评分

- Credibility：5/5（官方代码与变更记录）
- Recency：5/5（访问当日 commit pin）
- Bias：4/5（维护者自述）
