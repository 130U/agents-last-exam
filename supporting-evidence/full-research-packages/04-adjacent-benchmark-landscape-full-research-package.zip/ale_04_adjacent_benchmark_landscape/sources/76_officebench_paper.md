# OfficeBench 论文（canonical identity）

- 标题：OfficeBench: Benchmarking Language Agents across Multiple Applications for Office Automation
- 作者/机构：Zilong Wang 等；论文署名机构为准
- URL：https://arxiv.org/abs/2407.19056
- 发布日期：2024-07-26
- 访问日期：2026-08-08
- 版本/revision：arXiv `2407.19056v1`

## 与本问题直接相关的原文证据

- 英文短引（arXiv title field）："Benchmarking Language Agents across Multiple Applications for Office Automation."
- [事实] 本报告锁定的是 2024 language-agent benchmark，不是 2007 年同名 Windows/Office PC performance benchmark。
- [事实] 300 个 runnable task instances：93 single-application、95 two-application、112 three-application。
- [事实] 应用是 Docker 中的 Python tool APIs：System、Word、Excel、PDF、Calendar、Email、OCR、ChatGPT、Shell，共 23 类 operations；不是对真实 Microsoft Office GUI 的操作。
- [事实] 任务 instruction、documents、emails、calendar entries 由 ChatGPT 和随机生成器合成以规避隐私；并非真实职业 deliverables/workflow logs。
- [事实] agent 最多 50 actions；连续 5 次相同行为判定 stagnation。多 app/action chain 是 workflow-length proxy，不证明真实 long-horizon work。
- [事实] evaluator 使用 per-task exact、fuzzy 和 execution-based checks，主指标为 pass rate。
- [事实] human baseline 为两名计算机科学研究生，总体 93.33%；并非 occupation-matched professionals，样本也不足以估计人群分布。
- [事实] 公开资料未披露 task-production monetary cost、agent repeated trials、hidden holdout、rotation 或 contamination policy。

## 解释、支持与反驳

- 支持 H2：串联 1–3 个应用并不自动形成真实专业 long-horizon workflow。
- 支持 H3：有限 API、50-step/stagnation rule 和 fuzzy evaluator 会把 harness/strictness 混入难度。
- 支持 H4 风险：300 项全部公开且无轮换。
- [项目建议] 若保留 OfficeBench，应标为“synthetic cross-application tool-routing benchmark”，不能标成真实 office-work benchmark。

## 评分

- Credibility：5/5（版本固定 primary paper）
- Recency：3/5（2024 静态版本）
- Bias：3/5
