# WorkArena++：论文版本面

- **标题**：WorkArena++: Towards Compositional Planning and Reasoning-based Common Knowledge Work Tasks
- **作者/机构**：Léo Boisvert、Megh Thakkar、Maxime Gasse、Massimo Caccia、Thibault Le Sellier De Chezelles、Quentin Cappart、Nicolas Chapados、Alexandre Lacoste、Alexandre Drouin；ServiceNow Research、Mila、Polytechnique Montréal 等
- **URL**：https://arxiv.org/html/2407.05291v2
- **发布日期**：2024-07-07；v2 更新 2025-02-05
- **访问日期**：2026-08-08
- **版本/revision**：arXiv `2407.05291v2`；NeurIPS 2024 Datasets and Benchmarks Track
- **来源类型**：原始论文 / benchmark 作者
- **评分**：Credibility **5/5**；Recency **5/5**（pinned）；Bias **3/5**

## 与本研究直接相关的原文证据

> “each cover the same set of 341 workflows”

论文 §3.1 说明 L2 与 L3 是同一批 341 workflows 的两种任务呈现：L2 明示步骤，L3 通过 ticket/knowledge base 给出隐式目标，因此总计 `2×341=682 tasks`，不是 682 个独立 workflows。每项任务由较简单的 atomic tasks 作逻辑组合。五类目标能力为 planning/problem solving、information retrieval、data-driven decision/reasoning、sophisticated memorization、contextual understanding（含 infeasible cases）。

运行环境是 ServiceNow Personal Developer Instance；每个任务有程序化 Playwright oracle 与 binary validator，后者检查 backend/database 或页面状态。evaluation curriculum 将 seeds 0–9 留作评测并建议多 seeds；论文的 agent curriculum 对 L2/L3 各采 235 instances（合计 470），最多 50 actions。

human study 为 15 人完成 98-task subset，论文报告 93.9%；11/15 为 ServiceNow employees，约 75% 的参与者完成大部分任务，46.7% 自报首次使用 ServiceNow。human 无与 agent 完全一致的 action cap。

## 证据解释与单位边界

- **[事实]** `341 workflows`、`682 task presentations`、`470 sampled runnable instances`、`15 human participants` 是不同单位。
- **[事实]** real-world workflow 由 atomic components 程序化组合；其可扩展性和 evaluator 自动化较强，但 task family/template structure 高度可见。
- **[作者主张]** 这些组合“routinely performed by knowledge workers”；由于只在 ServiceNow、且 human sample 偏向雇员，这一外部效度尚未独立验证。
- **[研究员推断]** composition 不自动证明 long-horizon authenticity；L3 主要改变目标表达，而非底层 workflow。这是 H2 的正反并存案例。
- **[事实]** 论文明确把 hidden test 留作未来方向；生产人工时、美元成本、正式 private holdout 为 **公开资料不足**。

## 支持或反驳的结论

- 支持 H1：程序化 oracle/validator 与大规模配置采样以缩窄到单平台和可组合 task family 为代价。
- 支持 H2 的审慎表述：有逻辑依赖的组合强于简单串联，但仍需真实工作审计。
- 强支持 H3：action cap、instruction explicitness、platform familiarity 与 seed sampling 都影响难度。
- 支持 H4 风险：公开 generator/oracle 且论文无 hidden test；reserved seeds 不是隐藏 workflow holdout。

