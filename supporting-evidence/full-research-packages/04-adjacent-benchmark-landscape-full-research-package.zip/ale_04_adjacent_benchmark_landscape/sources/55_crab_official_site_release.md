# CRAB official project site / Benchmark-v0 release

- 作者/机构：CRAB authors / CAMEL-AI
- URL：https://crab.camel-ai.org/
- 发布日期：2024-10-18（Benchmark-v0 release noted on page）
- 访问日期：2026-08-08
- 版本/revision：CRAB Benchmark-v0，120-task website snapshot
- 类型：官方项目页/leaderboard snapshot

## 与本研究直接相关的原文证据

- lines 6–8、18：site 固定为 120 tasks、2 environments（Ubuntu/Android）、6 MLMs、3 communication settings，release 2024-10-18。
- lines 22–25：cross-environment support、graph evaluator、sub-task composition；actions/observations/evaluators 均为 Python functions。
- lines 55–68：graph-based evaluation 是 DAG intermediate checkpoints；task sourcing 分 handmade、LLM-inspired+human verification、template、sub-task composition。
- lines 77–83：completion ratio 是 graph evaluator partial metric；step limit、invalid action 和 false completion 是 termination failure sources。
- 原文短引："120 tasks across 2 environments"；"Sub-task Composition"。

## 证据解释

- 网站 120-task inventory 与 arXiv v4 abstract 对齐，但与论文正文的 100-task breakdown 不一致；必须保留 version matrix。
- 35/53/12 breakdown 不能用于 120-task current release 配额，除非 repo manifest 重新审计。
- completion ratio 不能当 success rate；SR=all-or-nothing task completion，CR=graph node partial completion。

## 支持/反驳

- 支持：intermediate state DAG 比 gold trajectory 更允许多条有效路径。
- 限制：site 的“closely mimic real-world scenarios”是作者主张，未提供职业抽样框或外部效度数据。

## 评分

- Credibility：5/5（官方 release/leaderboard）
- Recency：5/5（访问日 live snapshot）
- Bias：3/5（宣传性 project page）
