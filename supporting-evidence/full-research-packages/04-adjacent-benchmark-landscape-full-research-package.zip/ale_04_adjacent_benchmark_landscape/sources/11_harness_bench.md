# Harness-Bench

- 标题：Harness-Bench: Measuring Harness Effects across Models in Realistic Agent Workflows
- 作者/机构：Yilun Yao et al.
- URL：https://arxiv.org/html/2605.27922
- 发布日期：2026-05-27
- 访问日期：2026-08-08
- 版本：arXiv `2605.27922v1`
- 评分：Credibility **4/5**；Recency **5/5**；Bias **3/5**

## 统一矩阵证据

- 原文短引（§3）：“Agent = Model + Harness.”

- **construct**：configuration-level model–harness diagnostics，而不是 bare model ranking 或 harness component causal estimate。
- **task unit**：106 local sandboxed runnable tasks；每个 task manifest 含 prompt/sequence、fixtures、evaluator、timeout、category、tags、runtime hooks。
- **coverage**：8 workflow categories，覆盖 codebase、data/BI/finance、workspace/tool、knowledge/evidence、office、vertical professional、long-running state adaptation、SRE/DevOps。
- **real/synthetic**：由 practical agent-use patterns/common user requests 构造并人工审查；是 realism-oriented constructed tasks，不等同真实历史项目采样。
- **environment**：offline sandbox，固定 initial state/budget/timeout/evaluator；避免 live-service drift。
- **expert**：作者称 manual review realism、solvability、oracle-checkability、integrity；公开资料未证明各 vertical task 都由领域专家制作。
- **evaluator**：deterministic validator where possible、rubric judgment where necessary；trace 有 LLM process rubrics，security/permission binary gate。
- **runs**：主 factorial 为 6 harnesses × 8 model backends × 106 tasks = 5,088 trajectories；另有 106 Codex runs。trajectory 是 run，不是 task asset。
- **private/contamination**：hidden answers/evaluator scripts 不暴露给运行中 agent；公开资料不足以确认长期 private holdout/rotation。
- **human baseline / cost**：没有匹配的人类 task performance baseline；记录 tokens/turns/usage，但公开资料不足以给 1,000-task 生产成本。

## validity / saturation

- 优点：直接固定外部条件，保存 artifacts、traces、usage、validator outputs，适合拆分 harness effect。
- 限制：保留 harness native behavior，因此只能比较 configuration，不是 harness 机制的因果分解；constructed offline realism 与 live professional workflow 之间仍有外部效度差距。
- 对 H3 为强支持：论文在共享任务条件下仍观察 model–harness pairing 的显著差异。
