# Terminal-Bench: Benchmarking Agents on Hard, Realistic Tasks in Command Line Interfaces

- 作者/机构：Mike A. Merrill、Alexander G. Shaw、Nicholas Carlini 等 85 名作者
- URL：https://arxiv.org/html/2601.11868v1
- 发布日期：2026-01-17
- 访问日期：2026-08-08
- 版本/revision：arXiv `2601.11868v1`；论文研究对象 `Terminal-Bench 2.0`
- 类型：原始论文（ICLR 2026）

## 与本研究直接相关的原文证据

- lines 92–103：一个 task 由 instruction、containerized environment、tests、manual reference solution、time limit 组成；tests 判定 final container state，不比对命令轨迹。
- lines 105–115：93 contributors 提交 229 tasks；三名 experienced reviewers 筛出 89；平均每个 final task 约三 reviewer-hours。
- lines 138–151：35 Android? 不适用；此处 Terminal-Bench 的 human time 是 task author 对 expert/junior completion time 的估计，不是测得 baseline；分布见 Table 1。
- lines 155–170：每个 supported model–agent combination 至少跑五遍，合计 32,155 trials；一个 trial 是一个 agent 对一个 task 的 attempt；Harbor 用 32–100 个容器并行。
- lines 174–181：一次 full benchmark run 的模型成本范围从约 1 到 100 美元（取决于 model price）；部分单 task trial 可达两小时/近 1 亿 tokens；作者预期可能一年内 saturation。
- 原文短引："89 challenging tasks"；"at least five times"；"one agent’s attempt"。

## 证据解释

- 89 是 runnable task instances；229 是 submissions；93 是 contributors；32,155 是 trials。四者绝不能互换。
- Terminal-Bench 2.0 把“long horizon”部分落在交互时长和多步操作上，但 task author time estimates 不是实测职业 workflow baseline。
- benchmark 评价完整 agent system；paper 明确 agent scaffold 和 model 难以解耦。

## 支持/反驳

- 支持 H1：unique environment + outcome tests 可扩展，但高质量验证耗费大量专家审查。
- 支持 H3：agent scaffold、tool access、resource budget 会改变结果。
- 支持 H4/saturation concern：作者主动预计静态 2.0 可能快速饱和并计划新任务集。

## 评分

- Credibility：5/5（版本化原始论文）
- Recency：5/5（2026）
- Bias：4/5（创建者论文，主动披露限制与成本）
