# Windows Agent Arena official repository snapshot

- 作者/机构：Microsoft / WindowsAgentArena maintainers
- URL：https://github.com/microsoft/WindowsAgentArena
- 发布日期：持续维护
- 访问日期：2026-08-08
- 版本/revision：branch `main`，commit `6d39ed88c545a0d40a7a02e39b928e278df7332b`
- 类型：官方代码、task configuration、deployment docs

## 与本研究直接相关的原文证据

- Browser live DOM：latest commit `6d39ed88...`；4 tags；repo 于 2024-11-10 增加 `diff_lvl="hard"`，要求部分 tasks 自行启动/设置环境。
- GitHub lines 242–259：Windows 11 evaluation ISO + 30GB golden image；一次 image preparation 约 20 分钟。
- lines 270–307：local benchmark runner 与多个 SoM/a11y configurations；不同 configuration 不是同一 harness。
- lines 405–413：FAQ snapshot 的 40-VM approximate cost：Azure compute ~$8；GPT-4V/4o ~$100；GPT-4o-mini ~$15；约 30–35 min。
- 原文短引："new harder difficulty mode"；"30GB WAA golden image"。

## 证据解释

- paper v2 的 standard mode 与 post-paper hard mode 必须视为不同 evaluation configuration；不能在一条 leaderboard row 混用。
- cost 仅是当时 40-VM/特定 models 的 approximate snapshot，价格和吞吐会漂移，不能转成 1,000-task 项目配额。
- repo task/evaluator/config 全公开；未发现 hidden holdout 或 rotation policy。

## 支持/反驳

- 支持 H3：initialization difficulty、screen parser、VM/provider 都能改变难度。
- 支持项目建议：golden image checksum、app version、locale、DPI、network fixtures、configuration flags 必须纳入 manifest。

## 评分

- Credibility：5/5（官方代码与部署文档）
- Recency：5/5（访问日 commit pin）
- Bias：4/5
