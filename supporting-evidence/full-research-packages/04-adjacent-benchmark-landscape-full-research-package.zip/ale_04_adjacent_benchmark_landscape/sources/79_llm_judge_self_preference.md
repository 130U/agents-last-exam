# LLM evaluator 自偏好效度证据

- 标题：LLM Evaluators Recognize and Favor Their Own Generations
- 作者/机构：Panickssery 等
- URL：https://arxiv.org/abs/2404.13076
- 发布日期：2024-04-19
- 访问日期：2026-08-08
- 版本/revision：arXiv `2404.13076` 当前论文记录；具体 revision 未在本卡作未核验断言

## 与本问题直接相关的原文证据

- 英文短引（arXiv title field）："LLM Evaluators Recognize and Favor Their Own Generations."
- [独立学术证据] 论文发现 LLM evaluators 能识别并偏好同源模型生成内容，使自动比较产生 systematic bias。
- [事实] 该现象与 GDPval 论文对高能力同家模型的较低 grader agreement/偏好观察方向一致，但不是对 GDPval 或 SpreadsheetBench 2 的直接复现实验。

## 解释、支持与反驳

- 支持 H1/H3：LLM/VLM judge 的 strictness 与模型来源可能改变结果，难度不全是目标专业能力。
- [项目建议] judge 需要跨模型 ensemble、blind provenance、职业专家抽审、分层 false-positive/negative audit；公开资料不足时不得宣称 human-equivalent grading。

## 评分

- Credibility：4/5（独立方法研究）
- Recency：3/5（2024；机制仍相关）
- Bias：4/5
