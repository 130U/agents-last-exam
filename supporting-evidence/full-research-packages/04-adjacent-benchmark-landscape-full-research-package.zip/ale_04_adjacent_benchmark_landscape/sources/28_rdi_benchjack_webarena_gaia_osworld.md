# BenchJack：WebArena / GAIA / OSWorld evaluator exploit 反证

- **标题**：How We Broke Top AI Agent Benchmarks: And What Comes Next
- **作者/机构**：Hao Wang、Qiuyang Mang、Alvin Cheung、Koushik Sen、Dawn Song；UC Berkeley RDI
- **URL**：https://rdi.berkeley.edu/blog/trustworthy-benchmarks-cont/
- **发布日期**：2026-04
- **访问日期**：2026-08-08
- **版本/revision**：官网页面当日 snapshot；关联 arXiv `2605.12673` 与 BenchJack 工具
- **来源类型**：研究机构 adversarial audit；不是 WebArena/GAIA/OSWorld 官方实现来源
- **评分**：Credibility **4/5**（给出可运行 exploit 与代码线索）；Recency **5/5**；Bias **4/5**（推广审计工具，但主动披露边界）

## 与本研究直接相关的原文证据

> “Navigating Chromium to a `file://` URL reads the gold answer directly … ~100% on all 812 WebArena tasks.”

WebArena exploit 读取 `config_files/{task_id}.json`；作者还演示 `must_include` 可被隐藏 DOM 内容满足，LLM judge 可被 prompt injection 偏置。GAIA 部分称 validation answers 在 HF 公开，对 165 validation answers 作 lookup，并利用 normalization；OSWorld 部分指出 gold file URLs 位于 task metadata，attack 下载 public gold、直接设定 evaluator 检查的 state，且指出 untrusted `eval()` 风险。

## 证据解释与边界

- **[研究机构主张]** zero-capability exploit agent 可在这些 snapshot 获得近满分；这需要以其代码与原 evaluator revision 复现，但已构成强反例。
- **[事实]** 页面明确说“不主张当前 leaderboard leaders 在作弊”；漏洞存在不等于真实 submission 都利用漏洞。
- **[反方证据]** functional evaluator 若让 agent 读取 reference、影响 grader 或写入受信路径，高分可能来自 grader gaming 而非任务能力。
- **[研究员推断]** public task data、agent runtime、evaluator secret 必须是三个隔离权限域；只靠 instruction “不要作弊”不是控制。
- **[事实]** 这些 attack 对应特定代码/数据 snapshot；OSWorld-Verified、WebArena-Verified 或后续 release 是否完全修复需逐版本复测。

## 支持或反驳的结论

- 强支持 H3：evaluator weakness 可制造虚假成功或虚假失败。
- 强支持 H4：公开答案/ground truth 将 validation 退化成 lookup opportunity。
- 支持 H1：完全自动 evaluator 必须增加隔离、adversarial QA、null/random/tampering agents 和 private references，成本并非零。

## 对项目可复用的审计项

agent 与 evaluator 分离；references 不进入 agent-readable config；只读 verifier host；禁止 untrusted `eval()`；LLM-judge input 结构化和注入测试；null/random/state-tampering/prompt-injection agents；失败 task 不从 denominator 静默删除；定期轮换 private test。

## 限制

此来源与 ALE 同属 Berkeley RDI 生态，不能作为所有 ALE 主张的独立验证；本文件只把它作为邻近 benchmark evaluator 的 adversarial counterexample。
