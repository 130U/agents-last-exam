# SWE-rebench: An Automated Pipeline for Task Collection and Decontaminated Evaluation of Software Engineering Agents

- 作者/机构：Nebius/独立研究团队；作者详见 arXiv `2505.20411`
- URL：https://arxiv.org/abs/2505.20411
- 发布日期：2025-05-26
- 访问日期：2026-08-08
- 版本/revision：访问日 arXiv current revision
- 类型：独立 benchmark/pipeline study

## 与本研究直接相关的原文证据

- lines 5–6：持续抽取真实 GitHub tasks，并用新鲜任务比较 SWE-bench Verified；部分模型成绩可能被 contamination inflation。
- line 143：研究 benchmark subset 为 294 executable tasks、169 repositories；大数据 release 超过 21,000 interactive tasks。
- lines 243–246：自动安装配置和 LLM-based quality assessment 不完美，不能完全代替 nuanced human judgment。
- 原文短引："continuous supply of fresh tasks"；"cannot fully replicate nuanced human judgment"。

## 证据解释

- 21,000+ 是训练/研究 data inventory；294 是某一 benchmark slice；二者不能合并。
- 滚动采集降低 exposure age，但“contamination-free”仍是作者主张，取决于 cutoff、provider training data 和 issue timing。

## 支持/反驳

- 支持 H4：fresh/rotating collection 是缓解静态 benchmark 老化的设计。
- 反方：自动扩规模会把 installation、specification 与 evaluator errors 引入任务库，仍需人工/执行验证。

## 评分

- Credibility：5/5（独立论文，规模与限制披露）
- Recency：5/5
- Bias：4/5（新 benchmark 创建者，但主动披露自动化限制）
