# OSWorld：论文版本面

- **标题**：OSWorld: Benchmarking Multimodal Agents for Open-Ended Tasks in Real Computer Environments
- **作者/机构**：Tianbao Xie 等；The University of Hong Kong、Salesforce Research 等
- **URL**：https://arxiv.org/html/2404.07972v2
- **发布日期**：2024-04-11；v2 更新 2024-05-30
- **访问日期**：2026-08-08
- **版本/revision**：arXiv `2404.07972v2`；NeurIPS 2024 Datasets and Benchmarks Track 版本面
- **来源类型**：原始论文 / benchmark 作者
- **评分**：Credibility **5/5**；Recency **5/5**（immutable pinned revision）；Bias **3/5**（作者评价自己的 benchmark）

## 与本研究直接相关的原文证据

> “369 computer tasks involving real web and desktop apps, OS file I/O, and workflows spanning multiple applications.”

论文 §3–4 还明确：每项 task 由初态配置和 task-specific execution evaluator 定义，共 134 unique evaluation functions；九位具有 computer science 背景的作者参与任务标注；主实验的 Ubuntu 环境运行真实应用，另有 Windows 分析子集；launch baseline 每个 task 最多 15 steps；reward 在 `[0,1]`，可包含部分分与不可行任务处理。Table 3 报告 human 72.36%。论文披露动态在线内容可进入 evaluator，但也承认真实软件与运行依赖带来较高构建、维护和评估成本，且没有把安全副作用纳入评分。

## 证据解释与单位边界

- **[事实]** `369` 的单位是论文 v2 的 **runnable task instances**，不是 369 个 workflow 模板，也不是 369 次 agent runs。
- **[事实]** evaluation construct 是在真实桌面/网页应用中完成开放式计算机任务后的可执行状态验证；不是只测裸模型，也不是只测语言答案。
- **[作者主张]** 任务“open-ended”“real computer environments”的外部真实性由作者提出；论文没有职业抽样框或经济权重来证明对真实工作的代表性。
- **[研究员推断]** 15-step harness、环境配置、工具接口与 evaluator 共同决定观察分数，因此 launch 分数不能直接解释为模型的独立 GUI 能力。
- **[事实]** 论文未给出 hidden holdout、rotation cadence 或固定 repeated-trial protocol；有关长期抗污染能力为 **公开资料不足**。

## 支持或反驳的结论

- 支持 H1：真实应用与可执行 evaluator 可结合，但论文自己披露较高标注/维护成本与 evaluator 专门化。
- 支持 H3：task success 同时受 step budget、环境、工具和 evaluator 影响。
- 支持 H4 的风险面：静态 369-instance 集及 evaluator/数据公开，长期有效性需要另行验证。
- 对 H2 不作强支持：OSWorld v1 多应用不等于经证实的 professional long-horizon workflow。

## 限制

72.36% human 与 12.24% launch-best 均是该论文特定 snapshot；不能作为 2026 当前表现或 1,000-task 项目生产配额。
