# SWE-bench: Can Language Models Resolve Real-World GitHub Issues?

- 作者/机构：Carlos E. Jimenez 等；Princeton University 等
- URL：https://arxiv.org/abs/2310.06770
- 发布日期：2023-10-10；最后修订：2024-11-11
- 访问日期：2026-08-08
- 版本/revision：arXiv `2310.06770v3`
- 类型：原始论文（ICLR 2024 Oral）

## 与本研究直接相关的原文证据

- arXiv abstract，lines 16–19：论文将 benchmark 定义为 2,294 个来自 12 个 Python 仓库的真实 GitHub issue–PR 软件工程问题；agent/system 获得 issue 描述和代码库并修改代码。
- 原文短引："2,294 software engineering problems"；"12 popular Python repositories"。
- arXiv revision history，lines 8、23、28–30：当前可引用版本为 v3，而非 2023 年 v1。

## 证据解释

- task unit 是一个由 `issue + base repository state + corresponding PR-derived tests` 构成的 runnable issue-resolution instance；不是一个抽象 workflow，也不是一次 agent run。
- 论文的 2,294 是 original benchmark 的 instance 数，不能挪作 Verified、Lite、Multimodal 或当前 leaderboard 的数量。
- "real-world" 主要指 issue/PR 来源真实，不等于任务覆盖了软件工程从需求澄清、设计、协作、部署到维护的完整岗位流程。

## 支持/反驳

- 支持：SWE-bench 提供真实代码库、执行环境和 test-based outcome evaluation。
- 限制：只覆盖 12 个 Python 仓库，且问题与参考修复均公开，代表性与抗污染性不能由该论文自证。

## 评分

- Credibility：5/5（版本化原始论文）
- Recency：4/5（immutable v3；实现与 leaderboard 已继续变化）
- Bias：4/5（作者论文，明确贡献但没有后续污染审计）
