# GDPval Hugging Face 数据集

- 标题：openai/gdpval
- 作者/机构：OpenAI
- URL：https://huggingface.co/datasets/openai/gdpval
- 发布日期：2025
- 访问日期：2026-08-08
- 版本/revision：HF git revision `11e7900cdcac61bc4daf59e65feb238acda98fbf`；commit label “Release GDPval v2 (rubrics + deliverables)”

## 与本问题直接相关的原文证据

- 英文短引（HF commit message field）："Release GDPval v2."
- [事实] 当前 HF revision 提供 220 个公开 gold task instances，并新增 rubrics 与 gold deliverables。
- [事实] 早期 revision `69763877…` 的 README 描述为 prompt/reference-only release；因此“GDPval v2”是数据发布面变化，不能与 arXiv `2510.04374v1` 合并成论文 v2。
- [事实] 数据集公开面不包含完整 1,320 instances，也没有公开的 rotation cadence、contamination audit 或 private leaderboard contract。

## 解释、支持与反驳

- 支持版本矩阵要求；反驳“论文/数据/官网当前数字是同一快照”。
- [研究员推断] 发布 gold deliverables 增强 evaluator 复现，也增加 reference leakage 和 benchmark-specific optimization 风险。

## 评分

- Credibility：5/5（官方 revision-pinned dataset）
- Recency：5/5
- Bias：3/5
