# OdysseyBench 对 OfficeBench long-horizon construct 的反例

- 标题：OdysseyBench: Evaluating Long-Term Conversational Agents
- 作者/机构：论文署名团队
- URL：https://arxiv.org/abs/2508.09124
- 发布日期：2025-08-12
- 访问日期：2026-08-08
- 版本/revision：arXiv 当前快照（访问日；未在本卡把未核验 revision 编号写成事实）

## 与本问题直接相关的原文证据

- 英文短引（arXiv title field）："Evaluating Long-Term Conversational Agents."
- [独立学术证据] 作者把 OfficeBench task 描述为主要 atomic/self-contained，并据此构建跨日期的 dialogue-history variants。
- [事实] OdysseyBench+ 由 OfficeBench 等任务扩展为多轮/跨日上下文，但历史和部分执行仍经生成或模拟，并不等于真实 workplace workflow log。

## 解释、支持与反驳

- 支持 H2：OfficeBench 的多 app action chain 缺少长期上下文依赖；加入 dialogue history 是更强测试，但仍未解决数据真实性。
- [研究员推断] “long-horizon”至少需分别标注 action horizon、elapsed-time horizon、cross-session state 和 professional phase dependency。
- [项目建议] 若需要 multi-app/long-term 对照，可用 OdysseyBench 替代 OfficeBench，但必须明确其 synthetic lineage；它不能替代真实专业文件 benchmark。

## 评分

- Credibility：4/5（独立相邻 primary paper）
- Recency：4/5
- Bias：3/5（提出自有 benchmark）
