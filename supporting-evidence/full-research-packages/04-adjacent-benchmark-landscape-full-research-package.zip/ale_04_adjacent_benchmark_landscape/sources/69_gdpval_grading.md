# GDPval 官方 grading 指南

- 标题：GDPval Grading
- 作者/机构：OpenAI Evals
- URL：https://evals.openai.com/gdpval/grading
- 发布日期：2026
- 访问日期：2026-08-08
- 版本/revision：live documentation snapshot，2026-08-08

## 与本问题直接相关的原文证据

- 英文短引（documentation title field）："GDPval Grading."
- [事实] 文档把 occupation-expert human pairwise preference 定义为 benchmark 标准，LLM judge 仅提供 rough estimate。
- [事实] rubrics 与 gold deliverables 已开源，用于复现/诊断 grading。
- [事实] 文档没有证明 automated judge 与职业专家在所有 occupation、模型能力区间和 artifact type 上等价。

## 解释、支持与反驳

- 支持 H1：专业真实性和完全自动验证之间仍有结构性缺口。
- [项目建议] 自动 grader 可做 pre-QA/routing，但关键验收需人类 adjudication；按 artifact type 维护 agreement 和 false-positive/negative audit。

## 评分

- Credibility：5/5（官方 evaluator documentation）
- Recency：5/5
- Bias：3/5
