# OSWorld 2.0：官方 release 与 anti-leakage 实现面

- **标题**：xlang-ai/OSWorld-V2 — release-controlled evaluation environment
- **作者/机构**：XLANG Lab / OSWorld 2.0 authors
- **URL**：https://github.com/xlang-ai/OSWorld-V2
- **发布日期**：初始公开 release 2026-06-26
- **访问日期**：2026-08-08
- **版本/revision**：repo HEAD `1189c6a5ddd4e1b8c6c756e03fd5d41bb50f6ba5`；可比运行应固定 release `osworld-v2-2026.06.24` / tag `v2026.06.24`（release commit `2b9b7b4`）
- **来源类型**：官方 repo / release manifest
- **评分**：Credibility **5/5**；Recency **5/5**；Bias **3/5**

## 与本研究直接相关的原文证据

> “Do not mix releases or replace a pinned tag with `main` or `latest`.”

README 的 release-control 段要求 code、HF Python task files、HF task assets、mocked website deployment 使用同一 release；task classes 采用 gated distribution，目的在减少 benchmark leakage 和 agent 在线找到答案/设置/evaluator。它还说明 public assets repository 不是完整 snapshot。release 固定 108 tasks、task dataset、mocked websites、provider image；GitLab-backed tasks 必须 self-host 并配置 private token。

## 证据解释与版本边界

- **[事实]** release unit 不是单一 Git commit，而是 code、Python task classes、assets、websites、provider image 的联合 manifest；混用任一组件即失去官方可比性。
- **[事实]** task classes 与完整 assets 采用 gated HF distribution；这是访问控制和泄漏减缓，不等同统计上从未暴露的 private holdout。
- **[事实]** `main` 是开发面；本研究不得把 HEAD 的功能与 `v2026.06.24` 的正式成绩混合。
- **[机构主张]** gating“helps prevent”在线找答案；其实际污染降低幅度尚无独立测量。
- **[研究员推断]** 这种 multi-component release manifest 是 ALE-style 生产中应直接复用的基础设施模式；但每次 run 仍须记录 provider、region、image、screen、budget、retry、agent harness。
- **[事实]** release rotation cadence、私有 test 比例、托管成本为 **公开资料不足**。

## 支持或反驳的结论

- 支持 H3：环境/provider/version provenance 是测量的一部分。
- 部分支持 H4 的解决路径：固定 release + gated logic 优于全公开；尚未证明能长期防污染。
- 支持 H1：可复现性需要维护成组基础设施，并非“发布 JSON 就结束”。

## 限制

repo README 是官方当前实现说明；其中 release metadata 不能证明专业任务外部效度或 evaluator 准确率。
