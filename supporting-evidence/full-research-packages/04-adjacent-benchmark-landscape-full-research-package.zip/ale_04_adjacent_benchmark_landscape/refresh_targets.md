# Refresh targets

研究截止：2026-08-08。下列对象是 mutable surface；再次用于决策、采购、发布或比较时必须重新访问并记录新 revision。immutable arXiv revision 仅在明确切换版本时更新。

| Target | Frozen snapshot | Refresh trigger | What to re-pin |
|---|---|---|---|
| ALE homepage | 2026-08-08 live | 每次交付/官网计数变化 | 页面日期、tasks/experts/sub-industries 原样文案；不得回填 paper |
| ALE submit | 2026-08-08 live | submission schema/QC 改版 | 字段、准入、权利/奖励、QC gate |
| ALE GitHub | `1e615e456de7cef57706680613cb80ee13c7fc76` | harness/task tree/evaluator/release 更新 | commit、tag、task manifest、runner/provider、README blob |
| ALE Hugging Face | `a8c1fd174a1f6cfa76526572a2e3ebece1276be2` | dataset revision/row/schema 更新 | revision、row count、split、schema、license/card version |
| ALE RDI blog | 2026-08-08 live | institution page 更改 | 发布/修改日期、claim 原文、计数单位 |
| ALE leaderboard | ALE-V1；best-per-task 2026-07-04；runtime method 2026-07-10 | 任一结果/评测方法/agent 更新 | corpus version、agent manifest、harness、effort、runs、cost/runtime口径、日期 |
| OSWorld/OSWorld2 | paper/repo snapshots in sources 20–24 | OS/app image、verified set、result protocol 更新 | paper version、release/tag/commit、task manifest、VM/image、evaluator |
| WebArena/Verified | sources 25–28 | verified manifest/evaluator/网站快照更新 | templates vs instances、site state、evaluator revision、run policy |
| WorkArena/BrowserGym | sources 29–31 | ServiceNow/BrowserGym release 更新 | workflow/instance counts、release/tag、browser/site version、evaluator |
| GAIA/AssistantBench | sources 32–39 | HF split/revision、private leaderboard、HAL update | paper total vs accessible split、dataset revision、submission protocol |
| SWE-bench family | repo `cd37836…`; paper/subsets in 40–46 | Verified/Multimodal/live replacement 更新 | family name、subset manifest、repo/image/test revisions、contamination audit |
| Terminal-Bench | TB2 repo `2fd12b8…`; sources 47–53 | 2.1/challenge/integrity update | dataset/repo tag、task manifest、repetitions、resource config、trace rules |
| CRAB | paper v4/repo `c0790b…` | release-tagged manifest 出现 | 必须先消解 100 vs 120，再记录 evaluator DAG/version |
| Windows Agent Arena | paper v2/repo `6d39ed…` | harder mode/image/parser 更新 | protocol name、task manifest、VM/app/parser/evaluator、human baseline |
| RLI | paper v1/repo/HF sources 60–64 | private-set/leaderboard/rotation update | public/private manifest、human evaluator protocol、cost/time口径 |
| GDPval | paper v1/HF `11e7900…` | HF dataset release或grading更新 | paper version 与 dataset version 分开；public/full、rubric、judge |
| SpreadsheetBench 2 | paper v1/repo `599b24a…`/HF `9dea600…` | manifest/evaluator/CI 更新 | V1/V2分开；task manifest、source rights、evaluator/VLM revision |
| OfficeBench | paper v1/repo `b978b80…` | repo/evaluator更新 | 确认仍是 API synthetic benchmark，不与 2007 同名项混淆 |
| MBABench | arXiv `2605.22664v4` | paper/repo/data release更新 | canonical title、task manifest、expert/evaluator validation |
| Pricing/licensing/cloud | 仅访问日快照 | 每次预算/排期 | provider price、license、VM quota、storage/egress；不得复用论文报价 |

## Incident-triggered refresh

- task/reference/evaluator/solution 泄漏；训练数据曝光证据；agent 读取 grader 或修改 timeout。
- OS、browser、app、package、API、license、network policy 变化造成重现差异。
- evaluator FP/FN、等价解、错误 reference 或不可能任务被举报。
- leaderboard protocol、retry、best-of-N、cost/runtime aggregation 变化。
- domain sampling frame、客户目标人群或 intended-use claim 改变。
