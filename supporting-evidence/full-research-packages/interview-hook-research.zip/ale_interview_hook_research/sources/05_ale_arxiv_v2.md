# Source 05 — Agents' Last Exam, arXiv v2

- URL: https://arxiv.org/html/2606.05405v2
- Version: arXiv:2606.05405v2, 2026-06-11
- Type: primary academic paper
- Accessed: 2026-08-08
- Scores: Credibility 5/5 for documented design; Recency 5/5; Bias risk 3/5

## Verbatim evidence

> “experts contribute projects they have already completed”

> “150 public, 1,017 private, and 323 unverified pending QC”

> “Code-based (deterministic) 93.2%”

> “LLM-as-judge 6.8%”

## Notes

ALE reports 960 expert-authored workflows and 1,490 instances; task construction uses expert sourcing, review, engineering implementation/dry-runs, expert-committee QC, and a private/rolling holdout. Experts define and QC tasks, but the run-time evaluator is mostly code, with narrow LLM judges for a minority of workflows. These are author-reported design facts; they do not independently prove construct validity or economic impact.

