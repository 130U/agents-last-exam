# Source 01 — Nick Heiner talk transcript

- URL: https://www.youtube.com/watch?v=-npY6XjM8CQ
- Local evidence: `../../bilingual_transcript_en_zh.md`
- Type: primary, conference talk / automatic English captions
- Accessed: 2026-08-08
- Scores: Credibility 4/5; Recency 5/5; Bias risk 3/5

## Verbatim evidence

> “We need to hold the benchmark industry and the labs to a higher standard.”

> “You need high fidelity input data which is best done by going out and getting it from the real world.”

> “You need to thoroughly QC everything and you need to have a private hold out set.”

## Notes

The talk gives a general construction checklist: strong experts; product/operational context; high-fidelity inputs; working tools; bidirectional prompt–verifier coverage; QC; and a private holdout. Professional blind comparison is introduced later as Surge's solution for subjective writing evaluation, not as a universal requirement for every benchmark. Automatic captions may contain names/term errors.

