# Source 08 — MMLU-CF (ACL 2025)

- URL: https://aclanthology.org/2025.acl-long.656/
- Type: peer-reviewed academic paper
- Accessed: 2026-08-08
- Scores: Credibility 5/5; Recency 4/5; Bias risk 2/5

## Verbatim evidence

> “The test set remains closed-source to ensure reliable results.”

## Notes

Provides independent evidence for a public-validation/private-test split as a contamination-control strategy. Its multiple-choice setting is much simpler than ALE and does not validate ALE's task design or evaluator quality.

