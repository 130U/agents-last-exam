# Source 02 — AI Engineer World's Fair 2026 schedule

- URL: https://www.ai.engineer/worldsfair/schedule?view=list
- Type: primary, event organizer
- Accessed: 2026-08-08
- Scores: Credibility 5/5; Recency 5/5; Bias risk 1/5

## Verbatim evidence

> “When Will The Benchmaxxing Plague End?”

> “Nick Heiner — Surge AI, VP of RL Environments”

## Notes

Confirms the speaker, title, company, and role. The source describes a conference talk, not an interview or formal research report.

