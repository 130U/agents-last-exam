# Source 03 — Surge AI Hemingway-bench methodology

- URLs: https://surgehq.ai/blog/hemingway-bench-ai-writing-leaderboard ; https://surgehq.ai/benchmarks/hemingway-bench
- Type: primary, benchmark owner
- Accessed: 2026-08-08
- Scores: Credibility 4/5; Recency 5/5; Bias risk 4/5

## Verbatim evidence

> “Judges were a panel of Expert Creative Writers from the Surge platform.”

> “Judges performed over 5,000 blind pairwise comparisons.”

> “Our leaderboard is judged by professional writers.”

## Notes

Hemingway-bench is a writing benchmark/leaderboard, not a plugin. Surge reports professional writers, real-user plus aspirational prompts, blind pairwise comparisons, holistic quality, and eight sub-dimensions. The public methodology does not establish thousands of distinct judges or an independent audit.

