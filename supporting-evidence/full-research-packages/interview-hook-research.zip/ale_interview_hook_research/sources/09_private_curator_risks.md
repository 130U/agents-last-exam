# Source 09 — Risks of private benchmark curators

- URL: https://arxiv.org/abs/2503.04756
- Type: academic position paper / ICLR 2025 blogpost
- Accessed: 2026-08-08
- Scores: Credibility 4/5; Recency 4/5; Bias risk 2/5

## Verbatim evidence

> “private evaluations introduce inadvertent financial and evaluation risks.”

> “subjective preferences of private expert annotators will lead to inherent evaluation bias”

## Notes

Steelmans the counterargument: closed sets reduce contamination but also reduce auditability; commercial relationships and curator-specific preferences can bias results. This is directly relevant to using a Surge talk and to designing a client-owned private ALE-style benchmark.

