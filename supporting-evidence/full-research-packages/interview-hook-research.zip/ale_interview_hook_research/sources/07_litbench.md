# Source 07 — LitBench (EACL 2026)

- URL: https://aclanthology.org/2026.eacl-long.362/
- Type: peer-reviewed academic paper
- Accessed: 2026-08-08
- Scores: Credibility 5/5; Recency 5/5; Bias risk 2/5

## Verbatim evidence

> “the strongest OTS judge, Claude-3.7-Sonnet, achieves only 73% agreement with human preferences.”

## Notes

Independently supports the claim that generic off-the-shelf LLM judging is insufficient for nuanced creative-writing preference. It does not prove that human experts are unbiased or that every professional task needs human blind evaluation.

