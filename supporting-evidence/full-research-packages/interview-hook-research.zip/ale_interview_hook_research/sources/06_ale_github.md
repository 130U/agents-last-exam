# Source 06 — ALE official GitHub repository and evaluator implementations

- URLs: https://github.com/rdi-berkeley/agents-last-exam ; https://github.com/rdi-berkeley/agents-last-exam/blob/main/README.md
- Inspected revision: 1e615e456de7cef57706680613cb80ee13c7fc76 for sample evaluators
- Type: primary implementation
- Accessed: 2026-08-08 through the GitHub connector
- Scores: Credibility 5/5 for observable implementation; Recency 5/5; Bias risk 2/5

## Verbatim evidence

> “around 150 public tasks across all 55 subdomains”

> “a hidden reference that the grader evaluate() scores the output against”

## Notes

The repository exposes runnable `main.py` task specifications and `evaluate()` implementations. The Tesla workbook example reads a hidden manifest and scores workbook bytes in code. The Mota reproduction example uses narrow image questions with YES/NO outputs. This corroborates artifact-based scoring and shows that ALE is not merely a prompt collection.

