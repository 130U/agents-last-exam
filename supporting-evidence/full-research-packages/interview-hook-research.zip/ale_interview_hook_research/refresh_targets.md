# Refresh targets

- ALE arXiv version and task counts: check for v3+.
- Public repository revision and number of open task workflows.
- Whether the promised private-to-public rolling rotation has occurred in practice.
- Judge-type distribution in newer ALE releases.
- Hemingway-bench methodology: judge count, inter-rater agreement, randomization, compensation, and audit details if published.
- Client assignment wording: whether “1,000 tasks” means workflows, runnable instances, or accepted production units.
