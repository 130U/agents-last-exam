# ALE-style 1,000-task interview hook: research plan

Date: 2026-08-08
Genre: interview-facing validation brief

## Decision

Determine whether Nick Heiner's Surge AI talk on benchmaxxing is a defensible hook for explaining how to build 1,000 ALE-style benchmark instances, and produce a concise Chinese-English opening that demonstrates real ALE knowledge without overstating either source.

## Falsifiable hypotheses

1. The speaker is Nick Heiner of Surge AI, and the named writing benchmark is Hemingway Bench, not "Wingwell" or a benchmarking plugin.
2. The talk's five operational recommendations map materially onto ALE v2's expert sourcing, real-workflow provenance, evaluator alignment, QC, and private/rolling holdout design.
3. ALE does not use professional blind human comparison as its standard run-time evaluator; experts primarily author and QC tasks, while scoring is mostly deterministic code with a minority of narrow LLM judges.
4. The talk is useful as a hook only if framed as an external lens rather than evidence that ALE itself is valid or that the five controls are sufficient for real-world economic value.

## Source strategy

- Primary: YouTube transcript/video metadata, Surge AI/Hemingway materials, ALE arXiv v2, official ALE GitHub repository and task evaluators.
- Academic/industry context: ALE comparison section and any primary benchmark documentation directly relevant to human expert evaluation.
- Opposition queries: evidence that ALE's public/private count is misquoted; evidence of blind human judging in ALE; evidence that evaluator alignment or QC is not inspectable; conflicts of interest in the Surge framing.

## Risks

- Automatic captions may misrecognize names and coined terms.
- ALE uses several count units: workflows, instances, public/private/pending-QC, and evaluated subsets.
- "Experts participate" can be incorrectly upgraded into "experts blind-score every model output."
- A company talk promoting human evaluation may reflect Surge AI's commercial incentives.
- Mapping five principles onto ALE can become circular praise unless limitations are explicit.

## Stop criteria

- Identity and benchmark name confirmed by at least two independent primary/near-primary surfaces.
- Each ALE mapping supported by paper text and at least one implementation or repository artifact where applicable.
- Human-blind-evaluation claim checked against evaluation mode descriptions and judge distribution.
- Final hook includes one explicit limitation and uses correct count units.

## 2026-08-08 deliverable revision

The user clarified that the output will be submitted as a printed Word/deck page, not delivered mainly as an oral interview answer. The revised artifact must therefore:

- read as a compact report rather than a spoken script;
- lead with an observation and source link;
- state six benchmark-quality criteria;
- compare ALE against all six in one structured table;
- show ALE knowledge through concrete mechanisms and correct count units;
- end with an implication for the client's 1,000-instance project;
- keep professional blind review as a selective method for subjective outputs, not a universal replacement for deterministic evaluation.
