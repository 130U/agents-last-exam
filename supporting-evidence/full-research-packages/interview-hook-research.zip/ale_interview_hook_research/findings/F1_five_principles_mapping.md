# Finding F1 — The talk is a defensible lens for ALE's construction controls

Status: supported with qualifications

Heiner's recommendations can be consolidated into five interview-friendly controls without misrepresenting the talk:

1. Expert-defined tasks, success criteria, and operational/product context.
2. High-fidelity inputs grounded in real work.
3. Working tools plus bidirectional prompt–verifier alignment.
4. Rigorous, multi-stage quality control.
5. A private holdout and refresh/rotation policy.

ALE v2 materially operationalizes all five through expert sourcing, five-part task specifications, real software environments, executable `main.py` contracts, engineering dry-runs, expert-committee QC, hidden references, and public/private splits.

The defensible claim is not “ALE proves these five principles are sufficient.” It is: “ALE operationalizes these five principles unusually well at the level of benchmark design and public implementation.” Full-corpus quality and construct validity are not independently established.

Sources: 01, 05, 06, 08.

