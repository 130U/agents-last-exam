# Finding F2 — Blind expert scoring is a selective modality, not a universal sixth principle

Status: supported

Hemingway-bench uses professional writers and blind pairwise comparisons because creative and everyday writing contain preference, taste, coherence, and implicit-intent dimensions that resist deterministic checking.

ALE follows a different optimization: experts author, specify, reference, and QC tasks, while run-time grading is mostly automatic. ArXiv v2 reports 93.2% deterministic code-based judges and 6.8% LLM judges in the open reference task tree. No professional blind human run-time judging protocol was found.

This is not automatically a flaw. Deterministic checking is preferable for spreadsheet formulas, CAD geometry, executable code, file state, and exact constraints. The validity risk appears when subjective professional quality is forced into weak proxies. A 1,000-instance project should therefore use modality-aware evaluation:

- deterministic graders for objective artifacts;
- narrow calibrated model judges only when code cannot inspect the relevant signal;
- expert blind comparison or expert-calibrated audit for subjective/high-stakes dimensions;
- sampled human audit across all modalities to detect reward–value misalignment.

Sources: 03, 05, 06, 07.

