# F5 — Adversarial review of the ALE beginner investigation

## Scope and standard of review

This review stress-tests the four working hypotheses in `plan.md` against source notes 01–07, including the newly available Hugging Face dataset note 04. It does not ask whether the hypotheses are intuitive; it asks what the cited evidence literally establishes, what would falsify each conclusion, and which interpretation could change under a different benchmark snapshot or aggregation rule.

Evidence labels used below:

- **Fact:** directly inspectable in the linked paper, docs, dataset snapshot, or reported table.
- **Author claim:** an interpretation or motivation asserted by a benchmark's creators.
- **Reviewer inference:** a conclusion drawn by this investigation; it remains conditional on the measurement design.

## Bottom-line adversarial verdict

| Hypothesis | Verdict after adversarial review | Required wording correction |
|---|---|---|
| H1. The four links are companion resources, not four independent articles | **Strongly supported, with synchronization caveat** | Say “two views of one paper plus two first-party living implementation/data surfaces,” not “four synchronized companions.” |
| H2. ALE measures whole-agent end-to-end artifact completion | **Supported as an operational description** | Say “a configured agent–harness–tools–environment system completing selected ALE tasks under a fixed budget,” not “general professional ability.” |
| H3. A partial-score/full-pass gap indicates weak reliability | **Only partially supported; strongest hypothesis needing revision** | The gap proves incomplete satisfaction of ALE rubrics. It is *consistent with* end-to-end reliability problems, but is not by itself a calibrated reliability estimate. |
| H4. ALE alone cannot establish job replacement | **Strongly supported** | Preserve “alone” and distinguish task-level technical feasibility from job-level economic substitution. |

## H1 — Are the four links really companion resources rather than independent articles?

### Facts

- Source 01 (`arxiv.org/html/2606.05405`) and source 02 (`arxiv.org/abs/2606.05405v2`) carry the same paper title and arXiv identifier. The abstract page supplies bibliographic/version metadata; the HTML supplies the full manuscript.
- The official documentation describes the `ale_run` machinery: task hooks, sandboxes, agent integration, grading, configuration and run artifacts.
- The Hugging Face dataset page is a first-party metadata release. Its current v1.0 snapshot has 153 rows and points to separate input-data and gated reference-data repositories.
- The current dataset snapshot was modified after the v2 manuscript. Counts and split labels do not exactly reconstruct the paper's evaluated public set.

### Author claims

- The ALE team presents the paper, project site, code, documentation and data as parts of one benchmark project.
- It calls ALE a “living benchmark,” explicitly allowing the task pool and surrounding assets to evolve.

### Strongest objection

“Companion resources” can falsely imply that all four surfaces are synchronized to arXiv v2. They are not. The live docs say `full.txt` contains 152 tasks; the current metadata dataset has 153 rows; the paper itself contains 150/152 descriptions; the HF single-label split has 47 `full-spectrum` rows while the paper evaluates a 55-task Full-Spectrum view. The docs' 2.6% hardest-tier headline also differs from v2's below-1% average statement.

A skeptical evaluator would therefore say: these are related first-party artifacts, but the docs and dataset are independent **versions/products**, not frozen annexes to the paper. A beginner should not combine a live dataset count with a frozen paper result as though they came from one manifest.

### What evidence would overturn the conclusion?

The “not independent articles” portion would be overturned if one of the URLs were shown to contain a separately authored study, distinct experiment, separate DOI/manuscript identity, or independent replication rather than project documentation/data. The “companion” portion would need stronger wording if provenance showed that the docs or dataset were maintained by an unrelated organization under a different benchmark definition.

Neither condition is present in the inspected sources. What is already overturned is the stronger, unstated proposition that all four resources describe one identical frozen snapshot.

### Aggregation/version choices that could reverse interpretation

- Treating 153 current HF rows as the denominator for a paper table recorded on 152 distinct tasks.
- Treating HF's single `task_split` label as the paper's overlapping evaluation views.
- Treating the docs' current `full.txt` and provider allowlists as the exact paper manifest.
- Quoting 2.6%, 0%, or below 1% without identifying system, denominator, and whether the number is best configuration or average across configurations.
- Calling “1,490 task instances,” “960 workflows,” “153 public metadata rows,” and “152 evaluated tasks” the same unit.

### Reviewer inference

The defensible beginner formulation is:

> The first two links are two presentations of the same v2 preprint. The docs and Hugging Face release are first-party implementation/data companions that have continued evolving after the paper.

## H2 — Does ALE measure whole-agent end-to-end artifact completion?

### Facts

- A run combines an agent preset, a task variant and a sandbox environment. The preset selects a harness, model, executor and harness-specific controls.
- The task machine exposes files, applications, shell and GUI. Agents can use terminal/system operations and graphical actions.
- Visible inputs are staged before execution; hidden reference artifacts are introduced only after the agent stops.
- `evaluate()` assigns a normalized task score from delivered files or final machine/application state. The paper describes exact, structural, numeric, geometric, visual, behavioral and semantic checks.
- The harness controls prompts, action loop, tools, context compaction and sometimes subagents. The paper's fixed-model harness sweeps show nonzero performance differences across harnesses.
- Runs are capped at five wall-clock hours. Some historically human projects reportedly took days or weeks, but there is no matched human experiment under ALE conditions.

### Author claims

- The authors define the target as a Generalist Computer-Use Agent and frame the tasks as authentic, economically valuable professional workflows.
- They argue that ALE narrows the gap between benchmark success and real economic utility.
- They interpret model and harness comparisons as showing that both backbone capability and system engineering matter.

### Strongest objections

#### Objection 1: “End to end” is true only inside the benchmark boundary

ALE starts from an already specified instruction, prepared inputs, software and a gradeable deliverable. It normally omits upstream client discovery, ambiguous-goal negotiation, access approval, stakeholder coordination, organizational memory, deployment, follow-up, liability and maintenance. Thus it is end-to-end for the encoded task episode, not necessarily for the real job or project lifecycle.

#### Objection 2: artifact success is not process validity

Most grading observes output artifacts/final state. Unless a rubric explicitly checks provenance, safety or method, an agent may use a professionally unacceptable process, bypass the named application, leak sensitive data, fabricate intermediate evidence or create an unmaintainable result yet still earn points. Conversely, a valid professional alternative may lose points if the reference/grader is narrow.

#### Objection 3: “whole-agent score” can hide environmental confounding

The measured unit is broader than model plus harness. It includes tool wrappers, executor location, OS/image, installed software, network/credentials, licensed applications, resource shape, time budget, retry policy and grader revision. “Agent score” is therefore shorthand for performance of a complete configured evaluation stack on a dated task set.

#### Objection 4: whole-system evaluation does not make model comparisons impossible

The paper's fixed-harness model sweep reports a larger spread than fixed-model harness sweeps in the selected configurations. A skeptic could argue that, with a harness truly fixed, ALE can still support conditional model comparisons. The correct conclusion is not “ALE tells us nothing about models,” but “an uncontrolled leaderboard row is not a pure model estimate.”

### What evidence would overturn the conclusion?

The direct operational conclusion would be weakened or overturned if a code/manifests audit showed that most tasks were actually single-turn responses, that agents never acted in the stated environments, that reference artifacts were exposed during execution, or that scores ignored delivered artifacts/final state. It would also be weakened if supposedly different harness rows were normalized to an identical control loop and tool surface such that only model calls varied.

None of the inspected first-party materials shows this. However, an independent reproduction of the full public set is still missing, so the implementation facts are not independently verified here.

### Aggregation/version choices that could reverse interpretation

- Comparing a 105-task Linux ALE-CLI subset to a full 152-task Windows/Linux/GPU/licensed mix.
- Combining provider/task allowlists with different OS, software or license coverage.
- Macro-averaging tasks equally versus workflow→industry→cluster aggregation.
- Counting overlapping Near-Term, Full-Spectrum and Last-Exam memberships as disjoint tasks.
- Treating a best-per-task oracle, best-of-N attempt, auto-resumed run or retried failure as a single first-attempt agent.
- Ignoring missing runs, timeouts or artifact-transfer failures.
- Updating the harness/model while retaining an old task score or dataset label.

### What a skeptical evaluator would say

> ALE measures whether a particular configured system can satisfy ALE's observable rubrics on a selected digital task episode. It does not directly measure intrinsic model intelligence, the full professional process, or general job competence.

### Reviewer inference

The hypothesis survives after narrowing its scope:

> ALE directly measures end-to-end completion **within an encoded ALE task**, by a full configured agent system, through the artifacts or final state that its grader can observe.

## H3 — Does the partial-score/full-pass gap demonstrate weak end-to-end reliability?

### Facts

- Mean Score averages task-level partial-credit values; Full Pass Rate counts tasks with score exactly `1.0`.
- On the 38-task Last-Exam view, Codex + GPT-5.5 has mean score 11.2 and full-pass rate 0%; ALE-Claw + GPT-5.5 has mean score 12.8 and full-pass rate 2.6% (one task of 38).
- ALE uses heterogeneous aggregation patterns. Gate-and-score can force a task to zero when a hard validity condition fails even if other work looks useful.
- Most reported configurations were not repeated multiple times. Only selected configurations have three-run variation estimates.
- The independent adjacent OSWorld 2.0 paper also reports a large gap between partial score and binary completion (54.8% versus 20.6%) and describes lost constraints and skipped verification. It is not an ALE replication.

### Author claims

- ALE's authors interpret low full-pass performance as evidence that current agents struggle with sustained, complete professional workflows.
- Their one-configuration failure analysis attributes many failures to wrong strategy, abandonment, domain-knowledge gaps, formatting and implementation errors.

### Strongest objections

#### Objection 1: the gap is partly mathematical by construction

Any rubric that gives points for subcriteria but defines pass as the exact maximum will mechanically produce a gap. The size of that gap depends on the number of rubric items, tolerance settings and gates. It is not automatically a psychometric measure of “reliability.”

#### Objection 2: full pass may over-penalize low-value misses

A task can fail full pass because of one filename, screenshot, minor field or overly strict tolerance even if a human customer would accept the output. Without criterion-validity studies, the gap may partly measure rubric strictness rather than economically meaningful incompleteness.

#### Objection 3: partial score may overstate useful progress

The reverse is also possible. A system may collect easy rubric points while making a catastrophic core error, fabricate evidence, or produce an unusable artifact. Mean Score is not guaranteed to be linear in professional value, safety or saved labor.

#### Objection 4: cross-task pass rate is not repeated-run reliability

Reliability normally concerns stability across repeated measurements or probability of success under variation. A 0% pass rate on 38 different tasks says none received perfect credit in that run set; it does not estimate how often the same system would succeed on the same task across independent repeats. Most ALE cells lack repeated-run evidence.

#### Objection 5: the denominator is coarse

With 38 Last-Exam tasks, one extra pass moves the rate by 2.63 percentage points. Small absolute changes appear large relative to a near-zero baseline. A best-of-N or retry policy can materially alter full-pass rate.

### What evidence would overturn the reliability interpretation?

Any of the following would substantially weaken it:

1. blinded expert review showing that most non-full outputs are professionally acceptable despite minor rubric misses;
2. matched human runs showing an equally large partial/full gap because the grader is unrealistically strict;
3. a rubric audit finding systematic false negatives or unstable LLM-judge decisions;
4. value-weighted rescoring in which essential criteria are consistently satisfied and the gap largely disappears;
5. repeated runs demonstrating stable completion of the economically important task core, with only incidental metadata varying;
6. evidence that partial-score scales are not comparable across tasks and the published mean is dominated by rubric length rather than useful work.

Conversely, repeated independent runs, expert acceptance judgments and downstream usability tests that track full-pass status would strengthen the reliability claim.

### Aggregation/version choices that could reverse interpretation

- Exact `score == 1.0` versus a threshold such as 0.8 or “professionally acceptable.”
- Macro mean across tasks versus weighting rubric items, workflows, time saved, wages or risk.
- First attempt versus best-of-N, auto-resumed attempts or oracle best-per-task.
- Treating timeouts as graded partial artifacts, failures, or missing observations.
- Including or excluding strict gate-based tasks.
- Averaging task instances into workflows before domains versus treating every instance equally.
- Changing grader/tolerance/model-judge versions while keeping the same task label.
- Evaluating Last-Exam only versus the easier full/private pool.

### What a skeptical evaluator would say

> The score gap demonstrates a difference between “earned some rubric credit” and “earned every required point.” Calling that gap reliability requires external validation that full credit tracks repeatable, professionally acceptable completion.

### Reviewer inference and required revision

The original hypothesis was too strong. Replace it with:

> A large partial-score/full-pass gap shows that agents often satisfy some ALE criteria without satisfying the complete ALE rubric. Together with trajectory/failure evidence, this is consistent with an end-to-end completeness problem, but the gap alone is not a calibrated measure of real-world reliability.

OSWorld 2.0 strengthens the broad cross-benchmark pattern but cannot validate ALE's exact graders, denominator or reliability estimate.

## H4 — Can ALE establish human-level job readiness or job replacement?

### Facts

- The paper reports no matched human baseline under the same task instructions, environment, budget and grader.
- ALE selects digitally executable, complex and verifiable workflows. Physical, primarily interpersonal, tacit or non-gradeable work is excluded or underrepresented.
- Tasks are not weighted by labor-market frequency, worker time, wages, employment, risk, adoption cost or GDP share.
- A job contains multiple tasks plus coordination, judgment, accountability and organizational context; ALE evaluates selected task episodes.
- Agent runs are capped at five hours even when the source projects reportedly took humans days or weeks.
- RLI is independent adjacent evidence that also evaluates real economically valuable projects, but its “automation rate” uses different tasks, expert grading and methodology. Its number cannot be converted into an ALE job-replacement percentage.

### Author claims

- ALE authors describe the tasks as economically valuable and aim to connect benchmark progress with GDP-relevant impact.
- They argue that eventual benchmark saturation would indicate progress toward sustained tool-intensive professional work.

These are motivation/forecast claims. ALE does not itself compute labor displacement or GDP effects.

### Strongest objection to the cautious conclusion

A proponent could reasonably argue that ALE is more economically informative than exam benchmarks. Real expert projects, native software, end-to-end artifacts and strict verification provide direct evidence about the **technical feasibility of automating selected digital tasks**. If an agent reliably completed a representative set faster and cheaper than professionals, that would be relevant to substitution.

Therefore “ALE says nothing about work automation” would be too dismissive. It supplies one component of an automation analysis: system capability on curated professional tasks.

### Why that still does not establish job replacement

Technical task feasibility is neither necessary nor sufficient for realized job displacement. The missing bridge includes:

- representative within-job task frequencies and time shares;
- matched human quality, time and cost;
- error severity, legal/safety risk and supervision requirements;
- integration, data access, privacy, security and maintenance cost;
- worker–agent complementarity and organizational redesign;
- demand elasticity, regulation, liability and adoption behavior;
- longitudinal field evidence that employment or labor demand changes causally.

Current low scores could also understate deployable value because real organizations may add supervision, specialist tools and longer budgets. They could overstate replacement because the benchmark supplies clean inputs, explicit deliverables, preconfigured software and no responsibility for real-world consequences.

### What evidence would overturn the conclusion?

ALE alone could approach a job-replacement claim only if it added or was formally linked to:

1. a probability sample of tasks within occupations, weighted by real time/frequency/economic value;
2. matched professionals under identical instructions, tools, deadlines and graders;
3. repeated reliability and expert-acceptance thresholds appropriate to each field;
4. measurements of supervision, correction, integration and risk costs;
5. coverage of collaboration, client interaction, ambiguity and multi-session organizational work;
6. field deployments showing that ALE scores predict realized productivity and substitution;
7. an explicit economic model connecting task automation to employment, wages or output.

If these existed and showed strong predictive validity, the blanket statement “ALE cannot establish replacement” would need revision. They do not appear in the inspected paper/docs/dataset.

### Aggregation/version choices that could reverse interpretation

- Equal task weighting versus occupational frequency/time/wage weighting.
- Reporting coverage across 55 subdomains versus coverage of each job's complete task bundle.
- Using easiest/private tasks, hardest Last-Exam tasks, or the current public set as the “representative” denominator.
- Using partial score, full pass, expert acceptance or safety-qualified completion as automation.
- Comparing agent runtime/API cost with unmeasured human project duration and labor cost.
- Reporting best system or best-per-task oracle instead of a deployable single configuration.
- Ignoring supervision and correction labor.

### What a skeptical evaluator would say

> ALE is a technical capability benchmark on a curated sample of gradeable digital workflows. Job replacement is a labor-market outcome produced by capability, economics, institutions and adoption. The benchmark does not identify that causal outcome.

### Reviewer inference

The cautious conclusion survives:

> ALE results are evidence about automation feasibility for selected digital task episodes. They do not, by themselves, establish human-level job readiness, occupational automation rates or realized job displacement.

## Which conclusions depend on publisher-controlled sources?

| Claim | Evidence source | Independence concern |
|---|---|---|
| Paper/abstract identity and v2 dates | arXiv pages authored by ALE team; arXiv hosts them | Bibliographic facts are directly inspectable, but arXiv hosting is not peer review. |
| 250+ experts, corpus/task counts, five-stage QC, occupational coverage | ALE paper | Self-reported construction evidence; no independent audit in this source set. |
| Full run architecture, hidden-reference staging, provider behavior, task hooks | ALE official docs/repository descriptions | First-party implementation claims; inspectable code helps but no full independent reproduction was read here. |
| 153 current metadata rows and schema | First-party HF release/API | Strong evidence for the current published snapshot, not for representativeness or paper-table membership. |
| Main ALE scores, failure taxonomy, grader distribution | ALE paper | Author-run experiments; most configurations not repeatedly evaluated; failure coding is model-mediated. |
| Economic value/GDP relevance | ALE paper/abstract framing | Author interpretation, not a measured economic outcome. |
| Partial/completion gaps also arise elsewhere | OSWorld 2.0 | Independent of ALE but still its own authors' preprint and not an ALE replication. |
| Accuracy–cost–reproducibility cautions | *AI Agents That Matter* | Independent methodology lens; predates and does not evaluate ALE. |
| Real-project benchmarks do not equal job automation | RLI plus reviewer reasoning | RLI is independent adjacent work, but its published automation definition is not interchangeable with ALE. |

All four user-supplied ALE resources are first-party or author-controlled. They provide strong primary evidence about what the authors built and reported, but no source among the four is an independent replication. The independent sources 05–07 triangulate general concerns; none validates ALE's exact results.

## Cross-cutting aggregation/version choices most likely to mislead a beginner

1. **Metric:** Mean Score, exact Full Pass Rate, expert acceptance and economic usefulness are not synonyms.
2. **System:** model-only, fixed-harness model comparison and uncontrolled model–harness leaderboard rows answer different questions.
3. **Task unit:** workflow, instance, public metadata row, run unit and overlapping tier membership are different denominators.
4. **Task set:** 105 Linux, 140 CPU-unlicensed, 145 unlicensed, 152 paper/full-doc, 153 current HF and the larger private corpus are not interchangeable.
5. **Snapshot:** arXiv v2 is frozen; docs, repo, dataset and leaderboard are living surfaces.
6. **Attempt policy:** first run, retry, auto-resume, repeated mean and best-of-N can produce different pass rates.
7. **Missingness:** timeout, infrastructure failure, absent output transfer and unrun licensed tasks must not be silently treated alike.
8. **Weighting:** equal tasks, equal workflows, equal domains, labor time, wages and risk can reverse rankings or economic interpretation.
9. **Threshold:** exact 1.0 versus any lower acceptance threshold can radically change “completion.”
10. **Oracle selection:** best-per-task across systems is an upper-bound portfolio, not one deployable agent.

## Final skeptical summary for the beginner explainer

The strongest defensible account is deliberately narrower than the benchmark's promotional framing:

- The four URLs are two views of one paper plus evolving first-party implementation/data resources.
- ALE evaluates a whole configured agent stack on selected, sandboxed, digitally executable tasks and grades observable artifacts/final state.
- A partial/full gap proves incomplete rubric satisfaction; calling it real-world reliability requires repeated runs and professional-validity evidence.
- ALE can inform task-automation feasibility, but cannot be converted into a percentage of jobs replaced without human baselines, labor-market weighting and field validation.

The skeptical evaluator's central warning is not that ALE is useless. It is that the benchmark is a measurement instrument with a specific construct. The explanation must preserve the boundary between **what the instrument directly records**, **what its authors hope it predicts**, and **what reviewers infer about real work**.
