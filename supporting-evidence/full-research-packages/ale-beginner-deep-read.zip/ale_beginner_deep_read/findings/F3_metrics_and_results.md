# F3 — Metrics, counts, and reported results matrix

Use the source IDs and independence map defined in `F1_four_resource_roles.md`.

## Q1. Mean Score and Full Pass Rate answer different questions

| Field | Assessment |
|---|---|
| Atomic thesis | Mean Score averages task-level partial credit; Full Pass Rate is the fraction of tasks receiving exactly full credit (`1.0`). |
| Supporting sources | S1 Section 4.1 and Table 1 define both metrics; its grader appendix explains partial rubric composition and hard gates. S3 documents evaluators returning normalized `[0,1]` scores. |
| Source independence | Direct definition comes from one first-party research/implementation family. |
| Contradicting or qualifying evidence | A task score can itself average instances or subcriteria; gates can force 0. Mean Score therefore is not a simple percent of work hours completed. |
| Confidence | **High**. |
| Evidence status | **Insufficient independent triangulation**, but these are benchmark-defined metrics and the benchmark authority is decisive for their definitions. |
| Boundary | **Fact:** metric formulas/semantics. **Inference:** Mean Score represents partial outcome credit, not deployable completeness. |

## Q2. A nonzero mean score with a zero pass rate means partial progress without perfect end-to-end completion

| Field | Assessment |
|---|---|
| Atomic thesis | If a configuration has Last-Exam score 11.2 but 0% pass, it earned partial rubric credit on average while no task reached exactly 1.0. |
| Supporting sources | S1's definitions and Codex + GPT-5.5 row. S5 independently reports a similar binary-completion/partial-score gap (20.6% versus 54.8%) on OSWorld 2.0. |
| Source independence | Two independent benchmark teams show the general phenomenon; S5 does not validate ALE's number. No third differently typed direct source. |
| Contradicting or qualifying evidence | Partial credit may be highly valuable or practically useless depending on which gate/criterion failed. Aggregate scores do not reveal that by themselves. |
| Confidence | **High** as metric arithmetic; **moderate** for interpreting practical usefulness. |
| Evidence status | **Insufficient independent triangulation** for real-world reliability implications. |
| Boundary | **Fact:** score/pass relationship. **Inference:** the gap is evidence of weak strict reliability, not evidence of zero capability. |

## Q3. The three paper tiers overlap and serve different evaluation purposes

| Field | Assessment |
|---|---|
| Atomic thesis | The v2 paper reports 67 Near-Term memberships, 55 Full-Spectrum memberships, and 38 Last-Exam memberships; their sum of 160 exceeds the 152 distinct public tasks, so they cannot be treated as disjoint partitions. Overall uses distinct tasks. |
| Supporting sources | S1 Section 4.1 and Table 1. S3's current task lists distinguish `full`, `ale_cli`, and other subsets. S4 shows that a later one-label metadata field cannot reconstruct the frozen overlapping tier manifests. |
| Source independence | All direct evidence is first-party. |
| Contradicting or qualifying evidence | S4's current rows show only 47 `full-spectrum` labels, not the paper's 55-member slice, because the living metadata schema/release differs. The formal tier-assignment algorithm is not published in the notes. |
| Confidence | **High** for overlap and paper counts; **moderate** for explaining every later row migration. |
| Evidence status | **Insufficient independent triangulation** and **unresolved release mapping**. |
| Boundary | **Fact:** paper membership counts and distinct-task language. **Inference:** tiers are evaluation views rather than difficulty buckets that partition all tasks. |

## Q4. `0%`, `2.6%`, and `<1%` are compatible when denominator and aggregation are stated

| Field | Assessment |
|---|---|
| Atomic thesis | On the 38-task Last-Exam tier, 0% means one configuration passed 0 tasks; 2.6% is one task out of 38; v2's `<1%` is the average full-pass rate across mainstream harness/backbone configurations, most of which passed none. |
| Supporting sources | S1 Table 1 supplies 0.0 and 2.6 rows and the 38-task denominator. S2 supplies the v2 `<1%` average wording. S8 preserves an older/stale 2.6% abstract display, showing surface drift. |
| Source independence | S1/S2 are one paper; S8 is a mirror. No independent replication of these values. |
| Contradicting or qualifying evidence | The docs/HF mirror can display 2.6% as an “average,” conflicting with v2. Treat v2 as the canonical frozen manuscript and label older surfaces stale/different rather than silently blending them. |
| Confidence | **High** for the arithmetic and v2 interpretation; **moderate** on the precise history of the stale wording. |
| Evidence status | **Insufficient independent triangulation**. |
| Boundary | **Fact:** table values, denominator, abstract wording. **Inference:** one full pass explains the rounded 2.6%. |

## Q5. Selected v2 headline configurations show a large partial/full-completion gap

| Field | Assessment |
|---|---|
| Atomic thesis | In v2 Table 1, Codex + GPT-5.5 records Near-Term 38.1% pass/64.7 score, Full-Spectrum 22.7%/36.0, Last-Exam 0%/11.2, and 24.0% overall distinct-task pass. ALE-Claw + GPT-5.5 records Last-Exam 2.6%/12.8 and 23.0% overall pass. |
| Supporting sources | S1 Table 1. S2 identifies this as v2. |
| Source independence | Single author-reported experiment. |
| Contradicting or qualifying evidence | Only selected configurations have three-run score standard deviations; most rows are single runs. These are June 2026 paper results, not a current live-leaderboard claim. Exact software/model availability and task manifests can change. |
| Confidence | **High** that the paper reports these values; **unvalidated externally**. |
| Evidence status | **Insufficient independent triangulation**. |
| Boundary | **Fact:** transcribed v2 table values. **Author claim:** they demonstrate present benchmark headroom. **Inference:** do not shorten the row to “GPT-5.5 scored 24%” without naming Codex/harness and snapshot. |

## Q6. Public-task counts have drifted across the frozen paper and living surfaces

| Field | Assessment |
|---|---|
| Atomic thesis | S1 contains 150-public-task descriptions and also a 152-distinct-task experiment; S3 currently lists 152 in `full.txt`; S4 currently exposes 153 task-card rows. |
| Supporting sources | S1, S3, S4 with their dates and units. |
| Source independence | Same ALE project across three artifact types. |
| Contradicting or qualifying evidence | The current 153 rows include one blank split, 47 single-label Full-Spectrum rows, 14 repository categories, and 51 represented taxonomy codes. This is not simply “the paper plus one task”; unit/schema evolution may also matter. |
| Confidence | **High** that displayed counts differ; **low-to-moderate** on exact migration history. |
| Evidence status | **Insufficient independent triangulation** and **unresolved exact reconciliation**. |
| Boundary | **Fact:** dated displayed values. **Inference:** living-release drift. Always name source/date/unit. |

## Q7. The published failure percentages are a narrow model-mediated analysis, not a universal law

| Field | Assessment |
|---|---|
| Atomic thesis | For failed public tasks from Claude Code + Opus 4.7, excluding timeout/resource cases, S1 reports Approach 47%, Understanding 31%, and Execution 22%, with finer subcategories. |
| Supporting sources | S1 Appendix D.3 describes Codex-generated analysis cards, GPT-4o classification, evidence inputs, exclusions, and percentages. S5 independently reports some analogous constraint/verification failures in OSWorld 2.0 but uses another taxonomy. |
| Source independence | Exact percentages have one first-party source. One independent adjacent benchmark supports only qualitative convergence. |
| Contradicting or qualifying evidence | One configuration; failed tasks only; two model-mediated stages; full transcript excluded; timeouts/resources excluded; no human inter-rater reliability in the notes. |
| Confidence | **High** that S1 reports the percentages; **low-to-moderate** for generalization to all agents or causal attribution. |
| Evidence status | **Insufficient independent triangulation**. |
| Boundary | **Fact:** sample/method/reported distribution. **Author claim:** domain knowledge/approach are dominant bottlenecks. **Inference:** use “in this analysis,” never “47% of all agent failures.” |

## Q8. The model-versus-harness and efficiency conclusions are bounded comparisons

| Field | Assessment |
|---|---|
| Atomic thesis | S1 reports a 16.8-point pass-rate spread across 12 models with OpenClaw fixed, versus 4.9–7.2 points across selected harnesses with a model fixed; it also reports weak relationships between score and cost, wall time, or token volume. |
| Supporting sources | S1 Appendices D.4–D.5. S6 independently argues that cost and accuracy should be evaluated jointly and that standardized configurations matter. |
| Source independence | One direct experiment plus one independent general methodology source. |
| Contradicting or qualifying evidence | Range comparisons depend on which models/harnesses were selected and do not estimate causal variance shares. Model/harness interactions, retries, parallelism, pricing, and logging differences remain. Higher resources failing to guarantee score does not mean resources never matter. |
| Confidence | **High** for reported sample ranges; **moderate** for “model matters about 3× more”; **low** for universal generalization. |
| Evidence status | **Insufficient independent triangulation**. |
| Boundary | **Fact:** observed ranges/examples in v2. **Author claim:** foundation-model capability is the dominant factor among tested competitive harnesses. **Inference:** report efficiency metrics beside accuracy rather than assuming more spend means better performance. |

## Q9. Timeout is scored as an outcome, not automatically discarded as infrastructure failure

| Field | Assessment |
|---|---|
| Atomic thesis | At five hours the harness stops, then the normal evaluator grades existing artifacts. S1 reports 3.8% of Table 1 runs timed out; Last-Exam timeout rate was 6.4%. |
| Supporting sources | S1 Appendix D.2; S3 timeout/lifecycle configuration. |
| Source independence | Same first-party project. |
| Contradicting or qualifying evidence | Timeout can reflect planning inefficiency, harness retries, application latency, compute limits, or task difficulty. S1 excludes timeout/resources from its reasoning-failure percentages, so those two analyses have different denominators. |
| Confidence | **High** for protocol and reported rate. |
| Evidence status | **Insufficient independent triangulation**. |
| Boundary | **Fact:** cap and rates. **Inference:** timeout is a mixed capability/resource outcome and should not be labeled simply “model reasoning failure.” |

## Reporting rule for the final explainer

Every number should carry four labels where applicable: **paper/release date, task slice, metric, and model+harness configuration**. Avoid mixing frozen v2 results with the living dataset or leaderboard.

