# F2 — What ALE measures: atomic claim matrix

Use the source IDs and independence map defined in `F1_four_resource_roles.md`.

## M1. ALE directly measures end-to-end completion of selected digital professional workflows

| Field | Assessment |
|---|---|
| Atomic thesis | ALE gives an agent a professional-style task, inputs, software environment, time budget, and deliverable target, then scores the final artifact or state. It is not primarily a short-answer knowledge exam. |
| Supporting sources | S1 defines representativeness, complexity, verifiability, and artifact/state graders. S3 documents sandbox execution and post-run grading. S4 exposes real task prompts, required actions, software, inputs, and heterogeneous deliverables. S5 and S7 independently study related end-to-end workflows. |
| Source independence | Direct ALE evidence comes from one first-party family. S5 and S7 are independent adjacent benchmarks, not ALE replications. |
| Contradicting or qualifying evidence | “Professional-style” does not mean a probability sample of jobs. Tasks are selected for digital execution and verifiability. The agent gets at most five hours even when the source project took humans longer. |
| Confidence | **High** for what ALE operationally scores; **moderate** for how well that construct represents professional work generally. |
| Evidence status | **Insufficient independent triangulation** of ALE's construct validity. Independent sources support only the broader category of long-horizon work evaluation. |
| Boundary | **Fact:** task/run/grader design. **Author claim:** tasks are economically valuable and representative. **Inference:** ALE is best described as an “AI work-product delivery test.” |

## M2. The evaluated unit is a whole agent system, not a bare LLM

| Field | Assessment |
|---|---|
| Atomic thesis | An ALE score belongs to the combination of model, harness, prompts, tools, context management, GUI/CLI layer, runtime, environment, and budget. |
| Supporting sources | S1 defines the agent as “a harness orchestrating a foundation model,” introduces Brain/Eyes/Body/Hands/Feet, and reports fixed-model/fixed-harness comparisons. S3 separates model, harness/agent, and ALE framework and documents deployers/executors/tools. S6 independently argues that agent evaluations require standardized configurations, cost, and reproducibility. |
| Source independence | Two direct first-party artifact types plus one independent general methodology paper. S6 does not inspect ALE. |
| Contradicting or qualifying evidence | The backbone may explain more observed variation than tested harnesses in S1, but that does not convert the result into a pure model score. The measured components interact. |
| Confidence | **High**. |
| Evidence status | **Insufficient strict triangulation** because only the ALE family directly establishes its unit of evaluation; nevertheless this is an explicit design fact, not a speculative inference. |
| Boundary | **Fact:** configured system is run and rows pair harness/backbone. **Author claim:** model choice accounts for roughly three times the tested harness spread. **Inference:** leaderboard rows must name both model and harness. |

## M3. ALE stresses integrated reasoning, domain procedure, tool use, and delivery discipline

| Field | Assessment |
|---|---|
| Atomic thesis | The task design jointly stresses requirement/constraint tracking, domain-specific procedural knowledge, long-horizon planning, GUI/CLI/file/API orchestration, implementation, error recovery, exact formatting, completeness, and final verification. |
| Supporting sources | S1's design, GCUA architecture, task/grader modes, tool traces, and failure taxonomy. S3's CLI/GUI interfaces, context handling, task lifecycle, and artifacts. S4's diverse prompts from finance, ERP, cybersecurity, translation, chip design, medical imaging, research reproduction, and media. S5 independently reports constraint loss and skipped verification in another long-horizon computer-use benchmark. |
| Source independence | Direct capability decomposition is first-party; S5 provides one independent adjacent convergence point. |
| Contradicting or qualifying evidence | ALE produces one composite outcome score rather than cleanly isolating each capability. A failure may have several causes, and the one published failure taxonomy is model-mediated and configuration-specific. |
| Confidence | **High** that tasks demand these abilities; **moderate** that score changes can be attributed to any one ability. |
| Evidence status | **Insufficient independent triangulation** for the causal ability decomposition. |
| Boundary | **Fact:** interfaces, prompts, outputs, and observed categories. **Author claim:** domain knowledge/approach dominate execution. **Inference:** these are “stressed” capabilities, not separately identified latent traits. |

## M4. ALE primarily scores outcomes; it does not generally reward an expert-like process

| Field | Assessment |
|---|---|
| Atomic thesis | Evaluation mostly examines final files or final machine/world state. Intermediate method matters only when a provenance rule, hard gate, replay, or observable state explicitly encodes it. |
| Supporting sources | S1's artifact modes, gate-and-score, hidden references, and `evaluate()` design. S3 says the evaluator grades the state left behind and separates transcript recording from scoring. S4's metadata omits full private grading logic and shows deliverable contracts. |
| Source independence | Three first-party artifact types; no direct independent audit of ALE graders. |
| Contradicting or qualifying evidence | Some tasks include anti-gaming gates, behavioral replays, screenshots, or evidence files, so “only final file bytes” would be too strong. Trajectories are retained for post-hoc analysis even when not part of the score. |
| Confidence | **High**. |
| Evidence status | **Insufficient independent triangulation**. |
| Boundary | **Fact:** outcome-based evaluator architecture. **Inference:** unsafe, brittle, or non-expert intermediate behavior can escape the score unless encoded. |

## M5. ALE combines GUI and CLI; it is not a GUI-only benchmark

| Field | Assessment |
|---|---|
| Atomic thesis | ALE's target GCUA can use screenshots/mouse/keyboard and also shell, code, files, web/API, planning, and subagents. |
| Supporting sources | S1's GCUA definition and GUI-as-Tool setup. S3's in-sandbox/out-of-sandbox shapes and two MCP bridges. S4 task examples require native apps, scripts, databases, retrieval, and multi-file outputs. |
| Source independence | All direct evidence is first-party. |
| Contradicting or qualifying evidence | A Linux-only ALE-CLI subset exists. Tool traces show agents sometimes substitute Bash for intended GUI software, so an ALE run does not guarantee heavy GUI use. |
| Confidence | **High**. |
| Evidence status | **Insufficient independent triangulation**, but the interface definition is explicit. |
| Boundary | **Fact:** available action surface and task requirements. **Author claim:** the union is a superset of GUI-only and CLI-only benchmark surfaces. **Inference:** call ALE multimodal/generalist computer-use, not merely desktop clicking. |

## M6. Hidden references and post-run grading reduce answer leakage inside a run

| Field | Assessment |
|---|---|
| Atomic thesis | The agent receives visible inputs but not the golden reference; the reference is staged or made available only after the agent finishes, then the evaluator scores the output. |
| Supporting sources | S1's `input/software/output/reference` contract and reference-isolation appendix. S3's six-stage lifecycle and encrypted/withheld reference mechanisms. S4's separate gated reference repository and “no leakage at eval time” conditions. |
| Source independence | Three same-project sources of different implementation/data types. |
| Contradicting or qualifying evidence | Runtime hiding does not prove the model was never trained on public prompts or artifacts, and public tasks can be optimized against. Private/rolling releases mitigate but do not eliminate contamination. |
| Confidence | **High** for runtime isolation as documented; **moderate** for actual enforcement without an external audit. |
| Evidence status | **Insufficient independent triangulation**. |
| Boundary | **Fact:** intended staging contract. **Author claim:** this protects benchmark integrity. **Inference:** it blocks simple in-VM answer lookup, not all forms of benchmark contamination. |

## M7. “Long horizon” refers to multi-step execution, but the evaluated run is bounded at five hours

| Field | Assessment |
|---|---|
| Atomic thesis | Source projects reportedly took experts days or weeks, while each benchmark run has a five-hour wall-clock cap and grades whatever exists at timeout. |
| Supporting sources | S1 Sections 2.3/4 and Appendix D.2. S3 configuration/run documentation. S5 independently uses long workflows with a reported 1.6-hour skilled-human median, illustrating the broader construct without validating ALE's human-duration claim. |
| Source independence | ALE duration facts are first-party; S5 is adjacent. |
| Contradicting or qualifying evidence | The paper provides no matched human execution study under the same prompt, files, software, environment, or five-hour budget. Historical project duration and benchmark run duration are not directly comparable. |
| Confidence | **High** for the five-hour cap; **moderate** for the unsystematic “days or weeks” provenance description. |
| Evidence status | **Insufficient independent triangulation**. |
| Boundary | **Fact:** five-hour cap and timeout scoring. **Author claim:** contributed source projects took days/weeks. **Inference:** ALE is long-horizon relative to many agent benchmarks, not a weeks-long autonomous-worker trial. |

## M8. ALE does not directly measure whole-job readiness, replacement, human parity, or GDP impact

| Field | Assessment |
|---|---|
| Atomic thesis | The benchmark observes selected digital task outputs from bounded single runs; it does not provide matched human baselines, labor-market weighting, whole-job decomposition, organizational collaboration, accountability, or measured economic outcomes. |
| Supporting sources | S1's measured variables and absence of a human baseline; S4's task-card sampling surface; S6's distinction between model-development benchmarks and downstream application evaluation; S7's different expert-graded definition of project automation. |
| Source independence | One direct ALE family plus two independent conceptual/comparator sources. They are not three differently typed direct tests of ALE's predictive validity. |
| Contradicting or qualifying evidence | The tasks are drawn from professional practice and may be informative about some components of work. The authors explicitly intend economic relevance. That intention is weaker than validated prediction of job performance or GDP. |
| Confidence | **High** that these outcomes are not directly measured. |
| Evidence status | **Insufficient independent triangulation** of external/predictive validity; the negative scope claim follows from the published measurement design. |
| Boundary | **Fact:** reported metrics and missing baseline. **Author claim:** saturation would signal readiness for industrial adoption/GDP-relevant impact. **Inference:** do not translate pass rate into a job-automation percentage. |

## Capability wording safe for the final explainer

Use: “ALE tasks **stress** or **require evidence of** these abilities.” Avoid: “ALE separately measures eight abilities” or “a score proves professional competence.”

