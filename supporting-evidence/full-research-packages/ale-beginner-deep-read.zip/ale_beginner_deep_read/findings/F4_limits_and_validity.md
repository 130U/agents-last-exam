# F4 — Limits, validity, and adversarial-reading matrix

Use the source IDs and independence map defined in `F1_four_resource_roles.md`.

## L1. The paper has no matched human baseline, so it cannot establish human parity

| Field | Assessment |
|---|---|
| Atomic thesis | S1 does not report humans completing the same task instances under the same prompts, files, software, environment, five-hour cap, and graders. Historical claims that projects took experts days/weeks are not a controlled baseline. |
| Supporting sources | S1's experiment and appendices; S3's exact run conditions; S7 shows that another professional-work benchmark uses a distinct “automation rate” and expert evaluation, illustrating that parity/automation depends on design. |
| Source independence | Absence is established from the ALE paper; S7 is independent context, not validation. |
| Contradicting or qualifying evidence | Experts supplied references and tasks, so human work informs construction. That does not yield a measured human score distribution or time-quality comparison. |
| Confidence | **High**. |
| Evidence status | **Insufficient independent triangulation** of human predictive validity; no such study appears in the source set. |
| Boundary | **Fact:** no matched human experiment reported. **Author claim:** saturation would indicate industrially meaningful capability. **Inference:** current scores cannot be converted into “percent of human professional ability.” |

## L2. Task selection favors digital, artifact-producing, automatically gradeable work

| Field | Assessment |
|---|---|
| Atomic thesis | ALE excludes primarily non-digital/physical work and admits workflows that are representative, complex, and verifiable, creating a deliberate selection surface rather than a probability sample of all work. |
| Supporting sources | S1 Sections 2.1–2.3 and taxonomy appendix. S4's current task catalogue and metadata schema. S7 provides an independent alternative project-sampling benchmark. |
| Source independence | Direct ALE evidence is first-party; S7 is an adjacent comparator. |
| Contradicting or qualifying evidence | The SOC/O*NET grounding and broad expert network improve coverage. They do not weight tasks by employment, wages, hours, GDP, frequency, or consequence of error. |
| Confidence | **High** for selection criteria; **moderate** for the magnitude/direction of resulting bias. |
| Evidence status | **Insufficient independent triangulation** of representativeness. |
| Boundary | **Fact:** inclusion/exclusion and taxonomy construction. **Author claim:** coverage is broad and economically meaningful. **Inference:** ALE represents a selected digital-work frontier, not the labor market distribution. |

## L3. “Deterministic grader” does not equal “valid measure of professional quality”

| Field | Assessment |
|---|---|
| Atomic thesis | Code-based scoring is repeatable given the same artifacts/code, but validity still depends on reference correctness, tolerances, gates, parsing, rubric coverage, software versions, and evaluator bugs. |
| Supporting sources | S1 reports 93.2% code-based judges, four composition patterns, and QC. S3 documents deterministic/judge styles and host/VM execution. S6 independently emphasizes evaluation design and reproducibility. |
| Source independence | One direct project family plus one independent methodology source. |
| Contradicting or qualifying evidence | Five-gate QC, hidden references, narrow judge prompts, saved artifacts, and deterministic code are meaningful safeguards. The source set includes no external grader audit or inter-rater validation against human experts across the suite. |
| Confidence | **High** as a measurement principle; **unknown** error magnitude for ALE. |
| Evidence status | **Insufficient independent triangulation** of grader validity. |
| Boundary | **Fact:** grader types and safeguards. **Author claim:** these replace costly human grading while preserving meaningful evaluation. **Inference:** deterministic means reproducible, not automatically complete or correct. |

## L4. Strict gates and full-pass criteria improve reliability testing but can hide useful partial work

| Field | Assessment |
|---|---|
| Atomic thesis | A failed parse/safety/collision/provenance gate can force task score 0, and Full Pass requires exactly 1.0; these rules test strict completion but are not proportional estimates of useful labor performed. |
| Supporting sources | S1's gate-and-score appendix and metric definitions. S5 independently shows a large partial-score/binary-completion gap in another benchmark. |
| Source independence | Two independent benchmark teams support the general tradeoff; no third differently typed direct source. |
| Contradicting or qualifying evidence | Hard gates can be essential when a near-correct artifact is unusable or unsafe. Conversely, a high partial score may still omit the decisive requirement. |
| Confidence | **High** for the scoring behavior; **moderate** for practical interpretation task by task. |
| Evidence status | **Insufficient independent triangulation** of real-world utility. |
| Boundary | **Fact:** gates and exact-full-credit rule. **Inference:** low full-pass can coexist with useful subtask capability, and high mean score does not imply deployability. |

## L5. Living releases and environment differences threaten naive reproducibility

| Field | Assessment |
|---|---|
| Atomic thesis | Exact reproduction requires pinning task manifests/variants, repository commit, data/reference/image versions, OS/provider/resources, model+harness, prompts, grader/judge, time budget, retries, and attempt-selection rules. |
| Supporting sources | S3 explicitly enumerates these moving parts, provider differences, licensed tasks, best-effort output collection, and unpinned living docs. S1 notes limited repeated runs and frozen experiment details. S4 gives a current revision SHA/date and count/schema drift. S6 independently warns about non-standard agent evaluation and inadequate reproducibility. |
| Source independence | One direct project family plus one independent methodology paper. |
| Contradicting or qualifying evidence | ALE exposes code, manifests, normalized trajectories, raw logs, and task data, which is stronger than opaque evaluation. Seven licensed tasks, gated references, provider state, and living changes still limit one-command replication. |
| Confidence | **High**. |
| Evidence status | **Insufficient independent triangulation** of successful full-paper reproduction; no full independent rerun is in the source set. |
| Boundary | **Fact:** documented moving parts/access constraints. **Inference:** “we ran ALE” is scientifically underspecified without a snapshot manifest. |

## L6. Public/private representativeness evidence is narrow

| Field | Assessment |
|---|---|
| Atomic thesis | S1's `r = 0.89, p < 0.001` result compares domain-cluster pass rates for Claude Code + Opus 4.7 on public versus full pools; the full pool is easier because public includes all Last-Exam tasks. |
| Supporting sources | S1 Appendix D.1. S6 independently flags holdout quality and benchmark overfitting as general risks. |
| Source independence | Exact correlation has one first-party source; S6 supplies methodology only. |
| Contradicting or qualifying evidence | High cluster-level correlation for one system is evidence of similar domain difficulty ordering, not proof of exchangeability across tasks, models, graders, or aggregate score. Withholding/rotation reduces but cannot eliminate contamination. |
| Confidence | **High** for reported correlation; **moderate-to-low** for broad representativeness. |
| Evidence status | **Insufficient independent triangulation**. |
| Boundary | **Fact:** sample, statistic, and pool composition. **Author claim:** public subset is representative. **Inference:** evidence supports a narrow correlation claim, not full sampling validity. |

## L7. The published failure taxonomy should not be generalized to all agents

| Field | Assessment |
|---|---|
| Atomic thesis | The 47/31/22 distribution is based on failed public-task runs from one model+harness, uses Codex to write analysis cards and GPT-4o to classify them, and excludes timeout/resources. |
| Supporting sources | S1 Appendix D.3. S5 offers independent qualitative failure patterns but not the same taxonomy or percentages. |
| Source independence | Exact result is single-source; adjacent convergence is partial. |
| Contradicting or qualifying evidence | Evidence-linked cards and temperature-zero classification improve consistency. No human-coded reliability study, multi-agent replication, or causal intervention is reported in the notes. |
| Confidence | **High** for procedural description; **low-to-moderate** for universal causal conclusions. |
| Evidence status | **Insufficient independent triangulation**. |
| Boundary | **Fact:** method and sample. **Author claim:** domain knowledge/approach dominate. **Inference:** say “in one author analysis,” not “agents mainly fail because…”. |

## L8. Model-versus-harness range comparisons are not a universal causal decomposition

| Field | Assessment |
|---|---|
| Atomic thesis | The observed 16.8-point model range and 4.9–7.2-point harness ranges describe selected systems under particular fixed counterparts; range ratios do not estimate the causal share of model versus harness capability. |
| Supporting sources | S1 Appendix D.4. S3 shows many harness/runtime differences. S6 emphasizes standardization and evaluation purpose. |
| Source independence | Direct numbers are first-party; one independent methodology lens. |
| Contradicting or qualifying evidence | Fixed-harness and fixed-model sweeps are stronger than uncontrolled leaderboard comparisons and do support a bounded within-sample result. They do not cover all architectures or interactions. |
| Confidence | **High** for bounded comparison; **moderate** for “roughly 3×” within the sample; **low** for universalization. |
| Evidence status | **Insufficient independent triangulation**. |
| Boundary | **Fact:** sample ranges. **Author claim:** foundation model is dominant among tested competitive harnesses. **Inference:** neither “harness does not matter” nor “ALE is a pure model benchmark” follows. |

## L9. The four requested sources provide no independent full ALE replication

| Field | Assessment |
|---|---|
| Atomic thesis | S1–S4 are first-party. S5 and S7 are separate benchmarks, and S6 is a general evaluation-method critique. None reruns ALE's complete public suite with pinned tasks, graders, budgets, and configurations. |
| Supporting sources | Source-role statements in S1–S8. |
| Source independence | Three independent external teams exist in the evidence set, but they do not test ALE's exact claims. |
| Contradicting or qualifying evidence | Adjacent benchmarks can triangulate the broad proposition that end-to-end agent reliability remains low. They cannot validate ALE's counts, ranks, failure percentages, or construct validity. Absence in this collected set is not proof no replication exists anywhere. |
| Confidence | **High** about this source set; **not a global literature-exhaustion claim**. |
| Evidence status | **Insufficient independent triangulation** by definition. |
| Boundary | **Fact:** contents of collected notes. **Inference:** describe quantitative ALE findings as author-reported. |

## L10. Independent adjacent benchmarks support the broad reliability problem, not ALE's exact scores

| Field | Assessment |
|---|---|
| Atomic thesis | ALE, OSWorld 2.0, and RLI all report much lower strict end-to-end completion than partial/proximal capability might suggest, which supports a broad “reliability gap” hypothesis. |
| Supporting sources | S1 (strict pass versus mean score), S5 (20.6% binary versus 54.8% partial), S7 (2.5% top automation rate under its own expert-graded definition). |
| Source independence | Three independent benchmark teams, but all are author-produced preprints and use different tasks/metrics. They are not three differently typed validations of one measure. |
| Contradicting or qualifying evidence | Numerical comparison is invalid because budgets, interfaces, sampling, graders, denominators, and labels differ. RLI's “automation rate” is not ALE Full Pass. |
| Confidence | **Moderate-to-high** for the broad qualitative pattern; **low** for any pooled number or ranking. |
| Evidence status | **Insufficient strict differently-typed triangulation**, despite three independent teams. |
| Boundary | **Fact:** each paper's own reported metric. **Inference:** multiple project-style evaluations converge on an end-to-end reliability gap. Never convert between their percentages. |

## L11. “GDP-relevant” and “job replacement” are stronger than the measured construct

| Field | Assessment |
|---|---|
| Atomic thesis | ALE measures selected task artifacts and resource metrics, while GDP impact and occupation replacement require task frequency/value, human counterfactuals, adoption, complementarity, organizational costs, safety, and accountability data not supplied by the benchmark. |
| Supporting sources | S1/S2's explicit GDP framing and measured variables. S4's unweighted public catalogue. S6's benchmark-purpose distinction. S7's differently defined project automation measure. |
| Source independence | One ALE family plus two independent conceptual/comparator sources; no predictive validation study. |
| Contradicting or qualifying evidence | Professional provenance and SOC/O*NET breadth make ALE more economically grounded than exam QA. Economic grounding is not economic impact measurement. |
| Confidence | **High** as a scope distinction. |
| Evidence status | **Insufficient independent triangulation** of economic predictive validity. |
| Boundary | **Fact:** what variables are and are not reported. **Author claim:** benchmark saturation would connect to GDP-relevant transformation. **Inference:** call that a research ambition, not an empirical conclusion. |

## L12. Process safety, collaboration, and ongoing organizational work are undermeasured

| Field | Assessment |
|---|---|
| Atomic thesis | Final-artifact grading in isolated, bounded, single-task sandboxes does not by itself measure safe intermediate behavior, client clarification, team coordination, long-lived learning, organizational judgment, or accountability. |
| Supporting sources | S1/S3's run and grader design. S5 notes OSWorld 2.0 adds dynamic services, user state, interaction detail, and safety reports, showing adjacent dimensions that ALE's primary artifact orientation treats differently. |
| Source independence | One direct project plus one independent adjacent comparator. |
| Contradicting or qualifying evidence | Some ALE tasks include provenance gates, behavioral replay, evidence requirements, web use, or multi-stage application state. Logs enable post-hoc process study even when those dimensions are not core scores. |
| Confidence | **High** for missing direct measurement; **task-dependent** for how much process is indirectly captured. |
| Evidence status | **Insufficient independent triangulation** of external validity. |
| Boundary | **Fact:** sandbox/grader design. **Inference:** ALE task success is narrower than being a trustworthy autonomous employee. |

## Claims the final explainer must label as insufficient evidence

- “ALE tasks are statistically representative of the labor market.”
- “A given ALE pass rate equals a job-automation percentage.”
- “The benchmark predicts human-level professional performance.”
- “Model choice universally matters three times more than harness design.”
- “47% of all agent failures are wrong strategy.”
- “Deterministic grading guarantees correct measurement.”
- “The public and private pools are interchangeable.”
- “The current live dataset exactly reproduces the v2 paper experiment.”
- “Three or four first-party URLs constitute independent replication.”

