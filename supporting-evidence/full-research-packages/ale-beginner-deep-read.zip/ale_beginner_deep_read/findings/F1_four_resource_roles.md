# F1 — Four-resource role and independence matrix

## Source key and independence map

| ID | Source | Type | Independence for ALE claims |
|---|---|---|---|
| S1 | `01_arxiv_html.md` | Full ALE research preprint | First-party ALE team |
| S2 | `02_arxiv_abs_v2.md` | Abstract/version record | Same paper and authors as S1; not independent |
| S3 | `03_official_docs.md` | Living implementation manual | Same ALE project/publisher; different artifact type, not independent validation |
| S4 | `04_huggingface_dataset.md` | Living public dataset release | Same ALE project/publisher; different artifact type, not independent validation |
| S5 | `05_osworld2_context.md` | Independent adjacent benchmark preprint | Independent team, but not an ALE replication |
| S6 | `06_ai_agents_that_matter.md` | Independent evaluation-method paper | Independent methodological lens; contains no ALE result |
| S7 | `07_remote_labor_index.md` | Independent professional-work benchmark preprint | Independent team, but not an ALE replication |
| S8 | `08_hf_paper_page_companion.md` | Hugging Face index/mirror | Mirrors S1/S2 and contains generated content; not independent |

Strict rule used below: three URLs or three artifact types from the same ALE publisher do **not** count as three independent sources. A thesis is marked **insufficient independent triangulation** unless at least three independent source families of meaningfully different types directly test it.

## R1. The first two links are two views of one v2 paper, not two articles

| Field | Assessment |
|---|---|
| Atomic thesis | The arXiv HTML URL provides the complete manuscript; the arXiv `/abs/...v2` URL provides the canonical abstract, identifier, categories, dates, and version history for that same manuscript. |
| Supporting sources | S1 identifies arXiv:2606.05405v2 and contains the full sections/appendices. S2 identifies the same title, identifier, authors, v2 date, and links back to HTML/PDF. S8 also points back to the same arXiv record. |
| Source independence | S1 and S2 are the same underlying paper. S8 is an index/mirror. There is one underlying research source, not three. |
| Contradicting or qualifying evidence | None on identity. S8's displayed abstract lags v2 on the hardest-tier headline, demonstrating that a mirror should not override the canonical v2 record. |
| Confidence | **High** for source identity and roles. |
| Evidence status | **Insufficient independent triangulation**, but independence is unnecessary for this bibliographic identity fact because the canonical record itself is authoritative. |
| Boundary | **Fact:** same title, identifier, authors, and version. **Inference:** treat the abstract page as the metadata/front door and the HTML as the evidence-bearing body. |

## R2. The full paper is the source for scientific design, experiments, and author interpretation

| Field | Assessment |
|---|---|
| Atomic thesis | Questions about why ALE exists, how tasks were sourced/QC'd, what was measured in the reported experiment, and how the authors interpret results should be answered from S1, not from the abstract or dataset alone. |
| Supporting sources | S1 contains Sections 1–6, Tables 1–2, and Appendices B–D. S2 compresses these into three abstract paragraphs. S3 explicitly distinguishes the scientific paper's purpose from implementation documentation. S4 states that tier methodology and paper-table membership require the paper/manifests. |
| Source independence | S1–S4 are all first-party ALE artifacts. Their agreement verifies internal role separation, not external validity. |
| Contradicting or qualifying evidence | The paper is a preprint and a frozen June 11 snapshot; live docs/data can later diverge. Paper claims about representativeness, economic relevance, or failure causes remain author claims unless externally validated. |
| Confidence | **High** that S1 is the correct source for the frozen study; **moderate** for generalizing its author interpretations. |
| Evidence status | **Insufficient independent triangulation** for the paper's substantive validity claims. |
| Boundary | **Fact:** S1 contains methods/results. **Author claim:** ALE closes a benchmark-to-economic-impact gap. **Inference:** use the paper as primary evidence but label its interpretation as first-party. |

## R3. The official docs expose the runnable framework, not another empirical study

| Field | Assessment |
|---|---|
| Atomic thesis | S3 explains how the current framework provisions a sandbox, stages inputs, launches an agent, withholds references, grades, records artifacts, retries, and cleans up. It is an operations/implementation manual rather than an independent performance report. |
| Supporting sources | S3 documents the six-stage lifecycle, task hooks, providers, agents/executors, MCP tools, experiment YAML, run records, and trajectory schema. S1 gives the corresponding paper-level three-component and `load/start/evaluate` architecture. |
| Source independence | S3 is a different artifact type from S1 but the same project authority. It can corroborate current implementation mechanics, not validate the benchmark's claims. |
| Contradicting or qualifying evidence | S3 is living documentation without one rendered commit pin. It sometimes differs from S1: 152 current tasks, provider-count prose/table mismatch, host-side grading shorthand versus 11.5% VM-side verifiers in S1, and a stale 2.6% hardest-tier headline. |
| Confidence | **High** for a dated description of current documented mechanics; **lower** for exact reproduction of the frozen paper table without a repository commit and manifests. |
| Evidence status | **Insufficient independent triangulation**. |
| Boundary | **Fact:** documented lifecycle and interfaces. **Author claim:** these mechanics provide reproducible real-work evaluation. **Inference:** implementation transparency improves auditability but does not prove construct validity. |

## R4. The Hugging Face link is a task-card catalogue, not the entire runnable benchmark

| Field | Assessment |
|---|---|
| Atomic thesis | S4's primary table is a metadata-only public task index. Actual input files, gated reference artifacts, graders, software/VM images, and execution orchestration live elsewhere. |
| Supporting sources | S4 records 153 metadata rows and the three-repository separation: task cards, open input data, and gated reference data. S3 independently describes task staging, hidden references, task code, and environment images within the same ALE project. S1 describes hidden references and evaluators at the paper level. |
| Source independence | Three differently typed first-party artifacts agree, but they share one publisher. |
| Contradicting or qualifying evidence | The metadata table includes full prompts and useful execution fields, so “metadata-only” does not mean content-free. Conversely, its 153 rows and one `task_split` label per row cannot reconstruct the frozen paper's overlapping 152-task evaluation membership. |
| Confidence | **High** for the current release's contents and omissions. |
| Evidence status | **Insufficient independent triangulation**, although the first-party repository is authoritative about what it currently contains. |
| Boundary | **Fact:** current schema, row count, companion repositories, access state. **Inference:** it is suitable for learning task breadth but insufficient for reproducing a score. |

## R5. The four requested resources form four layers of one benchmark ecosystem

| Field | Assessment |
|---|---|
| Atomic thesis | The clean reading map is: S2 = identity/version/abstract; S1 = scientific argument and frozen experiment; S3 = current runnable machinery; S4 = current public task catalogue and data layout. |
| Supporting sources | Each source's metadata and own scope statement; cross-references among S1–S4. |
| Source independence | This is a synthesis of first-party artifacts, not a multi-party validation. |
| Contradicting or qualifying evidence | The layers are not synchronized snapshots. The paper, docs, and dataset may differ in counts, split labels, provider behavior, and headline wording. “One ecosystem” must not be read as “one frozen release.” |
| Confidence | **High** as a navigation/scope synthesis. |
| Evidence status | **Insufficient independent triangulation**; external sources are not needed to establish the roles of the supplied URLs, but are needed to validate broader claims. |
| Boundary | **Fact:** artifact contents. **Inference:** the four-layer mental model and recommended reading order. |

## R6. None of the four requested resources is independent evidence for ALE's validity

| Field | Assessment |
|---|---|
| Atomic thesis | All four requested URLs are produced, hosted, or released as part of the ALE research ecosystem; agreement among them is first-party consistency, not independent replication. |
| Supporting sources | S1/S2 identify the ALE authors and Berkeley lead; S3 identifies Berkeley RDI/ALE documentation; S4 identifies a first-party ALE dataset. S8 is explicitly a mirror/index. S5–S7 are separate teams but do not replicate ALE. |
| Source independence | One direct evidence family (ALE), plus three independent adjacent/method sources that test different constructs. |
| Contradicting or qualifying evidence | S3 and S4 are primary authoritative sources for their own implementation/data contents. Lack of independence does not make those descriptions false; it limits external validation of representativeness, grader validity, and headline scores. |
| Confidence | **High**. |
| Evidence status | **Insufficient independent triangulation** for ALE performance/validity. No source note reports a full independent ALE rerun. |
| Boundary | **Fact:** source ownership/relationship. **Inference:** claims needing external validation should be presented as author-reported. |

## R7. Count disagreements are version/scope warnings, not interchangeable answers

| Field | Assessment |
|---|---|
| Atomic thesis | “About 150,” 150, 152, and 153 refer to different snapshots and possibly different units; any beginner explanation must date and name the source rather than select one timeless count. |
| Supporting sources | S1 says 150 in its corpus/release discussion and 152 in the experiment text. S3's current `full.txt` has 152. S4's July-modified metadata release has 153 rows. S8 shows abstract-text drift too. |
| Source independence | All count evidence is first-party or a mirror, but the disagreement is directly observable across artifacts. |
| Contradicting or qualifying evidence | Some differences may be simple release evolution; others may reflect workflows, instances, rows, tier memberships, or stale prose. The available notes do not pin a single commit that fully reconciles every number. |
| Confidence | **High** that drift exists; **low-to-moderate** on its exact causal history. |
| Evidence status | **Insufficient independent triangulation** and **unresolved exact reconciliation**. |
| Boundary | **Fact:** each dated source's displayed count. **Inference:** version/unit drift is the safest explanation. Do not claim a specific undocumented migration. |

## Handoff rule for the final explainer

The final answer may confidently explain what each URL is. It should not call them “four studies,” should not count agreement among them as independent replication, and should attach dates/source names to changing counts or headlines.

