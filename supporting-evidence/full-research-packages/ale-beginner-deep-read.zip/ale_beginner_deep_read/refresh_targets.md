# ALE research refresh targets

Refresh this investigation when any of the following changes:

1. **Paper version:** check whether arXiv:2606.05405 has a revision after v2 (2026-06-11), a peer-reviewed venue, or a formal limitations/human-baseline addition.
2. **Public task manifest:** record the pinned repository commit and reconcile `150`, `152`, and current Hugging Face row counts.
3. **Dataset family:** track the task-card commit, open input-data repository, gated reference-data repository, schema changes, category count, and license/terms.
4. **Documentation:** check the overview's hardest-tier wording, provider count, task lists, grader-execution description, and whether direct `hf://` staging becomes implemented.
5. **Leaderboard:** snapshot exact task version, agent harness, model, pass rate, mean score, retries, cost, runtime, and access date. Never compare a Best-per-task oracle as a single agent.
6. **Independent validation:** search for a complete, pinned, budget-matched independent ALE rerun; distinguish partial reuse from full replication.
7. **Human baseline:** look for matched human runs under the same prompt, tools, time cap, environment, and grader.
8. **Grader validity:** look for human agreement, false-positive/negative audits, adversarial grader testing, and benchmark-gaming reports.
9. **Economic interpretation:** look for empirical links between ALE performance and deployed productivity, quality, supervision needs, wages, or occupation-level outcomes.

## Refresh protocol

- Re-open the exact four primary URLs.
- Record access date and visible version/commit.
- Diff source claims before updating conclusions.
- Preserve unresolved discrepancies rather than silently normalizing them.
- Add new evidence as a separate source note and update `sources.csv`.

