# Source note 02 — ALE arXiv v2 abstract and version record

## Metadata

- Title: *Agents' Last Exam*
- Exact URL: https://arxiv.org/abs/2606.05405v2
- Identifier: arXiv:2606.05405v2
- Categories: cs.AI; cs.CL; cs.LG
- Authors: Yiyou Sun et al.; page states Yiyou Sun and 309 other authors
- v1 submitted: 2026-06-03 20:20:46 UTC
- v2 submitted: 2026-06-11 10:09:39 UTC
- arXiv-issued DOI: https://doi.org/10.48550/arXiv.2606.05405
- Linked official resources: project site and GitHub code
- Source type: canonical bibliographic/version page and abstract for the same preprint as source note 01
- Accessed: 2026-08-05

## Source role

This page does not contain a second article or an independent result. Its role is to establish the paper's identity, latest arXiv version, authorship, dates, categories, and the exact headline claims in the v2 abstract. Methodological details and the evidence behind those claims live in the full HTML/PDF.

## Page-by-page content paraphrase

### Title and authorship

The page identifies the work as *Agents' Last Exam*. It lists a very large multi-institution author group; arXiv summarizes it as Yiyou Sun plus 309 other authors. A large author list signals broad contribution but is not itself proof of benchmark validity or independent review.

### Abstract paragraph 1 — the problem statement

The authors say AI systems have performed strongly on many benchmarks without matching deployment across professional domains. They diagnose this partly as an evaluation problem: prevalent benchmarks do not continuously measure performance on authentic, economically valuable workflows.

This is an author thesis. The abstract does not present economic adoption data that isolates evaluation as the cause of limited deployment.

### Abstract paragraph 2 — what ALE is

ALE is described as a benchmark for agents performing long-horizon, economically valuable, real-world tasks with verifiable outcomes. It covers non-physical industries and organizes digitally executable work using O*NET/SOC 2018 as an occupational reference.

The abstract reports:

- collaboration with more than 250 industry experts;
- 55 subfields grouped into 13 industry clusters;
- more than 1,000 tasks.

These are broad headline units. The full paper distinguishes 960 workflows from 1,490 task instances, so the abstract's “1K+ tasks” should not be treated as a more precise count.

### Abstract paragraph 3 — headline result and intended role

The v2 abstract says the average full-pass rate on the hardest tier is below 1% across mainstream harness and backbone configurations. This is an average across configurations. It is not the score of every system and not the maximum score of one system.

The full paper resolves the apparent conflict with other numbers:

- a specific system can have 0% (zero of 38 Last-Exam tasks fully passed);
- a specific system can have 2.6% (one of 38 fully passed);
- averaging across tested configurations can still be below 1% because most configurations passed none.

The abstract also calls ALE a living benchmark whose task pool grows as workflows and industries are added. Therefore the v2 page is a frozen paper version, while datasets, documentation, and leaderboards can change later.

Finally, the authors present ALE as an instrument for connecting benchmark progress with GDP-relevant impact. The abstract does not itself show that ALE score improvements cause deployment or economic growth.

### Comments, subject areas, and links

The page links the project website and code repository, identifies the paper under Artificial Intelligence, Computation and Language, and Machine Learning, and provides the arXiv DOI. These links make the benchmark auditable and reusable, but the abstract page does not document exact environment versions, task manifests, or grader implementations.

### Submission history

The page is explicitly versioned:

- v1 appeared on June 3, 2026.
- v2 appeared on June 11, 2026.

For claims tied to the paper, v2 should be cited. Older mirrors, cached pages, or dataset cards may still reproduce v1 wording. Exact benchmark comparisons should additionally pin the task manifest and evaluator snapshot because “v2 paper” and “current living leaderboard” are different objects.

## Key beginner definitions

- **Abstract:** a short author-written summary; it cannot replace the methods, tables, and appendices.
- **arXiv preprint:** a publicly posted research manuscript; arXiv hosting is not equivalent to peer review.
- **Version (`v1`, `v2`):** a frozen revision of the manuscript. v2 supersedes v1 for paper-level claims but does not freeze every linked web resource.
- **Backbone model:** the foundation LLM inside an agent system.
- **Harness:** the orchestration layer that gives the model prompts, tools, context management, and an action loop.
- **Full pass:** a task receives exactly full credit, rather than only partial points.
- **Average full-pass rate:** an average across multiple tested configurations, not necessarily the best system's pass rate.
- **Living benchmark:** a benchmark whose task pool and surrounding implementation can evolve over time.
- **O*NET / SOC 2018:** U.S. occupational classifications used to organize the benchmark's digital-work taxonomy.

## What this page directly establishes

- The canonical paper identifier and v2 submission date.
- The authors' high-level definition of ALE.
- The v2 headline claim of an average hardest-tier full-pass rate below 1%.
- That the benchmark is intentionally evolving.
- The project/code links and research categories.

## What this page cannot establish by itself

- How tasks were collected or quality-controlled.
- How the VM, tools, hidden references, and graders work.
- Which configurations produced 0%, 2.6%, or other scores.
- Whether the public task set contains 150, 152, or a later number of rows.
- Whether results replicate independently.
- Whether ALE predicts human job performance, labor replacement, or GDP impact.

## Uncertainties and cautions

1. **Preprint, not validation:** the page does not show a peer-reviewed venue or an independent replication.
2. **Abstract compression:** “1K+ tasks,” “55 sub fields,” and “250+ experts” omit the paper's more complicated units and evolving counts.
3. **Statistic ambiguity without the table:** `<1%` can be misread as the best system or every system; the full paper shows it is an average across configurations.
4. **Version drift:** v2 freezes manuscript text, not the linked dataset, docs, repository, or leaderboard.
5. **Causal overreach:** the abstract argues an evaluation gap, but it does not prove evaluation is the main cause of limited economic deployment.
6. **Economic interpretation:** “GDP relevant impact” is an intended use and motivation, not a metric directly computed on this page.

## Short verbatim evidence

All excerpts are under 25 words and are used only as evidence anchors.

1. “long horizon, economically valuable, real world tasks with verifiable outcomes” — Abstract
2. “the average full pass rate is below 1%” — Abstract
3. “ALE is designed as a living benchmark” — Abstract
4. “not merely as another leaderboard” — Abstract

