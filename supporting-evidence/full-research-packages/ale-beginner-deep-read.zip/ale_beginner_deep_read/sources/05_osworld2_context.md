# Source 05 — OSWorld 2.0 (independent adjacent context)

- URL: https://arxiv.org/abs/2606.29537v2
- Version: arXiv v2, revised 2026-07-13
- Authors/source relationship: independent benchmark team; adjacent to ALE, not an ALE replication.
- Credibility: 4/5 (primary academic preprint with detailed benchmark paper)
- Recency: 5/5
- Bias risk: 3/5 (authors evaluate and promote their own benchmark)

## Why it is included

OSWorld 2.0 independently tests 108 long-horizon computer-use workflows. It cannot validate ALE's exact numbers, but it tests a related construct and helps check whether ALE's claimed long-horizon failure pattern appears elsewhere.

## Relevant findings

- Tasks have a reported skilled-human median duration of about 1.6 hours.
- The strongest reported configuration completes 20.6% under a binary metric while receiving 54.8% partial score.
- The authors report failures from losing constraints, missing newly arriving information, guessing rather than asking, skipping verification, and weak hidden-state recovery.
- This independently supports the distinction between partial progress and reliable end-to-end completion.
- OSWorld 2.0 adds dynamic services, user state, interaction details, and safety reports that are less directly measured by ALE's final-artifact orientation.

## Short verbatim evidence

- “108 long-horizon computer-use workflows across everyday and professional tasks”
- “still completes only 20.6% of tasks at a 54.8% partial score”
- “they lose track of constraints”
- “skip verification”

## Boundary

This source is triangulation for the broad reliability problem only. Different tasks, interfaces, budgets, and graders prevent direct numerical comparison with ALE.

