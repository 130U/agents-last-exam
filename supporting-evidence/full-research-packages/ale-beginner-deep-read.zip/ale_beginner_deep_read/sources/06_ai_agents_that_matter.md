# Source 06 — AI Agents That Matter (evaluation-method critique)

- URL: https://arxiv.org/abs/2407.01502
- Version: arXiv v1, 2024-07-01
- Authors/source relationship: independent evaluation-method paper that predates ALE.
- Credibility: 4/5 (academic methodology paper; arguments and experiments are inspectable)
- Recency: 3/5
- Bias risk: 2/5

## Why it is included

This paper supplies general criteria for reading an agent benchmark responsibly: accuracy should be interpreted jointly with cost, evaluation purpose, holdout quality, standardization, and reproducibility.

## Relevant findings

- Agent accuracy alone can reward unnecessarily complex and expensive systems.
- Model-development benchmarks and downstream application evaluations answer different questions.
- Weak holdout design creates benchmark overfitting and shortcut risks.
- Non-standard evaluation practices impede reproducibility.
- Applied to ALE, these arguments support reporting the exact model-harness configuration, costs, task version, and release date rather than calling a row a pure model score.

## Short verbatim evidence

- “a narrow focus on accuracy without attention to other metrics”
- “jointly optimizing the two metrics”
- “many agent benchmarks have inadequate holdout sets”
- “a pervasive lack of reproducibility”

## Boundary

The paper contains no ALE results and cannot validate ALE. It is used only as a methodological lens.

