# Source note 01 — ALE full paper (arXiv HTML)

## Metadata

- Title: *Agents' Last Exam*
- Exact URL: https://arxiv.org/html/2606.05405
- Paper identity: arXiv:2606.05405v2 [cs.AI]
- Version displayed by the HTML: v2, 2026-06-11
- Authors: Yiyou Sun et al.; arXiv describes 310 authors in total
- Leading institution stated in the paper: University of California, Berkeley
- Source type: author-produced research preprint; not an independently peer-reviewed validation
- License displayed by arXiv HTML: CC BY 4.0
- Accessed: 2026-08-05

## Source role

This is the central primary source. It supplies the benchmark's motivation, definitions, task-construction method, evaluation environment, scoring design, experiment table, failure analysis, and appendices. The separate arXiv abstract page is bibliographic/version metadata for the same paper, not a second study.

For a beginner, the paper's core claim is best translated as follows: ALE does not ask an LLM to answer exam questions. It places a **complete agent system** in a computer environment and asks it to finish a professional digital project, then grades the resulting artifact or final state.

## Section-by-section paraphrase

### Abstract

The authors start from a claimed gap: models score highly on academic and coding benchmarks, but that success has not produced comparable deployment across many professional sectors. They argue that evaluation is part of the problem because common tests do not measure sustained work on authentic, economically relevant workflows.

ALE is proposed as a benchmark for long-horizon, real-world, non-physical professional work whose outputs can be verified. The abstract says it was built with more than 250 industry experts, spans 55 subfields in 13 clusters, and covers more than 1,000 tasks. Its headline v2 claim is that the average **full-pass rate** on the hardest tier is below 1% across the tested harness/model configurations. It also calls ALE a “living benchmark,” meaning the task pool is intended to change and grow.

Important boundary: the abstract frames eventual benchmark saturation as progress toward GDP-relevant impact. That is the authors' motivation and interpretation; ALE itself does not measure GDP, labor displacement, or human-agent productivity parity.

### 1. Introduction — why ALE was built

The introduction contrasts benchmark achievements in games, mathematics, and programming with limited measured transformation in major industries. The authors call this a “utility problem”: tests measure abstract competence more readily than the ability to execute lengthy professional workflows.

They identify three construction difficulties:

1. Authentic long projects are costly to collect and reproduce.
2. Broad industry coverage requires access to many specialists.
3. Professional outputs are heterogeneous—spreadsheets, reports, media, designs, code, simulations, or models—so automatic verification is hard.

ALE's proposed answer is to collect projects that experts have already completed, cover many digitally executable fields, and turn heterogeneous deliverables into automated artifact- or milestone-based checks. The evaluation target is called a **Generalist Computer-Use Agent (GCUA)**: a system combining a foundation model with planning, tool use, code execution, file manipulation, visual perception, and computer control.

This establishes the unit of measurement: results belong to a model–harness–tools–environment configuration, not to a bare LLM alone.

### 2.1 Design principles — which tasks qualify

The benchmark applies three admission principles:

- **Representativeness:** the workflow and software should resemble actual professional practice.
- **Complexity:** it should be an end-to-end workflow rather than a single click or local edit. The paper contrasts applying one video filter with transferring a running cheetah into another video, which requires tracking, rotoscoping, compositing, and color matching.
- **Verifiability:** the result must support deterministic checking or an unambiguous artifact-grounded rubric. A vague request to design any RPG is rejected; reproducing a specified game can be checked through map geometry, character attributes, and event states.

This design necessarily selects for work that leaves inspectable digital artifacts. Valuable work that is primarily interpersonal, tacit, physical, political, or impossible to verify automatically is outside or underrepresented.

### 2.2 Scope and taxonomy

ALE uses the U.S. SOC 2018 occupational classification and O*NET work/task/tool records as a starting point. It excludes occupations whose central work is not meaningfully digital, clusters related software-mediated workflows, and reports 13 top-level domains with 55 subdomains.

Appendix B explains the derivation more precisely:

- 1,016 O*NET 30.2 occupation entries were screened with a fixed GPT-4o mini prompt at temperature 0.
- Variants were consolidated to 117 SOC base codes.
- Those records were organized into 51 SOC-anchored workflow subdomains.
- Four frontier subdomains and seven extensions were added after literature/research and expert review.
- The final result is 55 subdomains in 13 domains.

The paper uses the same 55-subdomain coordinate system to map 16 earlier benchmarks and argues that their union still leaves 13 ALE subdomains uncovered. This breadth comparison is author-defined and LLM-assisted; it is useful orientation, not an independently validated universal taxonomy.

### 2.3 Task sourcing, construction, and quality control

The paper reports 1,490 task instances in the broader corpus. Figure 5 divides them into 150 public, 1,017 private, and 323 awaiting verification/QC. It also describes 960 external submissions and 530 commissioned tasks. Elsewhere the conclusion says there are 960 task workflows and 1,490 instances; these terms and counts should not be collapsed into one unit.

Tasks pass through five gates:

1. Recruit specialists through advisory committees.
2. Have practitioners submit real past projects, often originally taking days or weeks.
3. Edit and first-pass review the description, input files, software, expected deliverable, and evaluation plan.
4. Engineers implement the VM, dependencies, assets, and grader, then dry-run it.
5. An expert committee checks reference correctness, reproducibility, rubric bounds, and whether the prompt contains enough information.

Only roughly 10% of the corpus is public. The authors plan to rotate private tasks into later releases to reduce contamination and task-specific overfitting. Rotation mitigates exposure but does not make the public tasks uncontaminated.

### Appendix B — construction details and workflow examples

Appendix B expands the occupational-taxonomy derivation and gives four workflow landscapes:

- manufacturing and industrial operations;
- biomolecular structure and design;
- 3D, animation, and interactive media;
- robotics and autonomous systems.

Each landscape describes realistic handoffs, tools, inputs, and deliverables rather than isolated actions. Examples include CAM toolpaths and inspection plans, ligand poses and sequence designs, rigs and engine scenes, or URDFs and controller parameters. These examples show what the benchmark authors mean by a “professional workflow”: multiple dependent steps ending in a usable artifact.

Appendix B also says representative task cards contain the prompt, inputs, deliverables, rubric, observed score, and outcome. The HTML text states that the displayed trajectories use Claude Code + Opus 4.7. It points to an online inventory of 150 selected public tasks.

### 3.1 Evaluation pipeline — how one run works

The system separates three components:

1. **Task specification:** a `main.py` encodes the prompt, inputs, software, hidden references, and evaluation criteria.
2. **Agent:** a harness orchestrates a foundation model and its tools.
3. **Environment:** a fresh remote virtual machine contains the required applications and files.

Each specification implements:

- `load()` — declares the task, metadata, and compute requirements;
- `start()` — prepares a deterministic initial VM state;
- `evaluate()` — retrieves the delivered artifacts and returns a normalized score in `[0,1]`.

The canonical directory contract is:

- `input/`: read-only task assets;
- `software/`: installed applications and dependencies;
- `output/`: the intended writable delivery location;
- `reference/`: hidden ground-truth artifacts available only to evaluation.

The agent receives the task description and metadata, observes screenshots, shell output, and files, then takes mouse, keyboard, shell, file, or API actions until it stops or times out.

Appendix C reports the paper experiments used GCP VMs. The default was `c4-standard-4` (4 vCPUs, 16 GB RAM); GPU tasks used `g2-standard-8` with an NVIDIA L4, with larger configurations for a few heavy simulations.

### 3.2 Agent architecture — what system is actually tested

The authors divide a capable computer agent into five layers:

- **Brain:** model reasoning and planning.
- **Eyes:** perception of screenshots and GUI state.
- **Body:** orchestration and control flow.
- **Hands:** structured tools.
- **Feet:** the runtime where actions execute.

CLI agents generally lack visual “Eyes”; GUI agents may have perception and mouse control but weak shell/file/code orchestration. A GCUA is intended to unite all five layers.

The primary setup is **GUI-as-Tool**: mouse, keyboard, screenshot, scrolling, and related actions appear as tools inside the same model loop. A GUI sub-agent is reserved for models without native vision. Appendix C lists 14 GUI tools and describes a modern harness as a loop with prompt construction, model calls, tool execution, sub-agent dispatch, and context compaction.

This section is why ALE should not be called a pure LLM benchmark. Prompting, tool routing, context management, GUI integration, and runtime all affect the result.

### 3.3 Grading heterogeneous outputs

ALE supports several artifact-comparison modes:

- exact or hashed values;
- structured numeric/table fields with tolerances;
- geometric or point-cloud distance;
- visual comparison;
- behavioral/world-state replay;
- semantic/free-text rubric checks;
- executable artifacts tested on hidden cases or against an oracle.

Scores are combined through four patterns:

- **gate-and-score:** a hard validity condition must pass before partial quality is considered;
- **weighted rubric:** expert-defined weights combine submetrics;
- **binary checklist average:** independent yes/no checks are averaged;
- **pairwise file aggregation:** corresponding output/reference files are scored and averaged.

A gate is important for reading results. A file may be visually close but receive 0 if it does not parse, violates a safety condition, collides in simulation, or is missing a required structure. Therefore a zero task score can hide useful partial work, while a nonzero mean score can coexist with a zero full-pass rate.

The appendix's static analysis reports:

- 93.2% code-based deterministic judges and 6.8% LLM-as-judge;
- 88.5% host-side scoring and 11.5% VM-side verification.

When an LLM judge is unavoidable for perceptual/creative artifacts, the authors use narrow reference-grounded yes/no probes and aggregate them in code. This reduces open-ended judge discretion but does not eliminate judge-model drift or prompt sensitivity.

### Appendix C — reproducibility and harness internals

References are isolated from the agent and are checked for presence before scoring. Missing, unreadable, or incorrectly shaped outputs generally receive a defined score of 0 rather than crashing the benchmark. Code graders are deterministic; for LLM-judged tasks, the judge model and prompt are recorded so scores can be re-derived from saved artifacts.

A **task workflow** is one reusable professional procedure and evaluator; a **task instance** is one concrete input/reference pair. For example, one G-code workflow has 18 workpiece instances sharing the same collision and surface-similarity grader. The paper says instance scores average into workflow scores, then industry and cluster aggregates.

The harness loop includes initialization, context building, LLM inference, action selection, tool-result collection, and overflow/context checks. Context compaction can clear stale results, summarize older conversation segments, or truncate at hard limits. Sub-agents can explore in separate contexts. These are measured system affordances, not incidental implementation details.

### 4. Experiment setup

All evaluated systems are extended to GCUA mode with the same general GUI bridge. Each task run is capped at five wall-clock hours. The main table reports:

- **Mean Score:** average fine-grained task score, expressed as a percentage.
- **Full Pass Rate:** fraction of tasks scoring exactly `1.0`.
- API cost, aggregate wall-clock time, and token usage.

Only selected configurations were repeated three times because the study is expensive. Superscript `±` values are score standard deviations for those repeated runs; most entries do not have a repeated-run variance estimate.

The experiment has five comparison blocks:

1. mainstream harness–backbone combinations;
2. model sweep with OpenClaw fixed;
3. harness sweep with GPT-5.5 fixed;
4. harness sweep with Opus 4.7 fixed;
5. ALE-CLI, a 105-task Linux-only subset for terminal-capable systems.

The paper says an individual run costs roughly USD 3–10 and takes tens of minutes to hours, making a complete public evaluation expensive.

### Difficulty tiers and the count issue

The paper defines three evaluation views:

- **Near-Term:** 67 tasks that frontier systems can partly solve; intended for rapid iteration.
- **Full-Spectrum:** 55 tasks, at least one from each subdomain; intended for breadth.
- **Last-Exam:** 38 hardest tasks; intended as a milestone set.

They are not presented as three disjoint partitions. Their memberships sum to 160, yet the paper calls the complete public evaluation a 152-task set. “Overall” is said to operate on distinct tasks, avoiding double counting.

There is an unresolved internal snapshot discrepancy: the experiment text says 152 public tasks, while the corpus figure, release discussion, and Appendix B inventory say 150. The most defensible reading is version/count drift inside a living benchmark, not that 150, 152, and later dataset counts are interchangeable.

### 4.1 Main results

Selected v2 Table 1 results:

- **Codex + GPT-5.5:** Near-Term pass 38.1%, mean score 64.7%; Full-Spectrum pass 22.7%, score 36.0%; Last-Exam pass 0%, score 11.2%; overall distinct-task pass 24.0%.
- **ALE-Claw + GPT-5.5:** Near-Term pass 32.8%, score 67.4%; Full-Spectrum pass 23.6%, score 41.1%; Last-Exam pass 2.6%, score 12.8%; overall pass 23.0%.
- Most other reported Last-Exam configurations have 0% full pass; a few record 2.6%.
- **ALE-CLI Codex + GPT-5.5:** 23.3% overall full pass on the 105-task Linux subset and 0% on its Last-Exam slice.

The Last-Exam denominator explains the recurring 2.6%: one fully passed task out of 38 equals 2.63%. Therefore:

- `0%` means a particular configuration fully passed none of the 38 tasks.
- `2.6%` means a particular configuration fully passed one of 38.
- `<1%` in the v2 abstract is the average full-pass rate across the tested mainstream harness/backbone configurations, not the best single configuration.

These are compatible statistics at different aggregation levels.

### 4.2 Analysis

The authors report similar domain profiles for GPT-5.5 and Claude Fable 5: computational mathematics and agriculture/environment score highest, business/legal follow, and education is lowest. These are benchmark-domain aggregates, not occupational automation rates.

Tool traces show that 34% of public tasks designate graphical software as primary, while GUI calls remain a small share. Agents often substitute shell scripts for GUI workflows. This may be efficient, but it can also bypass domain software and miss visual or application-state requirements.

The paper says Understanding and Approach errors dominate failure cases, and interprets this as evidence that missing domain knowledge is more important than raw execution. That interpretation depends on the failure-analysis method described below and should not be generalized as a universal causal law.

### 5. Related work

The paper positions ALE against three families:

- knowledge/exam benchmarks such as MMLU, GPQA, and HLE;
- agent/computer-use benchmarks such as GAIA, SWE-bench, OSWorld, WebArena, and Terminal-Bench;
- economic/project benchmarks such as GDPval and the Remote Labor Index.

The authors' distinction is that question-answering tests what a model knows; software benchmarks test narrower action surfaces; GDPval/RLI contain professional projects but use costly human grading. ALE claims broader occupational coverage, longer workflows, expert sourcing, and automated verification.

The comparison table describes ALE's source-project horizon as hours to weeks. This is the historical human project scale; agent evaluation itself is capped at five hours.

### 6. Conclusion

The conclusion summarizes ALE as 960 expert-authored task workflows and 1,490 task instances across 55 digital industries. It argues that saturation would indicate progress toward sustained, tool-intensive professional work.

The paper does not show that saturation has occurred, nor does it provide a human baseline demonstrating professional parity.

### Appendix D.1 — public/private representativeness

Claude Code + Opus 4.7 was run on the full pool. Domain-cluster pass rates on public versus full tasks correlate at Pearson `r = 0.89`, `p < 0.001`. The full pool is easier because the public set contains all Last-Exam tasks, whereas private tasks include a larger proportion of Near-Term work.

This is evidence of domain-level correlation for one tested configuration. It does not prove that public and private tasks are exchangeable across every model, task type, or metric.

### Appendix D.2 — timeout behavior

Runs stop at five hours and existing artifacts are still graded. Overall, 3.8% of Table 1 runs time out; timed-out runs average 20.7 versus 33.2 for runs that finish earlier. Last-Exam has the highest timeout rate, 6.4%, and timed-out Last-Exam runs average only 1.3 versus 7.0 otherwise.

Timeout is therefore part capability and part benchmark resource constraint. A timeout does not automatically mean no work was completed.

### Appendix D.3 — failure analysis

The analysis covers failed public-task runs from **one configuration**, Claude Code + Opus 4.7. First, OpenAI Codex reads run artifacts and produces evidence-linked analysis cards. Then GPT-4o at temperature 0 assigns a taxonomy. Timeouts/resource exhaustion are excluded.

Reported distribution among classifiable failures:

- Approach 47%: wrong strategy 30%, incomplete/abandoned 17%.
- Understanding 31%: domain knowledge gap 25%, hallucination/fabrication 6%.
- Execution 22%: output-format error 10%, implementation bug 8%, GUI/browser failure 4%.

Because the coding and classification are model-mediated and use one system, the percentages are descriptive evidence, not audited human causal ground truth for all agents.

### Appendix D.4 — model versus harness

With OpenClaw fixed, 12 backbone models span 16.8 percentage points in overall pass rate. With the backbone fixed, changing harnesses spans 4.9 points for GPT-5.5 and 7.2 points for Opus 4.7. The authors summarize this as a roughly three-times larger model spread among the tested well-engineered systems.

This is a controlled comparison within the selected configurations, but it is not a universal decomposition of model and harness causality. The model, prompt, tool compatibility, safety behavior, and harness can interact.

### Appendix D.5–D.6 — cost, time, tokens, and per-task variation

Cost, runtime, and token count are weak predictors of score in the reported systems. Examples in the appendix show cheaper/faster configurations outperforming more resource-intensive ones. The authors attribute variation to model-task fit, context efficiency, retries, timeout behavior, and parallelism.

Heatmaps display each task–agent score across the three tiers. Their role is to show that aggregate rankings hide large per-task variation and missing runs.

## Key beginner definitions

- **Benchmark:** a fixed or versioned set of tasks and rules used to compare systems.
- **LLM:** the language model that proposes reasoning and actions; only one component of the tested system.
- **Agent:** model plus harness, prompts, tools, memory/context handling, computer-control layer, and runtime.
- **Harness:** the orchestration software that constructs context, calls the model, exposes tools, executes actions, and manages long runs.
- **GCUA:** Generalist Computer-Use Agent, intended to combine visual GUI use with shell, files, code, APIs, and planning.
- **Workflow:** a reusable end-to-end professional procedure with a shared evaluator.
- **Task instance:** one runnable input/reference case of a workflow.
- **Artifact:** the produced file, model, spreadsheet, report, media output, program, or final system state.
- **Grader / evaluator / judge:** code or a narrowly scoped model that converts the artifact into a score.
- **Mean Score:** average partial-credit score over tasks.
- **Full Pass Rate:** proportion of tasks receiving exactly full credit.
- **Gate-and-score:** a hard validity test that can force score 0 before quality credit is considered.
- **Tier:** a task selection for a different evaluation purpose; ALE's three tier lists overlap.
- **Living benchmark:** tasks, manifests, graders, or releases may change over time; comparisons must identify a snapshot.

## What this paper directly supports

- ALE measures end-to-end completion of selected, digitally executable, artifact-producing professional workflows.
- Results measure complete agent configurations, not isolated model intelligence.
- Current tested systems often make partial progress but rarely achieve perfect end-to-end completion on Last-Exam tasks.
- Strategy selection, domain knowledge, completion, formatting, implementation, GUI reliability, and time management all contribute to failure.
- Scores must be interpreted with the exact tier, metric, configuration, and version.

## What it does not establish

- No controlled human baseline or expert-time comparison is reported.
- It does not estimate how frequently tasks occur in the labor market or weight them by wages, GDP, risk, or business value.
- It does not establish that an Agent can replace a job, collaborate in an organization, manage clients, or accept legal responsibility.
- It does not isolate pure reasoning, domain knowledge, GUI skill, or harness quality into independent scores.
- It does not validate process safety or professional method unless the grader explicitly checks those properties.
- It does not independently validate the authors' task taxonomy or economic-impact framing.

## Limitations and uncertainties

The paper has no clearly labeled, consolidated “Limitations” section. Important limitations must be reconstructed from the design:

1. **Preprint status:** this is author-reported arXiv work, not an independent replication.
2. **No human baseline:** projects reportedly took experts days or weeks, but agents get five hours; the paper does not run matched humans under the benchmark conditions.
3. **Selection bias:** tasks must be digital, expert-submitted, complex, and automatically gradeable; that is not a probability sample of jobs or work hours.
4. **Whole-system confounding:** scores combine model, harness, tools, prompts, software, OS, licenses, network/credential access, and compute.
5. **Limited repeated runs:** most table cells lack multi-run variance estimates.
6. **Heterogeneous graders:** deterministic code can still encode mistaken tolerances or incomplete notions of quality; 6.8% of workflows also use model judges.
7. **Strict gates:** full-pass rates emphasize reliability but can erase useful partial progress.
8. **Outcome focus:** unsafe or non-expert intermediate behavior may go unnoticed unless encoded in a gate or provenance check.
9. **Public/private difference:** `r = 0.89` comes from one configuration and the private pool is easier in aggregate.
10. **Contamination:** withholding and rotation reduce but do not eliminate adaptation to public tasks.
11. **Failure-taxonomy scope:** one configuration, LLM-generated analysis, LLM classification, and resource failures excluded.
12. **Tier construction:** the paper explains the purpose of each tier but does not publish a formal reproducible formula that assigns difficulty.
13. **Count drift:** the same v2 paper contains 150- versus 152-public-task descriptions; external living surfaces may differ again.
14. **Economic overreach risk:** “GDP-relevant” is framing, not a measured outcome.

## Short verbatim evidence

All excerpts are under 25 words and are used only as evidence anchors.

1. “The key distinction is between a workflow and an action.” — Section 2.1
2. “The agent (a harness orchestrating a foundation model)” — Section 3.1
3. “full pass rate is the share of tasks receiving full credit.” — Section 4.1
4. “ALE evaluations use a five hour wall clock cap per run.” — Appendix D.2
5. “Code-based (deterministic) | 93.2%” — Appendix C, Table 4
6. “Nearly half (47%) of classifiable failures stem from Approach errors” — Appendix D.3.3
7. “higher resource consumption does not reliably translate to better performance.” — Section 4.2
8. “the average full pass rate is below 1%.” — Abstract

