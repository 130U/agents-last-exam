# Source 07 — Remote Labor Index (independent professional-work context)

- URL: https://arxiv.org/abs/2510.26787
- Version: arXiv v1, 2025-10-30
- Authors/source relationship: independent economically grounded agent benchmark that predates ALE.
- Credibility: 4/5 (primary academic preprint with real-project benchmark design)
- Recency: 4/5
- Bias risk: 3/5 (authors evaluate and promote their own benchmark)

## Why it is included

RLI is an independent example of a project-scale benchmark that connects agent work to economic tasks. It helps separate “real project evaluation” from the stronger claim that a score measures whole-job automation.

## Relevant findings

- RLI uses real-world, economically valuable projects and evaluates end-to-end agent performance.
- Its published abstract reports a 2.5% top automation rate at its release.
- Unlike ALE's largely automated artifact grading, RLI relies on expert evaluation of project deliverables and therefore measures a related but different construct.
- Agreement between different professional-task benchmarks that completion is low supports the broad reliability conclusion, but not numerical interchangeability.

## Short verbatim evidence

- “real-world, economically valuable projects”
- “evaluate end-to-end agent performance in practical settings”
- “the highest-performing agent achieving an automation rate of 2.5%”

## Boundary

RLI's sampling, budget, grading, task length, and definition of automation differ from ALE. It cannot be used to convert an ALE pass rate into a job-automation percentage.

