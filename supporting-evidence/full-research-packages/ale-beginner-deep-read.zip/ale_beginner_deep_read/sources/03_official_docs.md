# Source note 03 — ALE official framework documentation

## Metadata

- **Primary entry:** [Agents' Last Exam — Framework Documentation](https://agents-last-exam.org/docs/ale/index.html)
- **Publisher / authority:** UC Berkeley RDI / Agents' Last Exam team; primary documentation for the open `ale_run` implementation, but not an independent validation of ALE.
- **Document type:** living implementation and operations documentation, not a frozen scientific-paper version.
- **Accessed:** 2026-08-05 (America/New_York).
- **Explicit schema versions observed:** normalized trajectory schema `ALE-v1.0`; the documentation itself does not expose a single release tag or commit hash on the rendered pages.
- **Research use:** explains what actually runs, where it runs, how inputs/references are staged, how an agent is connected, what files a run leaves, and what must be fixed to reproduce an experiment.

## Navigated pages

Core architecture and lifecycle:

1. [Overview](https://agents-last-exam.org/docs/ale/index.html)
2. [Task spec & data staging](https://agents-last-exam.org/docs/ale/pages/tasks.html)
3. [Sandbox & provider](https://agents-last-exam.org/docs/ale/pages/sandbox.html)
4. [Agents & executor](https://agents-last-exam.org/docs/ale/pages/agents.html)
5. [Trajectories & artifacts](https://agents-last-exam.org/docs/ale/pages/trajectories.html)

Running and reproducing:

6. [Run an experiment](https://agents-last-exam.org/docs/ale/pages/providers.html)
7. [Configure an experiment](https://agents-last-exam.org/docs/ale/pages/configure.html)
8. [Run and collect results](https://agents-last-exam.org/docs/ale/pages/run.html)
9. [Local containers](https://agents-last-exam.org/docs/ale/pages/local-docker.html)
10. [QEMU/KVM VMs](https://agents-last-exam.org/docs/ale/pages/local.html)
11. [Existing sandbox](https://agents-last-exam.org/docs/ale/pages/static.html)

Extension and interfaces:

12. [Add an agent](https://agents-last-exam.org/docs/ale/pages/add-agent.html)
13. [Add a task](https://agents-last-exam.org/docs/ale/pages/add-task.html)
14. [MCP tools](https://agents-last-exam.org/docs/ale/pages/mcp-tools.html)
15. [Trajectory schema (ALE-v1.0)](https://agents-last-exam.org/docs/ale/pages/trajectory-schema.html)

The cloud-provider pages were not reproduced line by line because their account/network setup is not necessary for a beginner's conceptual model. Their existence was checked through the provider overview: GCE, AWS EC2 and Alibaba ECS are managed cloud options; Docker, QEMU/KVM and `static` are local/attached options.

## Beginner mental model

ALE is easiest to picture as a controlled work assignment rather than a question sheet:

`experiment = agent configuration × task variant × sandbox environment`

The framework gives the complete agent system a fresh computer, visible task inputs and an instruction. It lets the system work end to end. Only after the agent stops does ALE make the hidden reference available to the evaluator. It then records the score, artifacts, event log, native transcript and a normalized cross-agent trajectory.

Three words that must not be collapsed:

- **Model:** the underlying LLM selected by an agent preset.
- **Harness / agent:** the surrounding control loop, prompts, context management, tools, memory, subagents and runtime that use that model.
- **ALE framework:** the experiment orchestrator that provisions a machine, stages a task, launches the harness, evaluates the result and records the run.

Therefore the operational subject of an ALE run is a configured **agent system**, not a bare LLM call.

## The six-stage run lifecycle

The overview turns one run into six phases:

1. **Provision:** a provider creates or attaches a sandbox and waits for its CUA control server.
2. **Stage input:** the task's visible files and required starting application state are placed in the machine.
3. **Run agent:** the configured harness receives the instruction and works until completion, failure or timeout.
4. **Stage reference and grade:** the hidden reference is introduced only after the agent has finished; the evaluator compares the agent's final state/artifacts against it.
5. **Record:** ALE writes phase events, summary/score, normalized trajectory, screenshots, raw agent logs and optionally output files.
6. **Release:** the provider deletes, stops, keeps or detaches the sandbox according to cleanup mode.

This lifecycle is scientifically important because it defines what the score means. The agent does not get an interactive evaluator or a visible answer key, and the score is based on the state it leaves behind rather than on the persuasiveness of its final chat message.

## What an ALE task is in the implementation

The documentation gives a more concrete definition than “a prompt.” A task package contains:

```text
tasks/<domain>/<task>/
├── task_card.json
└── main.py
```

`task_card.json` supplies identity, category, logical machine snapshot, resource hints and wall-clock budget. `main.py` implements three cua-bench hooks:

- `load()` discovers one or more variants and returns the instruction plus metadata.
- `start(cfg, session)` prepares a fresh machine: inputs, directories, helper scripts and application state.
- `evaluate(cfg, session)` executes after the agent and returns one or more scores, normally a float in `[0,1]`.

One workflow can have multiple concrete variants sharing the same setup/evaluation logic. The docs say the public release ships the `base` variant of each public task. This helps distinguish a **workflow definition** from a **task variant/run unit**.

The evaluator is instructed to return `[0.0]` for missing output rather than throw an exception; exceptions are reserved for infrastructure failure. This separates “the agent failed the work” from “the benchmark machinery broke.” Task setup should also be idempotent and clear old `output/` and `reference/` state, especially if a machine might be reused.

## Input, reference, and output

- **Input:** visible to the agent before work begins.
- **Reference / golden artifact:** hidden answer material used by the evaluator.
- **Output:** the files or machine state produced by the agent.

Data may be pulled at runtime, baked into a machine image, or copied from a local host directory. In baked images the reference is stored as an encrypted archive and unpacked only for grading. In local Docker runs the host simply withholds `reference/` until after the agent exits. Configuration recognizes an `hf://` task-data source, but the docs explicitly say direct Hugging Face task-data staging is not implemented yet.

This hiding mechanism protects against the simplest contamination route inside a run: the agent cannot search the machine for the golden answer while working. It does **not** by itself prove that a model was never trained on public task descriptions or outputs; that broader contamination question belongs to benchmark design/versioning, not runtime staging.

## Sandboxes, providers, snapshots, and images

These are separate layers:

- A **sandbox** is the machine-like workspace exposed to the agent: OS paths, applications, shell, filesystem and graphical desktop.
- A **provider** creates/attaches and later releases that sandbox. Its stable interface returns a `SandboxHandle` with OS/path conventions and a CUA endpoint.
- A **logical snapshot** in a task card describes requirements such as `cpu-free-ubuntu`, `cpu-free`, `gpu-free`, `cpu-license` or `gpu-license`.
- An **environment profile** routes each logical snapshot to a provider/image and defines task-data and output transport.

Managed cloud and QEMU providers normally give each run unit a fresh full Ubuntu or Windows VM. The Docker profile gives a fresh Linux container with a virtual desktop but shares the host kernel. The `static` provider attaches to an already running machine and does not reset it.

The provider choice can therefore change task coverage, isolation, software/license availability, hardware and reproducibility even though the agent sees a nominally uniform CLI/GUI interface. The docs recommend managed fresh sandboxes for benchmark sweeps. `static` is positioned as a debugging path: state can leak between runs, so it is not a clean benchmark backend unless the user resets it independently.

Current documentation lists six implementations in its table:

- `gcloud`: new GCE VM per unit.
- `aws`: new EC2 instance per unit.
- `aliyun`: new ECS instance per unit.
- `docker`: new supported Linux container per unit.
- `qemu`: disposable full QEMU/KVM guest per unit.
- `static`: attach to a user-managed CUA endpoint.

QEMU is CPU-only in the documented profile and needs a Linux host, Docker, `/dev/kvm`, substantial disk, and enough memory for each concurrent guest. Docker is lighter but covers only a Linux subset and excludes tasks that need Windows, GPU or some nested container runtimes. Seven tasks in the current full task list require user-activated licensed software, so “the public set is downloadable” does not mean every task is immediately reproducible on every machine.

## What counts as the agent and what it can do

ALE intentionally combines terminal and desktop control. The docs argue that CLI is efficient and complete for some workflows, while professional applications may expose necessary functions only through GUI. Some deliverables are also meaningful only when created in their native editable application.

Two deployment shapes are supported:

- **In-sandbox agent:** a CLI harness such as Codex or Claude Code runs natively inside the task machine. It already has shell/filesystem access and receives the GUI bridge.
- **Out-of-sandbox agent:** its runtime, context, memory and subagents stay on the host or in a separate container. It controls the task machine remotely through CLI and GUI bridges. ALE-Claw is the reference example.

The integration separates:

- **Deployer — what to run:** `install()`, `launch(prompt)` and `parse_artifacts()` adapt one harness.
- **Executor — where the deployer runs:** inside the sandbox, in ALE's local process or in an isolation container.

This distinction matters for result interpretation. Two entries using the same LLM can differ in prompts, context management, tool wrappers, transcript parsing, runtime location and recovery behavior. Those are part of the evaluated system.

One terminology trap: the `provider` field inside an agent config names the **LLM API provider**. The environment's provider names the **sandbox provider**. They are unrelated.

## Machine-control interfaces

The low-level action surface is two thin bridges over the same open CUA computer server:

- `vm_mcp_server`: one-shot commands, UTF-8 and binary file I/O, clipboard, and persistent PTY sessions.
- `cua_mcp_server`: screenshot, normalized-coordinate mouse actions, keyboard actions, scrolling, dragging and waiting.

For GUI actions, a confirmation is not an observation of the resulting screen; the agent must take another screenshot. Out-of-sandbox agents normally use both bridges. In-sandbox agents already have a native shell and normally use only the GUI bridge. Harnesses without MCP support can receive the same action space through a native plugin.

The bridges intentionally expose primitives rather than a shared high-level “solve spreadsheet” tool. A harness may layer richer tools, pagination, truncation and recovery on top, which is another reason the benchmark compares whole agent systems rather than only models.

## Grading in the docs

The documented grading phase reads the agent's output plus the now-available reference and returns scores. It names two grader styles:

- **Deterministic:** exact, numeric, parsed or structural comparisons.
- **Judge-based:** an LLM/VLM for semantic, visual or video properties that cannot be reduced to exact comparison.

Judge-based grading is separate from the agent's own execution: evaluator credentials can be stored under `secret/eval_time/`, and the judging call occurs after the agent is gone. This reduces direct evaluator-agent interaction, but it does not eliminate judge-model measurement error. The implementation documentation explains the mechanism; the paper is the place to look for proportions, validity evidence and grader-audit arguments.

One cross-source ambiguity should be preserved: the task documentation summarizes the grader as running host-side, whereas the paper reports that 11.5% of scoring workflows invoke VM-side verifiers. The most charitable reading is that orchestration/evaluation is host-controlled while some verifier code executes inside the VM, or that the live docs and paper describe different revisions. Do not turn the docs' shorthand into the claim that every scoring computation is physically host-side.

## Configuring and running an experiment

An experiment YAML binds one environment profile, one or more agent presets and a task list. ALE forms the Cartesian product of agents and task variants. Important run-level controls include:

- `name` and `output.root`, which define the run-record namespace.
- `concurrency`, which caps simultaneous units but is still constrained by cloud quotas, RAM, disk and model rate limits.
- `wall_time_s` or each task card's timeout.
- `auto_resume` and `max_attempts` (1–3); each retry has a separate timestamped directory.
- `cleanup_mode`: `delete`, `stop`, or `keep` for managed sandboxes.
- `prompt_suffix`, which changes every task instruction and is recorded in the trajectory.

Before any expensive provisioning, `--dry-run` resolves credentials/config references, environment routing, agent presets, tasks and variants, then prints the exact agent × task × variant matrix. This is a necessary sanity check, not a scientific replication guarantee.

The live docs currently name several curated task lists: 99 Docker-supported tasks, 105 Linux `ale_cli` tasks, 140 CPU-unlicensed tasks, 145 unlicensed tasks and 152 in `full.txt`, including seven licensed tasks. These counts are implementation-snapshot facts and should be dated rather than treated as permanent properties of ALE.

Auto-resume skips prior `completed` and `timeout` units, but retries newly failed units. Consequently a final sweep may contain attempts created at different times, and the researcher must specify how retries were selected/aggregated. Turning off resume runs selected units once and avoids the prior-result scan.

## Output collection versus evaluation

Two output locations are easy to confuse:

- `output.root` is the host directory containing ALE's **run records**.
- Environment `output_path` controls copying/uploading the **agent-produced task files** before sandbox cleanup.

`output_path` can be absent (score only), local, or cloud-object storage. Collection of produced files is best-effort: a transfer failure is logged but need not block evaluation while the sandbox is still alive. Therefore a valid score can coexist with missing copied artifacts; researchers who need auditability must inspect `output_gather_done` / `output_gather_failed` rather than assume `output/` is present.

## Run directory and normalized trajectory

Each attempt lands under a path shaped like:

```text
.logs/<experiment>/<run_id>/<agent>/<model>/<task>/v<variant>/<timestamp>/
```

Key contents:

- `events.jsonl`: append-only authoritative phase trace, flushed during execution and likely to survive interruption.
- `run.json`: identity, status, final score, termination reason and usage summary.
- `eval_result.json`: the evaluator's result in isolation.
- `trajectory.json`: normalized `ALE-v1.0` interaction record.
- `screenshots/`: images the agent saw, referenced by relative path.
- `origin_log/`: unedited harness-native transcripts and scratch artifacts.
- `output/`: produced task files, only when local collection succeeds/is configured.

The normalized trajectory contains ordered `system`, `user`, `agent` and `environment` steps; text/images; tool calls/results; optional exposed reasoning; per-step token/cost/time metrics; final outcome; and nested subagent trajectories. A deployer's `parse_artifacts()` translates each harness's native log to this schema.

Normalization makes cross-agent analysis easier, but it cannot manufacture information that a harness did not log. Reasoning visibility, per-step accounting, image capture and transcript completeness can still differ. The raw `origin_log/` should be retained for audits, and the deployer/parser version is part of a reproducible run.

## What these docs add beyond the paper

The scientific paper and the framework docs answer different questions:

| Scientific paper | Framework documentation |
|---|---|
| Why these tasks are intended to represent economically relevant long-horizon work | How a task is encoded as `task_card.json` plus three Python hooks |
| How tasks were sourced/quality-controlled and how coverage is argued | How inputs, references, apps and paths are physically staged |
| Experimental modes, metrics, result tables and failure analyses | How any harness is installed/launched/parses logs through a deployer/executor |
| Evidence about grader distribution and benchmark validity | Exact MCP primitives, environment profiles, provider lifecycle and files emitted |
| Claims about current agent performance | Commands and configuration needed to run, resume, inspect and extend the public framework |

In short, the paper defines and studies the measurement instrument; the docs expose the instrument's machinery. The docs make ALE inspectable and runnable, but they are not additional independent evidence that the instrument measures job readiness or economic replacement.

## Minimum information required for a defensible reproduction

The docs imply that “we ran ALE” is underspecified. A reproduction should pin and report at least:

1. repository commit/release and access date;
2. exact task list, task variants and whether licensed tasks are excluded;
3. task/data/image snapshot versions and OS/provider;
4. agent harness/deployer version, executor shape and agent preset;
5. exact model identifier, API provider and model settings;
6. prompt and any `prompt_suffix`;
7. per-task/experiment budgets, cleanup and retry policy;
8. resource shape and concurrency constraints;
9. grader/evaluator model and credentials/config for judge-based tasks;
10. attempt-selection and aggregation rule, plus raw run artifacts.

The rendered docs do not provide one frozen manifest that binds all of these to every paper table. Exact paper-table reproduction therefore requires combining the paper, its referenced code/data release and a pinned repository revision rather than following only the latest documentation pages.

## Uncertainties and version drift

1. **Living pages:** the docs do not display a single commit/release pin. Counts, providers, models, CLI versions, images and allowlists can change after the paper.
2. **Task counts:** current pages say “around 150,” while `configure.html` names 152 in `full.txt`. The linked Hugging Face dataset may show a different current row count. Treat all as dated snapshots and distinguish workflows, variants and released rows.
3. **Hardest-tier headline:** the overview still says 2.6% average pass rate, while the arXiv v2 abstract reports below 1%. This likely reflects page/version or statistic drift and must not be silently harmonized.
4. **Provider-count typo/drift:** `providers.html` says ALE exposes “four provider implementations” but its table lists six (`gcloud`, `aws`, `aliyun`, `docker`, `qemu`, `static`). Use the explicit table, and flag the prose count as stale or erroneous.
5. **Grader locale:** docs describe grading as host-side; the paper reports 11.5% VM-side verifier workflows. Preserve the distinction between host orchestration and verifier execution until the pinned code revision is inspected.
6. **`hf://` limitation:** the configuration accepts a direct Hugging Face task-data source, but the backend is not implemented; local Docker instead downloads data to the host and uses `local:` staging.
7. **Static provider:** convenient for debugging, but machine state can carry across runs. It should not be treated as equivalent to a fresh-sandbox benchmark sweep.
8. **Artifacts:** output transfer is best-effort. A score alone does not prove that all auditable files were successfully copied off the sandbox.
9. **Licensing/access:** seven current public tasks need user-activated licensed software; Windows/cloud/provider licensing and gated task-data access can limit nominal reproducibility.
10. **Logging completeness:** `ALE-v1.0` standardizes the container format, not the amount or accuracy of information each harness exposes.

## Short verbatim excerpts

All excerpts are from the official documentation and each is under 25 words.

1. “Measure agents on real work, in real sandboxes.” — [Overview](https://agents-last-exam.org/docs/ale/index.html)
2. “Only now is the hidden reference staged.” — [Overview](https://agents-last-exam.org/docs/ale/index.html)
3. “A sandbox is the machine-like environment an agent controls.” — [Sandbox & provider](https://agents-last-exam.org/docs/ale/pages/sandbox.html)
4. “ALE deliberately needs both at once.” — [Agents & executor](https://agents-last-exam.org/docs/ale/pages/agents.html), referring to CLI and GUI.
5. “Every agent logs differently.” — [Trajectories & artifacts](https://agents-last-exam.org/docs/ale/pages/trajectories.html)
6. “Validate the matrix before provisioning anything.” — [Run and collect results](https://agents-last-exam.org/docs/ale/pages/run.html)
7. “Output collection is best-effort” — [Run and collect results](https://agents-last-exam.org/docs/ale/pages/run.html)
8. “The agent must not see `reference/` during `start()`.” — [Add a task](https://agents-last-exam.org/docs/ale/pages/add-task.html)

## Key terms for the final explainer

- **Agent harness:** the control system around a model—prompts, loop, tools, context, memory, recovery and sometimes subagents.
- **Generalist Computer Use Agent (CUA):** an agent capable of combining terminal/system primitives with graphical desktop actions.
- **Sandbox:** isolated or machine-like OS environment in which one run performs the task.
- **Provider:** lifecycle adapter that acquires/releases a sandbox.
- **Snapshot:** logical OS/software/resource requirement requested by a task.
- **Environment profile:** maps task snapshots to concrete providers/images and sets data/output transport.
- **Task variant:** one concrete input instance of shared workflow/setup/grading logic.
- **Golden reference:** hidden expert-validated artifacts used to score the output.
- **Deterministic grader:** code that applies exact, numerical, parsed or structural checks.
- **Judge-based grader:** an LLM/VLM used for semantic or visual properties.
- **Deployer:** harness adapter implementing install, launch and log parsing.
- **Executor:** substrate on which the deployer/harness runs.
- **MCP bridge:** thin standardized exposure of CLI/system or GUI controls.
- **Trajectory:** normalized, ordered record of agent/environment interaction and metrics.
- **Run unit:** one agent preset × one task variant, owning one sandbox during its lifecycle.

## Bottom line from this source only

The official documentation establishes that ALE is an end-to-end systems evaluation framework. It operationalizes a task as a fresh computer, visible inputs, hidden references, an unconstrained-to-completion agent run within a time budget, artifact/state grading, and a standardized audit record. Its strongest contribution beyond the paper is implementation transparency. Its main limitation as evidence is that it is a moving, publisher-controlled manual: current counts and mechanics must be pinned before scientific comparisons, and it cannot independently validate the benchmark's broader economic claims.
