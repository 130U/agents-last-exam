# Source 04 — Hugging Face ALE dataset family

## Metadata

- **Primary source:** [agents-last-exam/agents-last-exam](https://huggingface.co/datasets/agents-last-exam/agents-last-exam)
- **Companion input-data repository:** [agents-last-exam/agents-last-exam-data](https://huggingface.co/datasets/agents-last-exam/agents-last-exam-data)
- **Companion reference-data repository:** [agents-last-exam/agents-last-exam-reference](https://huggingface.co/datasets/agents-last-exam/agents-last-exam-reference)
- **Machine-readable endpoints checked:** [dataset metadata API](https://huggingface.co/api/datasets/agents-last-exam/agents-last-exam), [dataset rows API](https://datasets-server.huggingface.co/rows?dataset=agents-last-exam%2Fagents-last-exam&config=default&split=v1.0&offset=0&length=100)
- **Accessed:** 2026-08-05
- **Current metadata revision observed:** `a8c1fd174a1f6cfa76526572a2e3ebece1276be2`
- **API `lastModified`:** 2026-07-11 06:17:59 UTC
- **Release shown on dataset card:** v1.0, 153 rows, one split named `v1.0`
- **Format / language / size:** Parquet; English; metadata file about 191 kB (page total about 196 kB)
- **Displayed license:** CC-BY-4.0
- **Source type:** First-party benchmark release
- **Credibility:** 5/5 for what is currently published in these repositories
- **Recency:** 5/5 as a 2026-08-05 snapshot, but this is a living dataset
- **Bias / caveat:** The benchmark team describes its own release. This source shows task contents, not independent evidence that the tasks are representative or that the graders are valid.

## Beginner takeaway

The URL the user supplied is **not the complete runnable benchmark in one table**. It is the open, lightweight **task-card metadata index**. Each of its 153 rows tells you what a task is, what prompt the agent sees, what software and input files it expects, and how it is classified. The actual input files live in a second open repository; the correct/reference outputs live in a third, gated repository.

A useful analogy:

- **Task-card metadata** = an exam catalog plus each question's instruction sheet.
- **Input-data repository** = the documents, images, code, databases, media, and starter projects handed to the candidate.
- **Reference-data repository** = the answer key / expected artifacts, withheld during the run.
- **Evaluator / grader** = the marking program. It is not contained in the metadata table; private evaluation details are intentionally excluded.

Consequently, reading the 153-row table is enough to understand task breadth, but **not enough to reproduce an ALE score**.

## How the three Hugging Face repositories fit together

| Repository | What it contains | Access and observed size | What it does not contain |
|---|---|---|---|
| `agents-last-exam` | One metadata row per public task: title, prompt, taxonomy, expected software, input-file descriptors | Open; 153 rows; about 196 kB | Actual input file contents, software binaries, references, scoring fixtures, VM images |
| `agents-last-exam-data` | Per-task `input/` files and task software fixtures under `tasks/<task_id>/<variant>/` | Open; page reports 49.6 GB | Reference outputs, VM images, internal artifacts |
| `agents-last-exam-reference` | Per-variant `reference/` outputs used in scoring | Gated; manual approval; page reports 11 GB | Inputs, software, VM images, internal artifacts |

The open input repository's browser viewer currently reports a format-mismatch error because its directories contain many file formats. That is a viewer limitation, not evidence that the input files are absent; the file tree remains the intended access surface.

## What exactly is in one task-card row

The current schema has 12 top-level fields:

1. `task_id`: stable identifier, generally `<category>/<task_name>`.
2. `title`: human-readable name.
3. `summary`: short description of the professional deliverable.
4. `category`: repository-level/top-level grouping.
5. `subdomain`: readable occupational subdomain.
6. `task_split`: one label among `near-term`, `full-spectrum`, `last-exam`; one current row is blank.
7. `task_prompt`: the full instruction supplied to the agent, 439–5,840 characters in the current viewer.
8. `agent_must_do`: checklist of required actions, zero to nine items.
9. `software`: expected applications or libraries, zero to nine entries.
10. `input_files`: descriptors containing `name`, `format`, `path`, and `description`; these are metadata, not file contents.
11. `taxonomy`: structured `domain_id`, `domain_code`, `subdomain_id`, `subdomain_code`, and `subdomain_name`.
12. `source_repo_path`: where the task resides in the source repository.

For a beginner, the important distinction is that the row mixes three different things:

- **Intent:** title, summary, prompt.
- **Execution contract:** required actions, software, expected inputs.
- **Classification:** category, subdomain, split, taxonomy.

It does **not** expose the hidden correct artifacts, complete private grading logic, VM provisioning details, reference file lists, classifier audit trails, or model submissions.

## Current row-level counts derived from the official rows API

### Split labels

| `task_split` value | Rows |
|---|---:|
| `near-term` | 67 |
| `full-spectrum` | 47 |
| `last-exam` | 38 |
| blank | 1 |
| **Total** | **153** |

The blank split belongs to `engineering/2d_drawings_to_3d_bridge_model`.

### `category` values

The viewer correctly reports 14 distinct `category` values. Their current counts are:

| Category | Rows | Category | Rows |
|---|---:|---|---:|
| `agriculture_env` | 2 | `business_finance` | 21 |
| `computing_math` | 23 | `education_info` | 4 |
| `engineering` | 20 | `health_medicine` | 26 |
| `legal` | 2 | `life_sciences` | 19 |
| `other` | 2 | `physical_sciences` | 15 |
| `psychology_neuro` | 3 | `social_sciences` | 1 |
| `transport_safety` | 3 | `visual_media` | 12 |

This field should not be treated as identical to the occupational taxonomy. In the current rows, 18 records have a `category` different from `taxonomy.domain_code`. Examples include a task stored under `business_finance` but taxonomized as `legal`, and a Hangzhou metro task stored under `transport_safety` but taxonomized as `engineering` / urban planning.

### Small metadata gaps

- 2 rows have a blank title.
- 1 row has a blank split.
- 5 rows have an empty `agent_must_do` list.
- 3 rows have an empty `software` list.
- 5 rows have an empty `input_files` list.

These blanks do not by themselves mean the underlying task has no instructions, software, or inputs. They show that the metadata table is a convenient index rather than a perfectly complete execution manifest.

## Representative task examples

These are examples actually present in the current 153-row release. They illustrate why ALE is closer to an end-to-end work simulation than to a question-answer benchmark.

1. **Crop Rotation Audit for Stable Parcels** — `near-term`, precision agriculture. The agent reads a French parcel GeoPackage, computes eight audit fields, and writes eligible and flagged GeoPackage layers while preserving geometry and schema. This combines policy interpretation, geospatial processing, and exact file delivery.

2. **Annual Report Full Extraction (1500 files)** — `last-exam`, accounting and finance. The agent must download 1,500 specified annual-report PDFs from East Money, extract core technical-personnel records, verify the files, and consolidate the results into `final_dataset.xlsx`. It tests scale, web retrieval, PDF extraction, data normalization, and completeness.

3. **Odoo Supply-Chain End-To-End Workflow** — `full-spectrum`, supply chain and logistics. The agent operates Odoo and PostgreSQL through purchasing, landed cost, subcontracting, two-level manufacturing, delivery, invoicing, returns, and credit notes. The deliverable is partly the final state of the business database, not just a text answer.

4. **Enterprise PCAP Triage in Wireshark** — `last-exam`, cybersecurity and digital forensics. The agent analyzes an enterprise packet capture, identifies the compromised host, reconstructs the infection chain, and produces a structured report. It requires investigation, tool use, and evidentiary reconstruction.

5. **Yi Manuscript Translation 1** — `last-exam`, translation and localization. The agent inspects a classical Yi manuscript image, identifies which glyph a phonetic gloss refers to, outputs its pixel bounding box, and writes a cited translation report using bundled sources. It joins visual localization, rare-language scholarship, and citation discipline.

6. **OpenROAD SKY130 Ibex PnR Signoff** — `last-exam`, semiconductor design. The agent tunes one allowed configuration for an RTL-to-GDSII flow, runs a pinned Docker/OpenROAD pipeline, and submits configuration plus signoff evidence. Success depends on iterative engineering and strict edit boundaries.

7. **NSCLC Radiomics Cox Signature** — `last-exam`, clinical diagnostics and imaging. The agent builds a CPU-only survival-risk model from 422 lung CT volumes, tumor masks, training outcomes, and fixed held-out IDs, then emits risk scores and associated outputs. This tests medical-imaging data plumbing, feature extraction, survival modeling, and reproducibility; it is not a clinical deployment claim.

8. **Single-FOV MERFISH Image Decoding and Cell Segmentation** — `near-term`, cell and imaging biology. The agent processes 16 primary microscopy images plus DAPI, decodes a 130-gene codebook, segments nuclei, assigns transcripts to cells, and creates a cell-by-gene matrix with quality metrics.

9. **Scene2 Resample** — `full-spectrum`, experimental psychology and neuroimaging. Using 3D Slicer, the agent resamples a 1 mm ROI mask onto a 2 mm statistical-map grid with nearest-neighbor interpolation and saves both the aligned NIfTI output and a readable screenshot.

10. **Atwood 2022 Measles Vaccine Coefficient Reproduction** — `full-spectrum`, quantitative social research. The agent reads a paper and appendix, inspects an archived replication package, reproduces six published coefficients, and writes structured outputs. This is research reproduction rather than summarization.

11. **Hangzhou Metro Passenger Simulation** — `full-spectrum`, urban and spatial planning. The agent uses AFC demand, GIS, and network configuration data to simulate one operating day and deliver passenger records plus a validation report.

12. **Music Transcription** — `full-spectrum`, audio/music production. The agent listens to an orchestral recording, creates a professional score in notation software, and exports a PDF, a MIDI with correct instrument programs, and a verification screenshot.

Other rows span KiCad PCB layout, Blender character reconstruction, Cubase project migration, legal fee calculation, medical-image adjudication, genomics pipelines, particle filtering, fire-safety reconstruction, ERP dashboards, and paper replication.

## Beginner definitions

- **Task / task card:** One unit of work and its human-readable contract. It is not merely one multiple-choice question.
- **Variant:** A particular instance or configuration beneath a task, such as a different company, case, dataset, or software setup.
- **Input:** Material visible to the agent when work begins.
- **Reference / ground truth:** Withheld expected output or comparison artifact used after the run.
- **Grader / evaluation fixture:** Code or rules that compare the agent's artifacts/state to requirements and assign a score.
- **VM:** The isolated Windows or Linux machine in which the task is run, with relevant professional software installed.
- **Taxonomy:** The occupational/domain classification; it is separate from the repository path category.
- **Near-term / full-spectrum / last-exam:** Benchmark selection labels. Broadly, they denote relatively tractable work, one-per-subdomain breadth coverage, and the hardest long-horizon set; the paper/docs are needed for the authoritative selection methodology.
- **Metadata-only:** A description of the files and task, not the files or answers themselves.

## Version and count drift

1. **153 versus 152 versus about 150.** The current HF card says v1.0 has 153 metadata rows. The paper v2 reports an evaluated public set of 152 distinct tasks, while the repository/docs often say “around 150.” These are snapshots and may also count slightly different units. The current HF row count should not be silently substituted into frozen paper tables.

2. **1,490 is not the HF row count.** The paper's 1,490 figure refers to the much larger expert-contributed task-instance corpus, including non-public/private/pending material. The 153 HF rows are the current public task-card release.

3. **13 clusters versus 14 category values.** The paper describes 13 industry/occupational clusters. The current HF `category` field has 14 values because it includes `other`, and `category` is not always the same as `taxonomy.domain_code`. The README does not provide a formal reconciliation, so the safest statement is: **13 is the benchmark's advertised occupational-cluster count; 14 is the number of current repository category labels.**

4. **55 subdomains versus 51 currently represented taxonomy codes.** The benchmark advertises 55 subdomains. The 153 current rows contain 51 distinct nonempty `taxonomy.subdomain_code` values. The dataset card does not explain whether the remaining subdomains are absent from this release, represented through overlapping selections, or affected by taxonomy migration. Mark this unresolved rather than “correcting” either figure.

5. **The split count does not reproduce the paper's table.** Current single-label metadata gives 67 near-term, 47 full-spectrum, 38 last-exam, and one blank. The paper reports a 55-task full-spectrum evaluation slice. Because the HF field stores only one label per row and the release has evolved, it cannot by itself reconstruct every paper evaluation membership. Use the paper's selected-task manifests for frozen experimental counts.

6. **Current revision matters.** The API snapshot used here was last modified 2026-07-11, a month after arXiv v2 (2026-06-11). Later task-card changes can therefore disagree with the paper without implying that the paper's recorded experiment changed retroactively.

## What this source establishes, and what it does not

### Established directly

- The open metadata release currently contains 153 task cards.
- The schema exposes full prompts, required-action checklists, expected software, input descriptors, and taxonomy.
- ALE includes genuinely heterogeneous artifacts and workflows, not only code or text questions.
- Actual inputs and ground-truth references are separated into companion repositories.
- Reference data is gated and must not be shown to the agent during evaluation.

### Not established by this dataset card

- That all tasks are equally representative of real jobs.
- That task tiers were assigned objectively or reproducibly.
- That the graders measure all dimensions of professional quality.
- That an ALE score equals job readiness or human replacement.
- Human baseline time, quality, or success rate.
- Exact frozen membership of every paper table after the living release changed.

## Short verbatim excerpts

Each excerpt below is under 25 words.

> “A metadata-only release (v1.0) of 153 tasks”

> “This dataset contains task cards only (one row per task).”

> “No input data, software binaries, reference outputs, scoring fixtures, or VM images are included here.”

> “Input files (the materials each task hands to the agent at run start)”

> “Access is gated to protect benchmark integrity.”

> “No training. Do not use this data to train, fine-tune, or distill models.”

> “No leakage at eval time.”

## License and access caution

The metadata and input-data pages display CC-BY-4.0. The source GitHub repository separately licenses framework software under Apache-2.0 and benchmark data under CC-BY-4.0. The gated reference page also displays a CC-BY-4.0 badge but simultaneously imposes explicit access terms: no training, no evaluation-time leakage, and no redistribution. The access form's complete terms were not visible without requesting access. Anyone using reference data should follow those gating terms rather than relying only on the license badge; this note is not legal advice.

## Uncertainties / refresh triggers

- Recheck row count, SHA, and `lastModified` before quoting current numbers.
- Recheck whether the blank title/split rows and empty lists have been repaired.
- Recheck whether all 55 taxonomy subdomains appear in a later metadata release.
- Recheck the gated reference terms after login if actual evaluation access is needed.
- Do not treat current HF task rows as proof of the exact task versions run in the arXiv paper unless revision manifests match.
