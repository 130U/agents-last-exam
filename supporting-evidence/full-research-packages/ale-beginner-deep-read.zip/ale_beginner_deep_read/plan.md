# ALE beginner deep read plan

## Reframed question

Explain, for a reader with no prior agent-evaluation background, what the four linked ALE resources each contain, how they fit together, what ALE actually measures, how to read its metrics, and what conclusions the materials do and do not justify.

## Genre and audience

- Genre: beginner explainer with source-by-source reading map.
- Audience: no assumed knowledge of LLM agents, computer-use benchmarks, graders, harnesses, or benchmark statistics.
- Output language: Chinese, with key English terms retained and defined once.

## Falsifiable hypotheses

1. The four links are not four independent articles: the arXiv HTML and abstract describe the same v2 paper, while the official docs and Hugging Face dataset are implementation and data companions.
2. ALE directly measures end-to-end artifact completion by a full agent system, not an isolated language model capability.
3. A large gap between partial score and full-pass rate is evidence of weak end-to-end reliability, not evidence that agents perform no useful subtasks.
4. ALE's results do not by themselves establish human-level job readiness or occupation replacement.

## Source blocks

1. arXiv HTML 2606.05405: full paper structure, design, tasks, protocol, results, failures, limitations.
2. arXiv abs 2606.05405v2: canonical identity, version/date, authors, abstract-level claims.
3. Official ALE docs: executable framework, environments, directory lifecycle, harness/grader concepts, reproduction workflow.
4. Hugging Face ALE dataset: current row count, schema, task examples, task metadata, public-data role.
5. Independent context: only where needed to challenge over-interpretation; it must not be conflated with the four requested resources.

## Sourcing strategy

- Prefer the exact four user-supplied primary URLs.
- Use Hugging Face paper metadata/API only as a machine-readable companion.
- Use repository or independent academic sources only for claims not settled by the four links.
- Save one source note per URL with short verbatim excerpts and paraphrased findings.

## Opposition queries

- Is ALE a pure LLM benchmark or a full-system benchmark?
- Does ALE contain a matched human baseline?
- Are Near-Term, Full-Spectrum, and Last-Exam disjoint partitions?
- Do 0%, 2.6%, and below 1% refer to the same statistic?
- Does success prove GUI skill, job readiness, safe process, or occupation replacement?
- Are public task counts stable across paper, docs, and dataset snapshots?

## Risk register

- Living benchmark drift: paper, docs, leaderboard, repository, and dataset can update at different times.
- Shared-authority bias: all four requested sources are publisher-controlled and are not independent replication.
- Metric confusion: Mean Score, Pass Rate, and Best-per-task answer different questions.
- Unit confusion: workflow, task instance, public task, domain, and tier counts are not interchangeable.
- Construct confusion: final-artifact success does not isolate reasoning, GUI, domain knowledge, or harness quality.
- Beginner overload: preserve a clear concept order and defer implementation details until after the mental model.

## Stop criteria

- Every section of the full paper has been inspected, including appendices/tables relevant to design, results, and failure analysis.
- Official docs lifecycle, harness, environment, and grading pages have been inspected.
- Dataset schema and a diverse set of task rows have been inspected.
- All four hypotheses are confirmed, refuted, or marked underdetermined.
- Version/count/statistic discrepancies are explicitly reconciled or marked unresolved.
- An adversarial review identifies at least three claims a beginner should not infer.

