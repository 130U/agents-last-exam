# Source 05 — ALE 论文中的 workflow / instance 术语

- URL: https://arxiv.org/html/2606.05405
- 版本：arXiv v2，2026-06-11
- 访问日期：2026-08-05
- 类型：一手学术论文
- 可信度：高（用于解释 ALE 自身口径）
- 偏差：作者对自有 benchmark 的定义，不是外部审计

## 定义

- `task workflow`：一个端到端专业流程。
- `task instance`：该 workflow 的一个具体可运行案例，即一组具体 input/output；同一 workflow 的 instances 共享 `evaluate()`，但输入和 reference/output 不同。
- 论文说明，未额外限定的单数 `task` 通常指 runnable instance 层级。

## 短引文

> “task instance for one runnable case of a task workflow”

> “The current ALE release contains 960 task workflows and 1,490 task instances in total.”

## 对本次决策的意义

“1,000 个完全不同 workflows”与“一个 workflow 换 1,000 组输入”是两个极端。ALE 的真实结构是多个 workflows 各自拥有一个或多个 runnable instances。新项目可以把 1,000 定义为最终通过 QC 的 instances，同时单独设置 workflow 覆盖、复用与重复上限。

论文没有规定新项目必须沿用 960:1490 的比例；该比例只能描述当时的 ALE 快照。

