# Source 02 — Berkeley RDI 官方 ALE 发布页

- URL: https://rdi.berkeley.edu/blog/agents-last-exam/
- 访问日期：2026-08-05
- 类型：项目机构官方发布
- 可信度：高（用于说明项目自我定义）
- 偏差：项目作者自述，不能作为独立有效性验证

## 可复用证据

短引文："real work, not synthetic tasks"

页面将 ALE 定义为面向真实数字化专业工作的 agent benchmark，强调长期执行、专业知识、可验证产物，并链接论文、数据集、代码与贡献入口。

## 对本次任务拆解的意义

第一题中的“这样的 task”不是普通知识问答或孤立难题，而是完整的专业 workflow。因而 1,000-task 方案必须覆盖环境、输入、工具、产物与验收，而不能只讲题面生成。

