# Source 06 — ALE 官方 FAQ 对 variants 的处理

- URL: https://agents-last-exam.org/faq
- 访问日期：2026-08-05
- 类型：官方贡献者 FAQ
- 可信度：高（用于解释当前运营规则）
- 偏差：面向作者资格和贡献计数，不等同于商业交付计价规则

## 短引文

> “additional variants of one task count as 1/3 of a task”

## 对本次决策的意义

官方承认同一任务的 additional variants 有价值，但没有把低差异变体与全新 task 等价计算。这支持在千题方案中允许受控 variants，同时设置去模板化、实质差异与重复上限规则。

该 FAQ 规则不能直接当作 UniPat 项目的验收或报价规则；最终商业口径仍需由出题人或客户书面确认。

