# Source 04 — ALE 官方 task contribution guide

- URL: https://agents-last-exam.org/submit
- 访问日期：2026-08-05
- 类型：官方任务贡献与实施指南
- 可信度：高（当前 task 提交流程）
- 偏差：living benchmark 页面会继续更新，实际交付需固定版本日期

## 准入标准

页面用三个词概括合格 task：

- Complex：专家完成需要较长时间和实质性专业能力，而非几步操作。
- Representative：来自真实行业 workflow，并使用合适的专业工具。
- Verifiable：输出能够确定性核验，或依据清晰 rubric 评分。

## 一条 task 的五个组件

1. Task Description：agent 要完成什么。
2. Input：提供哪些文件、数据和上下文。
3. Software：需要哪些专业工具。
4. Output：必须交付什么产物。
5. Evaluation：怎样判断成功。

## 对本次任务拆解的意义

这五部分可直接作为第一题样题的 anatomy，也可扩展为千题项目的数据 schema、review checklist 与 acceptance contract。

