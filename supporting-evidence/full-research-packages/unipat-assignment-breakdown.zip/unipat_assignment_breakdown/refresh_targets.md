# Refresh targets

本拆解主要依赖一段已完成的面试转写，结论不会因排行榜变化而改变。后续只需更新下列项目：

- 面试官给出的正式 deadline、书面/演示格式、时长与页数。
- 是否明确要求提交 1 道 demo task、多少道样例或运行多少个模型。
- ALE 论文 / 数据集 / submission guide 的版本与公开 task schema。
- 用户选择的第二题 domain 或 capability；一旦确定，需要单独刷新该方向的 benchmark landscape。
- GS 是否回复 workflow / instance 的口径确认；若回复，应把主假设改为正式 acceptance unit。
- 是否允许 variants 计数、最低实质差异、每个 workflow 的实例上限以及 workflow 覆盖指标。

