# F2 — 第一题为什么不是普通“出题”

## 结论

ALE 的 unit 是完整专业 workflow，不是一段题面。千题交付至少需要把以下对象标准化：

- “1,000 道”究竟指 1,000 个 workflows 还是 1,000 个 task instances
- capability / taxonomy 与配额
- 专家画像、准入、培训和 calibration
- task brief、输入资产与授权
- 专业软件或 sandbox 环境
- 目标产物、reference 与 evaluator
- 人工 review、自动 QA、仲裁与返工
- pilot、agent dry-run、歧义/shortcut/泄漏检查
- batch release、版本化、验收指标和风险管理

## 来源与限制

Berkeley RDI 发布页、论文页与官方贡献指南共同支持“真实专业 workflow + 可验证 outcome”的任务结构，但三者都属于同一项目生态，不构成独立有效性验证。这里仅用它们解释项目自身的 task contract，不外推为对就业替代或通用智能的证明。
